//
//  CountryDL.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/6/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

// --- - -- - -- - - - -Country Model ---- -- - - -- -//

class CountryCodeBO: NSObject {
    var countryName:String!
    var countryCode:String!
    var countryId:NSNumber!
}

// --- - -- - -- - - - -Country Data Layers ---- -- - - -- -//

class CountryDL: PSRestAPIHelper {

// Requesting the Country List from server
    
    func requestforCountryCode(handler:CompletionHandler)
    {
        self.serviceURL = "CountryCodes"
        self.webservice.isShowLoader = true
        
        let dicParam:NSDictionary = ["":""]
        
        self.requestforGET(dicParam as! [NSObject : AnyObject!]) { (obj, success) -> Void in
            
            if success == true
            {
                let arrayOfCountry:NSMutableArray = NSMutableArray()
                
                if let arrayOfParams:NSArray = obj!.valueForKey("Data") as? NSArray
                {
                    for item in arrayOfParams {
                        let dicBlock = item as! NSDictionary
                        let countryObj = CountryCodeBO()
                        countryObj.countryName = NSIUtility.getObjectForKey("Name", dictResponse: dicBlock) as! String
                        countryObj.countryId = NSIUtility.getObjectForKey("ID", dictResponse: dicBlock) as! NSNumber
                        countryObj.countryCode = NSIUtility.getObjectForKey("Code", dictResponse: dicBlock) as! String
                        arrayOfCountry.addObject(countryObj)
                    }
                
                    handler(obj: arrayOfCountry, success: true)
                    return
                }
                
                handler(obj: nil, success: false)
                print("Data is nil")
            }
        }
    }
    
}
