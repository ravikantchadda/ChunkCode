//  ReferenceApp
//
//  Created by ravi kant on 11/6/15.
//  Copyright © 2015 Netsol. All rights reserved.
//

import UIKit
import CMLibrary

//http://172.16.13.129:8000/o/token/
//http://localhost:8080/o/token/
///http://192.168.0.211:8080

//test URL
//let serverAddress = "http://172.16.13.129:8000/"

// Base URL
let serverAddress = "http://192.168.0.211:8080/"
let baseURL =  serverAddress

// Completion Closure
typealias CompletionHandler = (obj:AnyObject?, success:Bool?) -> Void



class NSIRestAPIHelper: NSObject {
    
    // service URL property
    var serviceURL:String = String()
        {didSet{self.serviceURL =  baseURL + serviceURL}}
    
    // service Header Dictionary property
    var headerdict = ["":""]
    
    
    // property to indentify Outh service call or not
    var isCallforOuth = Bool()
    
    // Server communication API property
    let webservice:WebserviceCall = WebserviceCall()
    
    
    
    // MARK: -  Method to Request for Outh Post
    /**
    *************************************
    That is POST method  to call Outh service
    Params: Header body(its a predefined body that will authenticate the device to use the app services)
    *************************************
    **/
    func requestforOuthPOST(headerBody:String, withCompletionHandler handler:CompletionHandler)
    {
        
        webservice.headerBody = headerBody
        webservice.isShowLoader = true
        
        webservice.POST(NSURL(string: serviceURL), parameters: nil, withSuccessHandler: { (response:WebserviceResponse!) -> Void in
            
            if response.webserviceResponse != nil
            {
                handler(obj: response.webserviceResponse, success: true)
            }else{
                handler(obj: response.webserviceResponse, success: false)
            }
            
            }) { (error:NSError!) -> Void in
                
                
                handler(obj: nil, success: false)
                
        }
    }
    
    
    
    
    // MARK: -  Method to Request for POST
    /**
    *************************************
    That is POST method  to call App services(i.e. Signup/Signin/change password etc.)
    Params: params(defined the key:object required in the services)
    headerFieldsDict:(its define the Header body(i.e. Access Token+Token Type get from outh service))
    *************************************
    **/
    func requestforPOST(params:[NSObject:AnyObject!], withCompletionHandler handler:CompletionHandler)
    {
        
        NSIUtility.DBlog(params)
        
        
        webservice.headerFieldsDict = self.headerdict
        webservice.isShowLoader = true
        
        webservice.POST(NSURL(string: serviceURL), parameters: params as [NSObject : AnyObject]!, withSuccessHandler: { (response:WebserviceResponse!) -> Void in
            if response.webserviceResponse != nil
            {
                handler(obj: response.webserviceResponse, success: true)
            }else{
                handler(obj: response.webserviceResponse, success: false)
            }
            
            }) { (error:NSError!) -> Void in
                handler(obj: nil, success: false)
        }
    }
    
    
    // MARK: -  Method to Request for Upload Data in Mulipart
    /**
    *************************************
    That is UploadMultiPart method  to call App services where Images/files are upload
    Params: params(defined the key:object required in the services)
    headerFieldsDict:(its define the Header body(i.e. Access Token+Token Type get from outh service))
    *************************************
    **/
    
    func requestforUploadMultiPart(params:[NSObject:AnyObject!], withCompletionHandler handler:CompletionHandler)
    {
        
        NSIUtility.DBlog(params)
        
        webservice.headerFieldsDict = self.headerdict
        webservice.isShowLoader = true
        webservice.parametersDict = params
        
        
        
        let fileData = NSData(contentsOfFile: NSBundle.mainBundle().pathForResource("imageup.png", ofType: nil)!)

        webservice.uploadFile(fileData, withFileName: "userimage", withFieldName: "profilePic", mimeType: "image/png", onUrl: NSURL(string: serviceURL), withSuccessHandler: { (response: WebserviceResponse!) -> Void in
            
            if response.webserviceResponse != nil
            {
                handler(obj: response.webserviceResponse, success: true)
            }else{
                handler(obj: response.webserviceResponse, success: false)
            }
            
            }) { (error: NSError!) -> Void in
                handler(obj: nil, success: false)
        }
        
        
        ///**********Local Data*****************
        /*
        
        let arraydata  = NSMutableArray()
        
        let dictData = NSMutableDictionary(objects: [fileData!,"profilePic","image.png","image/png"], forKeys: ["data","fileKey","fileName","contentType"])
        
        arraydata.addObject(dictData)
        
        webservice.uploadDataWithImage(arraydata as [AnyObject], keyName: "data", onUrl: NSURL(string: serviceURL), withSuccessHandler: { (response: WebserviceResponse!) -> Void in
            
            print(response.webserviceResponse)
            
            if response.webserviceResponse != nil
            {
                handler(obj: response.webserviceResponse, success: true)
            }else{
                handler(obj: response.webserviceResponse, success: false)
            }

            
            }) { (error: NSError!) -> Void in
                handler(obj: nil, success: false)
        }
*/
        
        
        
    }
    
    
    // MARK: -  Method to Request for PUT
    /**
    *************************************
    That is PUT method  to call App services(i.e. Sign Out.)
    Params: params(defined the key:object required in the services)
    headerFieldsDict:(its define the Header body(i.e. Access Token+Token Type get from outh service))
    *************************************
    **/
    func requestforPUT(headerBody:String, withCompletionHandler handler:CompletionHandler)
    {
        
        NSIUtility.DBlog(serviceURL)
        
        webservice.headerFieldsDict = self.headerdict
        webservice.isShowLoader = true
        webservice.PUT(NSURL(string: serviceURL), parameters: nil, withSuccessHandler: { (response:WebserviceResponse!) -> Void in
            
            if response.webserviceResponse != nil
            {
                handler(obj: response.webserviceResponse, success: true)
            }else{
                handler(obj: response.webserviceResponse, success: false)
            }
            
            }) { (error:NSError!) -> Void in
                handler(obj: nil, success: false)
        }
    }
    
    // MARK: -  Method to Request for GET
    /**
    *************************************
    That is GET method  to call App services
    Params: params(defined the key:object required in the services)
    *************************************
    **/
    func requestforGET(params:[NSObject:AnyObject!], withCompletionHandler handler:CompletionHandler)
    {
        webservice.isShowLoader = true
        webservice.GET(NSURL(string: serviceURL), parameters: params as [NSObject : AnyObject]!, withSuccessHandler: { (response:WebserviceResponse!) -> Void in
            if response.webserviceResponse != nil
            {
                handler(obj: response.webserviceResponse, success: true)
            }else{
                handler(obj: response.webserviceResponse, success: false)
            }
            
            
            }) { (error:NSError!) -> Void in
                handler(obj: nil, success: false)
        }
    }
    
    
    
    
    // MARK: -  Method to Request for Without Service URL
    /**
    *************************************
    That is Get method  i.e. used with Service URL
    Params: params(defined the key:object required in the services)
    ----- Services for different API's -----
    *************************************
    **/
    func requestforGETWithoutServiceURL(params:[NSObject:AnyObject!], withURL urlString:String, withCompletionHandler handler:CompletionHandler)
    {
        webservice.headerFieldsDict = self.headerdict
        webservice.isShowLoader = true
        webservice.GET(NSURL(string: urlString), parameters: params as [NSObject : AnyObject]!, withSuccessHandler: { (response:WebserviceResponse!) -> Void in
            
            let resposeDic:NSDictionary = response.webserviceResponse as! NSDictionary
            
            if response.webserviceResponse != nil
            {
                handler(obj: resposeDic, success: true)
            }
            else{
                handler(obj: resposeDic, success: false)
            }
            
            }) { (error:NSError!) -> Void in
                
        }
    }
    
    
    
    
}
