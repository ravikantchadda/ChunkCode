//
//  UserCollCell.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/26/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class UserCollCell: UICollectionViewCell {

    @IBOutlet var imgViewPsgr: UIImageView!
    @IBOutlet var lblPsgrName: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
