//
//  AppDelegate.swift
//  ReferenceApp
//
//  Created by Aditya Aggarwal on 8/26/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit
import CoreData
import Fabric
import Crashlytics
import MFSideMenu
import MBProgressHUD


enum LoginType:Int {
    case LoginSourcetypeNormal = 0
    case LoginSourcetypeFacebook = 1
    case LoginSourcetypeGooglePlus = 2
    case LoginSourcetypeLinkedIn = 3
    case LoginSourcetypeTwitter = 4
}

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    var hud = MBProgressHUD()
    
    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        // Override point for customization after application launch..
        let infoModel:UserBO! = UserInfoManager.getUserInfoModel()
        if infoModel == nil {
            showLoginStoryboard()
        } else {
            showMainStoryboard()
        }
        
        //IQKeyboardManager Properties
        IQKeyboardManager.sharedManager().enableAutoToolbar = true
        IQKeyboardManager.sharedManager().shouldResignOnTouchOutside = true
        
        
        Fabric.with([Crashlytics.self()])
        
        // Setup core Data Manager
        self.dataManager.setupDataManager()
        
        self.addDummydata()
        
        self.showProgressHud()
        
        GPPSignIn.sharedInstance().clientID = Constants.APP_GOOGLE_CLIENTID
        return FBSDKApplicationDelegate.sharedInstance().application(application, didFinishLaunchingWithOptions: launchOptions)
    }
    
    
        func applicationWillResignActive(application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }
    
    func applicationDidEnterBackground(application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }
    
    func applicationWillEnterForeground(application: UIApplication) {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    }
    
    func applicationDidBecomeActive(application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        
        //Call Method to verify passcode
        //        verifyPasscode()
    }
    
    func applicationWillTerminate(application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
        // Saves changes in the application's managed object context before the application terminates.
        self.dataManager.saveContext()
    }
    
    func application(application: UIApplication, openURL url: NSURL, sourceApplication: String?, annotation: AnyObject) -> Bool
    {
        if(FBSDKApplicationDelegate.sharedInstance().application(application, openURL: url, sourceApplication: sourceApplication, annotation: annotation))
        {
            return FBSDKApplicationDelegate.sharedInstance().application(application, openURL: url, sourceApplication: sourceApplication, annotation: annotation)
        }
        else {
            return GPPURLHandler.handleURL(url, sourceApplication: sourceApplication, annotation: annotation)
        }
    }
    //MARK: - Storyboard Setup
    
    func showLoginStoryboard() {
        let loginFlowStoryBoard = UIStoryboard(name: "LoginModule", bundle: nil)
        let navigationVc:UINavigationController = loginFlowStoryBoard.instantiateViewControllerWithIdentifier("LoginModuleNavigationController") as! UINavigationController
        let container: MFSideMenuContainerViewController = self.window!.rootViewController as! MFSideMenuContainerViewController
        container.centerViewController = navigationVc
        
    }
    
    func showMainStoryboard() {
        let mainStoryBoard = UIStoryboard(name: "Main", bundle: nil)
        let navigationVc:UINavigationController = mainStoryBoard.instantiateViewControllerWithIdentifier("MainModuleNavigationController") as! UINavigationController
        let container: MFSideMenuContainerViewController = self.window!.rootViewController as! MFSideMenuContainerViewController
        let leftSideMenuViewController: UIViewController =    mainStoryBoard.instantiateViewControllerWithIdentifier("leftSideMenuViewController")
       // var rightSideMenuViewController: UIViewController =    mainStoryBoard.instantiateViewControllerWithIdentifier("rightSideMenuViewController")
        container.leftMenuViewController = leftSideMenuViewController
        container.centerViewController = navigationVc
    }
    
    
    
    // MARK: Initialize Core Data Manager
    lazy var dataManager: CoreDataManager = {
        let dataManager = CoreDataManager.sharedManager
        return dataManager
        }()
    
    
    
    
    // MARK: Core Data Operations
    func addDummydata() {
        let arrList:NSMutableArray = NSMutableArray()
        let dict:NSDictionary = NSDictionary(objects: ["Doe",1001,"John"], forKeys: ["last_name","id","first_name"])
        arrList.addObject(dict)
        App_ProfileAPI.saveProfile(arrList)
        
        let profiles = App_ProfileAPI.fetchProfiles(1001,fromBackgroundContext: true)
        App_UserAPI.saveUser(NSSet(array: profiles as! [AnyObject]))
    }
    
    //MARK: Show MBProgressHUD
    func showProgressHud(){
        
      
        hud.mode = MBProgressHUDMode.AnnularDeterminate
        hud.show(true)
      
    
    }
    //MARK: Hide MBProgressHUD
    func hideProgressHud(){
        
       hud.hide(true, afterDelay: 0.0)
        
    }
    
    
    
}

