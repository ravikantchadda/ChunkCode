//
//  MessageViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 18/09/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit

class MessageViewController: UIViewController {
    @IBOutlet weak var tblChatList: UITableView!
    var arrChatListData: NSMutableArray! = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationController?.navigationBar.translucent = false
        self.navigationItem.title = ""
        self.navigationItem.titleView = Utility.navBarTitleLabel("Messages")
        tblChatList.tableFooterView = UIView(frame: CGRectZero)
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        fnGetChatList()
    }
    func fnGetChatList(){
        
        if let userId = NSIConstants.userDefaults.valueForKey("userId") {
            let dict:NSDictionary = [
                "userId": userId,
            ]
            print("\(dict)")
            self.fnGetChatListWebServiceWithPostDic(dict, showLoader: true)
        }

    }
    //MARK: - Webservice call
    //Get Comments API
    func fnGetChatListWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
            ObjWebserviceCall.cachePolicy = WebserviceCallCachePolicyRequestFromCacheFirstAndThenFromUrlAndUpdateInCache
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceGetChatList)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("GetList--- \(response.webserviceResponse)")
                
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    
                    if self.arrChatListData != nil {
                        self.arrChatListData.removeAllObjects()
                    }
                    
                    let arrData = response.webserviceResponse.valueForKey("messages") as! NSArray
                    let arrModelData = ChatList().fillDataInModel(arrData)
                    arrModelData.enumerateObjectsUsingBlock({ object, index, stop in
                        self.arrChatListData.addObject(arrModelData.objectAtIndex(index))
                    })
                    self.fnNoMessageFoundAlert()
                    
                }else{
                    
                    self.fnNoMessageFoundAlert()
                    
                    if response.webserviceResponse.valueForKey("status") as! String != "Result not found" {
                        Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                    }
                }
                self.tblChatList.reloadData()
                self.tblChatList.infiniteScrollingView?.stopAnimating()
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
    
    func fnNoMessageFoundAlert() {
        if self.arrChatListData.count == 0 {
            let lblMsg = UILabel(frame: CGRectMake(0, 0, self.tblChatList.frame.size.width, 50))
            lblMsg.center = self.tblChatList.center
            lblMsg.text = "No messages found."
            lblMsg.numberOfLines = 0
            lblMsg.textAlignment = NSTextAlignment.Center
            lblMsg.font = UIFont(name: "Lato-Regular", size: 16)
            lblMsg.textColor = UIColor.blackColor()
            self.tblChatList.backgroundView = lblMsg
            self.tblChatList.scrollEnabled = false
        }else{
            self.tblChatList.backgroundView = nil
            self.tblChatList.scrollEnabled = true
        }
    }
    //MARK: - TableView DataSource/Delegate
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (arrChatListData != nil){
            return arrChatListData.count
        }
        return 0
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if(tableView.respondsToSelector(Selector("setSeparatorInset:"))){
            tableView.separatorInset = UIEdgeInsetsZero
        }
        if(tableView.respondsToSelector(Selector("setLayoutMargins:"))){
            
            tableView.layoutMargins = UIEdgeInsetsZero
            
        }
        if(cell.respondsToSelector(Selector("setLayoutMargins:"))){
            
            cell.layoutMargins = UIEdgeInsetsZero
            
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(
            "cellChatList", forIndexPath: indexPath)
        let objChatList:ChatList = self.arrChatListData.objectAtIndex(indexPath.row) as! ChatList
        
        //UIImage Profile Image
        if let imgVwProfile:AsyncImageView = cell.viewWithTag(1001) as? AsyncImageView {
            imgVwProfile.image = UIImage(named: "placeholder")
            if let variableName: String = objChatList.personProfilePicUrl{
                imgVwProfile.crossfadeDuration = 0.0
                imgVwProfile.imageURL = NSURL(string: variableName)
            }
        }
        if let lblName = cell.viewWithTag(1002) as? UILabel {
            lblName.text = objChatList.personFirstName + " " + objChatList.personLastName
        }
        if let lblTime = cell.viewWithTag(1003) as? UILabel {
            let strSec: NSInteger = Int(objChatList.minutesAgo)! * 60
            let date = NSDate(timeInterval: NSTimeInterval(-strSec), sinceDate: NSDate())
            lblTime.text = Utility.relativeDateStringForDate(date)
        }
        
        if let lblMsg = cell.viewWithTag(1004) as? UILabel {
            lblMsg.text = objChatList.messageText
        }
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let objChatList:ChatList = self.arrChatListData.objectAtIndex(indexPath.row) as! ChatList
        let objChatVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("ChatViewController") as! ChatViewController
            objChatVC.receiverId = objChatList.personId
            self.navigationController?.pushViewController(objChatVC, animated: true)
    }

    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
