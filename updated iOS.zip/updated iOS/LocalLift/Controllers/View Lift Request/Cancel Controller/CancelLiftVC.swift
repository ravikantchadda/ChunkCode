//
//  CancelLiftVC.swift
//  LocalLift
//
//  Created by prabhjot singh on 12/22/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit
import UIAlertView_Blocks
import UIActionSheet_Blocks

class CancelLiftVC: BaseViewController,UITableViewDelegate,UITableViewDataSource,ViewLiftTimeProtocol,GroupsOfPeopleProtocol {
    
    
    enum LoactionType:Int {case FromLocation = 0, ToLocation = 1}
    
    enum CancelType:Int {case CancelTypeRequest = 0, CancelTypeOffer = 1}
    
    @IBOutlet var tblView: UITableView!
    
    var viewSetLoc:ViewOfSetLocation!
    var cellOfMap: MapViewCell!
    var cellOfMessage:AddMessageCell!
    var requestBO:RequestBO!
    var cellShowTimeView: ShowTimeViewLiftCell!
    var cellGroupOfPassenger: GroupsOfPeopleCell!
    var cellOfDriver:DriverCell!
    var liftBO:LiftBO!
    var isRequestedByUser:Bool!
    let cancelPop = OptionalPopoverVC()
    let tablePop = SelectDatePopoverVC()
    
    var cancelType:CancelType!
    
    @IBOutlet var btnAcceptLift: UIButton!
    
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBar(.BlueNavigationType)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialInitilization()
        self.fetchRequestDetails()
    }
    
//MARK:- Button Methods
    
    
    @IBAction func actionPressed(sender: UIButton) {
        
        if cancelType == .CancelTypeRequest{
            if requestBO.isRecurring == true{
                
                UIActionSheet.showInView(self.view, withTitle: nil, cancelButtonTitle: "Back", destructiveButtonTitle: nil, otherButtonTitles: ["Cancel this specific date only","Select dates to cancel","Cancel all future date"], tapBlock: { (actionSheet, buttonIndex) -> Void in
                    if buttonIndex != actionSheet.cancelButtonIndex{
                        switch buttonIndex {
                        case 0:
                            self.cancelPop.didSelectButton({ (text, buttonClickedString) -> Void in
                                if buttonClickedString == "Send"{
                                    self.toCancelRequest(text, whichCancelString: "SpecificDate")
                                }
                            })
                            self.presentViewController(self.cancelPop, animated: true, completion: { () -> Void in
                                self.cancelPop.txtViewOptional.text = "Optional"
                            })
                            
                        case 1:
                            self.tablePop.didSelectButton({ (array, buttonClickedString) -> Void in
                                if buttonClickedString == "Confirm"{
//                                    self.toCancelRequest(text, whichCancelString: "SpecificDate")
                                }
                            })
                            self.presentViewController(self.tablePop, animated: true, completion: { () -> Void in
                            })
                        case 2:
                            self.cancelPop.didSelectButton({ (text, buttonClickedString) -> Void in
                                if buttonClickedString == "Send"{
                                    self.toCancelRequest(text, whichCancelString: "FutureDate")
                                }
                            })
                            self.presentViewController(self.cancelPop, animated: true, completion: { () -> Void in
                                self.cancelPop.txtViewOptional.text = "Optional"
                            })
                        default:
                            print(buttonIndex)
                            
                        }
                    }
                    
                    
                })
                
                }else{
//
                UIAlertView.showWithTitle("Are you sure you want to cancel \(liftBO.liftRequesterName)", message: nil, cancelButtonTitle: "No", otherButtonTitles: ["Yes"], tapBlock: { (alertView, buttonIndex) -> Void in
                    if alertView.cancelButtonIndex != buttonIndex{

                        self.cancelPop.didSelectButton({ (text, buttonClickedString) -> Void in
                            if buttonClickedString == "Send"{
                                self.toCancelRequest(text, whichCancelString: "SpecificDate")
                            }
                        })
                        self.presentViewController(self.cancelPop, animated: true, completion: { () -> Void in
                            self.cancelPop.txtViewOptional.text = "Optional"
                        })
                    }
                })
  
            }
            
            
        }else{
            
            self.toCancelOffer()
        }
        
    }
    
// Cancel the Requested Lift
    
    func toCancelRequest(message:String, whichCancelString:String!) {
        
        let cancelBO = CancelBO()
        
        if isRequestedByUser == true{
            cancelBO.liftRequesterId = UserBO.sharedInstanceOfUser.userID
            cancelBO.liftProviderId = 0
        }else{
            cancelBO.liftRequesterId = 0
            cancelBO.liftProviderId = requestBO.requesterId
        }
        
        cancelBO.message = message
        if requestBO.isRecurring == true{
            cancelBO.isCancelSeries = false
            cancelBO.requestIds = [requestBO.requestId]
        }else{
            cancelBO.isCancelSeries = false
            cancelBO.requestIds = [requestBO.requestId]
        }
        
        cancelBO.isAcceptRequest = false
        
        if whichCancelString == "FutureDate"{
            cancelBO.liftRequesterId = 0
            cancelBO.liftProviderId = 0
            cancelBO.isCancelSeries = true
        }
        
        
        
        let liftDL = LiftDL()
        liftDL.requestForCancelLiftRequest(cancelBO) { (obj, success) -> Void in
            if success == true{
                    self.navigationController?.popViewControllerAnimated(true)
            }else{
                NSIUtility.show(Constants.kSomethingWrong)
            }
        }
        
    }
    
// Cancel the Offered Lift
    
    func toCancelOffer() {
        
        //        let predicateFrom:NSPredicate = NSPredicate(format: "isLiftSelected == %@", argumentArray:[true])
        var arrayFiltered = NSArray()
        
        if requestBO.isRecurring == true{
            //            let predicateFrom:NSPredicate = NSPredicate(format: "self.isLiftSelected == 0")
            let predicateFrom:NSPredicate = NSPredicate(format: "isLiftSelectedNumber == 1")
            arrayFiltered = (self.requestBO.arrayRecurringLiftRequests?.filteredArrayUsingPredicate(predicateFrom))!
            
            if arrayFiltered.count == 0{
                NSIUtility.show("Please select atleast one Date")
                return
            }
        }
    }
    
    
//MARK:- Other Methods
    
    func initialInitilization(){
        
        cancelPop.modalPresentationStyle =  UIModalPresentationStyle.OverCurrentContext
        let modalStyle: UIModalTransitionStyle = UIModalTransitionStyle.CrossDissolve
        cancelPop.modalTransitionStyle = modalStyle
        
        tablePop.modalPresentationStyle =  UIModalPresentationStyle.OverCurrentContext
        tablePop.modalTransitionStyle = modalStyle
        
        
        
        viewSetLoc = UIView.viewFromNibName("ViewOfSetLocation") as? ViewOfSetLocation
        viewSetLoc.btnDestinationLoc.userInteractionEnabled = false
        viewSetLoc.btnPickupLoc.userInteractionEnabled = false

        
        tblView.registerNib(UINib.init(nibName: "MapViewCell", bundle: nil), forCellReuseIdentifier: "mapViewCell")
        tblView.registerNib(UINib.init(nibName: "AddMessageCell", bundle: nil), forCellReuseIdentifier: "addMessageCell")
        tblView.registerNib(UINib.init(nibName: "DriverCell", bundle: nil), forCellReuseIdentifier: "driverCell")
        tblView.registerNib(UINib.init(nibName: "ShowTimeViewLiftCell", bundle: nil), forCellReuseIdentifier: "showTimeViewLiftCell")
        tblView.registerNib(UINib.init(nibName: "GroupsOfPeopleCell", bundle: nil), forCellReuseIdentifier: "groupsOfPeopleCell")
        
        self.cellOfMap  = tblView.dequeueReusableCellWithIdentifier("mapViewCell") as! MapViewCell
        self.cellOfMap.callBack = self
        self.cellOfMap.titleView.hidden = true
        self.cellOfMap.mapCenterPinImage.hidden = true
        
        
        self.cellOfMessage  = tblView.dequeueReusableCellWithIdentifier("addMessageCell") as! AddMessageCell
        self.cellOfMessage.constraintVerticalTop.constant = 0
        

        
        self.cellShowTimeView  = tblView.dequeueReusableCellWithIdentifier("showTimeViewLiftCell") as! ShowTimeViewLiftCell
        self.cellShowTimeView.btnSelectedLift.hidden = true
        
        self.cellGroupOfPassenger  = tblView.dequeueReusableCellWithIdentifier("groupsOfPeopleCell") as! GroupsOfPeopleCell
        self.cellGroupOfPassenger.delegate = self
        self.cellGroupOfPassenger.collectionType = .CollectionPassenger
        
        self.cellOfDriver  = tblView.dequeueReusableCellWithIdentifier("driverCell") as! DriverCell
        
    }
    
    func fetchRequestDetails(){
        let requestDL = RequestDL()
        requestDL.requestForGetRequestLift(liftBO.requestId,lastIndex:1, hasMaxCount:false) { (obj, success) -> Void in
            if success == true{
                if let requestBO = obj as? RequestBO{
                    self.requestBO = requestBO
                    self.tblView.delegate = self
                    self.tblView.dataSource = self
                    self.setTheData()
                }
            }
        }
    }
    
    func fetchPassengers(){
        let passengertDL = PassengerDL()
        passengertDL.requestforPassengers(self.liftBO.requestId) { (obj, success) -> Void in
            if success == true{
                if let arrayOfPassengers = obj as? NSMutableArray{
                    self.cellGroupOfPassenger.arrayOfPassenger = arrayOfPassengers
                    self.cellGroupOfPassenger.collOfPsgr.reloadData()
                }
            }
        }
    }
    
    
    func setTheData(){
        
        self.tablePop.requestID = requestBO.requestId
        
        if self.requestBO.requesterId == UserBO.sharedInstanceOfUser.userID{
            self.isRequestedByUser = true
        }else{
            self.isRequestedByUser = false
        }
        
        self.cellOfMap.addMarkerToPickupLocation(self.requestBO.newStartLocation, title: "")
        self.cellOfMap.addMarkerToDestinationLocation(self.requestBO.newEndLocation, title: "")
        self.cellOfMap.addRouteToMap(self.requestBO.newStartLocation.locationCords, withDestinationLoc: self.requestBO.newEndLocation.locationCords)
        self.cellOfMap.viewShowDistance.hidden = false
        
        
        self.cellOfMessage.txtMessage.editable = false
        self.cellOfMessage.txtMessage.text = self.requestBO.message
        
        self.viewSetLoc.btnPickupLoc.setTitle(self.requestBO.newStartLocation.streetAddress, forState: .Normal)
        self.viewSetLoc.btnDestinationLoc.setTitle(self.requestBO.newEndLocation.streetAddress, forState: .Normal)
        
        if self.requestBO.arratLiftPassengers != nil{
            self.cellGroupOfPassenger.arrayOfPassenger = self.requestBO.arratLiftPassengers!
        }else{
            self.fetchPassengers()
        }
        
//        if self.requestBO.arrayRecurringLiftRequests != nil{
//            if self.requestBO.arrayRecurringLiftRequests!.count  == 0{
//                
//                let recurringLiftRequestsBO = RecurringLiftRequestsBO()
//                recurringLiftRequestsBO.requestReccuringID = requestBO.requestId
//                recurringLiftRequestsBO.liftDate = requestBO.requestDatetimeDATE
//                recurringLiftRequestsBO.dateString =  requestBO.requestDatetimeDATE.toString(format: .Custom(Constants.DateFormatwithAMPM))
//                recurringLiftRequestsBO.liftTime = requestBO.requestDatetimeDATE.toString(format: .Custom(Constants.TimeFormat))
//                recurringLiftRequestsBO.isLiftSelected = false
//                self.requestBO.arrayRecurringLiftRequests!.addObject(recurringLiftRequestsBO)
//                
//            }
//            self.viewForTime.arrayViewLiftTime = self.requestBO.arrayRecurringLiftRequests!
//            
//        }
        
        self.cellGroupOfPassenger.constraintTopView.constant = 0
        self.cellGroupOfPassenger.collOfPsgr.updateConstraintsIfNeeded()
        
        self.cellShowTimeView.lblShowDate.text! = requestBO.requestDatetimeDATE.toString(format: .Custom(Constants.DateFormatwithAMPM))
        self.cellShowTimeView.lblShowTime.text! = requestBO.requestDatetimeDATE.toString(format: .Custom(Constants.TimeFormat))
        
        
        
        self.title = self.liftBO.liftRequesterName
        
        self.tblView.reloadData()
        //        self.cellGroupOfPassenger.collOfPsgr.reloadData()
        
    }
    
    func reloadTimeTable() {
        self.tblView.reloadData()
    }
    
    
//MARK:- CallBack Delgates
    //Collection Delegates
    
    func didSelectTheCell() {
        
    }
    
// MARK:- Tableview Delgates
    
    // View of Footer nad Header View
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?{
        return viewSetLoc
    }
    
    // Height of Footer nad Header View
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat{
        return viewSetLoc.height
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) ->Int
    {return 1}
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) ->Int
    {return 4}
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat
    {
        switch indexPath.row {
        case 0:
            return 300
        case 1:
            return 105
        case 2:
            return 105
//        case 3:
//            return 0
        case 3:
            return 105
        default:
            return 75
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) ->UITableViewCell
    {
        cellOfMap.selectionStyle = .None
        cellOfDriver.selectionStyle = .None
        cellOfMessage.selectionStyle = .None
        cellGroupOfPassenger.selectionStyle = .None
        cellShowTimeView.selectionStyle = .None
        
        switch indexPath.row{
        case 0:
            return cellOfMap
        case 1:
            return self.cellGroupOfPassenger
        case 2:
            return self.cellShowTimeView
//        case 3:
//            return self.cellOfDriver
        case 3:
            return cellOfMessage
            
        default:
            return UITableViewCell()
        }
        
    }
    
    
}