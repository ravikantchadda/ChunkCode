//
//  SocialNetworking.swift
//  Rabbit
//
//  Created by ravi kant on 10/9/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit
import Foundation
import FBSDKCoreKit
import FBSDKLoginKit


//***** Clouser CompletionHandler
typealias SocialNetworkingCompletionHandler = (data :AnyObject?, success:Bool?) -> Void
public enum SocialNetworkingSourceType{
    
    case Facebook
    case TwitterSocial
    case Instagram
}

class SocialNetworking: NSObject {
    
    var socialcompletionHandler: SocialNetworkingCompletionHandler!
    var socialType: SocialNetworkingSourceType!
    var viewController: UIViewController!
    
    //****** Create Shared Instance
    static var sharedInstance = SocialNetworking()
    
    override init() {
        print("Create SocialNetworking Shared Instance");
    }

    // MARK: ---------------------------------------------------------------------------------
    // MARK: - socialNetworkHandler
    func socialNetworkHandler(handler:SocialNetworkingCompletionHandler) {
        print(socialType)
        self.socialcompletionHandler = handler
        
        if socialType == .Facebook {
            self.connectToFacebook(viewController)
        }
        
        if socialType == .TwitterSocial {}
        if socialType == .Instagram {}
    }

    /*
    ***********************************************************************************
    *************************** FACEBOOK SETUP ****************************************
    */
    
    // MARK: ---------------------------------------------------------------------------------
    // MARK: - connectToFacebook
    
    
    func connectToFacebook(fromViewController:UIViewController?){
        
        
        NSIUtility.addObserverToNSNotificationCenterForNameKey(self, selector:"accessTokenChanged", name: "FBSDKAccessTokenDidChangeNotification", object: nil)
        
        NSIUtility.addObserverToNSNotificationCenterForNameKey(self, selector:"currentProfileChanged", name: "FBSDKProfileDidChangeNotification", object: nil)
        
        let manager:FBSDKLoginManager = FBSDKLoginManager()
        
        
//        if (FBSDKAccessToken.currentAccessToken() == nil) {
        
            let facebookReadPermissions = ["public_profile", "email", "user_about_me", "user_photos"]
            //Some other options: "user_about_me", "user_birthday", "user_hometown", "user_likes", "user_interests", "user_photos", "friends_photos", "friends_hometown", "friends_location", "friends_education_history"

        
        
            manager.loginBehavior = FBSDKLoginBehavior.Web
        
            manager.logInWithReadPermissions(facebookReadPermissions, fromViewController: fromViewController, handler: { (result:FBSDKLoginManagerLoginResult!, error:NSError! ) -> Void in
                if ((error) != nil)
                {
                    // Process error
                    print("Error: \(error)")
                }
                else
                {
                    // Process result
                    print("Result: \(result.description)")
                    
//                    if result.isCancelled == false{
                    
                        let fbRequest = FBSDKGraphRequest(graphPath:"me?fields=id,name,email,first_name,last_name", parameters: nil);
                        fbRequest.startWithCompletionHandler { (connection : FBSDKGraphRequestConnection!, result1 : AnyObject!, error : NSError!) -> Void in
                        
                            if error == nil {
                                print("User Info : \(result1)")
                                self.socialcompletionHandler(data: result1, success: true)
                                
                            } else {
                                print("Error Getting Info \(error)");
                                
                                self.socialcompletionHandler(data:nil, success: false)
                                
                            }
                        }
                    }
//                }
            })
        }
//        else{
//
//            print("currentAccessToken: \( FBSDKAccessToken.currentAccessToken().tokenString)")
//            
//            let graphRequest : FBSDKGraphRequest = FBSDKGraphRequest(graphPath:  "me?fields=id,name,email,first_name,last_name", parameters: nil)
//            graphRequest.startWithCompletionHandler({ (connection, result, error) -> Void in
//                
//                if ((error) != nil)
//                {
//                    // Process error
//                    print("Error: \(error)")
//                    self.socialcompletionHandler(data:nil, success: false)
//                    
//                }
//                else
//                {
//                    // Process result
//                    print("Result: \(result)")
//                    self.socialcompletionHandler(data: result, success: true)
//                    
//                }
//            })
//        }
//    }
    
    // MARK: ---------------------------------------------------------------------------------
    // MARK: - Facebook Notifications
    func accessTokenChanged(notification:NSNotification){
    }
    
    func currentProfileChanged(notification:NSNotification){
    }

    // MARK: ---------------------------------------------------------------------------------
    // MARK: - Download Facebook Photos/Album
    func downloadFacebookPhotosAlbum(){
        
        print("currentAccessToken: \( FBSDKAccessToken.currentAccessToken().tokenString)")
        
        let graphRequest : FBSDKGraphRequest = FBSDKGraphRequest(graphPath:  "me?fields=photos", parameters: nil)
        graphRequest.startWithCompletionHandler({ (connection, result, error) -> Void in
            
            if ((error) != nil)
            {
                // Process error
                print("Error: \(error)")
                self.socialcompletionHandler(data: nil, success: false)
                
            }
            else
            {
                // Process result
                print("Result: \(result)")
                self.socialcompletionHandler(data: result, success: true)
  
            }
        })
 
    }
  
    
    
    
    
}
