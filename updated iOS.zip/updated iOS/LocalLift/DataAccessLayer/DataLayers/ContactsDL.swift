//
//  ContactsBO.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/30/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class ContactsBO: NSObject {

    var emailAddress:String!
    var firstName:String!
    var imagePath:String!
    var lastName:String!
    var liftRequestId:NSNumber!
    var mobileNumber:String!
    var photo:NSData!
    var userID:NSNumber!
    var isSelected:Bool!
    
    
}

class ContactsDL: PSRestAPIHelper {
    
    func requestforContacts(arrayOfEmail:NSArray,arrayOfNumbers:NSArray, handler:CompletionHandler){
        self.serviceURL = "AppUsers?si=1&nor=1000"
        self.setContentTypeHeaders()
//        self.webservice.isShowLoader = true

        
//         let dicParam:NSDictionary = ["EmailAddress":["kate-bell@mac.com"],"MobileNumber": ["+61412145235","+55556485834","+55556484583"]]
        
        let dicParam:NSDictionary = ["EmailAddress":arrayOfEmail,"MobileNumber": arrayOfNumbers]
        
        
        self.requestforPOST(dicParam as! [NSObject : AnyObject!]) { (obj, success) -> Void in
            
            if success == true
            {
                if let dicResponse:NSDictionary = obj as? NSDictionary{
                    let arrayOfContacts = NSMutableArray()
                    
                    if let arrayOfPersons:NSArray = NSIUtility.getObjectForKey("Data", dictResponse: dicResponse) as? NSArray {
                        
                        for dicOfPerson in arrayOfPersons{
                            let contactBO = ContactsBO()
                            contactBO.emailAddress = NSIUtility.getObjectForKey("EmailAddress", dictResponse:dicOfPerson as! NSDictionary) as! String
                            contactBO.firstName = NSIUtility.getObjectForKey("FirstName", dictResponse:dicOfPerson as! NSDictionary) as! String
                            contactBO.imagePath = NSIUtility.getObjectForKey("ImagePath", dictResponse:dicOfPerson as! NSDictionary) as! String
                            contactBO.lastName = NSIUtility.getObjectForKey("LastName", dictResponse:dicOfPerson as! NSDictionary) as! String
                            contactBO.liftRequestId = NSIUtility.getObjectForKey("LiftRequestId", dictResponse:dicOfPerson as! NSDictionary) as! NSNumber
                            contactBO.photo =  NSData()
                            contactBO.userID = NSIUtility.getObjectForKey("UserID", dictResponse:dicOfPerson as! NSDictionary) as! NSNumber
                            contactBO.isSelected = false
                            arrayOfContacts.addObject(contactBO)
                        }
                    }
                    handler(obj: arrayOfContacts, success: true)
                    return
                }
            }
            else{
                handler(obj: nil, success: false)
                
            }
        }
    }
}

