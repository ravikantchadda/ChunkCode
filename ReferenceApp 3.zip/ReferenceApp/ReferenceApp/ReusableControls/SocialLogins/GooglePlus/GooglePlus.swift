//
//  GooglePlus.swift
//  ReferenceApp
//
//  Created by ravi kant on 11/26/15.
//  Copyright © 2015 Netsol. All rights reserved.
//

import Foundation
import FBSDKCoreKit
import FBSDKLoginKit
import IOSLinkedInAPI
import TwitterKit


class GooglePlus: NSObject, GPPSignInDelegate
{
    
    var responseBlock:CompleteSocialLoginBlock?
    var signInGP:GPPSignIn?
    
    //MARK: - Log In With Google Plus[[GPPSignIn sharedInstance] trySilentAuthentication]
    func signInWithGoogle(block:CompleteSocialLoginBlock)
    {
        
       self.logout()
        responseBlock = block
        signInGP = GPPSignIn.sharedInstance()
        signInGP?.shouldFetchGooglePlusUser = true
        signInGP?.shouldFetchGoogleUserID = true
        signInGP?.shouldFetchGoogleUserEmail = true
        signInGP?.scopes = [kGTLAuthScopePlusLogin]
        signInGP?.delegate = self;
        signInGP!.clientID = Constants.APP_GOOGLE_CLIENTID
        signInGP?.authenticate()
    }
    
    
    //MARK: - Method to Get UserProfile
    func requestProfile(responseBlock:UserProfileCompletionHandler){
        
        
//        let plusService = GTLServicePlus()
//        plusService.retryEnabled = true
//        plusService.authorizer = signInGP?.authentication
//        
//        if let plusQuery = GTLQueryPlus.queryForPeopleListWithUserId("me",
//            collection: kGTLPlusCollectionVisible) as? GTLQueryPlus {
//                // execute the query
//                
//                
//                plusService.executeQuery(plusQuery) { (ticket: GTLServiceTicket!,
//                    peopleFeed: GTLPlusPeopleFeed!,
//                    error: NSError!) -> Void in
//                    // ... your callback ...
//                }
//        }
    }

    
    //MARK: -  Google Plus Delegate Methods
    func didDisconnectWithError(error:NSError!) {
        
        responseBlock!(false,LoginType.LoginSourcetypeGooglePlus,"")
    }
    
    func finishedWithAuth(auth: GTMOAuth2Authentication!, error:NSError!)
    {
        if error != nil {
            print(error.description)
            
            // handle Error
            responseBlock!(false,LoginType.LoginSourcetypeGooglePlus,auth.valueForKey("accessToken") as! String)
        }
        else {
            print("Auth = %@",auth)
            print(signInGP?.userEmail)
             print(signInGP?.userID)
            print(signInGP?.idToken)
          //  print(signInGP?.googlePlusUser)
            
            
         //   print(signInGP?.googlePlusUser.dictionaryWithValuesForKeys(["emails","url","tagline","displayName"]))
            
            let dict = signInGP?.googlePlusUser.dictionaryWithValuesForKeys(["emails","url","tagline","displayName","occupation","skills","image"])
            print(dict! as NSDictionary)
           
            
            let objDict = dict! as NSDictionary
            
            
            let personalImage:  GTLPlusPersonImage = objDict.valueForKey("image") as! GTLPlusPersonImage
            
          
            NSIUtility.setValueToUserDefaultsForKey("userimageurl", value:   personalImage.url)
             NSIUtility.setValueToUserDefaultsForKey("username", value: objDict.valueForKey("displayName"))

            
            responseBlock!(true,LoginType.LoginSourcetypeGooglePlus,auth.valueForKey("accessToken") as! String)
        }
    }
    
    
    
    
    
    func logout(){
        
         signInGP = GPPSignIn.sharedInstance()
        signInGP?.signOut()
        
    }


    
}