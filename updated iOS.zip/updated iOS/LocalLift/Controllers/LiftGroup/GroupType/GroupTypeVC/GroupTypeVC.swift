//
//  GroupTypeVC.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/22/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class GroupTypeVC: BaseViewController,UITableViewDataSource,UITableViewDelegate,UpdateCategoryListProtocol {
    
    @IBOutlet weak var tableOGroupType: UITableView!
    var arrayOfGroupType = NSMutableArray()
   @IBOutlet weak var noGroupTypeView:NoGroupType!
    var lastSelectedGroup:NSIndexPath?
    var liftGroupVC:CreateLiftGroupVC?
    
    // MARK:- viewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setNavigationBar(NavigationType.BlueNavigationType)
        self.setNavigationLeftBarButton()
        self.initialInitialization()
    }
    
    //MARK: - initialInitialization mthod to load view properly
    func initialInitialization()  {
        
        liftGroupVC = self.fetchPreviousControllerFromNavigationStack(1) as? CreateLiftGroupVC
        tableOGroupType.registerNib(UINib(nibName: "GroupTypeCell", bundle: nil) , forCellReuseIdentifier: "GroupType")
        
      //add uiview to show no Group
            noGroupTypeView.frame =  CGRectMake(0, 0, self.view.size.width, self.view.size.height-64)
            noGroupTypeView.hidden=true
            noGroupTypeView.btnContinue.hidden = true
            tableOGroupType.insertSubview(noGroupTypeView, aboveSubview: tableOGroupType)
        
     //tableview delegate and datasource and also add uiview in footer to avoid separator in table if data is not available
            tableOGroupType.tableFooterView = UIView()
            self.tableOGroupType.delegate = self
            self.tableOGroupType.dataSource = self
     //add empty array
            self.arrayOfGroupType = NSMutableArray()
     //Call web service to get group type
            self.fetchGroupTypeFromServices()
    }
    
    
    //MARK: - Set Bar button in navigation
    func setNavigationLeftBarButton() {
        let btnBack = UIBarButtonItem(title: "Back", style: .Plain, target: nil, action: nil)
        self.navigationItem.backBarButtonItem = btnBack;
        self.navigationItem.title = "Select Lift Group Type"
    }
    
    
    
    //MARK: - Fetch lifts from service
    func fetchGroupTypeFromServices()  {
        let groupDL = GroupTypeDL()
        groupDL.requestForGroupType(liftGroupVC?.liftGroupBO.groupType ?? "", withCompletionHandler: { (obj,  success) -> Void in
            if success == true {
                self.arrayOfGroupType.addObjectsFromArray(obj as! NSArray as [AnyObject])
                self.tableOGroupType.reloadData()
            }
        })
        
    }
    
    //MARK: - Table VIew Delegates
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 75;
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(self.arrayOfGroupType.count <= 0) {
            noGroupTypeView?.hidden=false
            return 0
        }
        else  {
            noGroupTypeView?.hidden=true
            return self.arrayOfGroupType.count
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell:GroupTypeCell = (tableView.dequeueReusableCellWithIdentifier("GroupType", forIndexPath: indexPath) as? GroupTypeCell)!
        cell.selectionStyle = .None
        
        let groupBO:GroupTypeBO
        groupBO = self.arrayOfGroupType[indexPath.row] as! GroupTypeBO
        cell.lblGroupTypeName.text = groupBO.groupTypeName
        
        if (!(groupBO.isGroupTypeSelected) && !(groupBO.hasSubCatories))  {
            cell.btnSelectGroupType.setImage(UIImage(named: "blue_unchecked"), forState: UIControlState.Normal)
        }
        else if ((groupBO.isGroupTypeSelected!) && !(groupBO.hasSubCatories))  {
            cell.btnSelectGroupType.setImage(UIImage(named: "blue_checked"), forState: UIControlState.Normal)
            liftGroupVC?.liftGroupBO.groupType = groupBO.groupTypeName
            lastSelectedGroup = indexPath
         }
        else  {
            cell.btnSelectGroupType.setImage(UIImage(named: "right_arrow"), forState: UIControlState.Normal)
        }
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let groupBO:GroupTypeBO
        groupBO = self.arrayOfGroupType[indexPath.row] as! GroupTypeBO
        
        if(groupBO.hasSubCatories!) {
            let groupType = NSIUtility.fetchViewControllerWithName("groupTypeSubCatVC", storyBoardName: "Main") as! groupTypeSubCatVC
            groupType.delegate = self
            self.navigationController?.pushViewController(groupType, animated: true)
        } else {
            
            if let lastSelectedIndexPath = lastSelectedGroup {
                let lastSeletedGroupBO:GroupTypeBO
                lastSeletedGroupBO = self.arrayOfGroupType[(lastSelectedGroup?.row)!] as! GroupTypeBO
                lastSeletedGroupBO.isGroupTypeSelected = !(lastSeletedGroupBO.isGroupTypeSelected)
                self.arrayOfGroupType[(lastSelectedGroup?.row)!]  = lastSeletedGroupBO
                
                if indexPath.row != lastSelectedGroup?.row {
                    tableView.reloadRowsAtIndexPaths([lastSelectedIndexPath], withRowAnimation: UITableViewRowAnimation.None)
                }
            }
            groupBO.isGroupTypeSelected = !(groupBO.isGroupTypeSelected)
            self.arrayOfGroupType[indexPath.row]  = groupBO
            tableView.reloadRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.None)
            
        }
    }
    
    // MARK:- Update list when SubCatory tableview is select group type (using UpdateCategoryListProtocol function)
    func updateListOnSelect() {
        if let lastSelectedIndexPath = lastSelectedGroup {
            let lastSeletedGroupBO:GroupTypeBO
            lastSeletedGroupBO = self.arrayOfGroupType[(lastSelectedGroup?.row)!] as! GroupTypeBO
            lastSeletedGroupBO.isGroupTypeSelected = !(lastSeletedGroupBO.isGroupTypeSelected)
            self.arrayOfGroupType[(lastSelectedGroup?.row)!]  = lastSeletedGroupBO
            
            tableOGroupType.reloadRowsAtIndexPaths([lastSelectedIndexPath], withRowAnimation: UITableViewRowAnimation.None)
            
            lastSelectedGroup = nil
        }
    }
    
    //MARK: - deinit methof to free allocate resources
    deinit {
        self.tableOGroupType = nil;
        self.noGroupTypeView = nil;
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}