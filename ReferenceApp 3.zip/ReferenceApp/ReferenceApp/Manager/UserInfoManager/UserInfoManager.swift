//
//  UserInfoManager.swift
//  ReferenceApp
//
//  Created by Mohit Jain on 9/3/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit

let userInfoKey:String = "userInfoModel"

class UserInfoManager: NSObject{
    
    //MARK: - Setter Method
    class func setUserInfo(userInfoModel:UserBO!) {
        if let userModel = userInfoModel {
            let archivedServerModules = NSKeyedArchiver.archivedDataWithRootObject(userModel)
            NSIUtility.setValueToUserDefaultsForKey(userInfoKey, value: archivedServerModules)
        
        }
    }

    //MARK: - Getter Method
    class func getUserInfoModel()->UserBO! {
        let archivedServerModules: AnyObject? = NSIUtility.getValueFromUserDefaultsForKey(userInfoKey)
        if archivedServerModules == nil {
            return nil
        }
        let userInfoModel:UserBO = NSKeyedUnarchiver.unarchiveObjectWithData(archivedServerModules as! NSData) as! UserBO
        return userInfoModel
    }
    
    //MARK: - Remove user's info
    class func removeUserInfo() {
        NSUserDefaults.standardUserDefaults().removeObjectForKey(userInfoKey)
        NSUserDefaults.standardUserDefaults().synchronize()
    }
}