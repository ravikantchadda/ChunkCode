//
//  LiftRequestVC.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/23/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit
import GoogleMaps
import CoreLocation
import MFSideMenu


typealias CompletionLocation = (fromLoc:NSNumber?,toLoc:NSNumber?, success:Bool?) -> Void

let ConstantTodayString = "Today ASAP"

class LiftRequestVC: BaseViewController,UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate {

    enum LoactionType:Int {case FromLocation = 0, ToLocation = 1}
    
    enum LiftType:Int {case LiftTypeOffer = 0, LiftTypeRequest = 1}
    
    @IBOutlet var tblView: UITableView!
    
    var viewSetLoc:ViewOfSetLocation!
    var cellOfMap: MapViewCell!
    var cellOfPeople:GroupsOfPeopleCell!
    var cellOfSeats:SeatsAvailableCell!
    var cellOfLiftNeed:WhenLiftNeedCell!
    var cellOfPeopleToNotify:GroupsOfPeopleCell!
    var cellOfMessage:AddMessageCell!
    var locType:LoactionType!
    var fromLocationData:AddressBO?
    var toLocationData:AddressBO?
    
    var strPickupOrDeparted:String!
    
    var whichLiftType:LiftType!
    
    @IBOutlet var btnRequestLift: UIButton!
    
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
//        self.navigationItem.setHidesBackButton(true, animated: true)
//        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.Plain, target: self, action: "toCancel")
        
        // Set the navigation back button

        self.setNavigationBar(.BlueNavigationType)
//        if count == 2 {
//            self.setNavigationBar(.BlueNavigationType)// With back button
//        }
//        else{
//            self.setNavigationBar(.BlueNavigationType, withLeftMenu: true) // With menu icon and logo
//        }
        
        self.setRightBarButton()
        
        self.addTextAndRouteFromAndToLocation()
        self.addMarkerOfLocation()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.initialInitilization()
    }
    
    
    func initialInitilization(){
    
        locType = .FromLocation
//        self.whichLiftType = .LiftTypeOffer
        
        viewSetLoc = UIView.viewFromNibName("ViewOfSetLocation") as? ViewOfSetLocation
        tblView.registerNib(UINib.init(nibName: "MapViewCell", bundle: nil), forCellReuseIdentifier: "mapViewCell")
        tblView.registerNib(UINib.init(nibName: "GroupsOfPeopleCell", bundle: nil), forCellReuseIdentifier: "groupsOfPeopleCell")
        tblView.registerNib(UINib.init(nibName: "WhenLiftNeedCell", bundle: nil), forCellReuseIdentifier: "whenLiftNeedCell")
        tblView.registerNib(UINib.init(nibName: "AddMessageCell", bundle: nil), forCellReuseIdentifier: "addMessageCell")
        
        
        self.cellOfMap  = tblView.dequeueReusableCellWithIdentifier("mapViewCell") as! MapViewCell
        self.cellOfMap.callBack = self
        self.cellOfMap.liftRequest = self
        
        if whichLiftType == .LiftTypeRequest{
            self.cellOfPeople  = tblView.dequeueReusableCellWithIdentifier("groupsOfPeopleCell") as! GroupsOfPeopleCell
            self.cellOfPeople.callBack = self
            self.cellOfPeople.collectionType = .CollectionPassenger
            self.cellOfPeople.lblTileOfTheGroup.text = "Who will be going on this trip?"
            self.strPickupOrDeparted = "Pickup"
            btnRequestLift.setTitle("Request Lift", forState: .Normal)
            self.title = "Request Lift"
        }else{
            tblView.registerNib(UINib.init(nibName: "SeatsAvailableCell", bundle: nil), forCellReuseIdentifier: "seatsAvailableCell")
            self.cellOfSeats  = tblView.dequeueReusableCellWithIdentifier("seatsAvailableCell") as! SeatsAvailableCell
            self.strPickupOrDeparted = "Departing"
            self.title = "Offer Lift"
            btnRequestLift.setTitle("Offer Lift", forState: .Normal)
            
        }
        
        viewSetLoc.btnPickupLoc.setTitle("Set \(self.strPickupOrDeparted)", forState: .Normal)
        
        self.cellOfLiftNeed  = tblView.dequeueReusableCellWithIdentifier("whenLiftNeedCell") as! WhenLiftNeedCell
        
        self.cellOfMessage  = tblView.dequeueReusableCellWithIdentifier("addMessageCell") as! AddMessageCell
        
        self.cellOfPeopleToNotify  = tblView.dequeueReusableCellWithIdentifier("groupsOfPeopleCell") as! GroupsOfPeopleCell
        self.cellOfPeopleToNotify.collectionType = .CollectionNotifyPeople
        self.cellOfPeopleToNotify.lblTileOfTheGroup.text = "Who do you want to notify?"
        self.cellOfPeopleToNotify.callBack = self
        
        self.viewSetLoc.liftRequestVCCallBack = self
        

    //Adding User to passenger array
        if whichLiftType == .LiftTypeRequest{
            self.addUserToPassengerArray()
        }
    }
    
    
    //MARK:- LeftNav Bar Items
    func setRightBarButton() {
//        let barBtnMenu = UIBarButtonItem(image: UIImage(named:"backIcon"), style: .Plain, target: self, action: "backButtonClick:")
        let barBtnMenu = UIBarButtonItem(title:"Cancel", style: .Plain, target: self, action: "cancelButtonClick:")
        barBtnMenu.tintColor = UIColor.grayColor()
        navigationItem.leftItemsSupplementBackButton = true
        navigationItem.setRightBarButtonItems([barBtnMenu], animated: true)
    }
    
    func cancelButtonClick(sender:UIButton!){
        self.navigationController?.dismissViewControllerAnimated(true, completion: {
        })
    }



    
// MARK:- Button Methods
    
     func callCreateRequestService(){

        if self.cellOfPeople.arrayOfPassenger.count == 0 {NSIUtility.show("Please add atleast one passenger"); return}
        
 
        
        let requestBO = RequestBO()
        requestBO.requesterId = UserBO.sharedInstanceOfUser.userID
        
        requestBO.requestDatetimeDATE = self.cellOfLiftNeed.selectedWhenDate
        requestBO.message = self.cellOfMessage.txtMessage.text
        requestBO.isRecurring = false
        requestBO.extraPassengers = 0
        requestBO.requestedUsers = self.cellOfPeopleToNotify.arrayOfNotifyPeople.valueForKey("userID") as! NSArray
        requestBO.isImmidiate = false
        requestBO.requestPassengers = []
        
        // Immidiate Condition
        if self.cellOfLiftNeed.btnRecurring.currentTitle != "None" {
            requestBO.isRecurring = true
            requestBO.liftFrequencyTypeId = self.cellOfLiftNeed.selectedFrequency.frequencyID
            requestBO.requestEndDateDATE = self.cellOfLiftNeed.selectedUntilDate
        }
        // Immidiate Condition
        if self.cellOfLiftNeed.btnWhentTime.currentTitle == ConstantTodayString{
            requestBO.isImmidiate = true
        }
        // Pickup Location Condition
        if self.fromLocationData!.addressID != nil{
            requestBO.startLocationId = self.fromLocationData!.addressID
        }else{
            requestBO.newStartLocation = self.fromLocationData!
            requestBO.startLocationId = 0
        }
        // Destination Condition
        if self.toLocationData!.addressID != nil{
            requestBO.endLocationId = self.toLocationData!.addressID
        }else{
            requestBO.newEndLocation = self.toLocationData!
            requestBO.endLocationId = 0
        }
        
        // Message Condition
        if requestBO.message == "Write any additional messages here"{
            requestBO.message = ""
        }
        
        let requestDL = RequestDL()
        requestDL.requestForCreateRequestLift(requestBO) { (obj, success) -> Void in
            if success == true{
                NSIUtility.show("Request has been created succefully")
                
                self.cancelButtonClick(nil)
            }
            else{
                NSIUtility.show(Constants.kSomethingWrong)
            }
            
        }

    }


    func callCreateOfferService(){
        
        
        
        let offerBO = OfferBO()
        offerBO.offerorId = UserBO.sharedInstanceOfUser.userID
       
        offerBO.offerDatetime = self.cellOfLiftNeed.selectedWhenDate
        offerBO.message = self.cellOfMessage.txtMessage.text
        offerBO.isRecurring = false
        
        
        
        offerBO.offereeId = self.cellOfPeopleToNotify.arrayOfNotifyPeople.valueForKey("userID") as! NSArray
        offerBO.seatAvailability = Int(self.cellOfSeats.txtSeats.text!)
        offerBO.isImmidiate = false
        
    // Immidiate Condition
        if self.cellOfLiftNeed.btnRecurring.currentTitle != "None" {
            offerBO.isRecurring = true
            offerBO.liftFrequencyTypeId = self.cellOfLiftNeed.selectedFrequency.frequencyID
            offerBO.offerEndDate = self.cellOfLiftNeed.selectedUntilDate
        }
    // Immidiate Condition
        if self.cellOfLiftNeed.btnWhentTime.currentTitle == ConstantTodayString{
            offerBO.isImmidiate = true
        }
    // Pickup Location Condition
        if self.fromLocationData!.addressID != nil{
            offerBO.startLocationId = self.fromLocationData!.addressID
        }else{
            offerBO.newStartLocation = self.fromLocationData!
            offerBO.startLocationId = 0
        }
    // Destination Condition
        if self.toLocationData!.addressID != nil{
            offerBO.endLocationId = self.toLocationData!.addressID
        }else{
            offerBO.newEndLocation = self.toLocationData!
            offerBO.endLocationId = 0
        }
        
    // Message Condition
        if offerBO.message == "Write any additional messages here"{
            offerBO.message = ""
        }
        
        let offerDL = OfferDL()
        offerDL.requestForCreateOfferLift(offerBO) { (obj, success) -> Void in
            if success == true{
                NSIUtility.show("Offer has been created successfully")
                self.cancelButtonClick(nil)
            }
            else{
                NSIUtility.show(Constants.kSomethingWrong)
            }
            
        }
    }


    
//    func callCreateRequestService(){
//        self.fetchLocationFromServer { (fromLoc, toLoc, success) -> Void in
//            
//            if success == true{
//                
//                let requestLiftBO = RequestBO()
//                requestLiftBO.requesterId = UserBO.sharedInstanceOfUser.userID
//                requestLiftBO.extraPassengers = 0
//                requestLiftBO.requestDatetime = self.cellOfLiftNeed.selectedWhenDate.datConvertJsonDate()
//                requestLiftBO.isRecurring = false
//                requestLiftBO.startLocationId = fromLoc
//                requestLiftBO.endLocationId = toLoc
//                requestLiftBO.requestPassengers = []
//                requestLiftBO.requestedUsers = self.cellOfPeopleToNotify.arrayOfNotifyPeople.valueForKey("userID") as! NSArray
//                requestLiftBO.message = self.cellOfMessage.txtMessage.text
//                
//                if requestLiftBO.message == "Write any additional messages here"{
//                    requestLiftBO.message = ""
//                }
//                requestLiftBO.isImmidiate = false
//                
//                if self.cellOfLiftNeed.btnWhentTime.currentTitle == ConstantTodayString{
//                    requestLiftBO.isImmidiate = true
//                }
//                
//                if self.cellOfLiftNeed.btnRecurring.currentTitle != "None" {
//                    requestLiftBO.isRecurring = true
//                    requestLiftBO.liftFrequencyTypeId = self.cellOfLiftNeed.selectedFrequency.frequencyID
//                    requestLiftBO.requestEndDate = self.cellOfLiftNeed.selectedUntilDate.datConvertJsonDate()
//                    requestLiftBO.requestEndDateDATE = self.cellOfLiftNeed.selectedUntilDate
//                    
//                    
//                }
//                
//                //                requestLiftBO.newEndLocation =
//                //                requestLiftBO.newStartLocation = 0
//                
//                let requestDL = RequestDL()
//                requestDL.requestForCreateRequestLift(requestLiftBO, handler: { (obj, success) -> Void in
//
//                    if success == true{
//                        NSIUtility.show("Request has been created succefully")
//                        
//                        if self.navigationController?.viewControllers.count == 1{
//                        NSNotificationCenter.defaultCenter().postNotificationName("ChangeMenuCenterControllerNotification", object: "Home")
//                        }
//                        else{
//                            self.navigationController?.popViewControllerAnimated(true)
//                        }
//                    }
//                    else{
//                        NSIUtility.show(Constants.kSomethingWrong)
//                    }
//                    
//                    //                    self.navigationController?.popToRootViewControllerAnimated(true)
//                    
//                })
//            }
//        }
//    }
    
    @IBAction func toRequestLift(){
        
        if self.fromLocationData == nil{NSIUtility.show("Please fill 'Set \(self.strPickupOrDeparted) Location'"); return}
        if self.toLocationData == nil{NSIUtility.show("Please fill 'Set Destination Location'"); return}
        if self.cellOfPeopleToNotify.arrayOfNotifyPeople.count == 0 {NSIUtility.show("Please add atleast one people who you want to notify"); return}
        
        if whichLiftType == .LiftTypeRequest{
            if self.cellOfPeople.arrayOfPassenger.count == 0 {NSIUtility.show("Please add atleast one passenger"); return}
            
            UIAlertView.showWithTitle("Are you sure?", message: "Your Request will be sent to the Groups/Individuals you have selected", cancelButtonTitle: "Cancel", otherButtonTitles:["Okay"]) { (alertView, buttonIndex) -> Void in
                if buttonIndex != alertView.cancelButtonIndex{
                    self.callCreateRequestService()
                    }
                }
        }else{
            
            if self.cellOfSeats.txtSeats.text?.length == 0{
                NSIUtility.show("Please fill the seats")
                return
            }else{
                let seats = Int(self.cellOfSeats.txtSeats.text!)
                if seats == 0 || seats == nil{
                    NSIUtility.show("Please fill atleast one seat")
                    return
                }
            }
            
            UIAlertView.showWithTitle("Are you sure?", message: "Your Offer will be sent to the Groups/Individuals you have selected", cancelButtonTitle: "Cancel", otherButtonTitles:["Okay"]) { (alertView, buttonIndex) -> Void in
                if buttonIndex != alertView.cancelButtonIndex{
                    self.callCreateOfferService()
                }
            }
            
        }
    
    }
 

// MARK:- Other Of Call Back Delgates
    
    func setLocationOfMap(typeOfLoc:LoactionType){
        locType = typeOfLoc
        let selectPickupAdd =  NSIUtility.fetchViewControllerWithName("SelectPickupAddressVC", storyBoardName: "Home")
        self.navigationController?.pushViewController(selectPickupAdd, animated: false)
        self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
        
    }
    
    
    func toSelectBtnValidation()
    {
        if whichLiftType == .LiftTypeRequest{
            if self.fromLocationData == nil || self.toLocationData == nil || self.cellOfPeopleToNotify.arrayOfNotifyPeople.count == 0 || self.cellOfPeople.arrayOfPassenger.count == 0{
                btnRequestLift.backgroundColor = UIColor.colorWithRGB(31, green: 81, blue: 108, alpha:0.7)}else{btnRequestLift.backgroundColor = Constants.APP_THEME_COLOR}
        }else{
            
            if self.fromLocationData == nil || self.toLocationData == nil || self.cellOfPeopleToNotify.arrayOfNotifyPeople.count == 0{
                btnRequestLift.backgroundColor = UIColor.colorWithRGB(31, green: 81, blue: 108, alpha:0.7)}else{btnRequestLift.backgroundColor = Constants.APP_THEME_COLOR}
            
        }
    }
    
    
// MARK:- Tableview Delgates
    
// View of Footer nad Header View
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?{
        if tableView == tblView{
            return viewSetLoc
        }else{
            return UIView()
        }
    
    }
    
// Height of Footer nad Header View
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat{
        if tableView == tblView{
             return viewSetLoc.height
        }
        else{
            return 0
        }
    }
    
    
    func refreshIt(){
        
//        self.fromLocationData = nil
//        self.toLocationData = nil
        self.cellOfPeopleToNotify.arrayOfNotifyPeople.removeAllObjects()
//        self.cellOfPeople.arrayOfPassenger.removeAllObjects()
        
        let frquency = FrequencyBO()
        frquency.frequencyID = 4711
        frquency.frequencyName = "None"
        let currentDate = NSDate()
        self.cellOfLiftNeed.selectedFrequency = frquency
        self.cellOfLiftNeed.btnRecurring.setTitle("None", forState: .Normal)
        self.cellOfLiftNeed.btnRecurringUntil.setTitle("-", forState: .Normal)
        self.cellOfLiftNeed.btnRecurringUntil.userInteractionEnabled = false
        // For When Date
        self.cellOfLiftNeed.selectedWhenDate = currentDate
        self.cellOfLiftNeed.btnWhentTime.setTitle(ConstantTodayString, forState: .Normal)
        
//        self.viewSetLoc.btnPickupLoc.setTitle("Enter Pickup Location", forState: .Normal)
//        self.viewSetLoc.btnDestinationLoc.setTitle("Enter Destination", forState: .Normal)
        
        self.cellOfMessage.txtMessage.text = "Write any additional messages here"
        
        self.cellOfPeople.collOfPsgr.reloadData()
        self.cellOfPeopleToNotify.collOfPsgr.reloadData()

    }
    
    func fetchLocationFromServer(completionLocation:CompletionLocation){
        
        var fromID:NSNumber!
        var toID:NSNumber!
        
        let addressDL = UserDL()
        addressDL.requestforAddresses { (obj, success) -> Void in
            if success == true
            {
                if let arrayOfLocations:NSArray = obj as? NSArray{

                    let predicateFrom:NSPredicate = NSPredicate(format: "streetAddress IN %@", argumentArray:[self.fromLocationData!.streetAddress])
                    let arrayFromLocFiltered = arrayOfLocations.filteredArrayUsingPredicate(predicateFrom)
                    
                    if arrayFromLocFiltered.count != 0{
                        if let adressBO:AddressBO =  arrayFromLocFiltered[0] as? AddressBO{
                            fromID = adressBO.addressID
                        }
                    }
                    
                    let predicateTo:NSPredicate = NSPredicate(format: "streetAddress IN %@", argumentArray:[self.toLocationData!.streetAddress])
                    let arrayToLocFiltered = arrayOfLocations.filteredArrayUsingPredicate(predicateTo)
                    
                    if arrayToLocFiltered.count != 0{
                        if let adressBO:AddressBO =  arrayToLocFiltered[0] as? AddressBO{
                            toID = adressBO.addressID
                        }
                    }
                    
                    if toID != nil && fromID != nil{
                        completionLocation(fromLoc: fromID, toLoc: toID, success: true)
                    }else{
                        completionLocation(fromLoc: fromID, toLoc: toID, success: false)
                    }
                    return
                }
            }
            completionLocation(fromLoc: nil, toLoc: nil, success: false)
            return
        }
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) ->Int
    {return 1}
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) ->Int
    {
        if tableView == tblView{
            return 5
        }else{
            return 5
        }
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat
    {
        if tableView == tblView{
        
            switch indexPath.row {
            case 0:
                return 300
            case 1:
                return 105
            case 2:
                return 105
            case 3:
                return 105
            case 4:
                return 105
            default:
                return 105
            }
        }else{
            return 75
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) ->UITableViewCell
    {
        cellOfMap.selectionStyle = .None
        if whichLiftType == .LiftTypeRequest{
            cellOfPeople.selectionStyle = .None
        }else{
            cellOfSeats.selectionStyle = .None
        }
        
        cellOfLiftNeed.selectionStyle = .None
        cellOfPeopleToNotify.selectionStyle = .None
        cellOfMessage.selectionStyle = .None
        
        if tableView == tblView{
            switch indexPath.row {
            case 0:
                return cellOfMap
            case 1:
                if whichLiftType == .LiftTypeRequest{
                    return cellOfPeople
                }else{
                    return cellOfSeats
            }
                
            case 2:
                return cellOfLiftNeed
            case 3:
                return cellOfPeopleToNotify
            case 4:
                return cellOfMessage
            default:
                return UITableViewCell()
            }
        }else{
            return UITableViewCell(style:UITableViewCellStyle.Default, reuseIdentifier: "Cell")
        }
    }
    
    
    
    
    
    
// MARK:- Other Methods
    
    func addUserToPassengerArray(){
        let userPassenger:PassengerBO = PassengerBO()
        userPassenger.countryCodeID = 0
        userPassenger.firstName = UserBO.sharedInstanceOfUser.userFirstName
        userPassenger.gender = UserBO.sharedInstanceOfUser.userGender
        userPassenger.lastName = UserBO.sharedInstanceOfUser.userLastName
        userPassenger.mobileNumber = UserBO.sharedInstanceOfUser.userMobileNo
        userPassenger.photo = UserBO.sharedInstanceOfUser.userPhoto
        userPassenger.requestID = 0
        userPassenger.passengerId = UserBO.sharedInstanceOfUser.userID
        self.cellOfPeople.arrayOfPassenger.addObject(userPassenger)
        self.cellOfPeople.collOfPsgr.reloadData()
    }
    
    
    // Adding The Location After pickup the location
    func addTextAndRouteFromAndToLocation(){
        if locType != nil{
            if locType == .FromLocation{
                if fromLocationData != nil{
                    self.viewSetLoc.btnPickupLoc.setTitle(fromLocationData!.streetAddress, forState: .Normal)
                    if toLocationData != nil{
                        self.cellOfMap.btnTitleName.setTitle("Change \(self.strPickupOrDeparted)", forState: .Normal)
                        // Route Map
                    }else{
                        self.cellOfMap.btnTitleName.setTitle("Set Destination", forState: .Normal)
                    }
                }else{
                    self.cellOfMap.btnTitleName.setTitle("Set \(self.strPickupOrDeparted)", forState: .Normal)
                }
            } else if locType == .ToLocation{
                if toLocationData != nil{
                    self.viewSetLoc.btnDestinationLoc.setTitle(toLocationData!.streetAddress, forState: .Normal)
                    if fromLocationData != nil{
                        self.cellOfMap.btnTitleName.setTitle("Change Destination", forState: .Normal)
                        // Route Map
                    }else{
                        self.cellOfMap.btnTitleName.setTitle("Set \(self.strPickupOrDeparted)", forState: .Normal)
                    }
                }else{
                    self.cellOfMap.btnTitleName.setTitle("Set Destination", forState: .Normal)
                }
            }
        }else{
            self.cellOfMap.btnTitleName.setTitle("Set \(self.strPickupOrDeparted)", forState: .Normal)
        }
    }
    
// Adding Route
    func addRouteToMapView(){
        if self.cellOfMap != nil {
            if fromLocationData != nil && toLocationData != nil{
                self.cellOfMap.addRouteToMap(fromLocationData!.locationCords, withDestinationLoc: toLocationData!.locationCords)
            }
        }
    }
    
// Adding Marker to Destination and Pickup Location
    func addMarkerOfLocation(){
        
        if locType != nil{
            if locType == .FromLocation{
                if fromLocationData != nil && self.cellOfMap != nil{
                    self.cellOfMap.addMarkerToPickupLocation(fromLocationData!, title: "\(self.strPickupOrDeparted) Point")
                }
            }else{
                if toLocationData != nil && self.cellOfMap != nil{
                    self.cellOfMap.addMarkerToDestinationLocation(toLocationData!, title: "Destination Point")
                }
            }
// Add route if destination and pickup is there
            self.addRouteToMapView()
        }
    }
}