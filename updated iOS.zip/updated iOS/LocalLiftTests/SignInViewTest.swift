//
//  SignInViewTest.swift
//  ReferenceApp
//
//  Created by ravi kant on 11/18/15.
//  Copyright © 2015 Netsol. All rights reserved.
//

import XCTest
@testable import LocalLift
class SignInViewTest: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
        }
    }
    

    
    func testToCallWebServiceWithDictParametrs(){
        
        let expectation = expectationWithDescription("Handler")
                
    
        let apiHelper = PSRestAPIHelper()
        let email: NSString = "email"
        let password: NSString = "password"
        
        apiHelper.serviceURL = "Login"
        
        let dictParams:NSDictionary = NSDictionary(objects: ["ravi@gmail.com","1234"], forKeys: [email,password])

        apiHelper.requestforPOST(dictParams as! [NSObject : AnyObject!]) { (obj, success) -> Void in
            if let dicResponse:NSDictionary = obj as? NSDictionary{
                if success == true{
                    
                    XCTAssertNotNil(obj, "data should not be nil")
                    //  print(obj as! NSDictionary)
                    // XCTAssertEqual(obj?.valueForKey(Constants.keyStatusCode) as? Int, 111, "Invalid user credentials.")
                    XCTAssertEqual(dicResponse.valueForKey("Status") as? Int, 200, "Success Valid user credentials.")
                    XCTAssertTrue((success) != nil,"PASS")
                    //    XCTAssertNil(obj as! NSArray, "Failes")
                    XCTAssert(obj is NSDictionary, "Pass")
                    XCTAssertNotEqual(1, 2, "PASS")
                
                    
                }else{
                    XCTAssertNil(obj, "data is nil")
                
                }
            }
            
            
            expectation.fulfill()
        }
        
        
        waitForExpectationsWithTimeout(5.0) { error in
            if let error = error {
                print("Error: \(error.localizedDescription)")
            }
        }
    
    }
    
    
    
    
    
}
