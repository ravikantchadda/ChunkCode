//
//  CXKeychainHelper.swift
//  ReferenceApp
//
//  Created by ravi kant on 11/17/15.
//  Copyright © 2015 Netsol. All rights reserved.
//

import Foundation
import Security

class CXResultWithStatus: NSObject {
    var status: OSStatus?
    var result: NSObject?
}

class CXKeychainHelper: NSObject {
    class func secItemCopyMatchingCaller(query: [NSObject : AnyObject]) -> CXResultWithStatus {
        let resultWithStatus: CXResultWithStatus = CXResultWithStatus()
        var result: AnyObject? = nil
        resultWithStatus.status = SecItemCopyMatching((query), &result)
        if result != nil {
            resultWithStatus.result = result as? NSObject
        }
        return resultWithStatus
    }
    class func secItemAddCaller(query: [NSObject : AnyObject]) -> CXResultWithStatus {
        let resultWithStatus: CXResultWithStatus = CXResultWithStatus()
        var result: AnyObject? = nil
        resultWithStatus.status = SecItemAdd((query), &result)
        if result != nil {
            resultWithStatus.result =  result as? NSObject
        }
        return resultWithStatus
    }}