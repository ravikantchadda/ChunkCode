//
//  SelectPassengerVC.swift
//  LocalLift
//
//  Created by Sarishti on 11/26/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class SelectPassengerVC: BaseViewController,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate {
    
    
    @IBOutlet var searchBarSelectPassenger: UISearchBar!
    @IBOutlet var tblViewSelectPassenger: UITableView!
    
    var arrayOfAddedPassenger:NSMutableArray!
    
    
    var isItemAvailble:Bool = false
    var index:Int = 0

    @IBOutlet var btnContinue: UIButton!
    var selectedItemsOfPassenger:[PassengerBO] = NSArray() as! [PassengerBO]
    var searchActive : Bool = false
//    var arrayOfSearchLinkedPassenger:[String] = []
    var arrayOfLinkedPassenger = NSMutableArray()
    var arrayOfSearchLinkedPassenger = NSArray()
    
    @IBOutlet var imgUser: UIImageView!
    @IBOutlet var lblUser: UILabel!
    @IBOutlet var lblEmailAdd: UILabel!
    @IBOutlet var btnUserSelect: UIButton!
    
    
    
//    let arrayOfLinkedPassenger = ["Sonakshi Aggarwal", "Nitin Obroy", "Riya Malhotra", "Jameson Quave", "James", "Minakshi", "Andrew Arora","ZIBar"];
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.initialInitialization()
    }
    
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
        self.setNavigationBar(.BlueNavigationType)
        
    }
    
    func initialInitialization(){
        
        tblViewSelectPassenger.registerNib(UINib.init(nibName: "SelectPassengerCell", bundle: nil), forCellReuseIdentifier: "SelectPassengerCell")
        searchBarSelectPassenger.delegate=self
        lblEmailAdd.text = UserBO.sharedInstanceOfUser.userEmailAddress
        self.checkUserAddedOrNot()
//        self.fetchPassengersFromServices()
    }
    
    
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
        
    }
    
     // MARK: - Data From Service
    
//    func fetchPassengersFromServices(){
//        
//        let psgrDL:PassengerDL = PassengerDL()
//        A { (obj, success) -> Void in
//            if success == true
//            {
//                self.arrayOfLinkedPassenger = obj as! NSMutableArray
//                self.tblViewSelectPassenger.delegate = self
//                self.tblViewSelectPassenger.dataSource = self
//                self.tblViewSelectPassenger.reloadData()
//            }
//        }
//    }
    
    // MARK: - Search Bar Delegate
    
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        
        searchActive = true;
    }
    
    func searchBarTextDidEndEditing(searchBar: UISearchBar) {
        
        searchActive = false;
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        
        searchActive = false;
    }
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        
        searchActive = false;
    }
    
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
//        let objPassenger:PassengerBO = arrayOfLinkedPassenger[row] as! PassengerBO
        arrayOfSearchLinkedPassenger = arrayOfLinkedPassenger.filter({ (text) -> Bool in
            
            let searchString: NSString = text.firstName
            let range = searchString.rangeOfString(searchText, options: NSStringCompareOptions.CaseInsensitiveSearch)
            return range.location != NSNotFound
        })
        
        if(arrayOfSearchLinkedPassenger.count == 0){
            
            searchActive = false;
            
        }else {
            searchActive = true;
        }
        self.tblViewSelectPassenger.reloadData()
    }
    
    
    // MARK:- Table View Delegate
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if(searchActive) {
            return 0;
        }else{
            return 0;
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cellOfPassenger : SelectPassengerCell = tableView.dequeueReusableCellWithIdentifier("SelectPassengerCell") as! SelectPassengerCell
        let row = indexPath.row
        
        if(searchActive){
            let objPassenger:PassengerBO = arrayOfSearchLinkedPassenger[row] as! PassengerBO
//            cellOfPassenger.lblSelectPassengerCell?.text = arrayOfSearchLinkedPassenger[row]
            cellOfPassenger.lblNameOfPassenger?.text = objPassenger.firstName
            cellOfPassenger.lblEmailOfPassenger?.text = objPassenger.emailAddress
            cellOfPassenger.btnSelectedPassenger?.tag = row
            cellOfPassenger.btnSelectedPassenger .addTarget(self, action:"btnSelectedPassengerAction:", forControlEvents: .TouchUpInside)
            
        }else{
            
            if(indexPath.row == self.arrayOfLinkedPassenger.count){
                
                cellOfPassenger.lblNameOfPassenger?.text = "Add new Linked passengers"
                cellOfPassenger.lblEmailOfPassenger?.text = "Lorem ipsum dolar sit ament consectetur"
                cellOfPassenger.btnSelectedPassenger.hidden = true
            }else{
                let objPassenger:PassengerBO = arrayOfLinkedPassenger[row] as! PassengerBO
                cellOfPassenger.lblNameOfPassenger?.text = objPassenger.firstName
                cellOfPassenger.lblEmailOfPassenger?.text = objPassenger.emailAddress
                cellOfPassenger.btnSelectedPassenger?.tag = row
                cellOfPassenger.btnSelectedPassenger .addTarget(self, action:"btnSelectedPassengerAction:", forControlEvents: .TouchUpInside)
                
            }
            
        }
        
        return cellOfPassenger
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat
    {
        return 75;
    }
    
    //  Header View
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?{
        
        if let viewHeader:ViewOfLinkedPassenger = UIView.viewFromNibName("ViewOfLinkedPassenger") as? ViewOfLinkedPassenger {
            return viewHeader
        }
        return UIView()
        
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat{
        
        if let viewHeader:ViewOfLinkedPassenger = UIView.viewFromNibName("ViewOfLinkedPassenger") as? ViewOfLinkedPassenger {
            return viewHeader.height}
        else{
            return 0
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if(indexPath.row == self.arrayOfLinkedPassenger.count){
            let addPassengerVC = NSIUtility.fetchViewControllerWithName("AddPassengerVC", storyBoardName: "Home")
            self.navigationController?.pushViewController(addPassengerVC, animated: true)
        }
    }
    
    // MARK:-  Button Action
    
    
    @IBAction func toContinueBtn(sender: AnyObject) {
        
//        if (self.selectedItemsOfPassenger.count != 0 || btnUserSelect.selected){
            self.arrayOfAddedPassenger.removeAllObjects()
            if btnUserSelect.selected{
                self.addUserToPassengerArray()
                
            }
            if let liftVC =  self.fetchPreviousControllerFromNavigationStack(1) as? LiftRequestVC{
                liftVC.cellOfPeople.arrayOfPassenger = arrayOfAddedPassenger
                liftVC.cellOfPeople.collOfPsgr.reloadData()
                self.navigationController?.popToViewController(liftVC, animated: true)
            }
//        }
    }
    
    
    
    func btnSelectedPassengerAction(sender: UIButton!) {
        
        isItemAvailble = false
        if(searchActive){
            let objPassenger:PassengerBO = arrayOfSearchLinkedPassenger[sender.tag] as! PassengerBO
            if(selectedItemsOfPassenger.count > 0){
               
                
                for index=0;index<selectedItemsOfPassenger.count; ++index{
                    if (selectedItemsOfPassenger[index].firstName == objPassenger.firstName){
//                        if var citiesArr = citiesArray as? Array<AnyObject>{
//                            citiesArr.removeAtIndex(0)
//                        }
                        selectedItemsOfPassenger.removeAtIndex(index)
                        isItemAvailble = true
                        break
                    }
                }
                if(!isItemAvailble){
                    selectedItemsOfPassenger.append(objPassenger)
                }
            }else{
                selectedItemsOfPassenger.append(objPassenger)
            }
            
        }else{
              let objPassenger:PassengerBO = arrayOfLinkedPassenger[sender.tag] as! PassengerBO
            if(selectedItemsOfPassenger.count > 0){
                
                for index=0;index<selectedItemsOfPassenger.count; ++index{
                    if (selectedItemsOfPassenger[index].firstName == objPassenger.firstName){
                        selectedItemsOfPassenger.removeAtIndex(index)
                        isItemAvailble = true
                        break
                    }
                }
                if(!isItemAvailble){
                    selectedItemsOfPassenger.append(objPassenger)
                }
            }else{
                
                selectedItemsOfPassenger.append(objPassenger)
            }
        }
        print(selectedItemsOfPassenger);
        self.tblViewSelectPassenger.reloadData();
        
        print("You selected cell #\(sender.tag)!")
        self.toSelectBtnValidation()
//
    }
    
    @IBAction func btnProfileAddToSelectePassengerAction(sender: AnyObject) {
        btnUserSelect.selected = !btnUserSelect.selected
        
        self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
        // white you + button function
        
    }
    
    
// MARK:- Other Methods
    
    func toSelectBtnValidation()
    {
        print(self.selectedItemsOfPassenger.count)
        if (self.selectedItemsOfPassenger.count == 0 && !btnUserSelect.selected){
            btnContinue.backgroundColor = UIColor.colorWithRGB(31, green: 81, blue: 108, alpha:0.7)
        }
        else{
            btnContinue.backgroundColor = Constants.APP_THEME_COLOR
        }
    }
    
    
    
    
    func checkUserAddedOrNot(){
        
        let predicate:NSPredicate = NSPredicate(format: "(passengerId == %@ )", argumentArray:[UserBO.sharedInstanceOfUser.userID])
        let fetchedArray:NSArray = self.arrayOfAddedPassenger.filteredArrayUsingPredicate(predicate) as NSArray
        if fetchedArray.count == 0{
            btnUserSelect.selected = false
        }else{
            btnUserSelect.selected = true
        }
        
        self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
    }
    
    func isBtnSelected(btnSelected:UIButton){
        
        if !btnSelected.selected{
            btnSelected.selected = false
        }
    }
    
    func addUserToPassengerArray(){
        let userPassenger:PassengerBO = PassengerBO()
        userPassenger.countryCodeID = 0
        userPassenger.firstName = UserBO.sharedInstanceOfUser.userFirstName
        userPassenger.gender = UserBO.sharedInstanceOfUser.userGender
        userPassenger.lastName = UserBO.sharedInstanceOfUser.userLastName
        userPassenger.mobileNumber = UserBO.sharedInstanceOfUser.userMobileNo
        userPassenger.photo = UserBO.sharedInstanceOfUser.userPhoto
        userPassenger.requestID = 0
        userPassenger.passengerId = UserBO.sharedInstanceOfUser.userID
        self.arrayOfAddedPassenger.addObject(userPassenger)

    }
    
    
    
}
