//
//  SignInViewTest.swift
//  ReferenceApp
//
//  Created by ravi kant on 11/18/15.
//  Copyright © 2015 Netsol. All rights reserved.
//

import XCTest
@testable import ReferenceApp
class SignInViewTest: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
        }
    }
    
    
    func testAsynchronousURLConnectionOfTypeGET() {
        let URL = NSURL(string: "http://nshipster.com/")!
        let expectation = expectationWithDescription("GET \(URL)")
        
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithURL(URL) { data, response, error in
            XCTAssertNotNil(data, "data should not be nil")
            XCTAssertNil(error, "error should be nil")
            
            if let HTTPResponse = response as? NSHTTPURLResponse,
                responseURL = HTTPResponse.URL,
                MIMEType = HTTPResponse.MIMEType
            {
                XCTAssertEqual(responseURL.absoluteString, URL.absoluteString, "HTTP response URL should be equal to original URL")
                XCTAssertEqual(HTTPResponse.statusCode, 200, "HTTP response status code should be 200")
                XCTAssertEqual(MIMEType, "text/html", "HTTP response content type should be text/html")
            } else {
                XCTFail("Response was not NSHTTPURLResponse")
            }
            
            expectation.fulfill()
        }
        
        task.resume()
        
        waitForExpectationsWithTimeout(task.originalRequest!.timeoutInterval) { error in
            if let error = error {
                print("Error: \(error.localizedDescription)")
            }
            task.cancel()
        }
    }
    func testAsynchronousURLConnectionToGetOuthTokenOfTypePOST() {
        
        let URL = NSURL(string: "http://192.168.0.211:8080/o/token/")!
        let expectation = expectationWithDescription("POST \(URL)")
        let headerBody:NSString = Constants.kOuthHeader
        
        let request = NSMutableURLRequest(URL: NSURL(string: "http://192.168.0.211:8080/o/token/")!)
        request.HTTPMethod = "POST"
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.HTTPBody = NSData(bytes:headerBody.UTF8String, length: headerBody.length)
        
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithRequest(request) { data, response, error in
            XCTAssertNotNil(data, "data should not be nil")
            XCTAssertNil(error, "error should be nil")
            
            if let HTTPResponse = response as? NSHTTPURLResponse,
                responseURL = HTTPResponse.URL,
                MIMEType = HTTPResponse.MIMEType
            {
                XCTAssertEqual(responseURL.absoluteString, URL.absoluteString, "HTTP response URL should be equal to original URL")
                XCTAssertEqual(HTTPResponse.statusCode, 200, "HTTP response status code should be 200")
                XCTAssertEqual(MIMEType, "application/json", "HTTP response content type should be text/html")
            } else {
                XCTFail("Response was not NSHTTPURLResponse")
            }
            
            expectation.fulfill()
        }
        
        task.resume()
        
        waitForExpectationsWithTimeout(task.originalRequest!.timeoutInterval) { error in
            if let error = error {
                print("Error: \(error.localizedDescription)")
            }
            task.cancel()
        }
    }
    
    
    func testOuthAPICallingWithPostMethod(){
        let expectation = expectationWithDescription("Handler")
        
        // If API is Calling without defining the header body
        //let headerBody:NSString = ""
        // If API is Calling with header body
        let headerBody:NSString = Constants.kOuthHeader
        
        
        let outh = OuthDL()
        outh.requestforOuth(headerBody as String) { (obj, success) -> Void in
            
            if success == true{
                XCTAssertNotNil(obj, "data should not be nil")
                print(obj as! NSDictionary)
                
                let accessToken: String!
                let tokenType: String!
                accessToken = obj?.valueForKey(Constants.keyAccessToken) as! String
                tokenType = obj?.valueForKey(Constants.keyTokenType) as! String
                
                let outhToken: String!
                outhToken = tokenType + " " + accessToken
                
                NSIUtility.setValueToUserDefaultsForKey(Constants.keyOuthToken, value: outhToken)
                
                
            }else{
                XCTAssertNil(obj, "data is nil")
                print(obj as! NSDictionary)

                
            }
            expectation.fulfill()
            

        }
        
        waitForExpectationsWithTimeout(5.0) { error in
            if let error = error {
                print("Error: \(error.localizedDescription)")
            }
            else{
                
            }
        }
        
    }
    
    func testToCallWebServiceWithDictParametrs(){
        
        let expectation = expectationWithDescription("Handler")

        
        
        let user = UserDL()
        let email: NSString = "email"
        let password: NSString = "password"
        
        let dictParams:NSDictionary = NSDictionary(objects: ["ravi@gmail.com","1234"], forKeys: [email,password])
        user.requestforUserSignIn(dictParams, withCompletionHandler: { (obj, success) -> Void in
            
            if success == true{
                XCTAssertNotNil(obj, "data should not be nil")
              //  print(obj as! NSDictionary)
                
               // XCTAssertEqual(obj?.valueForKey(Constants.keyStatusCode) as? Int, 111, "Invalid user credentials.")
                
                XCTAssertEqual(obj?.valueForKey(Constants.keyStatusCode) as? Int, 200, "Success Valid user credentials.")
                
                XCTAssertTrue((success) != nil,"PASS")
                
            //    XCTAssertNil(obj as! NSArray, "Failes")
            
                XCTAssert(obj is NSDictionary, "Pass")
                
                XCTAssertNotEqual(1, 2, "PASS")
                
            }else{
                XCTAssertNil(obj, "data is nil")
            
            }
            
            expectation.fulfill()
            
        })
        
        waitForExpectationsWithTimeout(5.0) { error in
            if let error = error {
                print("Error: \(error.localizedDescription)")
            }
        }
    
    }
    
    
    
    
    
}
