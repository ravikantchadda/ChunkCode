//
//  AddNewAddressVC.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/26/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit
import QuartzCore
import GoogleMaps
import CoreLocation

class AddNewAddressVC: BaseViewController,GMSMapViewDelegate {
    
    
    var mapView:MapViewCell!
    var addressViaPlaceAPI:AddressBO!
    
    @IBOutlet var btnAddress: UIButton!
    @IBOutlet var txtAddType: UITextField!
    @IBOutlet var btnSaveAddress: PSCustomFontButton!
    
    var placePicker = GMSPlacePicker!()
    var placesClient =  GMSPlacesClient()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        mapView = UIView.viewFromNibName("MapViewCell") as? MapViewCell
        mapView.titleView.hidden = true
        mapView.callBack = self
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillLayoutSubviews() {
        let viewForMap = self.view.viewWithTag(1001)
        mapView.frame = viewForMap!.bounds
        viewForMap!.addSubview(mapView)
        
        self.view.viewWithTag(901)?.layer.borderWidth = 1
        self.view.viewWithTag(901)?.layer.borderColor = UIColor.lightGrayColor().CGColor
        self.view.viewWithTag(902)?.layer.borderWidth = 1
        self.view.viewWithTag(902)?.layer.borderColor = UIColor.lightGrayColor().CGColor
        
    }

// MARK:- Other Of Call Back Delgates
    
    func setTheLocation(){
        if mapView != nil{
               btnAddress.setTitle(mapView.strAdress, forState: .Normal)
                self.toSelectBtnValidation()
        }
    }
    
// MARK:- Buutons Delegate

    @IBAction func toAddressBtn(sender: AnyObject) {
        
        let controller = GooglePlacesSearchController(
            apiKey: Constants.ServerKeyGoogle,
            placeType: PlaceType.All
        )
        
        controller.didSelectGooglePlace { (place) -> Void in
            if let placeObj:PlaceDetails = place{
//                self.addressViaPlaceAPI = AddressBO()
//                self.addressViaPlaceAPI.addressName = placeObj.formattedAddress
//                self.addressViaPlaceAPI.addressType = "Other Type"
//                self.addressViaPlaceAPI.country = placeObj.country
//                self.addressViaPlaceAPI.unit = "2"
//                self.addressViaPlaceAPI.city = placeObj.subLocality
//                self.addressViaPlaceAPI.state = placeObj.locality
//                self.addressViaPlaceAPI.zipCode = placeObj.postalCode
//                self.addressViaPlaceAPI.streetAddress = placeObj.streetNumber
//                self.addressViaPlaceAPI.locationCords = placeObj.coordinate
//                self.addressViaPlaceAPI.isPrimary = false
                self.mapView.mapView.camera = GMSCameraPosition.cameraWithTarget(placeObj.coordinate , zoom: 15)
//                self.btnAddress.setTitle(self.addressViaPlaceAPI.addressName, forState: .Normal)
            }
            
            //Dismiss Search
            controller.active = false
        }
        
        presentViewController(controller, animated: true, completion: nil)
    }
//    name: String    formattedAddress: formattedPhoneNo: coordinate: CLLoc streetNumber route locality subLocality administrativeAre administrativeAre subAdministrative postalCode country
//    ISOcountryCode   
//    state
    
    @IBAction func toSaveAddress(sender: AnyObject) {
        
        
        if self.txtAddType.text?.length > 0
        {
            if self.btnAddress.currentTitle?.length > 0 && self.btnAddress.currentTitle != "Address"{
                let addressBO = self.assignAddressFromMap()
//                if addressViaPlaceAPI != nil{
//                    if self.btnAddress.currentTitle == addressViaPlaceAPI?.addressName{
//                        addressBO = self.addressViaPlaceAPI
//                    }
//                }
                
                if let liftRequstVC:LiftRequestVC = self.fetchPreviousControllerFromNavigationStack(2) as? LiftRequestVC{
                
                    if liftRequstVC.locType == .FromLocation{
                        if liftRequstVC.toLocationData != nil{
                            if liftRequstVC.toLocationData!.locationCords.latitude ==  addressBO.locationCords.latitude && liftRequstVC.toLocationData!.locationCords.longitude ==  addressBO.locationCords.longitude{
                                NSIUtility.show("Both Location should not be same")
                                return
                            }else if liftRequstVC.toLocationData!.streetAddress == addressBO.streetAddress {
                                NSIUtility.show("Both Location should not be same")
                            }
                        }
                    }else{
                        if liftRequstVC.fromLocationData != nil{
                            if liftRequstVC.fromLocationData!.locationCords.latitude ==  addressBO.locationCords.latitude && liftRequstVC.fromLocationData!.locationCords.longitude ==  addressBO.locationCords.longitude
                            {
                                NSIUtility.show("Both Location should not be same")
                                return
                            }else if liftRequstVC.fromLocationData!.streetAddress == addressBO.streetAddress {
                                NSIUtility.show("Both Location should not be same")
                            }
                        }
                    }
                    
                    
                    if liftRequstVC.locType == .FromLocation{
                            liftRequstVC.fromLocationData = addressBO
                        }else{
                            liftRequstVC.toLocationData = addressBO
                        }
                    
                    self.navigationController?.popToViewController(liftRequstVC, animated: true)
                    
//                    let userDL:UserDL = UserDL()
//                    userDL.requestForCreateAddress(addressBO, handler: { (obj, success) -> Void in
//                        if success == true{
//                            NSIUtility.show("Address is created succesfully")
//                            
//                                if liftRequstVC.locType == .FromLocation{
//                                    liftRequstVC.fromLocationData = addressBO
//                                }else{
//                                    liftRequstVC.toLocationData = addressBO
//                                }
//                                self.navigationController?.popToViewController(liftRequstVC, animated: true)
//                            
//                            
//                        }else{
//                            NSIUtility.show(Constants.kSomethingWrong)
//                        }
//                    })
                }
            }else{
                NSIUtility.show("Please enter an address or drag the map around")
            }
        }else{
            NSIUtility.show("Please enter the type of Address")
        }
        
    }
    
    func assignAddressFromMap() -> AddressBO{
        let addressBO  = AddressBO()
//        addressBO.addressName = NSIUtility.safeInsert(self.mapView.strAdress, objectType: .StringType) as! String
        addressBO.addressType = NSIUtility.safeInsert(self.txtAddType.text, objectType: .StringType) as! String
        addressBO.country = NSIUtility.safeInsert(self.mapView.addressData.country, objectType: .StringType) as! String
        addressBO.city = NSIUtility.safeInsert(self.mapView.addressData.subLocality, objectType: .StringType) as! String
        addressBO.unit = "2"
        addressBO.state = NSIUtility.safeInsert(self.mapView.addressData.locality, objectType: .StringType) as! String
        addressBO.zipCode = NSIUtility.safeInsert(self.mapView.addressData.postalCode, objectType: .StringType) as! String
        addressBO.isPrimary = false
        addressBO.streetAddress = NSIUtility.safeInsert(self.mapView.strAdress, objectType: .StringType) as! String
        
        addressBO.locationCords = self.mapView.addressData.coordinate
        addressBO.addressName  = "Home"
        return addressBO
    }
    
    //MARK: - Text Field Delegates
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
        return UITextField.textField(textField, shouldChangeCharactersInRange: range, replacementString: string,
            withMaxLength: UITextField.MaxLength.DefaultMax, spaceAllowed: false)
        
    }
    
    func toSelectBtnValidation()
    {
        if (self.txtAddType.text?.length > 0 && self.btnAddress.currentTitle != "Address" && self.btnAddress.currentTitle != "" ){
            btnSaveAddress.backgroundColor = Constants.APP_THEME_COLOR
        }
        else{
            btnSaveAddress.backgroundColor = UIColor.colorWithRGB(31, green: 81, blue: 108, alpha:0.7)
        }
    }
}


