//
//  ChatList.swift
//  Aashiqui
//
//  Created by ketan saini on 09/11/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class ChatList: NSObject {
    /*
    {
    "messageId": "17720",
    "messageText": "Hi, how are you..",
    "personId": "2850",
    "personFirstName": "Nitin",
    "personLastName": "Saluja",
    "personProfilePicUrl": "",
    "minutesAgo": "46"
    }
   */
    var messageId:String!
    var messageText:String!
    var personId:String!
    var personFirstName:String!
    var personLastName:String!
    var personProfilePicUrl:String!
    var minutesAgo:String!
    
    
    // MARK: NSCoding
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.messageId = (decoder.decodeObjectForKey("messageId") as! String?)!
        self.messageText = (decoder.decodeObjectForKey("messageText") as! String?)!
        self.personId = (decoder.decodeObjectForKey("personId") as! String?)!
        self.personFirstName = (decoder.decodeObjectForKey("personFirstName") as! String?)!
        self.personLastName = (decoder.decodeObjectForKey("personLastName") as! String?)!
        self.personProfilePicUrl = (decoder.decodeObjectForKey("personProfilePicUrl") as! String?)!
        self.minutesAgo = (decoder.decodeObjectForKey("minutesAgo") as! String?)!
        
    }
    
    func encodeWithCoder(coder: NSCoder) {
        coder.encodeObject(self.messageId, forKey: "messageId")
        coder.encodeObject(self.messageText, forKey: "messageText")
        coder.encodeObject(self.personId, forKey: "personId")
        coder.encodeObject(self.personFirstName, forKey: "personFirstName")
        coder.encodeObject(self.personLastName, forKey: "personLastName")
        coder.encodeObject(self.personProfilePicUrl, forKey: "personProfilePicUrl")
        coder.encodeObject(self.minutesAgo, forKey: "minutesAgo")
    }
    
    func fillDataInModel(arrData: NSArray) -> NSMutableArray {
        let arrListData: NSMutableArray! = []
        for dict in arrData{
            let objChatList = ChatList()
            objChatList.messageId = dict.valueForKey("messageId") as! String
            objChatList.personId = dict.valueForKey("personId") as! String
            objChatList.personFirstName = dict.valueForKey("personFirstName") as! String
            objChatList.personLastName = dict.valueForKey("personLastName") as! String
            objChatList.minutesAgo = dict.valueForKey("minutesAgo") as! String
            if (dict.valueForKey("userProfilePicUrl")?.isKindOfClass(NSNull) != true){
                objChatList.personProfilePicUrl = dict.valueForKey("personProfilePicUrl") as! String
            }else{
                objChatList.personProfilePicUrl = ""
            }
            if (dict.valueForKey("messageText")?.isKindOfClass(NSNull) != true){
                objChatList.messageText = dict.valueForKey("messageText") as! String
            }else{
                objChatList.messageText = ""
            }
            arrListData.addObject(objChatList)
        }
        return arrListData
    }
}
