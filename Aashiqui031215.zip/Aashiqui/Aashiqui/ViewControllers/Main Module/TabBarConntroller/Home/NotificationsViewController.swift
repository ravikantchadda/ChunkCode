//
//  NotificationsViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 16/11/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class NotificationsViewController: UIViewController {
    @IBOutlet weak var tblNotificationsList: UITableView!
    var arrNotificationListData: NSMutableArray! = []
    var pageNotification = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationItem.titleView = Utility.navBarTitleLabel("Notifications")
        self.navigationItem.title = ""
//        self.navigationItem.hidesBackButton = true
//        self.navigationItem.leftBarButtonItem = Utility.navBarLeftButton(UIImage(named: "btnBack")!, viewController: self)
        tblNotificationsList.tableFooterView = UIView(frame: CGRectZero)
        tblNotificationsList.addInfiniteScrollingWithHandler {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), { () ->  Void in
                self.pageNotification += 1
                let dict:NSDictionary = [
                    "userId": NSIConstants.userDefaults.valueForKey("userId") as! String,
                    "page": "\(self.pageNotification)"
                ]
                print("\(dict)")
                if (Utility.checkNetwork() == true){
                    self.fnGetNotificationListWebServiceWithPostDic(dict, showLoader: false)
                }
            })
        }
    }

    // MARK: - NavigationBar LeftBarButton Method
    func fnLeftBarButton(){
        self.navigationController?.popViewControllerAnimated(true)
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        if self.arrNotificationListData != nil {
            self.arrNotificationListData.removeAllObjects()
        }
        pageNotification = 1
        if let userId = NSIConstants.userDefaults.valueForKey("userId") {
            let dict:NSDictionary = [
                "userId": userId,
                "page": "\(self.pageNotification)"
            ]
            print("\(dict)")
            if (Utility.checkNetwork() == true){
                self.fnGetNotificationListWebServiceWithPostDic(dict, showLoader: true)
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Webservice Call Methods
    //Get Notifications List API
    func fnGetNotificationListWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
//        ObjWebserviceCall.cachePolicy = WebserviceCallCachePolicyRequestFromCacheFirstAndThenFromUrlAndUpdateInCache
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceGetNotificationList)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("GetList--- \(response.webserviceResponse)")
                
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    let arrData = response.webserviceResponse.valueForKey("notificationsList") as! NSArray
                    let arrModelData = NotificationList().fillDataInModel(arrData)
                    arrModelData.enumerateObjectsUsingBlock({ object, index, stop in
                        self.arrNotificationListData.addObject(arrModelData.objectAtIndex(index))
                    })
                    if self.arrNotificationListData.count == 0 {
                        let lblMsg = UILabel(frame: CGRectMake(0, 0, self.tblNotificationsList.frame.size.width, 50))
                        lblMsg.center = self.tblNotificationsList.center
                        lblMsg.text = "No notification found."
                        lblMsg.numberOfLines = 0
                        lblMsg.textAlignment = NSTextAlignment.Center
                        lblMsg.font = UIFont(name: "Lato-Regular", size: 16)
                        lblMsg.textColor = UIColor.blackColor()
                        self.tblNotificationsList.backgroundView = lblMsg
                        self.tblNotificationsList.scrollEnabled = false
                    }else{
                        self.tblNotificationsList.backgroundView = nil
                        self.tblNotificationsList.scrollEnabled = true
                    }
                    
                }else{
                    
                    if self.arrNotificationListData.count == 0 {
                        let lblMsg = UILabel(frame: CGRectMake(0, 0, self.tblNotificationsList.frame.size.width, 50))
                        lblMsg.center = self.tblNotificationsList.center
                        lblMsg.text = "No notification found."
                        lblMsg.numberOfLines = 0
                        lblMsg.textAlignment = NSTextAlignment.Center
                        lblMsg.font = UIFont(name: "Lato-Regular", size: 16)
                        lblMsg.textColor = UIColor.blackColor()
                        self.tblNotificationsList.backgroundView = lblMsg
                        self.tblNotificationsList.scrollEnabled = false
                    }else{
                        self.tblNotificationsList.backgroundView = nil
                        self.tblNotificationsList.scrollEnabled = true
                    }
                    
                    if response.webserviceResponse.valueForKey("status") as! String != "No more data" {
                        Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                    }
                }
                self.tblNotificationsList.reloadData()
                self.tblNotificationsList.infiniteScrollingView?.stopAnimating()
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }

    //MARK: - TableView DataSource/Delegate
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (arrNotificationListData != nil){
            return arrNotificationListData.count
        }
        return 0
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if(tableView.respondsToSelector(Selector("setSeparatorInset:"))){
            tableView.separatorInset = UIEdgeInsetsZero
        }
        if(tableView.respondsToSelector(Selector("setLayoutMargins:"))){
            tableView.layoutMargins = UIEdgeInsetsZero
        }
        if(cell.respondsToSelector(Selector("setLayoutMargins:"))){
            cell.layoutMargins = UIEdgeInsetsZero
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(
            "cellNotification", forIndexPath: indexPath)
        
        let objNotificationList:NotificationList = self.arrNotificationListData.objectAtIndex(indexPath.row) as! NotificationList
        
        //UIImage Profile Image
        if let imgVwProfile:AsyncImageView = cell.viewWithTag(1001) as? AsyncImageView {
            imgVwProfile.image = UIImage(named: "placeholder")
            if let variableName: String = objNotificationList.userProfilePicUrl{
                imgVwProfile.crossfadeDuration = 0.0
                imgVwProfile.imageURL = NSURL(string: variableName)
            }
        }
        if let lblTime = cell.viewWithTag(1003) as? UILabel {
            let strSec: NSInteger = Int(objNotificationList.minutesAgo)! * 60
            let date = NSDate(timeInterval: NSTimeInterval(-strSec), sinceDate: NSDate())
            lblTime.text = Utility.relativeDateStringForDate(date)
        }
        
        if let lblMsg = cell.viewWithTag(1002) as? UILabel {
            lblMsg.text = objNotificationList.notificationText
        }
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let objNotificationList:NotificationList = self.arrNotificationListData.objectAtIndex(indexPath.row) as! NotificationList
        if objNotificationList.notificationType == "FR" {
            let objPairingRequestVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("RespondPairReqViewController") as! RespondPairReqViewController
            self.navigationController!.pushViewController(objPairingRequestVC, animated: true)
        }
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
