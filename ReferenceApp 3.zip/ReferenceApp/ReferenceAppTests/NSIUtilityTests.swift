//
//  NSIUtilityTests.swift
//  ReferenceApp
//
//  Created by ravi kant on 11/18/15.
//  Copyright © 2015 Netsol. All rights reserved.
//

import XCTest
@testable import ReferenceApp
class NSIUtilityTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
        }
    }
    
    func testGetObjectForKey() {
               let dictDummy:NSDictionary! = ["hello":""]
                let keyDummy:String! = "hello"
               let value:AnyObject! =  NSIUtility.getObjectForKey(keyDummy,dictResponse: dictDummy)
        
              // XCTAssertEqual(value as? String,"abc" ,"Pass")
    }
    
    //MARK: - Test Case for UserDefaults
    
    func testcheckIfStringContainsText(){
        let bool = NSIUtility.checkIfStringContainsText("11")
        XCTAssert(bool == true, "Pass")
        
        
    }
    
    //MARK: - Test Case for UserDefaults
    
    func testUserDefaults(){
        
        NSIUtility.setValueToUserDefaultsForKey("KeyValue", value: "123")
        let bool = NSIUtility.getValueFromUserDefaultsForKey("KeyValue")
        XCTAssert(bool != nil, "Pass")
        
        
    }
    
    //MARK: - Test Case for Validate Number
    /*
    *** If user enter String value as "AAA" than test case will falied
    *** If User enter Number+String value as "AAAA1111" than test case will falied
    *** If User enter Number+Special Character value as "AAAA+@1111" than test case will falied
    *** If User enter only Numaric Value as "123" than test case will success
    */
    
    func testValidateNumber(){
        
        let number: String! = "91"
         XCTAssert(NSIUtility.validateNumber(number), "Pass")
    
    
    }
    
    
    //MARK: - Test Case for URL validation
    
    func testValidateURL() {
        //let url:String! = "www.google.com"//"一.一一"
        let url:String! = "www.google"//"一.一一"
        XCTAssert(NSIUtility.validateURL(url), "Pass")
    }
    
    //MARK: - Test Case for Calculate Password Strength
    
    /**
    * The strength method implements the Truong3 Password Strength Algorithm, which
    * determines if the password contains:
    * . at least 6 characters
    * . at least one upper and one lower case Latin alphabet character
    * . at least one numerical character
    * . at least one special character
    */
    
    func testCalculatePasswordStrengthForWeak() {
        // This is an example of a functional test case.
        let password:String! = "aaa1aaa@aa!"
        let stregth:PasswordStrength = NSIUtility.calculatePasswordStrength(password)
        
        XCTAssertEqual(stregth,PasswordStrength.VERY_STRONG ,"Pass")
    }
    //Medium
    func testCalculatePasswordStrengthForMedium() {
        // This is an example of a functional test case.
        let password:String! = "154541"
        let stregth:PasswordStrength = NSIUtility.calculatePasswordStrength(password)
        
        XCTAssertEqual(stregth,PasswordStrength.MEDIUM ,"Pass")
    }
    
    //Strong
    func testCalculatePasswordStrengthForStrong() {
        // This is an example of a functional test case.
        let password:String! = "1111@@@"//"123Aa"
        let stregth:PasswordStrength = NSIUtility.calculatePasswordStrength(password)
        
        XCTAssertEqual(stregth,PasswordStrength.STRONG ,"Pass")
    }
    
    //Very Strong
    func testCalculatePasswordStrengthForVeryStrong() {
        // This is an example of a functional test case.
        let password:String! = "ravi@321"//"التلفزيون٪@"//"一個箭步十二十年寒窗？但他@電話@電電電佰六廿念‎"//"Aaaaaaaaaa1"
        let stregth:PasswordStrength = NSIUtility.calculatePasswordStrength(password)
        
        XCTAssertEqual(stregth,PasswordStrength.VERY_STRONG ,"Pass")
    }
    
    //Crazy Strong
    func testCalculatePasswordStrengthForCrazyStrong() {
        // This is an example of a functional test case.
        let password:String! = "&!)$###123"
        let stregth:PasswordStrength = NSIUtility.calculatePasswordStrength(password)
        
        XCTAssertEqual(stregth,PasswordStrength.CRAZY_STRONG ,"Pass")
    }

    
}
