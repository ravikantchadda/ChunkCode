//
//  CountryCodeVC.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/3/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class CountryCodeVC: BaseViewController,UITableViewDataSource,UITableViewDelegate {

    @IBOutlet var tableOfCountry: UITableView!
    @IBOutlet var searchBarOfCountry: UISearchBar!
    var arrayOfCountry = NSArray()
    var filteredCountryArray = NSArray()
    var searchActive : Bool = false
    
    
//MARK: - View Life Cycle Methods
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBar(NavigationType.BlueNavigationType)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.initialInitialization()

        // Do any additional setup after loading the view.
    }

    func initialInitialization()
    {
        tableOfCountry.registerNib(UINib(nibName: "CountryCodeCell", bundle: nil) , forCellReuseIdentifier: "countryCell")
        self.fetchCountryCodeFromServices()
    }
    
    func fetchCountryCodeFromServices()
    {
        let countryDL = CountryDL()
        countryDL.requestforCountryCode { (obj, success) -> Void in
            if success == true
            {
                self.arrayOfCountry = obj as! NSArray
                self.tableOfCountry.delegate = self
                self.tableOfCountry.dataSource = self
                self.tableOfCountry.reloadData()
            }
        }
    }
    
//MARK: - Table VIew Delegates
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searchActive == true{
            return filteredCountryArray.count
        }
        else{
            return arrayOfCountry.count
        }
    }

    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell:CountryCodeCell = (tableView.dequeueReusableCellWithIdentifier("countryCell", forIndexPath: indexPath) as? CountryCodeCell)!
        
        let countryObj:CountryCodeBO
        
        if searchActive == false{
            countryObj = arrayOfCountry[indexPath.row] as! CountryCodeBO
        }
        else{
            countryObj = filteredCountryArray[indexPath.row] as! CountryCodeBO
        }
        
        cell.countryName.text = countryObj.countryName
        cell.countryCode.text =  String(countryObj.countryCode)
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let countryObj:CountryCodeBO
        if searchActive == false{
            countryObj = arrayOfCountry[indexPath.row] as! CountryCodeBO
        }
        else{
            countryObj = filteredCountryArray[indexPath.row] as! CountryCodeBO
        }
        
        let signUPVCObj:SignUpVC = self.lastViewController() as! SignUpVC
        signUPVCObj.countryObj = countryObj
        self.navigationController!.popViewControllerAnimated(true)
        
    }
    
//MARK: - Search Bar Delegates
    
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        if(filteredCountryArray.count == 0){searchActive = false;} else {searchActive = true;}}
    
    func searchBarTextDidEndEditing(searchBar: UISearchBar) {searchActive = false}
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {searchActive = false; self.view.endEditing(true); self.tableOfCountry.reloadData(); searchBar.text = ""}
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {searchActive = false;self.view.endEditing(true)}
    
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        
        let predicate:NSPredicate = NSPredicate(format: "(countryName CONTAINS[c] %@ OR countryCode CONTAINS[c] %@)", argumentArray:[searchText,searchText])
        
        filteredCountryArray = self.arrayOfCountry.filteredArrayUsingPredicate(predicate) as NSArray
        
        if(filteredCountryArray.count == 0){
            searchActive = false;
        } else {
            searchActive = true;
        }
        self.tableOfCountry.reloadData()
    }

}
