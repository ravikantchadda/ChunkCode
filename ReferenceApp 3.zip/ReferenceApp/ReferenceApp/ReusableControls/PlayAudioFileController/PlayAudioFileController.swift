//
//  PlayAudioFileController.swift
//  ReferenceApp
//
//  Created by ravi kant on 11/19/15.
//  Copyright © 2015 Netsol. All rights reserved.
//

import UIKit
import AVFoundation
class PlayAudioFileController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // MARK: - Method to Play Audiofile From server
    func PlayAudioFileFromServer() {
        
        
        let urlAudio = NSURL(string: "http://gsu-miscwork02-qa.netsol.in/images/2798/audio/fae81cfab1ad53f470cce584e6b76a6d-aud-.mp3")!
        let request = NSURLRequest(URL: urlAudio)
        
        let session =  NSURLSession.sharedSession()
        
        let task = session.dataTaskWithRequest(request, completionHandler: {data, response, error -> Void in
            print("Response: \(response)")
            
            if error != nil {
                
                print("There was an error")
                
            } else {
                self.prepareYourSound(data!)
                self.myPlayer.play()
                
            }
            
        })
        
        task.resume()
        
    }
    
    var myPlayer = AVAudioPlayer()
    var yourSound:NSURL?
    func prepareYourSound(myData:NSData) {
        
        
        do {
            try myPlayer = AVAudioPlayer(data: myData, fileTypeHint: nil)
            myPlayer.prepareToPlay()
        }
        catch let error as NSError {
            error.description
        }
        
    }
    
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
