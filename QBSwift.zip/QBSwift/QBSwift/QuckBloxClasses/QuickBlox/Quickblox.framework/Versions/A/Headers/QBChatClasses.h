//
//  Classes.h
//  Chat
//
//  Created by IgorKh on 9/12/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

#import <Quickblox/QBChatDefinitions.h>
#import <Quickblox/QBChatBusiness.h>