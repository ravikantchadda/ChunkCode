//
//  LinkedIn.swift
//  ReferenceApp
//
//  Created by ravi kant on 11/26/15.
//  Copyright © 2015 Netsol. All rights reserved.
//

import Foundation
import LinkedinSwift


/**
*  Init with settings
*
*  @param clientId     Linkedin client id
*  @param clientSecret Linkedin client secret
*  @param state        state to identify each oauth redirect calls, make a unique one
*  @param permisssions Linkedin permissions to ask
*  @param redirectUrl  Linkedin oauth redirect url
*
*  @return LinkedinSwiftConfiguration
*/

let linkedinHelper = LinkedinSwiftHelper(configuration: LinkedinSwiftConfiguration(clientId: "755pyd40koa81y", clientSecret: "yvHoDrljGeO5xfbD", state: "DLKDJF45sd6ikMMZI", permissions: ["r_basicprofile", "r_emailaddress"], redirectUrl: "http://www.netsolutionsindia.com"))

var linkedToken =  LSLinkedinToken()

class LinkedIn: NSObject
{
    
    var responseBlock:CompleteSocialLoginBlock?
    
    //MARK: - Log In With Linked In
    func signInWithLinkedIn(successBlock:CompleteSocialLoginBlock)
    {
        
        responseBlock = successBlock
        linkedinHelper.authorizeSuccess({ (lsToken) -> Void in
            
            print("Login success lsToken: \(lsToken)")
            
             linkedToken = lsToken
            
            
            
            self.requestProfile()
            
            }, error: {  (error) -> Void in
                print("Encounter error: \(error.localizedDescription)")
            }, cancel: { () -> Void in
                
                print("User Cancelled!")

            })
        
    }
    
     //MARK: - Method to Get UserProfile
    func requestProfile() {
        
        linkedinHelper.requestURL("https://api.linkedin.com/v1/people/~:(id,first-name,last-name,email-address,picture-url,picture-urls::(original),positions,date-of-birth,phone-numbers,location)?format=json", requestType: LinkedinSwiftRequestGet, success: { (response) -> Void in
            
               // print("Request success with response: \(response)")
            let objResponse: LSResponse = response as LSResponse
            
            NSIUtility.DBlog(objResponse.jsonObject)
            
            let objDict = objResponse.jsonObject as NSDictionary
            
            NSIUtility.setValueToUserDefaultsForKey("userimageurl", value: objDict.valueForKey("pictureUrl"))
            NSIUtility.setValueToUserDefaultsForKey("username", value: objDict.valueForKey("firstName"))
            
            
            let accessToken = linkedToken.accessToken as String

            self.responseBlock!(true,LoginType.LoginSourcetypeLinkedIn, accessToken)
            
            }) { (error) -> Void in
                
               print("Encounter error: \(error.localizedDescription)")
        }
    }
    
    //MARK: - Method to Logout

    func logout(){
       
       
    }
    
    
    
}