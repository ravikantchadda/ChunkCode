//
//  RegisterViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 18/09/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit

class RegisterViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIActionSheetDelegate, UserSuggestionsDelegate {
    
    @IBOutlet weak var scrollVw_Container: UIScrollView!
    @IBOutlet weak var btnTakePicture: UIButton!
    @IBOutlet weak var txtFirstName: UITextField!
    @IBOutlet weak var txtLastName: UITextField!
    @IBOutlet weak var txtUsername: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPhoneNo: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtConfirmPassword: UITextField!
    @IBOutlet weak var vwContainerObj: UIView!
    let loader = Loader()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.navigationController?.navigationBarHidden = false
        self.navigationItem.leftBarButtonItem = Utility.navBarLeftButton(UIImage(named: "btnBack")!, viewController: self)
        self.navigationItem.titleView = Utility.navBarTitleLabel("Sign Up")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillLayoutSubviews() {
        
        scrollVw_Container.contentSize = CGSizeMake(290, 550)
    }
    
    // MARK: - NavigationBar LeftBarButton Method
    func fnLeftBarButton(){
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    // MARK: - UITextField Delegate Method
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        let nextTag:NSInteger = textField.tag + 1
        // Try to find next responder
        let nextResponder = textField.superview?.viewWithTag(nextTag)
        if (nextResponder != nil){
            nextResponder!.becomeFirstResponder()
        }else{
            textField.resignFirstResponder()
        }
        return true
    }
    func textFieldDidBeginEditing(textField: UITextField) {
        
    }
    func textFieldDidEndEditing(textField: UITextField) {
        if textField == txtUsername {
            if Utility.checkIfStringContainsText(txtUsername.text){
                let dict:NSDictionary = [
                    "userName": txtUsername.text!
                ]
                print("\(dict)")
                self.fnUsernameSuggestionWebServiceWithPostDic(dict, showLoader: true)
            }
        }
    }
    
    
    // MARK: - UIButton Action
    @IBAction func btnTapped_SignUp(sender: AnyObject) {
        self.view.endEditing(true)
        let strError = fnCheckValidation()
        if strError == ""{
            let dict:NSDictionary = [
                "userName": txtUsername.text!,
                "firstName": txtFirstName.text!,
                "lastName": txtLastName.text!,
                "phone": txtPhoneNo.text!,
                "password": txtPassword.text!,
                "email": txtEmail.text!
            ]
            print("\(dict)")
            fnSignUpWebServiceWithPostDic(dict)
            
        }else{
            Utility.showAlert("", message: strError as String, delegate: nil)
        }
        
    }
    @IBAction func btnPressed_termsCondition(sender: AnyObject) {
        let objTerms: TermsViewController = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("TermsViewController") as! TermsViewController
        self.navigationController!.pushViewController(objTerms, animated: true)
    }
    
    @IBAction func btnTapped_TakePic(sender: AnyObject) {
        self.view.endEditing(true)
//        if #available(iOS 8.0, *) {
            let objOptionMenu = UIAlertController(title: nil, message: "Choose Option", preferredStyle: .ActionSheet)
            let cameraAction = UIAlertAction(title: "Camera", style: .Default, handler: {
                (alert: UIAlertAction) -> Void in
                self.fnOpenCamera()
            })
            
            let galleryAction = UIAlertAction(title: "Gallery", style: .Default, handler: {
                (alert: UIAlertAction) -> Void in
                self.fnOpenPhotoGallery()
            })
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: {
                (alert: UIAlertAction) -> Void in
                
            })
            
            objOptionMenu.addAction(cameraAction)
            objOptionMenu.addAction(galleryAction)
            objOptionMenu.addAction(cancelAction)
            
            self.presentViewController(objOptionMenu, animated: true, completion: nil)
//        } else {
//            // Fallback on earlier versions
//            let objActionSheet = UIActionSheet()
//            objActionSheet.title = "Choose Option"
//            objActionSheet.addButtonWithTitle("Camera")
//            objActionSheet.addButtonWithTitle("Gallery")
//            objActionSheet.addButtonWithTitle("Cancel")
//            objActionSheet.cancelButtonIndex = 2
//            objActionSheet.tag = 2356
//            objActionSheet.delegate = self
//            objActionSheet.showInView(self.view)
//        }
        
    }
    
    @IBAction func btnPressed_FacebookLogin(sender: AnyObject) {
        self.view.endEditing(true)
        let fbLogin = FBSDKLoginManager()
        fbLogin.logOut()
        fbLogin .logInWithReadPermissions(["email"], handler: { (result, error) -> Void in
            if (error == nil){
                let fbloginresult : FBSDKLoginManagerLoginResult = result
                if fbloginresult.isCancelled {
                    // Handle cancellations
                    print("isCancelled\(result.isCancelled)")
                    
                }else if(fbloginresult.grantedPermissions.contains("email"))
                {
                    self.getFBUserData()
                }
            }
        })
    }
    
    func getFBUserData(){
        if((FBSDKAccessToken.currentAccessToken()) != nil){
            loader.showLoader()
            FBSDKGraphRequest(graphPath: "me", parameters: ["fields": "id, name, first_name, last_name, picture.type(large), email"]).startWithCompletionHandler({ (connection, result, error) -> Void in
                if (error == nil){
                    self.loader.hideLoader()
                    print(result)
                    let dict:NSDictionary = [
                        "firstName": result.valueForKey("first_name")!,
                        "lastName": result.valueForKey("last_name")!,
                        "phone": "",
                        "fbId": result.valueForKey("id")!,
                        "email": result.valueForKey("email")!,
                        "profilePic": result.valueForKey("picture")!.valueForKey("data")!.valueForKey("url")!
                    ]
                    print("\(dict)")
                    self.fnFBSignInWebServiceWithPostDic(dict)
                }else{
                    self.loader.hideLoader()
                }
            })
        }
    }
    
    func actionSheet(myActionSheet: UIActionSheet, clickedButtonAtIndex buttonIndex: Int){
        if(myActionSheet.tag == 2356){
            
            if (buttonIndex == 0){
                print("the index is 0")
                self.fnOpenCamera()
            }
            if (buttonIndex == 1){
                print("the index is 1")
                self.fnOpenPhotoGallery()
            }
            if (buttonIndex == 2){
                print("the index is 2")
            }
        }
    }
    func fnOpenCamera() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera)
        {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.allowsEditing = true
            imagePicker.sourceType = UIImagePickerControllerSourceType.Camera;
            self.presentViewController(imagePicker, animated: true, completion: nil)
            
        }else{
            Utility.showAlert("", message: "Camera not available." as String, delegate: nil)
        }
    }
    
    func fnOpenPhotoGallery() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.PhotoLibrary){
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.allowsEditing = true
            imagePicker.sourceType = UIImagePickerControllerSourceType.PhotoLibrary;
            self.presentViewController(imagePicker, animated: true, completion: nil)
            
        }else{
            Utility.showAlert("", message: "Gallery not available." as String, delegate: nil)
        }
    }
    
    
    // MARK: - UIImagePickerControllerDelegate Methods
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        UIApplication.sharedApplication().statusBarStyle = .LightContent
        if let pickedImage = info[UIImagePickerControllerEditedImage] as? UIImage {
            btnTakePicture .setBackgroundImage(Utility.RBResizeImage(pickedImage, targetSize: CGSizeMake(640, 640)), forState: UIControlState.Normal)
        }
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    // MARK: - Webservice Call Methods
    // SignUp API
    func fnSignUpWebServiceWithPostDic(dict: NSDictionary!) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        ObjWebserviceCall.isShowLoader = true
        if let DToken = NSIConstants.userDefaults.valueForKey("DEVICETOKEN") {
            
            ObjWebserviceCall.headerFieldsDict = ["DEVICETOKEN":DToken, "DEVICETYPE":"2", "APPTOKEN":"I8I23NJA89NS8NW293NA8SN383F5H7J8"]
            
        }else{
            ObjWebserviceCall.headerFieldsDict = ["DEVICETOKEN":"y6734y78rt334y734y785yt3897ty3893t35", "DEVICETYPE":"2", "APPTOKEN":"I8I23NJA89NS8NW293NA8SN383F5H7J8"]
        }
        ObjWebserviceCall.parametersDict = dict! as [NSObject : AnyObject]
        var imgData: NSData? = nil
        var arrData: NSArray = []
        if((btnTakePicture.backgroundImageForState(.Normal)) != nil){
            imgData = UIImagePNGRepresentation((btnTakePicture.backgroundImageForState(.Normal))!)!
            let dictData: NSMutableDictionary = NSMutableDictionary()
            dictData.setValue("profilePic", forKey: "fileKey")
            dictData.setValue("image.png", forKey: "fileName")
            dictData.setValue("image/png", forKey: "contentType")
            dictData.setValue(imgData, forKey: "data")
            arrData = [dictData]
        }
        /*
        fileKey = "image/audio"
        fileName = "image.png/audio.m4a"
        contentType = "image/png,audio/m4a"
        data = "data"
        */
        
        ObjWebserviceCall.uploadDataWithImage(arrData as [AnyObject] , onUrl: NSURL(string: "\(BASE_URL+WebserviceSignUp)"), withSuccessHandler: { (response: WebserviceResponse!) -> Void in
            let response = response
            print("\(response.webserviceResponse)")
            if (response.webserviceResponse != nil) {
            if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                let objLogin = Login()
                objLogin.userUserName = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("nickName") as! String
                objLogin.userFirstName = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("firstName") as! String
                objLogin.userLastName = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("lastName") as! String
                objLogin.userEmail = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("email") as! String
                objLogin.userId = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("userId") as! String
                objLogin.userDeviceId = "ewew2323ewew"
                objLogin.userAuthToken = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("authToken") as! String
                objLogin.userPost = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("feeds") as! NSArray
            NSIConstants.userDefaults.setValue(response.webserviceResponse.valueForKey("userDetail")?.valueForKey("userType") as! String, forKey: "userType")
                NSIConstants.userDefaults.synchronize()
                
                let objTabBarViewController = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("TabBarViewController") as! TabBarViewController
                let objNavigationHome = objTabBarViewController.viewControllers![0] as! UINavigationController
                let objHome: HomeViewController = objNavigationHome.viewControllers.first as! HomeViewController
                objHome.objLoginModel = objLogin
                self.navigationController!.pushViewController(objTabBarViewController, animated: false)
            }else{
                Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
            }
            }
            })
            { (error: NSError!) -> Void in
                let error = error
                print("\(error)")
        }
    }
    
    // Facebook Login API
    func fnFBSignInWebServiceWithPostDic(dict: NSDictionary!) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        ObjWebserviceCall.isShowLoader = true
        if let DToken = NSIConstants.userDefaults.valueForKey("DEVICETOKEN") {
            ObjWebserviceCall.headerFieldsDict = ["DEVICETOKEN":DToken, "DEVICETYPE":"2", "APPTOKEN":"I8I23NJA89NS8NW293NA8SN383F5H7J8"]
        }else{
            ObjWebserviceCall.headerFieldsDict = ["DEVICETOKEN":"y6734y78rt334y734y785yt3897ty3893t35", "DEVICETYPE":"2", "APPTOKEN":"I8I23NJA89NS8NW293NA8SN383F5H7J8"]
        }
        ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceFBlogin)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
            let response = response
            print("\(response.webserviceResponse)")
            
            if (response.webserviceResponse != nil) {
            if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                let objLogin = Login()
                objLogin.userUserName = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("nickName") as! String
                objLogin.userFirstName = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("firstName") as! String
                objLogin.userLastName = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("lastName") as! String
                objLogin.userEmail = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("email") as! String
                objLogin.userId = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("userId") as! String
                objLogin.userDeviceId = "ewew2323ewew"
                objLogin.userAuthToken = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("authToken") as! String
                objLogin.userPost = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("feeds") as! NSArray
            NSIConstants.userDefaults.setValue(response.webserviceResponse.valueForKey("userDetail")?.valueForKey("userType") as! String, forKey: "userType")
                NSIConstants.userDefaults.synchronize()
                
                let objTabBarViewController = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("TabBarViewController") as! TabBarViewController
                let objNavigationHome = objTabBarViewController.viewControllers![0] as! UINavigationController
                let objHome: HomeViewController = objNavigationHome.viewControllers.first as! HomeViewController
                objHome.objLoginModel = objLogin
                self.navigationController!.pushViewController(objTabBarViewController, animated: false)
            }else{
                self.txtUsername.text = ""
                self.txtPassword.text = ""
                Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
            }
            }
            }) { (error: NSError!) -> Void in
        }
    }
    
    //Get username suggestion API
    func fnUsernameSuggestionWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceGetAutoSuggestion)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("UsernameSuggestion--- \(response.webserviceResponse)")
                
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2004){
                    self.view.endEditing(true)
                    let arrSuggestions = response.webserviceResponse.valueForKey("suggestions") as! NSArray
                    if arrSuggestions.count > 0 {
                        let usernameSuggestionView = UsernameSuggestionsView.init(frame: CGRectMake(0, 0, self.view.frame.width, self.view.frame.height))
                        usernameSuggestionView.delegate = self
                        usernameSuggestionView.setUpSuggestionView(arrSuggestions)
                        self.view.addSubview(usernameSuggestionView)
                    }
                    self.navigationItem.prompt = "Username unavailable."
                    self.performSelector(Selector("removePrompt") , withObject: nil, afterDelay: 2.0)

                }
                
                }) { (error: NSError!) -> Void in
            }
        
    }
    
    func removePrompt() {
        self.navigationItem.prompt = nil
    }
    // MARK: - Username Suggestion Delegate
    func userSuggestionTapped(strSuggestion: String){
        txtUsername.text = strSuggestion
    }
    
    // MARK: - Validations check
    func fnCheckValidation() -> NSString{
        var strError = String()
        if !Utility.checkIfStringContainsText(txtFirstName.text){
            strError = "Please enter First name."
        }else if !Utility.checkIfStringContainsText(txtLastName.text){
            strError = "Please enter Last name."
        }else if !Utility.checkIfStringContainsText(txtUsername.text){
            strError = NSIConstants.usernameCheck
        }else if !Utility.isValidUsername(txtUsername.text!){
            strError = "Invalid Username(a-z, A-Z, 0-9, _ , . only)"
        }else if !Utility.checkIfStringContainsText(txtEmail.text){
            strError = "Please enter Email address."
        }else if !Utility.validateEmail(txtEmail.text!){
            strError = "Please enter valid Email address."
        }else if !Utility.checkIfStringContainsText(txtPhoneNo.text){
            strError = "Please enter Phone number."
        }else if (!Utility.checkIfStringContainsText(txtPassword.text)){
            strError = NSIConstants.passwordCheck
        }else if txtPassword.text!.characters.count < 6{
            strError = "Password must contain 6 or more characters."
        }else if (!Utility.checkIfStringContainsText(txtConfirmPassword.text)){
            strError = "Please enter Confirm Password."
        }else if txtPassword.text != txtConfirmPassword.text{
            strError = "Confirm Password does not match Password."
        }
        return strError
    }
    
    @IBAction func textEnterBegin(sender: AnyObject) {
        if (sender.tag == 104){
            self.checkMaxLength(sender as! UITextField, maxLength: 15)
        }else if(sender.tag == 103){
            self.checkMaxLength(sender as! UITextField, maxLength: 50)
        }else{
            self.checkMaxLength(sender as! UITextField, maxLength: 30)
        }
    }
    
    func checkMaxLength(textField: UITextField!, maxLength: Int) {
        let str = textField.text
        let strCount = str!.characters.count
        if (strCount > maxLength) {
            textField.deleteBackward()
        }
    }
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
    
    
}
