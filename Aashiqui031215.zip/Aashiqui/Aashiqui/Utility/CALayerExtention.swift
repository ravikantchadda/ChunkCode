//
//  calayer.swift
//  Aashiqui
//
//  Created by ketan saini on 23/09/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import Foundation

extension CALayer {
    func setBorderColorFromUIColor(color: UIColor) {

        self.borderColor = color.CGColor
    }
}