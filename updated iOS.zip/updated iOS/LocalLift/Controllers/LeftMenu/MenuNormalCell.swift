//
//  MenuNormalCell.swift
//  LocalLift
//
//  Created by neeru thakur on 12/10/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class MenuNormalCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}

