//
//  AudioPlay.swift
//  Aashiqui
//
//  Created by ketan saini on 19/11/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit
import AVFoundation

class AudioPlay: NSObject, AVAudioPlayerDelegate {
    class var sharedInstance: AudioPlay {
        struct Static {
            static var onceToken: dispatch_once_t = 0
            static var instance: AudioPlay? = nil
        }
        dispatch_once(&Static.onceToken) {
            Static.instance = AudioPlay()
        }
        return Static.instance!
    }
    var myPlayer = AVAudioPlayer()
    var audioPlayerBool = false
    // MARK: - Play Audio Methods
    func fnPlayAudioURL(audioURL: String) {
        audioPlayerBool = false
        let urlAudio = NSURL(string: audioURL)!
        let request = NSURLRequest(URL: urlAudio)
        let session =  NSURLSession.sharedSession()
        let task = session.dataTaskWithRequest(request, completionHandler: {data, response, error -> Void in
            print("Response: \(response)")
            
            if error != nil {
                print("There was an error")
            } else {
                self.prepareYourSound(data!)
                
            }
        })
        task.resume()
    }
    
    var yourSound:NSURL?
    func prepareYourSound(myData:NSData) {
        
        do {
            try myPlayer = AVAudioPlayer(data: myData, fileTypeHint: nil)
            myPlayer.delegate = self
            myPlayer.prepareToPlay()
            self.myPlayer.play()
            audioPlayerBool = true
        }
        catch let error1 as NSError {
            print(error1)
        } catch {
            // Catch any other errors
        }
    }
   
}
