//
//  LiftGroupPeopleCollectionView.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/23/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class LiftGroupUserBO: NSObject {
    
    var UserImage: String?
}

class LiftGroupPeopleCollectionView: UIView,UICollectionViewDelegateFlowLayout, UICollectionViewDataSource  {

    let identifier = "LiftGroupUserCell"
    var arrayUserOfLiftgroup = NSMutableArray()
    var delegate:SelectPassValueProtocol?
    
    @IBOutlet weak var collectionViewSelectLiftGroup: UICollectionView!
    
    //MARK:- Intial function
    func Intilization() {
        let nib = UINib(nibName: "LiftGroupUserCell", bundle:nil)
        self.collectionViewSelectLiftGroup.registerNib(nib, forCellWithReuseIdentifier: "LiftGroupUserCell")
        self.arrayUserOfLiftgroup = NSMutableArray()
      //  collectionViewSelectLiftGroup.scrollEnabled
        collectionViewSelectLiftGroup.dataSource = self
        collectionViewSelectLiftGroup.delegate = self
    }
    
    func reloadCollectionView() {
        collectionViewSelectLiftGroup.reloadData()
    }
    
    //MARK:- Collection view delegate
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrayUserOfLiftgroup.count + 1  // demodata 21
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell:LiftGroupUserCell = (collectionView.dequeueReusableCellWithReuseIdentifier(identifier, forIndexPath: indexPath) as? LiftGroupUserCell)!
        //DemoDelete
        
        if(self.arrayUserOfLiftgroup.count == indexPath.row) {
                cell.imageViewUser.image = UIImage(named: "groupThumbnail")
        }
        else {
        
                let contactBO:ContactsBO = self.arrayUserOfLiftgroup[indexPath.row] as! ContactsBO
                print(contactBO.firstName)
                
                if(self.arrayUserOfLiftgroup.count == indexPath.row) {
                   cell.imageViewUser.image = UIImage(named: "groupThumbnail")
                }
                else {
                    let dicOfLiftGroup = self.arrayUserOfLiftgroup[indexPath.row] as? LiftGroupUserBO
                    cell.imageViewUser.image = UIImage(named: "ProfileImage")
                    print(dicOfLiftGroup?.UserImage)
                }
        }
        
//        if(indexPath.row == 20 ) {
//                cell.imageViewUser.image = UIImage(named: "groupThumbnail")
//        }
//        else {
//                cell.imageViewUser.image = UIImage(named: "ProfileImage")
//        }
        
        return cell
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        if(delegate != nil) {
            delegate?.selectCell("")
        }
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize   {
        return CGSize(width: 50, height: 50)
    }

    
    // MARK:-  Our custom view from the XIB file
    var view: UIView!
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadViewFromNib ()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        loadViewFromNib ()
    }
    func loadViewFromNib() {
        let bundle = NSBundle(forClass: self.dynamicType)
        let nib = UINib(nibName: "LiftGroupPeopleCollectionView", bundle: bundle)
        let view = nib.instantiateWithOwner(self, options: nil)[0] as! UIView
        view.frame = bounds
        view.autoresizingMask = [.FlexibleWidth, .FlexibleHeight]
        self.addSubview(view);
    }

}
