//
//  ViewOfSetLocation.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/25/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class ViewOfSetLocation: UIView {

    @IBOutlet var btnPickupLoc: UIButton!
    @IBOutlet var btnDestinationLoc: UIButton!
    var liftRequestVCCallBack:LiftRequestVC!
    
    @IBAction func toPickupLocation(sender: AnyObject) {
        if (liftRequestVCCallBack != nil){
            liftRequestVCCallBack.setLocationOfMap(.FromLocation)
        }
    }
    
    @IBAction func toDestinationLoc(sender: AnyObject) {
        if (liftRequestVCCallBack != nil ){
            liftRequestVCCallBack.setLocationOfMap(.ToLocation)
        }
    }
    

}
