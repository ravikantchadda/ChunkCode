//
//  SignInVC.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/16/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit
import MFSideMenu

class SignInVC: BaseViewController,UITextFieldDelegate {
    
    @IBOutlet var txtEmail: UITextField!
    @IBOutlet var txtPassword: UITextField!
    @IBOutlet var scrlView: UIScrollView!
    @IBOutlet var btnSignIn: PSCustomFontButton!
    @IBOutlet var btnRemberMe: UIButton!
    
//MARK: - View Life Cycle Methods
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBar(NavigationType.ClearNavigationType)
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Back", style: UIBarButtonItemStyle.Plain, target: self, action: "toBack")
    }

    override  func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
//MARK: - Button Methods
    
    @IBAction func toSignIn(sender: AnyObject) {
        
        if NSIUtility.validateTextFieldArray(["Email Address","Password"],arrayOFFields: [txtEmail,txtPassword])
        {
            let userDL:UserDL = UserDL()
            let userCredentials = (strUserName:txtEmail.text!, strPassword:txtPassword.text!)
            userDL.requestforUserLogin(userCredentials, withCompletionHandler: { (obj, success) -> Void in
                if success == true{
                    
                   
//                      self.configureMFSideMenu()
                    if let signIN:CreateProfileVC = NSIUtility.fetchViewControllerWithName("CreateProfileVC", storyBoardName: "Main") as? CreateProfileVC{
                        //                            self.navigationController?.popViewControllerAnimated(false)
                        self.navigationController?.pushViewController(signIN, animated: true)
                    }                }else{
                }
                
            })
        }
    }
   
  
    func configureMFSideMenu(){
        
        let leftMenuVC:UIViewController = NSIUtility.fetchViewControllerWithName("LeftMenuVC", storyBoardName: "Home")
        let homeNavigationController:UINavigationController = NSIUtility.fetchViewControllerWithName("homeNavigationController", storyBoardName: "Home") as! UINavigationController
        let sideMenu:MFSideMenuContainerViewController = MFSideMenuContainerViewController.containerWithCenterViewController(homeNavigationController, leftMenuViewController: leftMenuVC, rightMenuViewController: nil)
        Constants.appDelegate.window?.rootViewController = sideMenu;
    }
    
    func toBack(){
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    @IBAction func toForgotPassword(sender: AnyObject) {
        
    }
    
    @IBAction func toNeedAnAccount(sender: AnyObject) {
        
        let arrayViewControllers:NSArray = self.navigationController!.viewControllers
        for controller in arrayViewControllers{
            if let signUp:SignUpVC = controller as? SignUpVC{
               self.navigationController?.popToViewController(signUp, animated: true)
            }
        }
     
    }
    
//MARK: - Text Field Delegates
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
        
        return UITextField.textField(textField, shouldChangeCharactersInRange: range, replacementString: string,
            withMaxLength: UITextField.MaxLength.DefaultMax, spaceAllowed: false)
        
    }
    
    
    func toSelectBtnValidation()
    {
        if (self.isAllTextFieldFilled(scrlView.viewWithTag(1001)!) == false ){
            btnSignIn.backgroundColor = UIColor.colorWithRGB(31, green: 81, blue: 108, alpha:0.7)
        }
        else{
            btnSignIn.backgroundColor = Constants.APP_THEME_COLOR
        }
    }
    
    
}
