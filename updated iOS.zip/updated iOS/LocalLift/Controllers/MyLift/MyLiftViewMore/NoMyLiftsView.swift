//
//  NoMyLiftsView.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/16/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit


protocol SearchForLiftProtocol
{
    func searchForLifts()
}
class NoMyLiftsView: UIView {

    var delegate:SearchForLiftProtocol?
    
    @IBAction func searchForLifts(sender: AnyObject) {
        if(delegate != nil) {
            delegate?.searchForLifts()
        }
        
    }
}
