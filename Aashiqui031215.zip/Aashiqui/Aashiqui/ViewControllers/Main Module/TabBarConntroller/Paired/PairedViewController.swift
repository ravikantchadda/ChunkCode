//
//  PairedViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 18/09/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit

class PairedViewController: UIViewController {
    @IBOutlet weak var tblFriendList: UITableView!
    var arrFriendList: NSMutableArray! = []
    var pageUser = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationItem.titleView = Utility.navBarTitleLabel("Paired")
        self.navigationItem.title = ""
        self.navigationController?.navigationBar.translucent = false
        tblFriendList.tableFooterView = UIView(frame: CGRectZero)
        tblFriendList.addInfiniteScrollingWithHandler {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), { () ->  Void in
                self.pageUser += 1
                let dict:NSDictionary = [
                    "userId": NSIConstants.userDefaults.valueForKey("userId") as! String,
                    "page": "\(self.pageUser)"
                ]
                print("\(dict)")
                self.fnGetFriendsWebServiceWithPostDic(dict, showLoader: false)
            })
        }
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        if self.arrFriendList != nil {
            self.arrFriendList.removeAllObjects()
        }
        if let userId = NSIConstants.userDefaults.valueForKey("userId") {
            let dict:NSDictionary = [
                "userId": userId,
                "page": "1"
            ]
            print("\(dict)")
            fnGetFriendsWebServiceWithPostDic(dict, showLoader: true)
        }
    }
    
    // MARK: - Webservice Call Methods
    //GetFriends API
    func fnGetFriendsWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
            ObjWebserviceCall.cachePolicy = WebserviceCallCachePolicyRequestFromCacheFirstAndThenFromUrlAndUpdateInCache
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceGetFriends)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
    
                print("getFriends--- \(response.webserviceResponse)")
                if (response.webserviceResponse != nil) {
                    if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                        if self.arrFriendList != nil {
                            self.arrFriendList.removeAllObjects()
                        }
                        //UserDetails Model
                        let arrData = response.webserviceResponse.valueForKey("friendsList") as! NSArray
                        let arrModelData = UserDetails().fillDataInModel(arrData)
                        arrModelData.enumerateObjectsUsingBlock({ object, index, stop in
                            self.arrFriendList.addObject(arrModelData.objectAtIndex(index))
                        })
                
                        if self.arrFriendList.count == 0 {
                            let lblMsg = UILabel(frame: CGRectMake(0, 0, self.tblFriendList.frame.size.width, 50))
                            lblMsg.center = self.tblFriendList.center
                            lblMsg.text = "You don't have any friend."
                            lblMsg.numberOfLines = 0
                            lblMsg.textAlignment = NSTextAlignment.Center
                            lblMsg.font = UIFont(name: "Lato-Regular", size: 16)
                            lblMsg.textColor = UIColor.blackColor()
                            self.tblFriendList.backgroundView = lblMsg
                            self.tblFriendList.scrollEnabled = false
                        }else{
                            self.tblFriendList.backgroundView = nil
                            self.tblFriendList.scrollEnabled = true
                        }
                        print("arrUserData-- \(self.arrFriendList)")
                        self.tblFriendList.reloadData()
                        self.tblFriendList.infiniteScrollingView?.stopAnimating()
                    }else{
                        self.tblFriendList.infiniteScrollingView?.stopAnimating()
                        Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                    }
                }
                
                
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
    
    //UnFriend API
    func fnUnFriendsWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceUnfriend)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("UnFriend--- \(response.webserviceResponse)")
                
                if (response.webserviceResponse != nil) {
                    
                    if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                        self.arrFriendList.removeAllObjects()
                        if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                            let dict:NSDictionary = [
                                "userId": userId,
                                "page": "1"
                            ]
                            print("\(dict)")
                            self.fnGetFriendsWebServiceWithPostDic(dict, showLoader: true)
                        }

                    }else{
                        if response.webserviceResponse.valueForKey("status") as! String != "Result not found" {
                            Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                        }
                    }
                }
                
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
    

    //MARK - TableView DataSource/Delegate
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrFriendList.count
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if(tableView.respondsToSelector(Selector("setSeparatorInset:"))){
            tableView.separatorInset = UIEdgeInsetsZero
        }
        if(tableView.respondsToSelector(Selector("setLayoutMargins:"))){
            
            tableView.layoutMargins = UIEdgeInsetsZero
          
        }
        if(cell.respondsToSelector(Selector("setLayoutMargins:"))){
           
            cell.layoutMargins = UIEdgeInsetsZero
            
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath)
        
        let objUserCell:UserDetails = arrFriendList.objectAtIndex(indexPath.row) as! UserDetails
        //UIImage Profile Image
        if let imgVwProfile:AsyncImageView = cell.viewWithTag(1001) as? AsyncImageView {
            imgVwProfile.image = UIImage(named: "placeholder")
            if let variableName: String = objUserCell.profilePic{
                imgVwProfile.imageURL = NSURL(string: variableName)
            }
        }
        if let lblName = cell.viewWithTag(1002) as? UILabel {
            lblName.text = objUserCell.firstName + "" + objUserCell.lastName
        }
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let objUserCell:UserDetails = arrFriendList.objectAtIndex(indexPath.row) as! UserDetails
        let objProfileVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("ProfileViewController") as! ProfileViewController
        objProfileVC.userID = objUserCell.userId
        self.navigationController!.pushViewController(objProfileVC, animated: false)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnPressed_Unfriend(sender: AnyObject) {
        let pointInTable: CGPoint = sender.convertPoint(sender.bounds.origin, toView: tblFriendList)
        let cellIndexPath: NSIndexPath = tblFriendList.indexPathForRowAtPoint(pointInTable)!
        let objUserCell:UserDetails = arrFriendList.objectAtIndex(cellIndexPath.row) as! UserDetails
        if let userId = NSIConstants.userDefaults.valueForKey("userId") {
            let dict:NSDictionary = [
                "userId": userId,
                "friendId": objUserCell.userId
            ]
            print("\(dict)")
            fnUnFriendsWebServiceWithPostDic(dict, showLoader: true)
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
