//
//  Login.swift
//  Aashiqui
//
//  Created by ketan saini on 18/09/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit

class Login: NSObject {
    
    //MARK: class variables
    var userEmail:String!
    var userUserName:String!
    var userDeviceId:String!
    var userId:String!
    var userAuthToken:String!
    var userFirstName:String!
    var userLastName:String!
    var userPost:NSArray!
    
    // MARK: NSCoding
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.userEmail = (decoder.decodeObjectForKey("email") as! String?)!
        self.userUserName = (decoder.decodeObjectForKey("username") as! String?)!
        self.userDeviceId = (decoder.decodeObjectForKey("deviceId") as! String?)!
        self.userId = (decoder.decodeObjectForKey("userId") as! String?)!
        self.userAuthToken = (decoder.decodeObjectForKey("authToken") as! String?)!
        self.userFirstName = (decoder.decodeObjectForKey("firstName") as! String?)!
        self.userLastName = (decoder.decodeObjectForKey("lastName") as! String?)!
        self.userPost = (decoder.decodeObjectForKey("userPost") as! NSArray?)!
    }
    
    func encodeWithCoder(coder: NSCoder) {
        coder.encodeObject(self.userEmail, forKey: "email")
        coder.encodeObject(self.userUserName, forKey: "username")
        coder.encodeObject(self.userDeviceId, forKey: "deviceId")
        coder.encodeObject(self.userId, forKey: "userId")
        coder.encodeObject(self.userAuthToken, forKey: "authToken")
        coder.encodeObject(self.userPost, forKey: "userPost")
        coder.encodeObject(self.userFirstName, forKey: "firstName")
        coder.encodeObject(self.userLastName, forKey: "lastName")
    }
}
