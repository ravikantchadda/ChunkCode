//
//  LoginViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 18/09/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet weak var txtUsername: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    let loader = Loader()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.navigationController?.navigationBar.translucent = false
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.navigationBarHidden = true
    }
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(true)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - UITextField Delegate Method
    func textFieldDidBeginEditing(textField: UITextField) {
       
    }
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        return true;
    }
    func textFieldShouldClear(textField: UITextField) -> Bool {
        return true;
    }
    func textFieldShouldEndEditing(textField: UITextField) -> Bool {
        return true;
    }
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        return true;
    }
    func textFieldShouldReturn(textField: UITextField) -> Bool{
        
        let nextTag:NSInteger = textField.tag + 1
        // Try to find next responder
        let nextResponder = textField.superview?.viewWithTag(nextTag)
        if (nextResponder != nil){
            nextResponder!.becomeFirstResponder()
        }else{
            textField.resignFirstResponder()
        }
        return true
    }
    
    // MARK: - UIButton Action
    @IBAction func btnTapped_SignIn(sender: AnyObject) {
        self.view.endEditing(true)
        let strError = fnCheckValidation()
        if strError == ""{
            let dict:NSDictionary = [
                "userName": txtUsername.text!,
                "password": txtPassword.text!
            ]
            print("\(dict)")
            fnSignInWebServiceWithPostDic(dict)
            
        }else{
            Utility.showAlert("", message: strError as String, delegate: nil)
        }
        
    }
    @IBAction func btnPressed_SignUp(sender: AnyObject) {
        let objRegisterViewController = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("RegisterViewController") as! RegisterViewController
        self.navigationController!.pushViewController(objRegisterViewController, animated: true)
    }
    
//    @IBAction func btnPressed_ForgotUsername(sender: AnyObject) {
//        Utility.showAlert("", message: NSIConstants.underConstruction, delegate: nil)
//    }
    @IBAction func btnTapped_FacebookLogin(sender: AnyObject) {
        self.view.endEditing(true)
        let fbLogin = FBSDKLoginManager()
        fbLogin.logOut()
        fbLogin .logInWithReadPermissions(["email"], handler: { (result, error) -> Void in
            if (error == nil){
                let fbloginresult : FBSDKLoginManagerLoginResult = result
                if fbloginresult.isCancelled {
                    // Handle cancellations
                    print("isCancelled\(result.isCancelled)")
                    
                }else if(fbloginresult.grantedPermissions.contains("email"))
                {
                    self.getFBUserData()
                }
            }
        })
    }
    
    func getFBUserData(){
        if((FBSDKAccessToken.currentAccessToken()) != nil){
            loader.showLoader()
            FBSDKGraphRequest(graphPath: "me", parameters: ["fields": "id, name, first_name, last_name, picture.type(large), email"]).startWithCompletionHandler({ (connection, result, error) -> Void in
                if (error == nil){
                    self.loader.hideLoader()
                    print(result)
                    let dict:NSDictionary = [
                        "firstName": result.valueForKey("first_name")!,
                        "lastName": result.valueForKey("last_name")!,
                        "phone": "",
                        "fbId": result.valueForKey("id")!,
                        "email": result.valueForKey("email")!,
                        "profilePic": result.valueForKey("picture")!.valueForKey("data")!.valueForKey("url")!
                        
                    ]
                    print("\(dict)")
                    self.fnFBSignInWebServiceWithPostDic(dict)
                }else{
                    self.loader.hideLoader()
                }
            })
        }
    }
    
    // MARK: - Webservice Call Methods
    //SignIn API
    func fnSignInWebServiceWithPostDic(dict: NSDictionary!) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        ObjWebserviceCall.isShowLoader = true
        
        if let DToken = NSIConstants.userDefaults.valueForKey("DEVICETOKEN") {
            ObjWebserviceCall.headerFieldsDict = ["DEVICETOKEN":DToken, "DEVICETYPE":"2", "APPTOKEN":"I8I23NJA89NS8NW293NA8SN383F5H7J8"]
        }else{
            ObjWebserviceCall.headerFieldsDict = ["DEVICETOKEN":"y6734y78rt334y734y785yt3897ty3893t35", "DEVICETYPE":"2", "APPTOKEN":"I8I23NJA89NS8NW293NA8SN383F5H7J8"]
        }
        
        ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceSignIn)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
            let response = response
            print("\(response.webserviceResponse)")
            if (response.webserviceResponse != nil) {
            if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                
                let objLogin = Login()
                objLogin.userUserName = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("nickName") as! String
                objLogin.userEmail = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("email") as! String
                objLogin.userFirstName = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("firstName") as! String
                objLogin.userLastName = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("lastName") as! String
                objLogin.userId = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("userId") as! String
                objLogin.userDeviceId = "ewew2323ewew"
                objLogin.userAuthToken = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("authToken") as! String
                objLogin.userPost = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("feeds") as! NSArray
            NSIConstants.userDefaults.setValue(response.webserviceResponse.valueForKey("userDetail")?.valueForKey("userType") as! String, forKey: "userType")
                NSIConstants.userDefaults.synchronize()
                
                let objTabBarViewController = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("TabBarViewController") as! TabBarViewController
                let objNavigationHome = objTabBarViewController.viewControllers![0] as! UINavigationController
                let objHome: HomeViewController = objNavigationHome.viewControllers.first as! HomeViewController
                objHome.objLoginModel = objLogin
                
                self.navigationController!.pushViewController(objTabBarViewController, animated: false)
                
            }else{
                self.txtPassword.text = ""
                Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
            }
            }
            }) { (error: NSError!) -> Void in
        }
        

    }
    //Facebook Facebook Login API
    func fnFBSignInWebServiceWithPostDic(dict: NSDictionary!) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        ObjWebserviceCall.isShowLoader = true
        if let DToken = NSIConstants.userDefaults.valueForKey("DEVICETOKEN") {
            
            ObjWebserviceCall.headerFieldsDict = ["DEVICETOKEN":DToken, "DEVICETYPE":"2", "APPTOKEN":"I8I23NJA89NS8NW293NA8SN383F5H7J8"]
            
        }else{
            ObjWebserviceCall.headerFieldsDict = ["DEVICETOKEN":"y6734y78rt334y734y785yt3897ty3893t35", "DEVICETYPE":"2"]
        }
        ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceFBlogin)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
            let response = response
            print("\(response.webserviceResponse)")
            if (response.webserviceResponse != nil) {
            if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                let objLogin = Login()
                objLogin.userUserName = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("nickName") as! String
                objLogin.userFirstName = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("firstName") as! String
                objLogin.userLastName = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("lastName") as! String
                objLogin.userEmail = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("email") as! String
                objLogin.userId = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("userId") as! String
                objLogin.userDeviceId = "ewew2323ewew"
                objLogin.userAuthToken = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("authToken") as! String
                objLogin.userPost = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("feeds") as! NSArray
            NSIConstants.userDefaults.setValue(response.webserviceResponse.valueForKey("userDetail")?.valueForKey("userType") as! String, forKey: "userType")
                NSIConstants.userDefaults.synchronize()
                
                let objTabBarViewController = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("TabBarViewController") as! TabBarViewController
                let objNavigationHome = objTabBarViewController.viewControllers![0] as! UINavigationController
                let objHome: HomeViewController = objNavigationHome.viewControllers.first as! HomeViewController
                objHome.objLoginModel = objLogin
                self.navigationController!.pushViewController(objTabBarViewController, animated: false)
            }else{
                self.txtUsername.text = ""
                self.txtPassword.text = ""
                Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
            }
            }
            }) { (error: NSError!) -> Void in
        }
    }
    
    // MARK: - Validations check
    func fnCheckValidation() -> NSString{
        var strError = String()
        if !Utility.checkIfStringContainsText(txtUsername.text){
            strError = "Please enter User name."
        }
        else if txtPassword.text!.characters.count < 6{
            strError = "Password must contain 6 or more characters."
        }
        else if (!Utility.checkIfStringContainsText(txtPassword.text)){
            strError = "Please enter Password."
        }
        return strError
    }
    
    @IBAction func textEnterBegin(sender: AnyObject) {
        
        self.checkMaxLength(sender as! UITextField, maxLength: 30)
       
    }
    func checkMaxLength(textField: UITextField!, maxLength: Int) {
        let str = textField.text
        let strCount = str!.characters.count
        if (strCount > maxLength) {
            textField.deleteBackward()
        }
    }
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
}
