//
//  ResetPasswordViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 18/09/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit

class ResetPasswordViewController: UIViewController {
    @IBOutlet weak var txtEmail: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        UIApplication.sharedApplication().statusBarStyle = .Default
    }
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        UIApplication.sharedApplication().statusBarStyle = .LightContent
    }
    
    
    // MARK: - Webservice Call Methods
    //Reset Password API
    func fnResetPasswordWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["APPTOKEN":"I8I23NJA89NS8NW293NA8SN383F5H7J8"]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceForgetPassword)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("GetList--- \(response.webserviceResponse)")
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    let alert = UIAlertController(title: "", message: response.webserviceResponse.valueForKey("status") as? String, preferredStyle: .Alert)
                    let action = UIAlertAction(title: "OK", style: .Default) { _ in
                        self.dismissViewControllerAnimated(true, completion: nil)
                    }
                    alert.addAction(action)
                    self.presentViewController(alert, animated: true, completion: nil)
                    
                }else{
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                }) { (error: NSError!) -> Void in
            }
    }

    @IBAction func btnPressed_Cross(sender: AnyObject) {
        self .dismissViewControllerAnimated(true, completion: nil)
    }
    @IBAction func btnPressed_ResetPassword(sender: AnyObject) {
        self.view.endEditing(true)
        if !Utility.checkIfStringContainsText(txtEmail.text){
            Utility.showAlert("", message: NSIConstants.emailCheck, delegate: nil)
        }else{
                let dict:NSDictionary = [
                    "email": txtEmail.text!,
                ]
                print("\(dict)")
                self.fnResetPasswordWebServiceWithPostDic(dict, showLoader: true)
        }
    }
    
    // MARK: - UITextField Delegate Method
    func textFieldShouldReturn(textField: UITextField) -> Bool{
        textField .resignFirstResponder()
        return true
    }
    
    // MARK: - Validations check
    func fnCheckValidation() -> NSString{
        var strError = String()
        if !Utility.checkIfStringContainsText(txtEmail.text){
            strError = NSIConstants.emailCheck
        }else if !Utility.validateEmail(txtEmail.text!){
            strError = "Please enter valid Email."
        }
        return strError
    }
    
    @IBAction func textEnterBegin(sender: AnyObject) {
        self.checkMaxLength(sender as! UITextField, maxLength: 30)
    }
    func checkMaxLength(textField: UITextField!, maxLength: Int) {
        let str = textField.text
        let strCount = str!.characters.count
        if (strCount > maxLength) {
            textField.deleteBackward()
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
