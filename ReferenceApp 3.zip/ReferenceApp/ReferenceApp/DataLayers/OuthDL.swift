//  ReferenceApp
//
//  Created by ravi kant on 11/6/15.
//  Copyright © 2015 Netsol. All rights reserved.
//

import Foundation


class OuthDL: NSIRestAPIHelper{
    
    // MARK: -  Method to Request for Outh
    /**
    *************************************
    requestforOuth is method to call Outh service required to get Token i.e. used before using the signin/signup services
    Params: Header body(its a predefined body that will authenticate the device to use the app services)
    Params:ServiceURL(its defined the method name)
    *************************************
    **/
    func requestforOuth(headerBody:String, withCompletionHandler handler:CompletionHandler)
    {
        
        self.serviceURL = "o/token/"
        self.isCallforOuth = true
        
        self.requestforOuthPOST(headerBody) { (obj, success) -> Void in
            if success == true
            {
                handler(obj: obj, success: true)
            }
            else{
                handler(obj: nil, success: false)
            }
        }
        
        
        
    }
    
    
    
    
    
    
    
    
}