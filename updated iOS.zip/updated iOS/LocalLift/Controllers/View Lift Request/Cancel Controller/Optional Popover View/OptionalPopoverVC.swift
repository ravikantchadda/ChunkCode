//
//  OptionalPopoverVC.swift
//  LocalLift
//
//  Created by prabhjot singh on 12/24/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit



class OptionalPopoverVC: UIViewController {
    
typealias CompletionHandlerOfPopup = (text: String! , buttonClickedString:String!) -> Void
    
    @IBOutlet var txtViewOptional: UITextView!
    @IBOutlet var btnCancel: UIButton!
    @IBOutlet var btnSend: UIButton!
    
    var handler = CompletionHandlerOfPopup!()
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func didSelectButton(handlerPop:CompletionHandlerOfPopup){
        self.handler = handlerPop
    }
    
    @IBAction func toActionBtn(sender: UIButton) {
        self.handler(text: self.txtViewOptional.text,buttonClickedString: sender.currentTitle)
        self.toDismissView([])
    }
    
    @IBAction func toDismissView(sender: AnyObject){
        self.dismissViewControllerAnimated(true) { () -> Void in
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
