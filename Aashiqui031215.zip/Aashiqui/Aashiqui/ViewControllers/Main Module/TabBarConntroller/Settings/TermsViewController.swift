//
//  TermsViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 14/10/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class TermsViewController: UIViewController {
    @IBOutlet weak var webVwTerms: UIWebView!
    let loader = Loader()
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationItem.titleView = Utility.navBarTitleLabel("Terms & Conditions")
//        self.navigationItem.hidesBackButton = true
//        self.navigationItem.leftBarButtonItem = Utility.navBarLeftButton(UIImage(named: "btnBack")!, viewController: self)
       
        if (Utility.checkNetwork() == true){
            loader.showLoader()
            webVwTerms.loadRequest(NSURLRequest(URL: NSURL(string: "http://aashiqui.net/mobileapi/cmsdetail.php?pagename=terms")!, cachePolicy: NSURLRequestCachePolicy.UseProtocolCachePolicy, timeoutInterval: 30.0))
        }else{
            loader.hideLoader()
        }
    }
    // MARK: - NavigationBar LeftBarButton Method
    func fnLeftBarButton(){
        self.navigationController?.popViewControllerAnimated(true)
    }

    func webViewDidStartLoad(webView : UIWebView) {

    }
    
    func webViewDidFinishLoad(webView : UIWebView) {
        loader.hideLoader()
    }
    func webView(webView: UIWebView, didFailLoadWithError error: NSError?){
        loader.hideLoader()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
