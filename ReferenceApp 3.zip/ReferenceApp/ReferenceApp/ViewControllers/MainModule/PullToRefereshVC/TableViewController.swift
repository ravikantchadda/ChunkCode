//
//  PullToRefereshVC.swift
//  ReferenceApp
//
//  Created by ravi kant on 12/4/15.
//  Copyright © 2015 Netsol. All rights reserved.
//

import UIKit

class TableViewController: ScrollViewController, UITableViewDelegate,UITableViewDataSource {
 @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        let dataList = DataListDL()
//        
//        dataList.requestforDataList(["":""]) { (obj, success) -> Void in
//            
//            NSIUtility.DBlog(obj as! NSDictionary)
//            
//        }

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.numberOfItems;
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let CellIdentifier: String = "MyTableCell"
        var cell: UITableViewCell = tableView.dequeueReusableCellWithIdentifier(CellIdentifier)!
        cell = UITableViewCell(style: .Subtitle, reuseIdentifier: CellIdentifier)
        cell.contentView.backgroundColor = (indexPath.row % 2 == 0) ? UIColor.lightGrayColor() : UIColor.whiteColor()
        //cell.textLabel?.text = "Text"
        
        

        return cell
    }
    
    override func reloadData() {
        self.tableView.reloadData()
    }

}
