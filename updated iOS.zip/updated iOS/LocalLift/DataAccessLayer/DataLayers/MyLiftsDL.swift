//
//  MyLiftsDL.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/16/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import Foundation
import CoreLocation

// --- - -- - -- - - - -MyLifts Model ---- -- - - -- -//

class MyLiftBO: NSObject {
    
    var isImmediate:Bool!
    var isOfferRequest:Bool!
    var liftFrequencyType:String!
    var liftName:String!
    var liftRequesterName:String!
    var liftRequesterPhoto:String!
    var liftRequesterPhotoPath:String!
    var message:String!
    var requestCreatorId:NSNumber!
    var requestId:NSNumber!
    var requestStatus:String!
    var requestEndDatetime:NSDate!
    var requestedDatetime:NSDate!
    var passengerCount:NSNumber!
    var addressBO:AddressBO!
    
}



//_______Defined LiftBO in LiftDL.swift file____________

// --- - -- - -- - - - -v Data Layers ---- -- - - -- -//
class MyLiftsDL: PSRestAPIHelper {
    
    func requestforMyLifts(startIndex:Int, withDate:String, withNumberOfItems:Int, withCompletionHandler handler:CompletionHandler)
    {
        self.serviceURL = "ViewScheduledLiftRequests/\(UserBO.sharedInstanceOfUser.userID)/\(startIndex)/\(withNumberOfItems)/\(withDate)"
        print(self.serviceURL)
        self.webservice.isShowLoader = true
        self.setContentTypeHeaders()
        let dicParam:NSDictionary = ["":""]
        self.requestforGET(dicParam as! [NSObject : AnyObject!]) { (obj, success) -> Void in
            print(obj as? NSDictionary)
            if success == true{
                if let dicResponse:NSDictionary = obj as? NSDictionary{
                    let arrayOfLifts = NSMutableArray()
                    if let arrayOfData = NSIUtility.getObjectForKey("Data", dictResponse: dicResponse) as? NSArray{
                        for dictionary in arrayOfData{
                            if let dicLift = dictionary as? NSDictionary{
                                let liftBO = MyLiftBO()
                                if let dicAddress = NSIUtility.getObjectForKey("ToAddress", dictResponse:dicLift) as? NSDictionary
                                {
                                    let addressObj:AddressBO = AddressBO()
                                    addressObj.addressID = NSIUtility.getObjectForKey("AddressID", dictResponse:dicAddress) as! NSNumber
                                    addressObj.addressName = NSIUtility.getObjectForKey("AddressName", dictResponse:dicAddress) as! String
                                    addressObj.city = NSIUtility.getObjectForKey("City", dictResponse:dicAddress) as! String
                                    addressObj.country = NSIUtility.getObjectForKey("Country", dictResponse:dicAddress) as! String
                                    addressObj.isActive = NSIUtility.getObjectForKey("IsActive", dictResponse:dicAddress) as! Bool
                                    addressObj.isNew = NSIUtility.getObjectForKey("IsNew", dictResponse:dicAddress) as! Bool
                                    addressObj.isPrimary = NSIUtility.getObjectForKey("IsPrimary", dictResponse:dicAddress) as! Bool
                                    addressObj.state = NSIUtility.getObjectForKey("State", dictResponse:dicAddress) as! String
                                    addressObj.streetAddress = NSIUtility.getObjectForKey("StreetAddress", dictResponse:dicAddress) as! String
                                    addressObj.unit = NSIUtility.getObjectForKey("Unit", dictResponse:dicAddress) as! String
                                    addressObj.zipCode = NSIUtility.getObjectForKey("ZipCode", dictResponse:dicAddress) as! String
                                    addressObj.addressType = "Home"
                                    
                                    if let latitudeString = dicAddress.objectForKey("Latitude") as? String{
                                        let lactionLatitude:Double? = Double(latitudeString)
                                        if let laongitudeString = dicAddress.objectForKey("Longitude") as? String{
                                            let lactionLongitude:Double? = Double(laongitudeString)
                                            addressObj.locationCords = CLLocationCoordinate2D(latitude: lactionLatitude!, longitude: lactionLongitude!)
                                        }
                                    }else{
                                        addressObj.locationCords = CLLocationCoordinate2D(latitude: NSIUtility.randomFloat(-90, max: 90), longitude: NSIUtility.randomFloat(-180, max: 180))
                                    }
                                    
                                    liftBO.addressBO  = addressObj
                                }
                                
                                liftBO.isImmediate = NSIUtility.getObjectForKey("IsImmediate", dictResponse:dicLift) as! Bool
                                liftBO.isOfferRequest = NSIUtility.getObjectForKey("IsOfferRequest", dictResponse:dicLift) as! Bool
                                liftBO.liftFrequencyType = NSIUtility.getObjectForKey("LiftFrequencyType", dictResponse:dicLift) as! String
                                liftBO.liftName = NSIUtility.getObjectForKey("LiftName", dictResponse:dicLift) as! String
                                liftBO.liftRequesterName = NSIUtility.getObjectForKey("LiftRequesterName", dictResponse:dicLift) as! String
                                liftBO.liftRequesterPhoto = NSIUtility.getObjectForKey("LiftRequesterPhoto", dictResponse:dicLift) as! String
                                liftBO.liftRequesterPhotoPath = NSIUtility.getObjectForKey("LiftRequesterPhotoPath", dictResponse:dicLift) as! String
                                liftBO.message = NSIUtility.getObjectForKey("Message", dictResponse:dicLift) as! String
                                liftBO.passengerCount = NSIUtility.getObjectForKey("PassengerCount", dictResponse:dicLift) as! NSNumber
                                liftBO.requestCreatorId = NSIUtility.getObjectForKey("RequestCreatorId", dictResponse:dicLift) as! NSNumber
                                liftBO.requestId = NSIUtility.getObjectForKey("RequestId", dictResponse:dicLift) as! NSNumber
                                liftBO.requestStatus = NSIUtility.getObjectForKey("RequestStatus", dictResponse:dicLift) as! String
                                let dateTimeString = NSIUtility.getObjectForKey("RequestedDatetime", dictResponse:dicLift) as! String
                                
                                liftBO.requestedDatetime = NSDate(fromString: dateTimeString, format: .DotNet)
                    //MARK - TO  DO
                                liftBO.requestedDatetime = liftBO.requestedDatetime.dateByAddingMinutes(330)
                                
                                arrayOfLifts.addObject(liftBO)
                            }
                        }
                    }
                    handler(obj: arrayOfLifts, success: true)
                    return
                }
            }
            else{
                handler(obj: obj, success: false)
            }
        }
    }
    
    

    
    
    
}