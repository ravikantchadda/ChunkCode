//
//  WebserviceConstants.h
//  Mobitime
//
//  Created by Mohit Jain on 9/11/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WebserviceConstants : NSObject
#ifndef CMLibraryTest_WebserviceConstants_h
#define CMLibraryTest_WebserviceConstants_h

#define SuppressPerformSelectorLeakWarning(Stuff) \
do { \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Warc-performSelector-leaks\"") \
Stuff; \
_Pragma("clang diagnostic pop") \
} while (0)

#endif

/**
 *  Local Server
 */
//

FOUNDATION_EXPORT NSString *const BASE_URL;
FOUNDATION_EXPORT NSString *const APP_URL;
FOUNDATION_EXPORT NSString *const AUTH_URL;

/********************************** Webservice Constants ****************************************************/

// Webservice Key or Value constants

FOUNDATION_EXPORT NSInteger const DeviceType;
FOUNDATION_EXPORT NSString  *const WebserviceStatusCodeKey;
FOUNDATION_EXPORT NSString  *const WebserviceResponseKey;
FOUNDATION_EXPORT NSInteger const WebserviceSuccessValue;
FOUNDATION_EXPORT NSString  *const WebserviceAccessTokenKey;
FOUNDATION_EXPORT NSString  *const WebserviceKeyForPublicToken;
FOUNDATION_EXPORT NSString  *const WebserviceValueForPublicToken;



/**
 *  Webservice
 */
FOUNDATION_EXPORT NSString *const WebservicePublicToken;
FOUNDATION_EXPORT NSString *const WebserviceSignUp;
FOUNDATION_EXPORT NSString *const WebserviceSignIn;
FOUNDATION_EXPORT NSString *const WebserviceFBlogin;
FOUNDATION_EXPORT NSString *const WebserviceGetFeeds;
FOUNDATION_EXPORT NSString *const WebserviceGetFriends;
FOUNDATION_EXPORT NSString *const WebserviceSaveFeed;
FOUNDATION_EXPORT NSString *const WebserviceGetNotiSettings;
FOUNDATION_EXPORT NSString *const WebserviceSaveNotiSettings;
FOUNDATION_EXPORT NSString *const WebserviceGetSearchUser;
FOUNDATION_EXPORT NSString *const WebserviceGetSendFriendReq;
FOUNDATION_EXPORT NSString *const WebserviceGetProfile;
FOUNDATION_EXPORT NSString *const WebservicePagingProfile;
FOUNDATION_EXPORT NSString *const WebserviceSendFriendReq;
FOUNDATION_EXPORT NSString *const WebserviceFriendRequests;
FOUNDATION_EXPORT NSString *const WebserviceupdateFriendRequest;
FOUNDATION_EXPORT NSString *const WebserviceLogout;
FOUNDATION_EXPORT NSString *const WebserviceLikeProfile
;
FOUNDATION_EXPORT NSString *const WebserviceUpdateCoverPic;
FOUNDATION_EXPORT NSString *const WebserviceUpdateProfilePic;
FOUNDATION_EXPORT NSString *const WebserviceUnfriend;
FOUNDATION_EXPORT NSString *const WebserviceNotifyTagFriends;
FOUNDATION_EXPORT NSString *const WebservicePostComment;
FOUNDATION_EXPORT NSString *const WebserviceGetComment;
FOUNDATION_EXPORT NSString *const WebserviceGetChatList;
FOUNDATION_EXPORT NSString *const WebserviceGetChat;
FOUNDATION_EXPORT NSString *const WebserviceSendMessage;
FOUNDATION_EXPORT NSString *const WebserviceChangeUsername;
FOUNDATION_EXPORT NSString *const WebserviceChangePassword;
FOUNDATION_EXPORT NSString *const WebserviceChatHistory;
FOUNDATION_EXPORT NSString *const WebserviceClearHistory;
FOUNDATION_EXPORT NSString *const WebserviceUpdateProfile;
FOUNDATION_EXPORT NSString *const WebserviceGetNotificationList;
FOUNDATION_EXPORT NSString *const WebserviceForgetPassword;
FOUNDATION_EXPORT NSString *const WebserviceForgetUsername;
FOUNDATION_EXPORT NSString *const WebserviceSaveBookmark;
FOUNDATION_EXPORT NSString *const WebserviceGetBookmarkList;
FOUNDATION_EXPORT NSString *const WebserviceDeleteMessage;
FOUNDATION_EXPORT NSString *const WebserviceDeletePost;
FOUNDATION_EXPORT NSString *const WebserviceReportFeed;
FOUNDATION_EXPORT NSString *const WebserviceNotificationCount;
FOUNDATION_EXPORT NSString *const WebserviceGetAutoSuggestion;
FOUNDATION_EXPORT NSString *const WebserviceViewPost;

@end
