//
//  AppDelegate.swift
//  QBSwift
//
//  Created by ketan saini on 23/12/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit
import Reachability
@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate,QBRTCClientDelegate{

    var window: UIWindow?
    //******Core Data objects*********
    var managedObjectContextVar:NSManagedObjectContext!
    var managedObjectModelVar:NSManagedObjectModel!
    var persistentStoreCoordinatorVar:NSPersistentStoreCoordinator!
    
    //******Internet Reachibility************
    var internetReach: Reachability!
    var wifiReach: Reachability!
    var internetWorking: Int!
    var session: QBRTCSession!
    
    let kCallViewControllerID: String = "CallViewController"
    let kIncomingCallViewControllerID: String = "IncomingCallViewController"
    let kContainerViewControllerID: String = "ContainerViewController"
    var containerVC: ContainerViewController!
    
    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        // Override point for customization after application launch.
        /*
        *********Set QuickBlox credentials**************
        ************************************************
        */
        
        QBApplication.sharedApplication().applicationId = 32165
        QBConnection.registerServiceKey("mz8Wy8GadCmtTyD")
        QBConnection.registerServiceSecret("En9bEVXx9xt77Of")
        QBSettings.setAccountKey("geBjH6atfzJmyyRyFYzs")
        
        
        // Enables Quickblox REST API calls debug console output
        QBSettings.setLogLevel(QBLogLevel.Debug)
        
        // Enables detailed XMPP logging in console output
        QBSettings.enableXMPPLogging()
        
        /****************************************************/
        
        /*
        **********************QuickbloxWebRTC preferences*********************************
        */
        
        // Set answer time interval
        QBRTCConfig.setAnswerTimeInterval(60)
        
        // Set disconnect time interval
        QBRTCConfig.setDisconnectTimeInterval(30)
        
        // Set dialing time interval
        QBRTCConfig.setDialingTimeInterval(5)
        
        // Enable DTLS (Datagram Transport Layer Security)
        QBRTCConfig.setDTLSEnabled(true)
        
        // Set custom ICE servers
        
        
        let stunUrl: NSURL = NSURL(string: "stun:turn.quickblox.com")!
        let stunServer:QBICEServer = QBICEServer(URL: stunUrl, username: "quickblox", password: "baccb97ba2d92d71e26eb9886da5f1e0")
        
        
        let turnUDPUrl: NSURL = NSURL(string: "turn:turn.quickblox.com:3478?transport=udp")!
        let turnUDPServer:QBICEServer = QBICEServer(URL: turnUDPUrl, username: "quickblox", password: "baccb97ba2d92d71e26eb9886da5f1e0")
        
        let turnTCPUrl: NSURL = NSURL(string: "turn:turn.quickblox.com:3478?transport=tcp")!
        let turnTCPServer:QBICEServer = QBICEServer(URL: turnTCPUrl, username: "quickblox", password: "baccb97ba2d92d71e26eb9886da5f1e0")
        
        QBRTCConfig.setICEServers([stunServer, turnUDPServer, turnTCPServer])
        QBRTCClient.instance().addDelegate(self)
        
        /****************************************************************************************/

        return true
    }

    func applicationWillResignActive(application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
        ServicesManager.instance().chatService.logoutChat()
    }

    func applicationWillEnterForeground(application: UIApplication) {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
        ServicesManager.instance().chatService.logIn { (error:NSError!) -> Void in
            
        }
    }

    func applicationDidBecomeActive(application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }

    //MARK: ----------------------------------------------------------------------
    //MARK: - Method to Call Another Storyboard
    
    
    //MARK: ----------------------------------------------------------------------
    //MARK: -  Core Data stack
    
    func applicationDocumentsDirectory() -> NSURL {
        // The directory the application uses to store the Core Data store file. This code uses a directory named "com.netsolution.SampleCoreData.QBSampleChat" in the application's documents directory.
        let paths = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true) as NSArray
        return paths.lastObject as! NSURL
        
    }
    
    func managedObjectModel() -> NSManagedObjectModel {
        // The managed object model for the application. It is a fatal error for the application not to be able to find and load its model.
        if managedObjectModelVar != nil {
            return managedObjectModelVar
        }
        let modelURL: NSURL = NSBundle.mainBundle().URLForResource("QBSampleChat", withExtension: "momd")!
        self.managedObjectModelVar = NSManagedObjectModel(contentsOfURL: modelURL)
        return managedObjectModelVar
    }
    
    func persistentStoreCoordinator() -> NSPersistentStoreCoordinator {
        
        // The persistent store coordinator for the application. This implementation creates and returns a coordinator, having added the store for the application to it.
        if persistentStoreCoordinatorVar != nil {
            return persistentStoreCoordinatorVar
        }
        // Create the coordinator and store
        
        self.persistentStoreCoordinatorVar = NSPersistentStoreCoordinator(managedObjectModel: self.managedObjectModel())
        let storeURL: NSURL = self.applicationDocumentsDirectory().URLByAppendingPathComponent("QBSampleChat.sqlite")
        let error: NSError? = nil
        let failureReason: String = "There was an error creating or loading the application's saved data."
        
        
        if ((try? self.persistentStoreCoordinatorVar.addPersistentStoreWithType(NSSQLiteStoreType, configuration: nil, URL: storeURL, options: nil)) != nil){
            var dict: [NSObject : AnyObject] = [NSObject : AnyObject]()
            dict[NSLocalizedDescriptionKey] = "Failed to initialize the application's saved data"
            dict[NSLocalizedFailureReasonErrorKey] = failureReason
            dict[NSUnderlyingErrorKey] = error!
            // error = NSError.errorWithDomain("YOUR_ERROR_DOMAIN", code: 9999, userInfo: dict)
            
            // Replace this with code to handle the error appropriately.
            // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            NSLog("Unresolved error %@, %@", error!, error!.userInfo)
            abort()
            
        }
        
        return persistentStoreCoordinatorVar;
        
    }
    
    func updateInterfaceWithReachability(curReach: Reachability) {
        if curReach == self.internetReach {
            NSLog("Internet")
            let netStatus: NetworkStatus = curReach.currentReachabilityStatus()
            switch netStatus {
            case .NotReachable:
                self.internetWorking = -1
                NSLog("Internet NOT WORKING")
                
            case .ReachableViaWiFi:
                self.internetWorking = 0
                
            case .ReachableViaWWAN:
                self.internetWorking = 0
                
            }
        }
    }
    
    func CheckInternetConnection() {
        self.internetReach = Reachability.reachabilityForInternetConnection()
//        self.internetReach.reachableOnWWAN
        self.updateInterfaceWithReachability(self.internetReach)
    }
    
    func loadActivityAlert() {
        GMDCircleLoader.setOnView(self.window, withTitle: "Loading...", animated: true)
    }
    
    func dismissActivityAlert() {
        GMDCircleLoader.hideFromView(self.window, animated: true)
    }
    
     func callToUsers(users: [AnyObject], withConferenceType conferenceType: QBConferenceType) {
        if self.session != nil {
            return
        }
        QBSoundRouter.instance().initialize()
        let opponentsIDs: [AnyObject] = ConnectionManager.instance().idsWithUsers(users)
        let session: QBRTCSession = QBRTCClient.instance().createNewSessionWithOpponents(opponentsIDs,withConferenceType: conferenceType)
//        if (session){
            self.session = session
        let callVC: CallViewController = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier(kCallViewControllerID) as! CallViewController
            callVC.session = self.session
//            assert(!self.containerVC, "Must be nil")
            self.containerVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier(kContainerViewControllerID) as! ContainerViewController
            self.containerVC.viewControllers = [callVC]
            self.containerVC.modalTransitionStyle = .CrossDissolve
            self.window!.rootViewController!.presentViewController(self.containerVC, animated: true, completion: { _ in })
            //[]
//        }
//        else {
//            SVProgressHUD.showErrorWithStatus("Creating new session - Failure")
//        }
    }
    
    func didReceiveNewSession(session: QBRTCSession!, userInfo: [NSObject : AnyObject]!) {
        if (self.session != nil) {
            session.rejectCall(["reject": "busy"])
            return
        }
        self.session = session
        QBSoundRouter.instance().initialize()
        if UIApplication.sharedApplication().applicationState == .Background {
            self.session.acceptCall(nil)
        }
        else {
            let callVC: CallViewController = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier(kCallViewControllerID) as! CallViewController
            QMSoundManager.playRingtoneSound()
             let incomingVC: IncomingCallViewController = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier(kIncomingCallViewControllerID) as! IncomingCallViewController
//            assert(!self.containerVC, "Muste be nil")
            self.containerVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier(kContainerViewControllerID) as! ContainerViewController
            self.containerVC.viewControllers = [incomingVC, callVC]
            incomingVC.session = session
            callVC.session = session
            self.window!.rootViewController!.presentViewController(self.containerVC, animated: true, completion: { _ in })
        }

    }
    func sessionDidClose(session: QBRTCSession!) {
        if session == self.session {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, Int64(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), {() -> Void in
                QBSoundRouter.instance().deinitialize()
                self.session = nil
                self.containerVC.dismissViewControllerAnimated(false, completion: { _ in })
                self.containerVC = nil
            })
        }

    }
}

