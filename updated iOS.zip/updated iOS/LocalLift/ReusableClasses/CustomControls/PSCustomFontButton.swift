//
//  PSCustomFontButton.swift
//  Rabbit
//
//  Created by prabhjot singh on 10/15/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import Foundation
import UIKit


public class PSCustomFontButton: UIButton {
    
    @IBInspectable var roundCornerRadius: NSNumber? {
        didSet {
            self.layer.cornerRadius = roundCornerRadius as! CGFloat
        }
    }
    
    public func setCustomFont()
    {
//        print("will set in sub class")
    }
    
    override public func awakeFromNib() {
        super.awakeFromNib()
        self.setCustomFont()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder:aDecoder)
        self.setCustomFont()
    }
    
    required  public override init(frame: CGRect) {
        super.init(frame: frame)
        self.setCustomFont()
    }
    
}



public class PSBariolLightButton: PSCustomFontButton {
    
    
    override public func setCustomFont()
    {
        let fontLabel:PSBariolHeavyLabel = PSBariolHeavyLabel()
        self.titleLabel?.font = fontLabel.font.fontWithSize((self.titleLabel?.font.pointSize)!)
    }
    
    @IBInspectable var bgColor: UIColor? {
        didSet {
            self.backgroundColor = bgColor
        }
    }
    
}