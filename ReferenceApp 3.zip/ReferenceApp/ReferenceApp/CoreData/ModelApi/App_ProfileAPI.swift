//
//  App_ProfileAPI.swift
//  ReferenceApp
//
//  Created by Mohit Jain on 10/16/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import Foundation
import CoreData
class App_ProfileAPI: NSObject {
    class func fetchProfileCountForUser(userId: Int) -> Bool {
        let userPredicate:NSPredicate? = NSPredicate(format: "id == %d", userId)
        return CoreDataManager.sharedManager.entityIsEmpty("App_Profile", predicate: userPredicate!)
    }
    
    class func saveProfile(arrProfiles:NSArray) {
        CoreDataManager.sharedManager.saveEntity("App_Profile", arrOfRecords: arrProfiles)
        
    }
    class func fetchProfiles(userId: Int,fromBackgroundContext:Bool) -> AnyObject{
        let userPredicate:NSPredicate? = NSPredicate(format: "id == %d", userId)
        return CoreDataManager.sharedManager.fetchEntity("App_Profile", predicate: userPredicate!,fromBackgroundContext: fromBackgroundContext)!
    }

}
