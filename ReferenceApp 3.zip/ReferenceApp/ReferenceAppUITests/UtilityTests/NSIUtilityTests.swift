//
//  NSIUtilityTests.swift
//  Mobitime
//
//  Created by Mohit Jain on 9/2/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit
import XCTest

class NSIUtilityTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    
    
    func testGetObjectForKey() {
//        let dictDummy:NSDictionary! = ["hello":""]
//        let keyDummy:String! = "hello"
//        var value:AnyObject! =  NSIUtility.getObjectForKey(keyDummy,dictResponse: dictDummy)
//        
//        XCTAssertEqual(value,"abc" ,"Pass")
    }
    
     //MARK: - Test Case for URL validation 
    
    func testValidateURL() {
        let url:String! = "1.1"//"一.一一"
       XCTAssert(NSIUtility.validateURL(url), "Pass")
    }
    
    //MARK: - Test Case for Calculate Password Strength
    
    /**
    * The strength method implements the Truong3 Password Strength Algorithm, which
    * determines if the password contains:
    * . at least 6 characters
    * . at least one upper and one lower case Latin alphabet character
    * . at least one numerical character
    * . at least one special character
    */

    func testCalculatePasswordStrengthForWeak() {
        // This is an example of a functional test case.
        let password:String! = "aa@aaa1aaa"
        let stregth:PasswordStrength = NSIUtility.calculatePasswordStrength(password)
        
        XCTAssertEqual(stregth,PasswordStrength.VERY_STRONG ,"Pass")
    }
    
    //Medium
    func testCalculatePasswordStrengthForMedium() {
        // This is an example of a functional test case.
        let password:String! = "電話@電"
        let stregth:PasswordStrength = NSIUtility.calculatePasswordStrength(password)
        
        XCTAssertEqual(stregth,PasswordStrength.MEDIUM ,"Pass")
    }
    
    //Strong
    func testCalculatePasswordStrengthForStrong() {
        // This is an example of a functional test case.
        let password:String! = "電話@電電電"//"123Aa"
        let stregth:PasswordStrength = NSIUtility.calculatePasswordStrength(password)
        
        XCTAssertEqual(stregth,PasswordStrength.STRONG ,"Pass")
    }
    
    //Very Strong
    func testCalculatePasswordStrengthForVeryStrong() {
        // This is an example of a functional test case.
        let password:String! = "一"//"التلفزيون٪@"//"一個箭步十二十年寒窗？但他@電話@電電電佰六廿念‎"//"Aaaaaaaaaa1"
        let stregth:PasswordStrength = NSIUtility.calculatePasswordStrength(password)
        
        XCTAssertEqual(stregth,PasswordStrength.VERY_STRONG ,"Pass")
    }
    
    //Crazy Strong
    func testCalculatePasswordStrengthForCrazyStrong() {
        // This is an example of a functional test case.
        let password:String! = "Aaaaaaaaaa1$"
        let stregth:PasswordStrength = NSIUtility.calculatePasswordStrength(password)
        
        XCTAssertEqual(stregth,PasswordStrength.CRAZY_STRONG ,"Pass")
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock() {
            // Put the code you want to measure the time of here.
        }
    }
    
}
