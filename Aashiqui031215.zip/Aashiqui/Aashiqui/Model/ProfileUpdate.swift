//
//  ProfileUpdate.swift
//  Aashiqui
//
//  Created by ketan saini on 20/11/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class ProfileUpdate: NSObject {
    /*
    {
    aboutMe = "";
    email = "rrr@rrr.com";
    firstName = Rocky;
    lastName = Rocks;
    phone = 5623895628;
    }
    */
    
    var aboutMe:String!
    var email:String!
    var firstName:String!
    var lastName:String!
    var phone:String!
    
    // MARK: NSCoding
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.aboutMe = (decoder.decodeObjectForKey("aboutMe") as! String?)!
        self.email = (decoder.decodeObjectForKey("email") as! String?)!
        self.firstName = (decoder.decodeObjectForKey("firstName") as! String?)!
        self.lastName = (decoder.decodeObjectForKey("lastName") as! String?)!
        self.phone = (decoder.decodeObjectForKey("phone") as! String?)!
       
    }
    
    func encodeWithCoder(coder: NSCoder) {
        coder.encodeObject(self.aboutMe, forKey: "aboutMe")
        coder.encodeObject(self.email, forKey: "email")
        coder.encodeObject(self.firstName, forKey: "firstName")
        coder.encodeObject(self.lastName, forKey: "lastName")
        coder.encodeObject(self.phone, forKey: "phone")
      
    }
    
}
