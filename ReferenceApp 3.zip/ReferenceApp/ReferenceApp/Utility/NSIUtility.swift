
//
//  NSIUtility.swift
//  ReferenceApp
//
//  Created by Mohit Jain on 8/31/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit
enum PasswordStrength :Int {
    case WEAK = 0
    case MEDIUM = 1
    case STRONG = 2
    case VERY_STRONG = 3
    case CRAZY_STRONG = 4
}

let debubPrintLog:Int = 1

class NSIUtility: NSObject {
    
    //MARK: - Check For Empty String
    
    class func checkIfStringContainsText(string:String?) -> Bool
    {
        if let stringEmpty = string {
            let newString = stringEmpty.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
            if(newString.isEmpty){
                return false
            }
            return true
        } else {
            return false
        }
    }
    
    //MARK: - Get value from dictionary

    class func getObjectForKey(key:String!,dictResponse:NSDictionary!) -> AnyObject! {
        if key != nil{
            if let dict = dictResponse {
                if let value: AnyObject = dict.valueForKey(key) {
                    return value
                } else {
                    return nil
                }
                
            } else {
                return nil
            }
        } else {
            return nil
        }
    }
   
    //MARK: - Get value from user defaults
    class func getHeaderDict() -> NSDictionary! {
        let infoModel:UserBO! = UserInfoManager.getUserInfoModel()
        if(infoModel != nil) {
            let accessToken = infoModel.userAccesstoken
            let dictHeader:NSDictionary = ["Authorization":"Bearer \(accessToken)"]
            return dictHeader
        } else {
            
            if let accessToken = NSIUtility.getValueFromUserDefaultsForKey(Constants.keyAccessToken) {
                let dictHeader:NSDictionary = ["Authorization":"Bearer \(accessToken)"]
                return dictHeader
            }
            return nil
        }
    }

    //MARK: - Get value from user defaults
    class func getUniqueIdentifier()-> String {
        return UIDevice.currentDevice().identifierForVendor!.UUIDString
    }

    
    //MARK: - Get value from user defaults
    class func getValueFromUserDefaultsForKey(keyName:String!) -> AnyObject? {
        if !NSIUtility.checkIfStringContainsText(keyName) {
            return nil
        }
        let value: AnyObject? = NSUserDefaults.standardUserDefaults().objectForKey(keyName)
        if value != nil {
            return value
        } else {
            return nil
        }
    }
    //MARK: - Set value to user defaults
    
    class func setValueToUserDefaultsForKey(keyName:String!, value:AnyObject!) {
        
        if !NSIUtility.checkIfStringContainsText(keyName) {
            return
        }
        if  value == nil {
            return
        }
        NSUserDefaults.standardUserDefaults().setObject(value, forKey: keyName)
        NSUserDefaults.standardUserDefaults().synchronize()
    }
    
    //MARK: - Check URL validation
    
    class func validateURL(url:String) -> Bool
    {
       let urlRegex:String = "^(?:(?:https?|ftp)://)(?:\\S+(?::\\S*)?@)?(?:(?!(?:10|127)(?:\\.\\d{1,3}){3})(?!(?:169\\.254|192\\.168)(?:\\.\\d{1,3}){2})(?!172\\.(?:1[6-9]|2\\d|3[0-1])(?:\\.\\d{1,3}){2})(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}(?:\\.(?:[1-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))|(?:(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)(?:\\.(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)*(?:\\.(?:[a-z\\u00a1-\\uffff]{2,}))\\.?)(?::\\d{2,5})?(?:[/?#]\\S*)?$";
        
        let predicateForURL:NSPredicate = NSPredicate(format: "SELF MATCHES %@",urlRegex)
        
        if predicateForURL.evaluateWithObject(url) {
            return true
        } else if predicateForURL.evaluateWithObject("http://\(url)") {
            return true
        } else {
            return false
        }
    }
    
    //MARK: - Check Number validation
   
    class func validateNumber(emailStr:String) -> Bool
    {
        let numberRegex:String = "[\\p{N}\\p{Lo}}]+"
        let predicateForNumber:NSPredicate = NSPredicate(format: "SELF MATCHES %@",numberRegex)
        return predicateForNumber.evaluateWithObject(emailStr);
    }
    
    
    //MARK: - Check Email validation
    
    class func validateEmail(emailStr:String) -> Bool
    {
        let emailRegex:String = "^[_\\p{L}\\p{Mark}0-9-]+(\\.[_\\p{L}\\p{Mark}0-9-]+)*@[\\p{L}\\p{Mark}0-9-]+(\\.[\\p{L}\\p{Mark}0-9]+)*(\\.[\\p{L}\\p{Mark}]{2,})$"
        let predicateForEmail:NSPredicate = NSPredicate(format: "SELF MATCHES %@",emailRegex)
        return predicateForEmail.evaluateWithObject(emailStr);
    }
    
    //MARK: - Calculate Password Strength
    
    /**
    * The strength method implements the Truong3 Password Strength Algorithm, which
    * determines if the password contains:
    * . at least 6 characters
    * . at least one upper and one lower case Latin alphabet character
    * . at least one numerical character
    * . at least one special character
    */
    
    class func calculatePasswordStrength(password: String) -> PasswordStrength {
        
//        let PASSWORD_STRENGTH_REGEX = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).{6,}$"
        let CAPS_REGEX = "^(?=.*[A-Z]).{6,}$"
        let DIGIT_REGEX = ["^(?=.*[0-9]).{6,}$", "^(?=.*[\\p{N}\\p{Lo}]).{6,}$"]
        let LOWER_REGEX = "^(?=.*[a-z]).{6,}$"
        let SPECIAL_REGEX = "^(?=.*[@#$%^&+=]).{6,}$"
        let ISENGLISH_REGEX = "^(?=.*[a-zA-Z]).{6,}$"
        let ALPHABETS_REGEX = "^(?=.*[\\p{L}\\p{M}]).{6,}$"
        
        let predicateForCapitalLetter:NSPredicate = NSPredicate(format: "SELF MATCHES %@",CAPS_REGEX)
        let predicateForLowerLetter:NSPredicate = NSPredicate(format: "SELF MATCHES %@",LOWER_REGEX)
        let predicateForSpecialCharacter:NSPredicate = NSPredicate(format: "SELF MATCHES %@",SPECIAL_REGEX)
        let predicateForEnglishLanguage:NSPredicate = NSPredicate(format: "SELF MATCHES %@",ISENGLISH_REGEX)
        let predicateForAlphabet:NSPredicate = NSPredicate(format: "SELF MATCHES %@",ALPHABETS_REGEX)
        
         // firstText is UITextField

        var counter:Int = 0
        var set:Int = 1
        if password.characters.count > 5 {
            if predicateForEnglishLanguage.evaluateWithObject(password) {
                set = 0;
            }
            if set == 0 {
                if predicateForLowerLetter.evaluateWithObject(password) || predicateForCapitalLetter.evaluateWithObject(password) {
                    counter++;
                }
            } else {
                if predicateForAlphabet.evaluateWithObject(password) {
                    counter++;
                }
            }
            let predicateForDigit:NSPredicate = NSPredicate(format: "SELF MATCHES %@",DIGIT_REGEX[set])
            
            if predicateForDigit.evaluateWithObject(password) {
                counter++;
            }
            if predicateForSpecialCharacter.evaluateWithObject(password) {//(text.matches(SPECIAL_REGEX))
                counter++;
            }
        }
        
        switch (counter) {
        case 0: return PasswordStrength.WEAK;
        case 1: return PasswordStrength.MEDIUM;
        case 2: return PasswordStrength.STRONG;
        case 3: return PasswordStrength.VERY_STRONG;
        case 4: return PasswordStrength.CRAZY_STRONG;
        default: return PasswordStrength.WEAK
        }
    }
    
    class func isCapital(letter:UInt32) -> Bool {
        return letter >= 65 && letter < 91
    }
    
    class func isLatinCharacter(letter:UInt32) -> Bool {
        return letter >= 32 && letter < 127
    }
    
    
    
    
    /**
     *************************************
     The maximum length of your keychain string can be somewhere between 4 to 4.5 
     billion characters. You most likely aren't going to need to worry about this.
     To handle passwords and other short but sensitive bits of data,
     such as keys and login tokens. The iOS keychain provides a secure way to store these items.
     *************************************
     **/
    //MARK: - Delete Token from Keychain
    class func deleteTokenFromKeychain() {
        let q = Keychain.Query()
        
        q.kSecClass = Keychain.Query.KSecClassValue.kSecClassGenericPassword
        q.kSecAttrGeneric = "12345678".dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: false)
        q.kSecAttrAccount = "admin"
        q.kSecReturnData = true
        q.kSecReturnAttributes = true
        q.kSecReturnRef = true
        q.kSecReturnPersistentRef = true
        
        
        let res = Keychain.secItemCopyMatching(query: q)
        if (res.status == Keychain.ResultCode.errSecSuccess) {
            
         
            
             NSIUtility.DBlog("Returned object: \(res.result)")
            
            
            var dict = NSDictionary()
            dict = res.result as! NSDictionary
         
            NSIUtility.DBlog(dict)

            
            let token = dict.valueForKey("desc") as! String
            
            let qDel = Keychain.Query()
            
            qDel.kSecClass = Keychain.Query.KSecClassValue.kSecClassGenericPassword
            qDel.kSecAttrDescription = token
            qDel.kSecAttrGeneric = "12345678".dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: false)
            qDel.kSecAttrAccount = "admin"
            qDel.kSecReturnData = true
            qDel.kSecReturnAttributes = true
            qDel.kSecReturnRef = true
            qDel.kSecReturnPersistentRef = true
            
            let resDel = Keychain.secItemDelete(query: qDel)
            
            print(resDel)
         
            
        } else {
          
            
            NSIUtility.DBlog("Error Copying Objects: \(res.status.description)")

           
        }
        
      


    }
    
    //MARK: - Save Token from Keychain
    class func saveTokenToKeychain(accesstoken:String)throws->Bool {
        let q = Keychain.Query()
        
        q.kSecClass = Keychain.Query.KSecClassValue.kSecClassGenericPassword
        q.kSecAttrDescription = accesstoken
        q.kSecAttrGeneric = "12345678".dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: false)
        q.kSecAttrAccount = "admin"
        q.kSecReturnData = true
        q.kSecReturnAttributes = true
        q.kSecReturnRef = true
        q.kSecReturnPersistentRef = true
        
        
        let r = Keychain.secItemAdd(query: q)
        
        let success:Bool!
        
        if (r.status == Keychain.ResultCode.errSecSuccess) {
         
            NSIUtility.DBlog("Password saved. Returned object: \(r.result)")
            success = true
        } else {
                 NSIUtility.DBlog("Error saving password: \(r.status.description)")
            
            success = false
        }
        return success
       

    }
    
    //MARK: - Get Token from Keychain
    class func getTokenFromKeychain()throws->AnyObject {
        let q = Keychain.Query()
        
        q.kSecClass = Keychain.Query.KSecClassValue.kSecClassGenericPassword
        q.kSecAttrGeneric = "12345678".dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: false)
        q.kSecAttrAccount = "admin"
        q.kSecReturnData = true
        q.kSecReturnAttributes = true
        q.kSecReturnRef = true
        q.kSecReturnPersistentRef = true
        
        
        let res = Keychain.secItemCopyMatching(query: q)
        if (res.status == Keychain.ResultCode.errSecSuccess) {
         
           NSIUtility.DBlog("Returned object: \(res.result)")
            
        } else {
          
            NSIUtility.DBlog("Error saving password: \(res.status.description)")

           
        }
        
        return res.result!

    }
    
    
    
    
    // MARK: - Show AlertView Methods
    
    class func showAlert(title:String, message:String,view:UIViewController, delegate:AnyObject?) {
        
        
        if  Constants.Version.iOS7 {
            let alertView = UIAlertView(title: title, message: message, delegate: delegate, cancelButtonTitle: "OK")
                    alertView.show()
        
        }else{
       
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
        let defaultAction = UIAlertAction(title: "OK", style: .Default, handler: nil)
        alertController.addAction(defaultAction)
        view.presentViewController(alertController, animated: true, completion: nil)
            
        }
        

    }
    
    // MARK: - Show DebubLogs Methods
    /*
      1.    set value 1 to debubPrintLog to Enable the debuging logs
      2.    set value 0 to debubPrintLog to Disable the debuging logs
      3.    debubPrintLog is a Global variable
    */
    
    class func DBlog(message:AnyObject) {
        if debubPrintLog == 1{
        print(message)
        }
        else{
        
        }
        
    }
    
    /*
     __FILE__, __FUNCTION__, __LINE__ and __COLUMN__
    “macros” as default function parameter values in Swift the value is set to the file, 
    function etc of the caller rather than the details of the called functions location.
    
    */
  class func DLog(message: String, file: String = __FUNCTION__, function: String = __FILE__, line: Int = __LINE__, column: Int = __COLUMN__) {
        
        #if DEBUG
            print("\(file) : \(function) : \(line) : \(column) - \(message)")
        #endif

        
        
    }
    
   

   
}
