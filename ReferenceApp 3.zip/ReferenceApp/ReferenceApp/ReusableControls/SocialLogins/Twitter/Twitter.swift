//
//  Twitter.swift
//  ReferenceApp
//
//  Created by ravi kant on 11/26/15.
//  Copyright © 2015 Netsol. All rights reserved.
//

import Foundation
import TwitterKit
import Fabric
import SwiftyJSON


class TWitter: NSObject
{
    var responseBlock:CompleteSocialLoginBlock?
    // MARK: - Log In With Twitter
    func signInWithTwitter(vc:UIViewController!,Block:CompleteSocialLoginBlock){
        
        responseBlock = Block
        Twitter.sharedInstance().startWithConsumerKey("797TrX4HsLlC4qyuVUZk7ol6E", consumerSecret: "Nvm4NreUSdPuwfEUhnvjnoNXB6K5Og7srZTECUxKDzpVw33QMq")
        Fabric.with([Twitter.sharedInstance()])
        
        self.logout()
        Twitter.sharedInstance().logInWithCompletion { session, error in
            if let unwrappedSession = session {
                let alert = UIAlertController(title: "Logged In",
                    message: "User \(unwrappedSession.userName) has logged in",
                    preferredStyle: UIAlertControllerStyle.Alert
                )
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
                vc.presentViewController(alert, animated: true, completion: nil)
                
                NSIUtility.DBlog(unwrappedSession.userID)
                NSIUtility.DBlog(unwrappedSession.userName)
                NSIUtility.DBlog(unwrappedSession.authTokenSecret)
                NSIUtility.DBlog(unwrappedSession.authToken)
                
               NSIUtility.setValueToUserDefaultsForKey("userimageurl", value: "")
               NSIUtility.setValueToUserDefaultsForKey("username", value: unwrappedSession.userName)
                
                 self.responseBlock!(true,LoginType.LoginSourcetypeTwitter, unwrappedSession.authToken )
                
               // self.performSelector("requestToShare", withObject: nil, afterDelay: 1.0)
                
            } else {
                NSLog("Login error: %@", error!.localizedDescription);
                self.responseBlock!(false,LoginType.LoginSourcetypeTwitter,error!.localizedDescription)
            }
        }
        
    }
    
    
    func requestToShare(){
        
        let image = UIImage(named: "imageup.png")
        
        let media: String = "https://upload.twitter.com/1.1/media/upload.json"
        let imageData: NSData = UIImageJPEGRepresentation(image!, 0.9)!
        let imageString: String = imageData.base64EncodedStringWithOptions(NSDataBase64EncodingOptions.Encoding76CharacterLineLength)
        let request: NSURLRequest = Twitter.sharedInstance().APIClient.URLRequestWithMethod("POST", URL: media, parameters: ["media": imageString], error: nil)
       
        
        
        Twitter.sharedInstance().APIClient.sendTwitterRequest(request) { (response:NSURLResponse?, data:NSData?, error:NSError?) -> Void in
            
            if error != nil{
                NSIUtility.DBlog((error?.description)!)
            }else{
                
                NSIUtility.DBlog(response!)
                NSIUtility.DBlog(data!)

            }
       
            
        }
        
        
        
    }
    
    
    func logout(){
        
        Twitter.sharedInstance().logOut()
        
        
       
      }
}