//
//  ProfileViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 15/10/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIActionSheetDelegate,TaggedFriendsViewDelegate, ReportFeedDelegate {
    @IBOutlet weak var tblFeeds: UITableView!
    @IBOutlet weak var btnPhotos: UIButton!
    @IBOutlet weak var btnPost: UIButton!
    @IBOutlet weak var btnPaired: UIButton!
    @IBOutlet weak var btnLikes: UIButton!
    @IBOutlet weak var btnLikeProfile: UIButton!
    @IBOutlet weak var btnEditProfile: UIButton!
    @IBOutlet weak var imgVwProfilePic: UIImageView!
    @IBOutlet weak var btnRespondRequest: UIButton!
    @IBOutlet weak var vwRightNavButtons: UIView!
    @IBOutlet weak var containerVwTabs: UIView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var lblLocation: UILabel!
    @IBOutlet weak var imgVwCover: UIImageView!
    @IBOutlet weak var collVwTabs: UICollectionView!
    var isBookmarked: NSInteger!
    var isAudioPlaying: Bool = false
    var audioPlayingIndex: NSIndexPath!
    
    var cropController:DemoImageEditor!
    var isCover: Bool = false
    var arrFeedData: NSMutableArray! = []
    var arrPhotosData: NSMutableArray! = []
    var arrPairedData: NSMutableArray! = []
    var arrLikesData: NSMutableArray! = []
    var arrTabData: NSMutableArray! = []
    var userID: String = ""
    var tabType: String = "Photos"
    var pagePhotos = 1
    var pagePost = 1
    var pagePaired = 1
    var pageLikes = 1
    var profileID: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.navigationController?.navigationBarHidden = true
        self.navigationItem.title = ""
        tblFeeds.tableFooterView = UIView(frame: CGRectZero)
        btnPhotos.selected = true
        tblFeeds.hidden = true
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "editProfilePic")
        imgVwProfilePic.addGestureRecognizer(tapGesture)
        
        if userID == "" || userID == NSIConstants.userDefaults.valueForKey("userId") as! String {
            userID = NSIConstants.userDefaults.valueForKey("userId") as! String
            btnLikeProfile.hidden = true
            vwRightNavButtons.hidden = true
        }else{
            btnEditProfile.hidden = true
            imgVwProfilePic.userInteractionEnabled = false
        }
        self.navigationController?.navigationBarHidden = true
        if (Utility.checkNetwork() == true){
            pagePhotos = 1
            if(self.arrFeedData != nil){
                self.arrFeedData.removeAllObjects()
            }
            let dict:NSDictionary = [
                "profileId": userID,
                "userId": NSIConstants.userDefaults.valueForKey("userId") as! String
            ]
            print("\(dict)")
            fnGetProfileWebServiceWithPostDic(dict, showLoader: true)
        }
        //Paging
        tblFeeds.addInfiniteScrollingWithHandler {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), { () ->  Void in
                self.pagePost += 1
                let dict:NSDictionary = [
                    "profileId": self.userID,
                    "userId": NSIConstants.userDefaults.valueForKey("userId") as! String,
                    "page": self.pagePost,
                    "tap":"2"
                ]
                print("\(dict)")
                self.fnPagingWebServiceWithPostDic(dict, showLoader: false)
            })
        }
        //Paging
        collVwTabs.addInfiniteScrollingWithHandler {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), { () ->  Void in
                if self.tabType == "Photos"{
                    self.pagePhotos += 1
                    let dict:NSDictionary = [
                        "profileId": self.userID,
                        "userId": NSIConstants.userDefaults.valueForKey("userId") as! String,
                        "page": self.pagePhotos,
                        "tap":"1"
                    ]
                    print("\(dict)")
                    self.fnPagingWebServiceWithPostDic(dict, showLoader: false)
                }
                if self.tabType == "Paired"{
                    self.pagePaired += 1
                    let dict:NSDictionary = [
                        "profileId": self.userID,
                        "userId": NSIConstants.userDefaults.valueForKey("userId") as! String,
                        "page": self.pagePaired,
                        "tap":"3"
                    ]
                    print("\(dict)")
                    self.fnPagingWebServiceWithPostDic(dict, showLoader: false)
                }
                if self.tabType == "Likes"{
                    self.pageLikes += 1
                    let dict:NSDictionary = [
                        "profileId": self.userID,
                        "userId": NSIConstants.userDefaults.valueForKey("userId") as! String,
                        "page": self.pageLikes,
                        "tap":"4"
                    ]
                    print("\(dict)")
                    self.fnPagingWebServiceWithPostDic(dict, showLoader: false)
                }
                
                
            })
        }
        
        cropController = DemoImageEditor(nibName: "DemoImageEditor", bundle: nil)
        cropController.setLandscapeAction()
        cropController.checkBounds = true;
        cropController.rotateEnabled = false;
        cropController.doneCallback = {(editedImage: UIImage!, canceled: Bool) in
            if !canceled {
                if self.isCover == true{
                    self.imgVwCover.image = Utility.RBResizeImage(editedImage, targetSize: CGSizeMake(640, 486))
                    if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                        let dict:NSDictionary = [
                            "userId": userId
                        ]
                        print("\(dict)")
                        self.fnUpdateCoverPicWebServiceWithPostDic(dict, image: self.imgVwCover.image!)
                    }
                }
            }
            self.navigationController?.navigationBarHidden = false
            self.navigationController?.popViewControllerAnimated(false)
        }
    }
    
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.navigationBarHidden = true
        isBookmarked = nil
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        self.navigationController?.navigationBarHidden = false
        if AudioPlay.sharedInstance.audioPlayerBool == true {
            AudioPlay.sharedInstance.myPlayer.stop()
        }
        isAudioPlaying = false
    }

    // MARK: - Webservice Call Methods
    //Get Profile API
    func fnGetProfileWebServiceWithPostDic(dict: NSDictionary! , showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
//            ObjWebserviceCall.cachePolicy = WebserviceCallCachePolicyRequestFromCacheFirstAndThenFromUrlAndUpdateInCache
        if(showLoader){
            ObjWebserviceCall.isShowLoader = true
        }else{
            ObjWebserviceCall.isShowLoader = false
        }
        
        ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":NSIConstants.userDefaults.valueForKey("AUTHTOKEN") as! String]
        ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceGetProfile)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
            let response = response
//            if(response.isResponseFromCache){
//                
//            }else{
                print("GetFeedResponse \(response.webserviceResponse)")
                if response.webserviceResponse != nil {
                    if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                        //Profile Model
                        let arrDataProfile = response.webserviceResponse.valueForKey("profileDetail") as! NSDictionary
                        let objProfile = Profile().fillProfileDataInModel(arrDataProfile)
                        self.lblName.text = objProfile.firstName + " " + objProfile.lastName
                        self.btnPhotos.setTitle(objProfile.uploadedPhotosCount, forState: UIControlState.Normal)
                        self.btnPhotos.setTitle(objProfile.uploadedPhotosCount, forState: UIControlState.Selected)
                        self.btnPost.setTitle(objProfile.postCount, forState: UIControlState.Normal)
                        self.btnPaired.setTitle(objProfile.friendsCount, forState: UIControlState.Normal)
                        self.btnLikes.setTitle(objProfile.profileGotLikedCount, forState: UIControlState.Normal)
                        self.lblStatus.text = objProfile.aboutMe
                        self.profileID = objProfile.profileId
                        //UIImage Profile Image
                        self.imgVwProfilePic.imageURL = NSURL(string: objProfile.profilePic)
                        //UIImage Cover Image
                        self.imgVwCover.imageURL = NSURL(string: objProfile.coverImage)
                        //Button Like Profile Image
                        if objProfile.isLike == true {
                            self.btnLikeProfile .setImage(UIImage(named: "likeProfileSel"), forState: .Normal)
                        }else {
                            self.btnLikeProfile .setImage(UIImage(named: "likeProfile"), forState: .Normal)
                        }
                        //Button Send Friend Request
                        if objProfile.isFriend == true {
                            self.btnRespondRequest.userInteractionEnabled = false
                            self.btnRespondRequest.alpha = 0.5
                        }else {
                            self.btnRespondRequest.userInteractionEnabled = true
                            self.btnLikeProfile.alpha = 1.0
                        }
                                
                        //Photos Model
                        let arrDataPhotos = response.webserviceResponse.valueForKey("profileDetail")?.valueForKey("photos") as! NSArray
                        let arrPhotosModelData = PhotosTab().fillPhotosInModel(arrDataPhotos)
                        arrPhotosModelData.enumerateObjectsUsingBlock({ object, index, stop in
                            self.arrPhotosData.addObject(arrPhotosModelData.objectAtIndex(index))
                        })
                        self.arrTabData = self.arrPhotosData
                        self.fnAddAlertLabelOnTab(self.arrTabData, tabTypeSelected: "collection", strLabelText: "No photos uploaded yet.")
                        self.collVwTabs.reloadData()
                        //Paired Model
                        let arrDataPaired = response.webserviceResponse.valueForKey("profileDetail")?.valueForKey("friends") as! NSArray
                        let arrPairedModelData = PairedLikesTab().fillPairedLikeInModel(arrDataPaired)
                        arrPairedModelData.enumerateObjectsUsingBlock({ object, index, stop in
                            self.arrPairedData.addObject(arrPairedModelData.objectAtIndex(index))
                        })
                        //Likes Model-
                        let arrDataLikes = response.webserviceResponse.valueForKey("profileDetail")?.valueForKey("likes") as! NSArray
                        let arrLikesModelData = PairedLikesTab().fillPairedLikeInModel(arrDataLikes)
                        arrLikesModelData.enumerateObjectsUsingBlock({ object, index, stop in
                            self.arrLikesData.addObject(arrLikesModelData.objectAtIndex(index))
                        })
                        //Feed Model
                        let arrDataFeed = response.webserviceResponse.valueForKey("profileDetail")?.valueForKey("posts") as! NSArray
                        let arrDataModel = Feed().fillDataInModel(arrDataFeed)
                        arrDataModel.enumerateObjectsUsingBlock({ object, index, stop in
                            self.arrFeedData.addObject(arrDataModel.objectAtIndex(index))
                        })
                        self.tblFeeds.reloadData()
                        self.tblFeeds.infiniteScrollingView?.stopAnimating()
                        
                    }else{
                        self.tblFeeds.infiniteScrollingView?.stopAnimating()
                        if (response.webserviceResponse.valueForKey("status") as! String != "Data not found"){
                            Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                        }
                    }
                }
//            }
            }) { (error: NSError!) -> Void in
        }
    }
    
    //Get Load More API
    func fnPagingWebServiceWithPostDic(dict: NSDictionary! , showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
            ObjWebserviceCall.cachePolicy = WebserviceCallCachePolicyRequestFromCacheFirstAndThenFromUrlAndUpdateInCache
        if(showLoader){
            ObjWebserviceCall.isShowLoader = true
        }else{
            ObjWebserviceCall.isShowLoader = false
        }
        ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":NSIConstants.userDefaults.valueForKey("AUTHTOKEN") as! String]
        ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebservicePagingProfile)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
            let response = response
            if(response.isResponseFromCache){
                
            }else{
                print("GetLoadmoreResponse \(response.webserviceResponse)")
                if response.webserviceResponse != nil {
                    if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                        if self.tabType == "Photos"{
                            //Photos Model
                            let arrDataPhotos = response.webserviceResponse.valueForKey("photos") as! NSArray
                            let arrPhotosModelData = PhotosTab().fillPhotosInModel(arrDataPhotos)
                            arrPhotosModelData.enumerateObjectsUsingBlock({ object, index, stop in
                                self.arrPhotosData.addObject(arrPhotosModelData.objectAtIndex(index))
                            })
                            self.collVwTabs.reloadData()
                            self.collVwTabs.infiniteScrollingView?.stopAnimating()
                        }
                        if self.tabType == "Post"{
                            //Feed Model
                            let arrDataFeed = response.webserviceResponse.valueForKey("posts") as! NSArray
                            let arrDataModel = Feed().fillDataInModel(arrDataFeed)
                            arrDataModel.enumerateObjectsUsingBlock({ object, index, stop in
                                self.arrFeedData.addObject(arrDataModel.objectAtIndex(index))
                            })
                            self.tblFeeds.reloadData()
                            self.tblFeeds.infiniteScrollingView?.stopAnimating()
                        }
                        if self.tabType == "Paired"{
                            //Paired Model
                            let arrDataPaired = response.webserviceResponse.valueForKey("friends") as! NSArray
                            let arrPairedModelData = PairedLikesTab().fillPairedLikeInModel(arrDataPaired)
                            arrPairedModelData.enumerateObjectsUsingBlock({ object, index, stop in
                                self.arrPairedData.addObject(arrPairedModelData.objectAtIndex(index))
                            })
                            self.collVwTabs.reloadData()
                            self.collVwTabs.infiniteScrollingView?.stopAnimating()
                        }
                        if self.tabType == "Likes"{
                            //Likes Model
                            let arrDataLikes = response.webserviceResponse.valueForKey("likes") as! NSArray
                            let arrLikesModelData = PairedLikesTab().fillPairedLikeInModel(arrDataLikes)
                            arrLikesModelData.enumerateObjectsUsingBlock({ object, index, stop in
                                self.arrLikesData.addObject(arrLikesModelData.objectAtIndex(index))
                            })
                            self.collVwTabs.reloadData()
                            self.collVwTabs.infiniteScrollingView?.stopAnimating()
                        }
                        
                    }else{
                        if self.arrFeedData.count == 0 {
                            self.btnPost.setTitle("0", forState: UIControlState.Normal)
                            self.fnAddAlertLabelOnTab(self.arrFeedData, tabTypeSelected: "table", strLabelText: "No posts added yet.")
                        }
                        self.tblFeeds.reloadData()
                        self.tblFeeds.infiniteScrollingView?.stopAnimating()
                        if (response.webserviceResponse.valueForKey("status") as! String != "No more data" && response.webserviceResponse.valueForKey("status") as! String != "Result not found"){
                            Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                        }
                    }
                    self.tblFeeds.infiniteScrollingView?.stopAnimating()
                    self.collVwTabs.infiniteScrollingView?.stopAnimating()
                }
            }
            }) { (error: NSError!) -> Void in
        }
    }
    
    //Send Friend Request API
    func fnFriendRequestWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceSendFriendReq)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("Send Friend Req--- \(response.webserviceResponse)")
                if (response.webserviceResponse != nil) {
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }else{
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                }
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
    }
    
    //Profile Like Request API
    func fnProfileLikeWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceLikeProfile)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("Send Friend Req--- \(response.webserviceResponse)")
                if (response.webserviceResponse != nil) {
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                    self.btnLikeProfile .setImage(UIImage(named: "likeProfileSel"), forState: .Normal)
                }else{
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                }
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
    }
    
    // Update Profile Pic API
    func fnUpdateProfilePicWebServiceWithPostDic(dict: NSDictionary!, image:UIImage) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        ObjWebserviceCall.isShowLoader = true
        if let AuthToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":AuthToken]
            ObjWebserviceCall.parametersDict = dict! as [NSObject : AnyObject]
            
            var imgData: NSData? = nil
            imgData = UIImageJPEGRepresentation(image, 1.0)
            
            var arrData: NSArray = []
            let dictData: NSMutableDictionary = NSMutableDictionary()
            dictData.setValue("profilePic", forKey: "fileKey")
            dictData.setValue("image.png", forKey: "fileName")
            dictData.setValue("image/png", forKey: "contentType")
            dictData.setValue(imgData, forKey: "data")
            arrData = [dictData]
            
            /*
            fileKey = "image/audio"
            fileName = "image.png/audio.m4a"
            contentType = "image/png,audio/m4a"
            data = "data"
            */
            
            ObjWebserviceCall.uploadDataWithImage(arrData as [AnyObject] , onUrl: NSURL(string: "\(BASE_URL+WebserviceUpdateProfilePic)"), withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("\(response.webserviceResponse)")
                if (response.webserviceResponse != nil) {
                Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                })
                { (error: NSError!) -> Void in
                    let error = error
                    print("\(error)")
            }
        }
        
    }
    
    // Update Cover Pic API
    func fnUpdateCoverPicWebServiceWithPostDic(dict: NSDictionary!, image:UIImage) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        ObjWebserviceCall.isShowLoader = true
        if let AuthToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":AuthToken]
            ObjWebserviceCall.parametersDict = dict! as [NSObject : AnyObject]
            
            var imgData: NSData? = nil
            imgData = UIImageJPEGRepresentation(image, 1.0)
            var arrData: NSArray = []
            let dictData: NSMutableDictionary = NSMutableDictionary()
            dictData.setValue("coverPhoto", forKey: "fileKey")
            dictData.setValue("image.png", forKey: "fileName")
            dictData.setValue("image/png", forKey: "contentType")
            dictData.setValue(imgData, forKey: "data")
            arrData = [dictData]
            
            /*
            fileKey = "image/audio"
            fileName = "image.png/audio.m4a"
            contentType = "image/png,audio/m4a"
            data = "data"
            */
            
            ObjWebserviceCall.uploadDataWithImage(arrData as [AnyObject] , onUrl: NSURL(string: "\(BASE_URL+WebserviceUpdateCoverPic)"), withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("\(response.webserviceResponse)")
                if (response.webserviceResponse != nil) {
                Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                })
                { (error: NSError!) -> Void in
                    let error = error
                    print("\(error)")
            }
        }
        
    }
    //Save Bookmark API
    func fnSaveBookmarkWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceSaveBookmark)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("SaveBookmark--- \(response.webserviceResponse)")
                
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    
                    
                }else{
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                
                }) { (error: NSError!) -> Void in
            }
            
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
    //Delete Post API
    func fnDeletePostWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceDeletePost)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("DeletePost--- \(response.webserviceResponse)")
                if (response.webserviceResponse != nil) {
                    if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                        if(self.arrFeedData != nil && self.arrFeedData.count > 0){
                            self.arrFeedData.removeAllObjects()
                        }
                        self.fnReloadFeedData()
                    }else{
                        Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                    }
                }
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
    }
    
    //MARK: - UIButton Action
    @IBAction func btnPressed_Photos(sender: AnyObject) {
        tabType = "Photos"
        tblFeeds.hidden = true
        collVwTabs.hidden = false
        btnPhotos.selected = true
        btnPost.selected = false
        btnPaired.selected = false
        btnLikes.selected = false
        print("photos---\(self.arrPhotosData)")
        arrTabData = arrPhotosData
        fnAddAlertLabelOnTab(arrTabData, tabTypeSelected: "collection", strLabelText: "No photos uploaded yet.")
        collVwTabs.reloadData()
        
    }
    @IBAction func btnPressed_Post(sender: AnyObject) {
        tabType = "Post"
        tblFeeds.hidden = false
        collVwTabs.hidden = true
        btnPhotos.selected = false
        btnPost.selected = true
        btnPaired.selected = false
        btnLikes.selected = false
        self.fnAddAlertLabelOnTab(self.arrFeedData, tabTypeSelected: "table", strLabelText: "No posts added yet.")
    }
    @IBAction func btnPressed_Paired(sender: AnyObject) {
        tabType = "Paired"
        tblFeeds.hidden = true
        collVwTabs.hidden = false
        btnPhotos.selected = false
        btnPost.selected = false
        btnPaired.selected = true
        btnLikes.selected = false
        self.arrTabData = self.arrPairedData
        fnAddAlertLabelOnTab(arrTabData, tabTypeSelected: "collection", strLabelText: "No friends added yet.")
        self.collVwTabs.reloadData()
    }
    @IBAction func btnPressed_Likes(sender: AnyObject) {
        tabType = "Likes"
        tblFeeds.hidden = true
        collVwTabs.hidden = false
        btnPhotos.selected = false
        btnPost.selected = false
        btnPaired.selected = false
        btnLikes.selected = true
        self.arrTabData = self.arrLikesData
        fnAddAlertLabelOnTab(arrTabData, tabTypeSelected: "collection", strLabelText: "No likes added yet.")
        self.collVwTabs.reloadData()
    }
    
    func fnAddAlertLabelOnTab(arrDataCheck: NSMutableArray, tabTypeSelected: String, strLabelText: String){
        if tabTypeSelected == "table" {
        if arrDataCheck.count == 0 {
            let lblMsg = UILabel(frame: CGRectMake(0, 0, self.tblFeeds.frame.size.width, 50))
            lblMsg.center = self.tblFeeds.center
            lblMsg.text = "No posts added yet."
            lblMsg.numberOfLines = 0
            lblMsg.textAlignment = NSTextAlignment.Center
            lblMsg.font = UIFont(name: "Lato-Regular", size: 16)
            lblMsg.textColor = UIColor.blackColor()
            self.tblFeeds.backgroundView = lblMsg
            self.tblFeeds.scrollEnabled = false
        }else{
            self.tblFeeds.backgroundView = nil
            self.tblFeeds.scrollEnabled = true
        }
        }else{
            if arrDataCheck.count == 0 {
                let lblMsg = UILabel(frame: CGRectMake(0, 0, self.collVwTabs.frame.size.width, 50))
                lblMsg.center = self.collVwTabs.center
                lblMsg.text = strLabelText
                lblMsg.numberOfLines = 0
                lblMsg.textAlignment = NSTextAlignment.Center
                lblMsg.font = UIFont(name: "Lato-Regular", size: 16)
                lblMsg.textColor = UIColor.blackColor()
                self.collVwTabs.backgroundView = lblMsg
                self.collVwTabs.scrollEnabled = false
            }else{
                self.collVwTabs.backgroundView = nil
                self.collVwTabs.scrollEnabled = true
            }
        }
    }
    
    func updateProfileTab(data: NSMutableArray) {
        let dictTemp: NSDictionary = ["type":tabType, "data":data]
        NSNotificationCenter.defaultCenter().postNotificationName("tabData", object: dictTemp)
    }
    
    @IBAction func btnPressed_Back(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    @IBAction func btnPressed_AddFriend(sender: AnyObject) {
        let dict:NSDictionary = [
            "userId": NSIConstants.userDefaults.valueForKey("userId") as! String,
            "friendId": self.userID
        ]
        print("\(dict)")
        self.fnFriendRequestWebServiceWithPostDic(dict, showLoader: true)
    }
    @IBAction func btnPressed_Message(sender: AnyObject) {
        let objChatVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("ChatViewController") as! ChatViewController
        objChatVC.receiverId = self.profileID
        self.navigationController?.pushViewController(objChatVC, animated: true)
    }
    @IBAction func btnPressed_More(sender: AnyObject) {
        let reportView = ReportInappropriateView.init(frame: CGRectMake(0, 0, self.view.frame.width, self.view.frame.height))
        reportView.setUpReportView(["center":[250, 200]])
        self.view.addSubview(reportView)
    }
    @IBAction func btnPressed_LikeProfile(sender: AnyObject) {
        let dict:NSDictionary = [
            "userId": NSIConstants.userDefaults.valueForKey("userId") as! String,
            "profileId": self.userID
        ]
        print("\(dict)")
        self.fnProfileLikeWebServiceWithPostDic(dict, showLoader: true)
    }
    
    @IBAction func btnPressed_Bookmark(sender: AnyObject) {
        let pointInTable: CGPoint = sender.convertPoint(sender.bounds.origin, toView: tblFeeds)
        let cellIndexPath: NSIndexPath = tblFeeds.indexPathForRowAtPoint(pointInTable)!
        let objFeedCell:Feed = arrFeedData.objectAtIndex(cellIndexPath.row) as! Feed
        let cell: UITableViewCell = tblFeeds.cellForRowAtIndexPath(cellIndexPath)!
        
        //Previous cell
        if isBookmarked != nil {
            let indexPathPre = NSIndexPath(forRow: isBookmarked, inSection: 0)
            if tblFeeds.indexPathsForVisibleRows!.contains(indexPathPre) {
                let cellPrevious: UITableViewCell = tblFeeds.cellForRowAtIndexPath(indexPathPre)!
                if let btnBookmark:UIButton = cellPrevious.viewWithTag(1005) as? UIButton {
                    btnBookmark.setImage(UIImage(named: "btnBookmark"), forState: .Normal)
                }
            }
        }
        isBookmarked = cellIndexPath.row
        if let btnBookmark:UIButton = cell.viewWithTag(1005) as? UIButton {
            if objFeedCell.isBookmark == "1" {
                btnBookmark.setImage(UIImage(named: "btnBookmark"), forState: .Normal)
            }else{
                btnBookmark.setImage(UIImage(named: "btnBookmarkSelected"), forState: .Normal)
            }
        }
        if let userId = NSIConstants.userDefaults.valueForKey("userId") {
            let dict:NSDictionary = [
                "userId": userId,
                "postId": objFeedCell.postId
            ]
            print("\(dict)")
            fnSaveBookmarkWebServiceWithPostDic(dict, showLoader: true)
        }
    }
    
    @IBAction func btnPressed_EditProfile(sender: AnyObject) {
        isCover = true
        fnChooseImage()
    }
    func editProfilePic(){
        isCover = false
        fnChooseImage()
    }
    
    @IBAction func btnPressed_PlayAudio(sender: AnyObject) {
        let pointInTable: CGPoint = sender.convertPoint(sender.bounds.origin, toView: tblFeeds)
        let cellIndexPath: NSIndexPath = tblFeeds.indexPathForRowAtPoint(pointInTable)!
        let objFeedCell:Feed = arrFeedData.objectAtIndex(cellIndexPath.row) as! Feed
        let cell: UITableViewCell = tblFeeds.cellForRowAtIndexPath(cellIndexPath)!
        if objFeedCell.audioUrl != "" {
        if isAudioPlaying == false{
            AudioPlay.sharedInstance.fnPlayAudioURL(objFeedCell.audioUrl)
            isAudioPlaying = true
            audioPlayingIndex = cellIndexPath
            //Sound Wave
            if let btnWave:UIButton = cell.viewWithTag(1007) as? UIButton {
                let jeremyGif = UIImage.gifWithName("waveAnimated")
                btnWave.setBackgroundImage(jeremyGif, forState: .Normal)
            }
        }else{
            //Sound Wave
            if let btnWave:UIButton = cell.viewWithTag(1007) as? UIButton {
                audioPlayingIndex = nil
                btnWave.setBackgroundImage(UIImage(named: "waveSimple.png"), forState: .Normal)
            }
            if AudioPlay.sharedInstance.audioPlayerBool == true {
                AudioPlay.sharedInstance.myPlayer.stop()
            }
            isAudioPlaying = false
        }
        }
    }
    
    //MARK: - UIButton Actions
    @IBAction func btnPressed_View(sender: AnyObject) {
    }
    
    @IBAction func btnPressed_Comment(sender: AnyObject) {
        let pointInTable: CGPoint = sender.convertPoint(sender.bounds.origin, toView: tblFeeds)
        let cellIndexPath: NSIndexPath = tblFeeds.indexPathForRowAtPoint(pointInTable)!
        let objFeedCell:Feed = arrFeedData.objectAtIndex(cellIndexPath.row) as! Feed
        
        let objCommentVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("CommentsViewController") as! CommentsViewController
        objCommentVC.postId = objFeedCell.postId
        self.navigationController!.presentViewController(objCommentVC, animated: true, completion: nil)
    }
    
    @IBAction func btnPressed_Inappropriate(sender: AnyObject) {
        let pointInTable: CGPoint = sender.convertPoint(sender.bounds.origin, toView: tblFeeds)
        let cellIndexPath: NSIndexPath = tblFeeds.indexPathForRowAtPoint(pointInTable)!
        let objFeedCell:Feed = arrFeedData.objectAtIndex(cellIndexPath.row) as! Feed
        
        if NSIConstants.userDefaults.valueForKey("userId") as! String == objFeedCell.userId {
            let objOptionMenu = UIAlertController(title: nil, message: "Choose option", preferredStyle: .ActionSheet)
            let deleteAction = UIAlertAction(title: "Delete Post", style: .Destructive, handler: {
                (alert: UIAlertAction) -> Void in
                //                "userId": "2864", "feedId":"42044"
                if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                    let dict:NSDictionary = [
                        "userId": userId,
                        "feedId": objFeedCell.postId
                    ]
                    print("\(dict)")
                    self.fnDeletePostWebServiceWithPostDic(dict, showLoader: true)
                }
            })
            let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: {
                (alert: UIAlertAction) -> Void in
                
            })
            objOptionMenu.addAction(cancelAction)
            objOptionMenu.addAction(deleteAction)
            self.presentViewController(objOptionMenu, animated: true, completion: nil)
        }else{
            let reportView = ReportInappropriateView.init(frame: CGRectMake(0, 0, self.view.frame.width, self.view.frame.height))
            reportView.delegate = self;
            let strUserId: String = NSIConstants.userDefaults.valueForKey("userId") as! String
            reportView.setUpReportView(["center":[self.view.frame.size.width/2, self.view.frame.size.height/2],"data":["userId": strUserId,"feedId":objFeedCell.postId]])
            self.view.addSubview(reportView)
        }
    }
    
    func fnReloadFeedData(){
        let dict:NSDictionary = [
            "profileId": self.userID,
            "userId": NSIConstants.userDefaults.valueForKey("userId") as! String,
            "page": "1",
            "tap":"2"
        ]
        print("\(dict)")
        self.fnPagingWebServiceWithPostDic(dict, showLoader: false)
    }
    
    func reportFeedTapped(){
        fnReloadFeedData()
    }
    

    
    //MARK: - TableView DataSource/Delegate
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (arrFeedData != nil){
            return arrFeedData.count
        }
        return 0
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if(tableView.respondsToSelector(Selector("setSeparatorInset:"))){
            tableView.separatorInset = UIEdgeInsetsZero
        }
        if(tableView.respondsToSelector(Selector("setLayoutMargins:"))){
           
            tableView.layoutMargins = UIEdgeInsetsZero
            
        }
        if(cell.respondsToSelector(Selector("setLayoutMargins:"))){
            
            cell.layoutMargins = UIEdgeInsetsZero
            
        }
    }
    
    func tableView(tableView: UITableView!, heightForRowAtIndexPath indexPath: NSIndexPath!) -> CGFloat {
        
        return self.getRowHeightFeedCell(indexPath)
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var strCellIdentifier: NSString
        
        let objFeedCell:Feed = arrFeedData.objectAtIndex(indexPath.row) as! Feed
        if objFeedCell.feedType == "Status" {
            strCellIdentifier = "cellStatus"
        }else{
        if(objFeedCell.audioUrl == "" && objFeedCell.photo == "" && objFeedCell.statusText != ""){
            strCellIdentifier = "cellText"
        }
        else if(objFeedCell.audioUrl != "" && objFeedCell.photo == "" && objFeedCell.statusText == ""){
            strCellIdentifier = "cellSound"
        }
        else if(objFeedCell.audioUrl != "" && objFeedCell.photo == "" && objFeedCell.statusText != ""){
            strCellIdentifier = "cellSoundText"
        }
        else if(objFeedCell.audioUrl == "" && objFeedCell.photo != "" && objFeedCell.statusText != ""){
            strCellIdentifier = "cellImgText"
        }
        else if(objFeedCell.audioUrl != "" && objFeedCell.photo != "" && objFeedCell.statusText == ""){
            strCellIdentifier = "cellImgSound"
        }else
        {
            strCellIdentifier = "cellFeedAll"
        }
        }
        let cell = tableView.dequeueReusableCellWithIdentifier(
            strCellIdentifier as String, forIndexPath: indexPath)
        
        //--------------------------UserInfo View--------------------------------
        //UIImage Profile Image
        if let imgVwProfile:AsyncImageView = cell.viewWithTag(1001) as? AsyncImageView {
            imgVwProfile.image = UIImage(named: "placeholder")
            if let variableName: String = objFeedCell.profilePic{
                imgVwProfile.imageURL = NSURL(string: variableName)
            }
        }
        //Label Name
        if let lblName:UILabel = cell.viewWithTag(1002) as? UILabel {
//            let strFname: String = objFeedCell.firstName
//            let strLname: String = objFeedCell.lastName
            let strUsername: String = objFeedCell.userName
            lblName.text = strUsername
        }
        //Label Location
        if let lblLocation:UILabel = cell.viewWithTag(1003) as? UILabel {
            lblLocation.text = objFeedCell.location
            if let imgVwLocation:UIImageView = cell.viewWithTag(4566) as? UIImageView {
                if (lblLocation.text == ""){
                    imgVwLocation.hidden = true
                }else{
                    imgVwLocation.hidden = false
                }
            }
        }
        //Label time
        if let lblTime:UILabel = cell.viewWithTag(1004) as? UILabel {
            let strSec: NSInteger = Int(objFeedCell.minutesAgo)! * 60
            let date = NSDate(timeInterval: NSTimeInterval(-strSec), sinceDate: NSDate())
            lblTime.text = Utility.relativeDateStringForDate(date)
            
        }
        //-----------------------------------------------------------------------
        
        //--------------------------Post Image--------------------------------
        //UIImage Post Image
        if let imgVwPost:AsyncImageView = cell.viewWithTag(1006) as? AsyncImageView {
            imgVwPost.image = UIImage(named: "err")
            if let variableName: String = objFeedCell.photo{
                imgVwPost.crossfadeDuration = 0.0
                imgVwPost.imageURL = NSURL(string: variableName)
            } else {
                // abc is nil
            }
        }
        //-----------------------------------------------------------------------
        
        //--------------------------Bookmark Image--------------------------------
        if let btnBookmark:UIButton = cell.viewWithTag(1005) as? UIButton {
            if objFeedCell.isBookmark == "1" {
                btnBookmark.setImage(UIImage(named: "btnBookmarkSelected"), forState: .Normal)
            }else{
                btnBookmark.setImage(UIImage(named: "btnBookmark"), forState: .Normal)
            }
            if isBookmarked != nil {
                if indexPath.row == isBookmarked {
                    btnBookmark.setImage(UIImage(named: "btnBookmarkSelected"), forState: .Normal)
                }else{
                    btnBookmark.setImage(UIImage(named: "btnBookmark"), forState: .Normal)
                }
            }
        }
        
        //-------------------------------------------------------------------

        //----------------------------Audio Wave------------------------------
        if isAudioPlaying == true && audioPlayingIndex != nil && audioPlayingIndex == indexPath{
            //Sound Wave
            if let btnWave:UIButton = cell.viewWithTag(1007) as? UIButton {
                let jeremyGif = UIImage.gifWithName("waveAnimated")
                btnWave.setBackgroundImage(jeremyGif, forState: .Normal)
            }
        }else{
            //Sound Wave
            if let btnWave:UIButton = cell.viewWithTag(1007) as? UIButton {
                btnWave.setBackgroundImage(UIImage(named: "waveSimple.png"), forState: .Normal)
            }
        }
        //-------------------------------------------------------------------
        
        for view in cell.contentView.subviews{
            if(view.tag == 9852 || view.tag == 2589 || view.tag == 4563){
                view.removeFromSuperview()
            }
        }
        
        let lblStatus = UILabel()
        lblStatus.textAlignment = NSTextAlignment.Left
        if objFeedCell.feedType == "Status" {
            //Label Status
            if let txtStatusText:UITextView = cell.viewWithTag(3001) as? UITextView {
                txtStatusText.text = objFeedCell.statusText
                txtStatusText.textAlignment = NSTextAlignment.Center
                txtStatusText.scrollEnabled = false
                txtStatusText.font = UIFont(name: "ChalkDustRegularSWFTE", size: 20.0)
                lblStatus.text = " "
            }
        }else{
            lblStatus.text = objFeedCell.statusText
        }
        let lblHeight = self.heightForView(lblStatus.text!, width: cell.frame.size.width - 30)
        lblStatus.tag = 9852
        lblStatus.numberOfLines = 0
        lblStatus.font = UIFont(name: "Lato-Regular", size: 14)
        lblStatus.lineBreakMode = NSLineBreakMode.ByWordWrapping
        lblStatus.sizeToFit()
        if(strCellIdentifier == "cellSoundText"){
            lblStatus.frame = CGRectMake(15, 149, cell.frame.size.width - 30, lblHeight + 2)
            cell.contentView.addSubview(lblStatus)
        }else if(strCellIdentifier == "cellText"){
            lblStatus.frame = CGRectMake(15, 79, cell.frame.size.width - 30, lblHeight + 2)
            cell.contentView.addSubview(lblStatus)
        }else if(strCellIdentifier == "cellImgText"){
            lblStatus.frame = CGRectMake(15, 310, cell.frame.size.width - 30, lblHeight + 2)
            cell.contentView.addSubview(lblStatus)
        }else if(strCellIdentifier == "cellFeedAll"){
            lblStatus.frame = CGRectMake(15, 359, cell.frame.size.width - 30, lblHeight + 2)
            cell.contentView.addSubview(lblStatus)
        }else{
            if objFeedCell.audioUrl == "" {
                //Sound Wave
                if let btnWave:UIButton = cell.viewWithTag(1007) as? UIButton {
                    btnWave.hidden = true
                }
                lblStatus.frame = CGRectMake(15, 290, cell.frame.size.width - 30, lblHeight + 2)
                cell.contentView.addSubview(lblStatus)
            }else{
                if let btnWave:UIButton = cell.viewWithTag(1007) as? UIButton {
                    btnWave.hidden = false
                }
                lblStatus.frame = CGRectMake(15, 320, cell.frame.size.width - 30, lblHeight + 2)
                cell.contentView.addSubview(lblStatus)
            }
            
        }
        
        //Tagged Friends
        let arrTagedFriends = objFeedCell.taggedFriendList
        if(arrTagedFriends.count > 0){
            let strTagNames: NSMutableString = "- with "
            if(arrTagedFriends.count > 2){
                
                for var index = 0; index < 2; ++index {
                    strTagNames.appendString(arrTagedFriends.objectAtIndex(index).valueForKey("nickName") as! String)
                    strTagNames.appendString(" ,")
                }
                if (strTagNames.length > 0) {
                    strTagNames.deleteCharactersInRange(NSMakeRange(strTagNames.length-1, 1))
                }
                strTagNames.appendString("and \(arrTagedFriends.count - 2) others")
            }else{
                
                arrTagedFriends.enumerateObjectsUsingBlock({ object, index, stop in
                    let objTaggedFriends:TagFriendList = arrTagedFriends.objectAtIndex(index) as! TagFriendList
                    strTagNames.appendString(objTaggedFriends.nickName)
                    strTagNames.appendString(" ,")
                })
                if (strTagNames.length > 0) {
                    strTagNames.deleteCharactersInRange(NSMakeRange(strTagNames.length-1, 1))
                }
            }
            
            let main_string = strTagNames
            let attributedString = NSMutableAttributedString(string:main_string as String)
            attributedString.addAttribute(NSForegroundColorAttributeName, value: UIColor.blackColor() , range: NSRange(
                location:0,
                length:6))
            attributedString.addAttribute(NSForegroundColorAttributeName, value: UIColor.blueColor() , range: NSRange(
                location:7,
                length:strTagNames.length - 7))
            attributedString.addAttribute(NSFontAttributeName,
                value: UIFont(name: "Lato-Regular", size: 14)!,
                range: NSRange(
                    location: 0,
                    length: strTagNames.length))
            
            let lblTaggedFriend = UILabel()
            lblTaggedFriend.textAlignment = NSTextAlignment.Left
            lblTaggedFriend.attributedText = attributedString
            lblTaggedFriend.frame = CGRectMake(15, lblStatus.frame.origin.y + lblStatus.frame.size.height + 5, cell.frame.size.width - 30, lblHeight)
            lblTaggedFriend.tag = 4563
            lblTaggedFriend.numberOfLines = 1
            lblTaggedFriend.lineBreakMode = NSLineBreakMode.ByWordWrapping
            lblTaggedFriend.sizeToFit()
            cell.contentView.addSubview(lblTaggedFriend)
            
            let btnTagList   = UIButton(type: UIButtonType.Custom) as UIButton
            btnTagList.frame = CGRectMake(15, lblStatus.frame.origin.y + lblStatus.frame.size.height + 5, cell.frame.size.width - 30, 30)
            btnTagList.tag = 2589
            btnTagList.backgroundColor = UIColor.clearColor()
            btnTagList.setTitle("", forState: UIControlState.Normal)
            btnTagList.addTarget(self, action: "buttonActionTagList:", forControlEvents: UIControlEvents.TouchUpInside)
            cell.contentView.addSubview(btnTagList)
        }
        
        //--------------------------Bottom Comment Section--------------------------------
        //Label Views
        if let btnViews:UIButton = cell.viewWithTag(1009) as? UIButton {
            let xString : String = (objFeedCell.viewsCount)!
            btnViews .setTitle(xString + " Views", forState: .Normal)
            
        }
        //Label Comments
        if let btnComments:UIButton = cell.viewWithTag(1010) as? UIButton {
            btnComments .setTitle((objFeedCell.commentsCount)! + " Comments", forState: .Normal)
        }
        //-----------------------------------------------------------------------
        
        return cell
    }
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
    }
    
    //Calculate UILabel height
    func heightForView(text:String, width:CGFloat) -> CGFloat{
        let label:UILabel = UILabel(frame: CGRectMake(0, 0, width, CGFloat.max))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.ByWordWrapping
        label.font = UIFont(name: "Lato-Regular", size: 14)
        label.text = text
        label.sizeToFit()
        return label.frame.height
    }
    
    //Tag Button Clicked
    func buttonActionTagList(sender:UIButton!)
    {
        let pointInTable: CGPoint = sender.convertPoint(sender.bounds.origin, toView: tblFeeds)
        let cellIndexPath: NSIndexPath = tblFeeds.indexPathForRowAtPoint(pointInTable)!
        let objFeedCell:Feed = arrFeedData.objectAtIndex(cellIndexPath.row) as! Feed
        let arrTagedFriends = objFeedCell.taggedFriendList
        
        let taggedFriendsView = TaggedFriendListView.init(frame: CGRectMake(0, 0, self.view.frame.width, self.view.frame.height))
        taggedFriendsView.delegate = self
        taggedFriendsView.setUpTaggedFriendView(["tagList":arrTagedFriends])
        self.view.addSubview(taggedFriendsView)
    }
    
    func taggedFriendTapped(userId: String) {
        let objProfileVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("ProfileViewController") as! ProfileViewController
        objProfileVC.userID = userId
        self.navigationController!.pushViewController(objProfileVC, animated: true)
    }
    
    //MARK - Get Feed Cell Height
    func getRowHeightFeedCell(indexPath: NSIndexPath) -> CGFloat{
        let objFeedCell:Feed = arrFeedData.objectAtIndex(indexPath.row) as! Feed
        if objFeedCell.feedType == "Status" {
            if objFeedCell.audioUrl == "" {
                let arrTagedFriends = objFeedCell.taggedFriendList
                if(arrTagedFriends.count > 0){
                    return 420
                }
                return 380
            }else{
                let arrTagedFriends = objFeedCell.taggedFriendList
                if(arrTagedFriends.count > 0){
                    return 444
                }
                return 414
            }
        }else{
            
            if(objFeedCell.audioUrl == "" && objFeedCell.photo == "" && objFeedCell.statusText != ""){
                let lblHeight = self.heightForView(objFeedCell.statusText, width: tblFeeds.frame.size.width - 30)
                let arrTagedFriends = objFeedCell.taggedFriendList
                if(arrTagedFriends.count > 0){
                    return 167 + 20 + lblHeight
                }
                return 167 + lblHeight
            }
            else if(objFeedCell.audioUrl != "" && objFeedCell.photo == "" && objFeedCell.statusText == ""){
                let arrTagedFriends = objFeedCell.taggedFriendList
                if(arrTagedFriends.count > 0){
                    return 184 + 20
                }
                return 184
            }
            else if(objFeedCell.audioUrl != "" && objFeedCell.photo == "" && objFeedCell.statusText != ""){
                let lblHeight = self.heightForView(objFeedCell.statusText, width: tblFeeds.frame.size.width - 30)
                let arrTagedFriends = objFeedCell.taggedFriendList
                if(arrTagedFriends.count > 0){
                    return 207 + 20 + lblHeight
                }
                return 207 + lblHeight
            }
            else if(objFeedCell.audioUrl == "" && objFeedCell.photo != "" && objFeedCell.statusText != ""){
                let lblHeight = self.heightForView(objFeedCell.statusText, width: tblFeeds.frame.size.width - 30)
                let arrTagedFriends = objFeedCell.taggedFriendList
                if(arrTagedFriends.count > 0){
                    return 397 + 20 + lblHeight
                }
                return 397 + lblHeight
                
            }
            else if(objFeedCell.audioUrl != "" && objFeedCell.photo != "" && objFeedCell.statusText == ""){
                return 141
            }else
            {
                let lblHeight = self.heightForView(objFeedCell.statusText, width: tblFeeds.frame.size.width - 30)
                let arrTagedFriends = objFeedCell.taggedFriendList
                if(arrTagedFriends.count > 0){
                    return 437 + 20 + lblHeight
                }
                return 437 + lblHeight
            }
        }
    }
    
    // MARK: UICollectionView Delegate
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if arrTabData != nil {
            return arrTabData.count
        }
        return 0
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        
        if tabType == "Photos"{
            let objPhoto:PhotosTab = arrTabData.objectAtIndex(indexPath.row) as! PhotosTab
            
            let cell = collectionView.dequeueReusableCellWithReuseIdentifier("cellPhotos", forIndexPath: indexPath)
            // Configure the cell
            //UIImage Photo Image
            if let imgVwPhoto:AsyncImageView = cell.viewWithTag(1001) as? AsyncImageView {
                imgVwPhoto.image = UIImage(named: "er")
                if let variableName: String = objPhoto.photoUrl{
                    imgVwPhoto.crossfadeDuration = 0.0
                    imgVwPhoto.imageURL = NSURL(string: variableName)
                }
            }
            
            return cell
        }else{
            
            let cell = collectionView.dequeueReusableCellWithReuseIdentifier("cellLikesPaired", forIndexPath: indexPath)
            // Configure the cell
            if tabType == "Paired"{
                let objPaired:PairedLikesTab = arrTabData.objectAtIndex(indexPath.row) as! PairedLikesTab
                //UIImage Profile Image
                if let imgVwProfile:AsyncImageView = cell.viewWithTag(1001) as? AsyncImageView {
                    imgVwProfile.image = UIImage(named: "placeholder")
                    if let variableName: String = objPaired.profilePicUrl{
                        imgVwProfile.crossfadeDuration = 0.0
                        imgVwProfile.imageURL = NSURL(string: variableName)
                    }
                }
                //Label Name
                if let lblName:UILabel = cell.viewWithTag(1002) as? UILabel {
                    let strFname: String = objPaired.firstName
                    let strLname: String = objPaired.lastName
                    lblName.text = strFname + " " + strLname
                }
                
            }else{
                let objLikes:PairedLikesTab = arrTabData.objectAtIndex(indexPath.row) as! PairedLikesTab
                //UIImage Profile Image
                if let imgVwProfile:AsyncImageView = cell.viewWithTag(1001) as? AsyncImageView {
                    imgVwProfile.image = UIImage(named: "placeholder")
                    if let variableName: String = objLikes.profilePicUrl{
                        imgVwProfile.crossfadeDuration = 0.0
                        imgVwProfile.imageURL = NSURL(string: variableName)
                    }
                }
                //Label Name
                if let lblName:UILabel = cell.viewWithTag(1002) as? UILabel {
                    let strFname: String = objLikes.firstName
                    let strLname: String = objLikes.lastName
                    lblName.text = strFname + " " + strLname
                }
            }
            
            
            return cell
        }
        
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath){
        if tabType == "Paired"{
            let objPaired:PairedLikesTab = arrTabData.objectAtIndex(indexPath.row) as! PairedLikesTab
            let objProfileVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("ProfileViewController") as! ProfileViewController
            objProfileVC.userID = objPaired.userId
            self.navigationController!.pushViewController(objProfileVC, animated: true)
        }else if tabType == "Likes"{
            let objLikes:PairedLikesTab = arrTabData.objectAtIndex(indexPath.row) as! PairedLikesTab
            let objProfileVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("ProfileViewController") as! ProfileViewController
            objProfileVC.userID = objLikes.userId
            self.navigationController!.pushViewController(objProfileVC, animated: true)
        }else if tabType == "Photos"{
            let photoView = PhotoDisplayView.init(frame: CGRectMake(0, 0, self.view.frame.width, self.view.frame.height))
            photoView.setUpDisplayImagesView(self.arrPhotosData, indexSelected: indexPath.row)
            self.view.addSubview(photoView)
        }
        
    }
    
    // MARK: UICollectionViewFlowLayout Delegate
    
    func collectionView(collectionView: UICollectionView,
        layout collectionViewLayout: UICollectionViewLayout,
        sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
            if tabType == "Photos"{
                //375,414
                if (UIScreen.mainScreen().bounds.size.width == 375){
                    return CGSizeMake(118, 118)
                }else if(UIScreen.mainScreen().bounds.size.width == 414){
                    return CGSizeMake(131, 131)
                }else{
                    return CGSizeMake(100, 100)
                }
            }else{
                //375,414
                if (UIScreen.mainScreen().bounds.size.width == 375){
                    return CGSizeMake(collVwTabs.frame.size.width, 50)
                }else if(UIScreen.mainScreen().bounds.size.width == 414){
                    return CGSizeMake(collVwTabs.frame.size.width, 50)
                }else{
                    return CGSizeMake(collVwTabs.frame.size.width, 50)
                }
            }
    }
    
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAtIndex section: Int) -> UIEdgeInsets {
        if tabType == "Photos"{
            return UIEdgeInsetsMake(5, 5, 5, 5)
        }else{
            return UIEdgeInsetsMake(0, 0, 0, 0)
        }
        
    }
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAtIndex section: Int) -> CGFloat {
        if tabType == "Photos"{
            return 5
        }else{
            return 1
        }
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAtIndex section: Int) -> CGFloat {
        if tabType == "Photos"{
            return 5
        }else{
            return 1
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    if segue.destinationViewController is ProfileTabViewController{
    let objProfileTabVC: ProfileTabViewController = segue.destinationViewController as! ProfileTabViewController
    }
    }
    */
    
    // MARK: - UIImagePickerControllerDelegate Methods
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        UIApplication.sharedApplication().statusBarStyle = .LightContent
        if isCover{
            if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
                cropController.sourceImage = pickedImage
                cropController.previewImage = pickedImage
                dismissViewControllerAnimated(true, completion: nil)
                self.navigationController?.navigationBarHidden = false
                self.navigationController!.pushViewController(cropController, animated: false)
            }else{
                dismissViewControllerAnimated(true, completion: nil)
            }
        }else{
            if let pickedImage = info[UIImagePickerControllerEditedImage] as? UIImage {
                self.imgVwProfilePic.image = Utility.RBResizeImage(pickedImage, targetSize: CGSizeMake(320, 320))
                dismissViewControllerAnimated(true, completion: nil)
                
                if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                    let dict:NSDictionary = [
                        "userId": userId
                    ]
                    print("\(dict)")
                    fnUpdateProfilePicWebServiceWithPostDic(dict, image: self.imgVwProfilePic.image!)
                }
            }else{
                dismissViewControllerAnimated(true, completion: nil)
            }
        }
        
    }
    
    
    func fnChooseImage() {
//        if #available(iOS 8.0, *) {
            let objOptionMenu = UIAlertController(title: nil, message: "Choose Option", preferredStyle: .ActionSheet)
            let cameraAction = UIAlertAction(title: "Camera", style: .Default, handler: {
                (alert: UIAlertAction) -> Void in
                self.fnOpenCamera()
            })
            
            let galleryAction = UIAlertAction(title: "Gallery", style: .Default, handler: {
                (alert: UIAlertAction) -> Void in
                self.fnOpenPhotoGallery()
            })
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: {
                (alert: UIAlertAction) -> Void in
                
            })
            objOptionMenu.addAction(cameraAction)
            objOptionMenu.addAction(galleryAction)
            objOptionMenu.addAction(cancelAction)
            
            self.presentViewController(objOptionMenu, animated: true, completion: nil)
//        } else {
//            // Fallback on earlier versions
//            let objActionSheet = UIActionSheet()
//            objActionSheet.title = "Choose Option"
//            objActionSheet.addButtonWithTitle("Camera")
//            objActionSheet.addButtonWithTitle("Gallery")
//            objActionSheet.addButtonWithTitle("Cancel")
//            objActionSheet.cancelButtonIndex = 2
//            objActionSheet.tag = 2356
//            objActionSheet.delegate = self
//            objActionSheet.showInView(self.view)
//        }
    }
    
    func actionSheet(myActionSheet: UIActionSheet, clickedButtonAtIndex buttonIndex: Int){
        if(myActionSheet.tag == 2356){
            
            if (buttonIndex == 0){
                print("the index is 0")
                self.fnOpenCamera()
            }
            if (buttonIndex == 1){
                print("the index is 1")
                self.fnOpenPhotoGallery()
            }
            if (buttonIndex == 2){
                print("the index is 2")
            }
            
        }
    }
    
    func fnOpenCamera() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera)
        {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            if isCover{
                imagePicker.allowsEditing = false
            }else{
                imagePicker.allowsEditing = true
            }
            imagePicker.sourceType = UIImagePickerControllerSourceType.Camera;
            self.presentViewController(imagePicker, animated: true, completion: nil)
            
        }else{
            Utility.showAlert("", message: "Camera not available." as String, delegate: nil)
        }
    }
    
    func fnOpenPhotoGallery() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.PhotoLibrary){
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            if isCover{
                imagePicker.allowsEditing = false
            }else{
                imagePicker.allowsEditing = true
            }
            imagePicker.sourceType = UIImagePickerControllerSourceType.PhotoLibrary;
            self.presentViewController(imagePicker, animated: true, completion: nil)
            
        }else{
            Utility.showAlert("", message: "Gallery not available." as String, delegate: nil)
        }
    }
    
}
