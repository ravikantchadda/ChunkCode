//
//  MapViewCell.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/25/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//


import UIKit
import GoogleMaps
import CoreLocation

enum TravelModes: Int {
    case driving
    case walking
    case bicycling
}


class MapViewCell: UITableViewCell {

    @IBOutlet var mapView: GMSMapView!
    @IBOutlet weak var mapCenterPinImage: UIImageView!
    @IBOutlet var titleView:UIView!
    @IBOutlet var btnTitleName: UIButton!
    @IBOutlet var viewShowDistance: UIView!
    @IBOutlet var lblSpeed: UILabel!
    
    var strAdress:String!
    var callBack:AnyObject!
    var liftRequest:LiftRequestVC!
    var addressData:GMSAddress!
    var markerOfFromLoc = GMSMarker()
    var markerOfToLocation=GMSMarker()
    
    var mapTasks = MapTasks()
    
    let locationManager = CLLocationManager()
    
    var polyline = GMSPolyline()
    var travelMode = TravelModes.driving
    

    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        locationManager.requestWhenInUseAuthorization()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        mapView.myLocationEnabled = true
        mapView.settings.myLocationButton = true
        locationManager.startUpdatingLocation()
        
        mapView.delegate = self
        mapView.updateConstraintsIfNeeded()
    }
    

    
    func reverseGeocodeCoordinate(coordinate: CLLocationCoordinate2D) {
        
        if callBack is AddNewAddressVC || callBack is MyProfileAddressVC {
            let geocoder = GMSGeocoder()
            geocoder.reverseGeocodeCoordinate(coordinate) { response , error in
                if let address:GMSAddress = response?.firstResult() {
                    let lines = address.lines as! [String]
                    self.strAdress = lines.joinWithSeparator("\n")
                    self.addressData = address
                    self.titleView.fadeIn(0.25)
                }else{
                    self.titleView.fadeOut(0.25)
                    self.strAdress = ""
                    self.addressData = nil
                }
                self.updateTheController()
            }
        }
    }
    
    func updateTheController(){
        
        if (callBack != nil && callBack.respondsToSelector("setTheLocation")){
             callBack.performSelector("setTheLocation")
            
        }
    }
    

//Mark:- Add Marker

    func addMarkerToPickupLocation(fromLocationData:AddressBO, title:String){
        
            markerOfFromLoc.position = fromLocationData.locationCords
//            markerOfFromLoc.snippet = title
            markerOfFromLoc.appearAnimation = kGMSMarkerAnimationPop
            markerOfFromLoc.map = mapView
            markerOfFromLoc.icon = UIImage(named: "icon_me")
        
            mapView.camera = GMSCameraPosition.cameraWithLatitude(fromLocationData.locationCords.latitude,
            longitude: fromLocationData.locationCords.longitude, zoom: 16)
        
    }
    
    func addMarkerToDestinationLocation(toLocationData:AddressBO, title:String){

        markerOfToLocation.position = toLocationData.locationCords
        markerOfToLocation.snippet = title
        markerOfToLocation.appearAnimation = kGMSMarkerAnimationPop
        markerOfToLocation.map = mapView
        markerOfToLocation.icon = UIImage(named: "icon_me")
        
        mapView.camera = GMSCameraPosition.cameraWithLatitude(toLocationData.locationCords.latitude,
            longitude: toLocationData.locationCords.longitude, zoom: 16)
    }
    
//Mark:- Add Route
    
    func addRouteToMap(fromLocation:CLLocationCoordinate2D,withDestinationLoc destinationLoc:CLLocationCoordinate2D){
        
        let origin = "\(fromLocation.latitude)" + "," + "\(fromLocation.longitude)"
        let destination = "\(destinationLoc.latitude)" + "," + "\(destinationLoc.longitude)"
        
        self.mapTasks.getDirections(origin, destination: destination, waypoints: nil, travelMode: self.travelMode, completionHandler: { (status, success) -> Void in
            if success {
                self.drawRoute()
                self.lblSpeed.text = "\(self.mapTasks.totalDistance) km/ \(self.mapTasks.totalDurationInMinutes) mins"
//                self.mapView.camera = GMSCameraPosition.cameraWithTarget(self.mapTasks.originCoordinate, zoom: 10.0)
                let zoom = GMSCameraPosition.zoomAtCoordinate(self.mapTasks.originCoordinate, forMeters:Double(self.mapTasks.totalDistanceInMeters)  , perPoints: 200)
                self.mapView.camera = GMSCameraPosition.cameraWithTarget(self.mapTasks.originCoordinate, zoom: zoom-1)
            }
            else {
                print(status)
            }
        })
    }
    
    func drawRoute(){
        
        let route = mapTasks.overviewPolyline["points"] as! String
        let path: GMSPath = GMSPath(fromEncodedPath: route)
        polyline.path = path
        polyline.strokeWidth = 4.0
        //        polyline.geodesic = true
        polyline.map = self.mapView
    }
    
    
    @IBAction func toSelectLocation(sender: UIButton) {
        if liftRequest != nil{
            
            if sender.currentTitle == "Change \(liftRequest.strPickupOrDeparted)" || sender.currentTitle == "Set \(liftRequest.strPickupOrDeparted)"{
                liftRequest.setLocationOfMap(.FromLocation)
            }else{
                liftRequest.setLocationOfMap(.ToLocation)
            }
        }
    }

}

// / // /// / / //  -- - - - -- - - -- -  Delgates Of Map and Location -- --- ---- - - -- - -  //////// // // / // /


// MARK: - CLLocationManagerDelegate
    extension MapViewCell: CLLocationManagerDelegate {
        func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus) {
            if status == CLAuthorizationStatus.AuthorizedWhenInUse {

            }
        }
        
//        func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//            var locValue:CLLocationCoordinate2D = manager.location.coordinate
//            print("locations = \(locValue.latitude) \(locValue.longitude)")
//        }

        func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
            if  self.locationManager.location != nil{
                mapView.camera = GMSCameraPosition(target: self.locationManager.location!.coordinate, zoom: 15, bearing: 0, viewingAngle: 0)
                self.locationManager.stopUpdatingLocation()
            }
        }
    }
    
// MARK: - GMSMapViewDelegate
    extension MapViewCell: GMSMapViewDelegate {
        func mapView(mapView: GMSMapView!, idleAtCameraPosition position: GMSCameraPosition!) {
            reverseGeocodeCoordinate(position.target)
        }
        
        func mapView(mapView: GMSMapView!, willMove gesture: Bool) {
            
            if (gesture) {
                mapCenterPinImage.fadeIn(0.25)
                mapView.selectedMarker = nil
            }
        }
        
//        func mapView(mapView: GMSMapView!, markerInfoContents marker: GMSMarker!) -> UIView! {
//            let placeMarker = marker as! GMSMarker
//            
//            return nil
//        }
        
//        func mapView(mapView: GMSMapView!, didTapMarker marker: GMSMarker!) -> Bool {
//            mapCenterPinImage.fadeOut(0.25)
//            return false
//        }
        
//        func didTapMyLocationButtonForMapView(mapView: GMSMapView!) -> Bool {
//            mapCenterPinImage.fadeIn(0.25)
//            mapView.selectedMarker = nil
//            return false
//        }
    }

