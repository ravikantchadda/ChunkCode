//
//  LiftInfoView.swift
//  LocalLift
//
//  Created by prabhjot singh on 12/8/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class LiftInfoView: UIView {

    @IBOutlet var imgProfile: UIImageView!
    @IBOutlet var viewUrgentBar: UIView!
    @IBOutlet var imgLiftIcon: UIImageView!
    @IBOutlet var lblNoOfPeople: UILabel!
    @IBOutlet var lblTitleNotification: UILabel!
    @IBOutlet var lblLiftDate: UILabel!
    @IBOutlet var lblDestination: UILabel!
    @IBOutlet var imgGroupView:UIImageView!
    var liftBO:LiftBO!
    
    
    
    func toSetLiftViewData(mapMarkerBo:MapMarkerBO){
        
        let liftDL = LiftDL()
        liftDL.requestForGetMarkerInformation(mapMarkerBo) { (obj, success) -> Void in
            if success == true{
                
                if let liftBo = obj as? LiftBO{
                    self.liftBO = liftBo
                    self.imgLiftIcon.image = (mapMarkerBo.isOfferRequest == true ? UIImage(named: "offerIcon"):UIImage(named: "requestIcon2"))
                    self.lblNoOfPeople.text = "\(liftBo.seats)"
                    let liftString = (mapMarkerBo.isOfferRequest == true ? "offered":"requested")
                    self.lblTitleNotification.text = "\(liftBo.liftRequesterName)" + " \(liftString)"
                    self.lblLiftDate.text = liftBo.requestedDatetime.toString(format:.Custom(Constants.DateTimeFormatwithAMPM))
                    self.lblDestination.text = liftBo.toAddress
                    
                    self.lblNoOfPeople.hidden = mapMarkerBo.isOfferRequest
                    self.imgGroupView.hidden = mapMarkerBo.isOfferRequest
                    self.viewUrgentBar.hidden = !mapMarkerBo.isImmediate
                    
                }
            }
        }
    }
}
