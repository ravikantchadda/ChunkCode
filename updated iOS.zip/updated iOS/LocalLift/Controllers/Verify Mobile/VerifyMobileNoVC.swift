//
//  VerifyMobileNoVC.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/4/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class VerifyMobileNoVC: BaseViewController {
    
    var countryCode:CountryCodeBO!
    @IBOutlet var btnCountryCode: UIButton!
    @IBOutlet var txtMobileNo: UITextField!
    @IBOutlet var btnResendCode: PSCustomFontButton!
    
//MARK: - View Life Cycle Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.intialIntialization()
    }

    func intialIntialization()
    {
        let verifyObj:VerifyOTPVC = self.lastViewController() as! VerifyOTPVC
        print(verifyObj)
        
        let userObj = UserBO.sharedInstanceOfUser
        txtMobileNo.text = userObj.userMobileNo
        btnCountryCode.setTitle(userObj.userCountryObj.countryName + "  " + userObj.userCountryObj.countryCode, forState: UIControlState.Normal)
        btnCountryCode.roundCorner(5)
        self.toSelectBtnValidation()
    }
    
//MARK: - Button Action Methods
    
    @IBAction func toResendCode(sender: AnyObject){
            let nexmoDL = NexmoDL()
            let userBO:UserBO = UserBO.sharedInstanceOfUser
        

            nexmoDL.requestTheNexmoMobile("\(userBO.userCountryObj.countryCode + self.txtMobileNo.text!)" ) { (obj, success) -> Void in
            if success == true{
                let verifyObj:VerifyOTPVC = self.lastViewController() as! VerifyOTPVC
                verifyObj.nexmoObject.requestID = obj?.valueForKey("requestID") as! String
                self.navigationController?.popViewControllerAnimated(true)
            }else{
            }
            
        }
    }
    
//MARK: - Text Field Delegates
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
        return UITextField.textField(textField, shouldChangeCharactersInRange: range, replacementString: string,
            withMaxLength: UITextField.MaxLength.MobileNoMax, spaceAllowed: false)
    }
    
    
    func toSelectBtnValidation()
    {
        if  self.txtMobileNo.text?.length < 10{
            btnResendCode.backgroundColor = UIColor.colorWithRGB(31, green: 81, blue: 108, alpha: 0.7)
            btnResendCode.userInteractionEnabled = false
        }
        else{
            btnResendCode.backgroundColor = Constants.APP_THEME_COLOR
            btnResendCode.userInteractionEnabled = true
        }
    }
    

}
