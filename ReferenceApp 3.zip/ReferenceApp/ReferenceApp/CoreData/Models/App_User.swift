//
//  App_User.swift
//  ReferenceApp
//
//  Created by Mohit Jain on 10/13/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import Foundation
import CoreData

@objc(App_User)
class App_User: NSManagedObject {
    @NSManaged var create_date: NSDate?
    @NSManaged var fb_id: String?
    @NSManaged var google_id: String?
    @NSManaged var id: NSNumber?
    @NSManaged var last_login: NSDate?
    @NSManaged var linked_id: String?
    @NSManaged var username: String?
    @NSManaged var profile: NSSet?
}
