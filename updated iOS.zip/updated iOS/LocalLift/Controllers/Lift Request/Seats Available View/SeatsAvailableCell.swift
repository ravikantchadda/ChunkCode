//
//  SeatsAvailableCell.swift
//  LocalLift
//
//  Created by prabhjot singh on 12/15/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class SeatsAvailableCell: UITableViewCell,UITextFieldDelegate {

    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var lblSeats: UILabel!
    @IBOutlet var txtSeats: UITextField!
    var value:Int!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    @IBAction func toChangedSlider(sender: UISlider) {
       
        value = Int(sender.value)
        lblSeats.text = "\(value) Seats"
        
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool{
         return UITextField.textField(textField, shouldChangeCharactersInRange: range, replacementString: string, withMaxLength:.CodeMax, spaceAllowed: false)
    }
    
}
