//
//  UpdateStatusViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 06/10/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit
import AssetsLibrary
import CoreLocation
import AVFoundation
import MediaPlayer

class UpdateStatusViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIAlertViewDelegate, CLLocationManagerDelegate {
    
    @IBOutlet weak var btnGallery: UIButton!
    @IBOutlet weak var btnTagFriend: UIButton!
    @IBOutlet weak var btnMusic: UIButton!
    @IBOutlet weak var collVwPhotoLibrary: UICollectionView!
    @IBOutlet weak var tblVwFriendsTag: UITableView!
    @IBOutlet weak var txtVw_Comment: UITextView!
    @IBOutlet weak var lblTaggedFriendName: UILabel!
    @IBOutlet weak var btnRemoveTagFriends: UIButton!
    @IBOutlet weak var vwMusic: UIView!
    @IBOutlet weak var lblTextCount: UILabel!
    
    var count = 0
    var imgSelected: NSIndexPath!
    var stopped = false
    var indexSelected: NSInteger!
    var arrFriendList: NSArray!
    var arrFriendSelected: NSMutableArray = []
    var arrLibSongs: NSMutableArray = []
    var strSelectedFriends: NSMutableString = ""
    var strSelectedNames: NSMutableString = ""
    var imageSelected: UIImage!
    let locationManager = CLLocationManager()
    var strLocation: String = ""
    var strTagSongType: String = ""
    var selectedSongIndex: NSIndexPath!
    var audioDataTrimmed: NSData!
    var objMusicPlayer: MPMusicPlayerController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.navigationItem.titleView = Utility.navBarTitleLabel("Update Status")
        //        self.navigationItem.hidesBackButton = true
        //        self.navigationItem.leftBarButtonItem = Utility.navBarLeftButton(UIImage(named: "btnBack")!, viewController: self)
        self.navigationItem.rightBarButtonItem = Utility.navBarRightButton(UIImage(named: "savePost")!, viewController: self)
        tblVwFriendsTag.tableFooterView = UIView(frame: CGRectZero)
        tblVwFriendsTag.allowsMultipleSelection = false
        btnGallery.selected = true
        vwMusic.hidden = true
        objMusicPlayer = MPMusicPlayerController.systemMusicPlayer()
        
        self.view.bringSubviewToFront(collVwPhotoLibrary)
        btnRemoveTagFriends.hidden = true
        self.collVwPhotoLibrary.allowsMultipleSelection = false
        self.collVwPhotoLibrary.delaysContentTouches = false
        
        if (Utility.checkNetwork() == true){
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            if #available(iOS 9.0, *) {
                locationManager.requestLocation()
                locationManager.requestWhenInUseAuthorization()
            } else {
                // Fallback on earlier versions
                //            if #available(iOS 8.0, *) {
                locationManager.requestWhenInUseAuthorization()
                //            }
                // Fallback on earlier versions
                
            }
            locationManager.startUpdatingLocation()
        }
        
    }
    override func viewDidDisappear(animated: Bool) {
        super.viewDidDisappear(true)
        if objMusicPlayer.playbackState == MPMusicPlaybackState.Playing {
            objMusicPlayer.stop()
        }
    }
    
    // MARK: - CLLocationManagerDelegate
    
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        if (Utility.checkNetwork() == true){
            // Add below code to get address for touch coordinates.
            if (locations.first != nil) {
                //                print("Current location: \(location)")
                let geoCoder = CLGeocoder()
                
                geoCoder.reverseGeocodeLocation(manager.location!, completionHandler: { (placemarks, error) -> Void in
                    let placeArray = placemarks
                    // Place details
                    var placeMark: CLPlacemark!
                    placeMark = placeArray?[0]
                    if (placeMark != nil){
                        // City
                        if let city = placeMark.addressDictionary?["City"] as? NSString
                        {
                            print(city)
                            self.strLocation = city as String
                        }
                        // Location name
                        if let locationName = placeMark.addressDictionary?["Name"] as? NSString
                        {
                            print(locationName)
                            self.strLocation = self.strLocation + " ,\(locationName)"
                        }
                        //                        print("Location---- \(self.strLocation)")
                    }
                    self.locationManager.stopUpdatingLocation()
                })
            } else {
                
            }
        }
    }
    
    func locationManager(manager: CLLocationManager, didFailWithError error: NSError) {
        print("Error finding location: \(error.localizedDescription)")
        Utility.showAlert("", message: "Unable to get your location, please go to Settings and turn on location service for this app.", delegate: nil)
    }
    
    // MARK: - Webservice Call Methods
    // Post API
    func fnPostImageWebServiceWithPostDic(dict: NSDictionary!) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        ObjWebserviceCall.isShowLoader = true
        if let AuthToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":AuthToken]
            var imgData: NSData? = nil
            let arrData: NSMutableArray = []
            ObjWebserviceCall.parametersDict = dict! as [NSObject : AnyObject]
            if((imageSelected) != nil){
                imgData = UIImageJPEGRepresentation(imageSelected, 1.0)
                let dictData: NSMutableDictionary = NSMutableDictionary()
                dictData.setValue("photo", forKey: "fileKey")
                dictData.setValue("image.png", forKey: "fileName")
                dictData.setValue("image/png", forKey: "contentType")
                dictData.setValue(imgData, forKey: "data")
                arrData.addObject(dictData)
            }
            if audioDataTrimmed != nil {
                let dictData: NSMutableDictionary = NSMutableDictionary()
                dictData.setValue("audio", forKey: "fileKey")
                dictData.setValue("audio.mp3", forKey: "fileName")
                dictData.setValue("audio/mp3", forKey: "contentType")
                dictData.setValue(audioDataTrimmed, forKey: "data")
                arrData.addObject(dictData)
            }
            /*
            fileKey = "image/audio"
            fileName = "image.png/audio.m4a"
            contentType = "image/png,audio/m4a"
            data = "data"
            */
            
            ObjWebserviceCall.uploadDataWithImage(arrData as [AnyObject] , onUrl: NSURL(string: "\(BASE_URL+WebserviceSaveFeed)"), withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("\(response.webserviceResponse)")
                if (response.webserviceResponse != nil) {
                    if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                        
                        if response.webserviceResponse.valueForKey("action") as! String == "notifyTaggedFriends" {
                            let dict: NSDictionary = response.webserviceResponse.valueForKey("notifyTaggedFriends") as! NSDictionary
                            //GCD Backgroung queue
                            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)) {
                                // do your task
                                self.fnNotifyTagFriendsWebServiceWithPostDic(dict, showLoader: false)
                                dispatch_async(dispatch_get_main_queue()) {
                                    // update some UI
                                }
                            }
                        }
                        let alert = UIAlertController(title: "", message: NSIConstants.photoUploadCheck, preferredStyle: .Alert)
                        let action = UIAlertAction(title: "OK", style: .Default) { _ in
                            
                            self.navigationController?.popViewControllerAnimated(true)
                        }
                        alert.addAction(action)
                        self.presentViewController(alert, animated: true, completion: nil)
                        
                        
                    }else{
                        Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                    }
                }
                })
                { (error: NSError!) -> Void in
                    let error = error
                    print("\(error)")
            }
        }
        
    }
    
    //NotifiTagged Friend API
    func fnNotifyTagFriendsWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceNotifyTagFriends)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("getTagFriends--- \(response.webserviceResponse)")
                if (response.webserviceResponse != nil) {
                    if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                        
                    }else{
                        
                        Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                    }
                }
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
    
    func alertView(View: UIAlertView, clickedButtonAtIndex buttonIndex: Int){
        
        if (buttonIndex == 0){
            self.navigationController?.popViewControllerAnimated(true)
        }
    }
    
    // MARK: - NavigationBar LeftBarButton Method
    func fnLeftBarButton(){
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    // MARK: - NavigationBar RightBarButton Method
    func fnRightBarButton(){
        self.view.endEditing(true)
        if(txtVw_Comment.text == "Add status here"){
            Utility.showAlert("", message: "Please add status here" as String, delegate: nil)
        }else if((imageSelected) == nil){
            Utility.showAlert("", message: "Please select photo." as String, delegate: nil)
        }
        else{
            
            if (selectedSongIndex != nil) {
                let mpItem = arrLibSongs.objectAtIndex(selectedSongIndex.row).valueForKey("mpItem") as! MPMediaItem
                let url:NSURL = mpItem.valueForProperty(MPMediaItemPropertyAssetURL) as! NSURL
                
                if let asset: AVAsset = AVAsset(URL: url) {
                    exportAsset(asset, fileName: "trimmed.m4a")
                }
            }else {
                
                if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                    let dict:NSDictionary = [
                        "userId": userId,
                        "statusText": txtVw_Comment.text,
                        "type": "1",
                        "location": self.strLocation,
                        "taggedFriends": strSelectedFriends,
                        "hashTags": ""
                    ]
                    print("\(dict)")
                    fnPostImageWebServiceWithPostDic(dict)
                }
            }
        }
        
    }
    
    // MARK: - UIButton Actions
    @IBAction func btnPressed_Gallery(sender: UIButton) {
        btnGallery.selected = true
        btnMusic.selected = false
        btnTagFriend.selected = false
        self.view.bringSubviewToFront(collVwPhotoLibrary)
    }
    @IBAction func btnPressed_TagFriend(sender: UIButton) {
        strTagSongType = "tag"
        btnGallery.selected = false
        btnMusic.selected = false
        btnTagFriend.selected = true
        self.view.bringSubviewToFront(tblVwFriendsTag)
        
        if let userId = NSIConstants.userDefaults.valueForKey("userId") {
            let dict:NSDictionary = [
                "userId": userId,
                "page": "1"
            ]
            print("\(dict)")
            fnGetFriendsWebServiceWithPostDic(dict, showLoader: true)
        }
    }
    
    @IBAction func btnPressed_Music(sender: UIButton) {
        strTagSongType          = "song"
        btnGallery.selected     = false
        btnMusic.selected       = true
        btnTagFriend.selected   = false
        self.view.bringSubviewToFront(tblVwFriendsTag)
        
        if(self.arrLibSongs.count > 0){
            self.arrLibSongs.removeAllObjects()
        }
        
        let songsQuery: MPMediaQuery  = MPMediaQuery.songsQuery()
        let songsLocal: NSArray = songsQuery.items!
        if songsLocal.count > 0 {
            songsLocal.enumerateObjectsUsingBlock({ object, index, stop in
                let rowItem1: MPMediaItem = songsLocal.objectAtIndex(index) as! MPMediaItem
                if (rowItem1.valueForProperty( MPMediaItemPropertyTitle ) != nil && rowItem1.valueForProperty( MPMediaItemPropertyAssetURL ) != nil) {
                    let dictTemp: NSDictionary = ["title": rowItem1.valueForProperty( MPMediaItemPropertyTitle ) as! String, "url": rowItem1.valueForProperty( MPMediaItemPropertyAssetURL ) as! NSURL, "mpItem":rowItem1]
                    self.arrLibSongs.addObject(dictTemp)
                }
            })
            print("songs---\(arrLibSongs)")
            
        }else{
            Utility.showAlert("", message: "No music in your library.", delegate: nil)
        }
        tblVwFriendsTag.reloadData()
    }
    
    // MARK: UICollectionView Delegate
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return 22
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("cell", forIndexPath: indexPath)
        // Configure the cell
        
        if let imgLibrary = cell.contentView.viewWithTag(123) as? UIImageView {
            imgLibrary.image = UIImage(named: "\(indexPath.row + 1)")
        }
        
        if (imgSelected != nil && imgSelected == indexPath){
            
            let imgVw = UIImageView(frame: CGRectMake(0, 0, cell.frame.size.width, cell.frame.size.height))
            imgVw.image = UIImage(named: "photoSelected")
            imgVw.tag = 6514
            imgVw.contentMode = UIViewContentMode.Center
            if let imgLibrary = cell.contentView.viewWithTag(123) as? UIImageView {
                imgLibrary.alpha = 0.6
            }
            cell.contentView.addSubview(imgVw)
        }else{
            if let imgLibrary = cell.contentView.viewWithTag(123) as? UIImageView {
                imgLibrary.alpha = 1.0
            }
            for view in cell.contentView.subviews{
                if(view.tag == 6514){
                    view.removeFromSuperview()
                }
            }
        }
        
        return cell
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath){
        
        let cell : UICollectionViewCell = collectionView.cellForItemAtIndexPath(indexPath)!
        let imgVw = UIImageView(frame: CGRectMake(0, 0, cell.frame.size.width, cell.frame.size.height))
        imgVw.image = UIImage(named: "photoSelected")
        imgVw.tag = 6514
        imgVw.contentMode = UIViewContentMode.Center
        if let imgLibrary = cell.contentView.viewWithTag(123) as? UIImageView {
            imgLibrary.alpha = 0.6
        }
        cell.contentView.addSubview(imgVw)
        imgSelected = indexPath
        imageSelected = UIImage(named: "\(indexPath.row + 1)")
        collVwPhotoLibrary.reloadData()
    }
    
    // MARK: UICollectionViewFlowLayout Delegate
    
    func collectionView(collectionView: UICollectionView,
        layout collectionViewLayout: UICollectionViewLayout,
        sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
            //375,414
            if (UIScreen.mainScreen().bounds.size.width == 375){
                return CGSizeMake(118, 118)
            }else if(UIScreen.mainScreen().bounds.size.width == 414){
                return CGSizeMake(131, 131)
            }else{
                return CGSizeMake(100, 100)
            }
            
    }
    
    
    // MARK: UITableView Delegate
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if strTagSongType == "tag"{
            if (self.arrFriendList != nil){
                return self.arrFriendList.count
            }
            return 0
        }else{
            return self.arrLibSongs.count;
        }
        
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if(tableView.respondsToSelector(Selector("setSeparatorInset:"))){
            tableView.separatorInset = UIEdgeInsetsZero
        }
        if(tableView.respondsToSelector(Selector("setLayoutMargins:"))){
            
            tableView.layoutMargins = UIEdgeInsetsZero
            
        }
        if(cell.respondsToSelector(Selector("setLayoutMargins:"))){
            
            cell.layoutMargins = UIEdgeInsetsZero
            
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        if strTagSongType == "tag"{
            let cell = tableView.dequeueReusableCellWithIdentifier(
                "cellTagFriends", forIndexPath: indexPath)
            
            if let imgVwPic:AsyncImageView = cell.viewWithTag(8001) as? AsyncImageView {
                imgVwPic.image = UIImage(named: "placeholder")
                if let variableName: String = self.arrFriendList.objectAtIndex(indexPath.row).valueForKey("profilePic") as? String{
                    imgVwPic.crossfadeDuration = 0.0
                    imgVwPic.imageURL = NSURL(string: variableName)
                }
            }
            if let lblName = cell.viewWithTag(8002) as? UILabel {
                let strFName = self.arrFriendList.objectAtIndex(indexPath.row).valueForKey("firstName") as! String
                let strLName = self.arrFriendList.objectAtIndex(indexPath.row).valueForKey("lastName") as! String
                let strFullName = strFName + " " + strLName
                lblName.text = strFullName
            }
            
            let btnSelectFriend:UIButton = (cell.viewWithTag(8003) as? UIButton)!
            if(self.arrFriendSelected.objectAtIndex(indexPath.row) as! String == "0"){
                btnSelectFriend.setImage(UIImage(named: "addSong"), forState:UIControlState.Normal)
            }else{
                btnSelectFriend.setImage(UIImage(named: "AddSongSel"), forState:UIControlState.Normal)
            }
            return cell
            
        }else{
            let cell = tableView.dequeueReusableCellWithIdentifier(
                "cellSongs", forIndexPath: indexPath)
            
            if let lblName = cell.viewWithTag(7002) as? UILabel {
                let strSName = self.arrLibSongs.objectAtIndex(indexPath.row).valueForKey("title") as! String
                lblName.text = strSName
            }
            
            let btnSelectSong:UIButton = (cell.viewWithTag(7003) as? UIButton)!
            if(selectedSongIndex != nil && selectedSongIndex.row == indexPath.row){
                btnSelectSong.setImage(UIImage(named: "AddSongSel"), forState:UIControlState.Normal)
            }else{
                btnSelectSong.setImage(UIImage(named: "addSong"), forState:UIControlState.Normal)
            }
            
            return cell
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
    }
    
    func scrollViewWillBeginDecelerating(scrollView: UIScrollView){
        print("BeginDecelerating")
        btnGallery.userInteractionEnabled = false
        btnMusic.userInteractionEnabled = false
        btnTagFriend.userInteractionEnabled = false
    }
    func scrollViewDidEndDecelerating(scrollView: UIScrollView){
        print("EndDecelerating")
        btnGallery.userInteractionEnabled = true
        btnMusic.userInteractionEnabled = true
        btnTagFriend.userInteractionEnabled = true
    }
    
    @IBAction func btnPressed_SelectFriend(sender: UIButton) {
        
        let pointInTable: CGPoint = sender.convertPoint(sender.bounds.origin, toView: tblVwFriendsTag)
        let cellIndexPath: NSIndexPath = tblVwFriendsTag.indexPathForRowAtPoint(pointInTable)!
        
        let cell: UITableViewCell = tblVwFriendsTag.cellForRowAtIndexPath(cellIndexPath)!
        let btnSelectFriend:UIButton = (cell.viewWithTag(8003) as? UIButton)!
        if(self.arrFriendSelected.objectAtIndex(cellIndexPath.row) as! String == "0"){
            btnSelectFriend.setImage(UIImage(named: "AddSongSel"), forState:UIControlState.Normal)
            self.arrFriendSelected.replaceObjectAtIndex(cellIndexPath.row, withObject: "1")
        }else{
            btnSelectFriend.setImage(UIImage(named: "addSong"), forState:UIControlState.Normal)
            self.arrFriendSelected.replaceObjectAtIndex(cellIndexPath.row, withObject: "0")
        }
        self.strSelectedFriends = ""
        self.strSelectedNames = ""
        self.arrFriendSelected.enumerateObjectsUsingBlock({ object, index, stop in
            if (self.arrFriendSelected.objectAtIndex(index) as! String == "1"){
                let strID = self.arrFriendList.objectAtIndex(index).valueForKey("userId") as! String
                let strFName = self.arrFriendList.objectAtIndex(index).valueForKey("firstName") as! String
                let strLName = self.arrFriendList.objectAtIndex(index).valueForKey("lastName") as! String
                let strFullName = strFName + " " + strLName
                self.strSelectedFriends.appendString("\(strID),")
                self.strSelectedNames.appendString("   \(strFullName)")
            }
        })
        if (strSelectedFriends.length > 0) {
            strSelectedFriends.deleteCharactersInRange(NSMakeRange(strSelectedFriends.length-1, 1))
        }
        lblTaggedFriendName.text = strSelectedNames as String
        if(strSelectedNames == ""){
            btnRemoveTagFriends.hidden = true
        }else{
            btnRemoveTagFriends.hidden = false
        }
        
    }
    
    @IBAction func btnPressed_RemoveTagFriends(sender: AnyObject) {
        self.strSelectedNames = ""
        lblTaggedFriendName.text = strSelectedNames as String
        btnRemoveTagFriends.hidden = true
    }
    
    
    // MARK: UITextView Delegate
    func textViewDidBeginEditing(textView: UITextView) {
        if textView.text == "Add status here" {
            textView.text = ""
            textView.textColor = UIColor.blackColor()
        }
    }
    
    func textViewDidEndEditing(textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = "Add status here"
            textView.textColor = UIColor.lightGrayColor()
        }
    }
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            textView.resignFirstResponder()
            return false
        }
        let newLength = textView.text.characters.count + text.characters.count - range.length
        if newLength <= 200 {
//            Utility.showAlert("", message: "You can enter maximum 200 characters.", delegate: nil)
            lblTextCount.text = "\(200 - newLength)/200"
        }
        return newLength <= 200 // Bool
        //        return true
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Webservice Call Methods
    //GetFriends API
    func fnGetFriendsWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        //        ObjWebserviceCall.cachePolicy = WebserviceCallCachePolicyRequestFromCacheFirstAndThenFromUrlAndUpdateInCache
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceGetFriends)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("getFriends--- \(response.webserviceResponse)")
                
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    self.arrFriendSelected.removeAllObjects()
                    self.arrFriendList = response.webserviceResponse.valueForKey("friendsList") as! NSArray
                    self.arrFriendList.enumerateObjectsUsingBlock({ object, index, stop in
                        self.arrFriendSelected.addObject("0")
                    })
                    if self.arrFriendList.count == 0 {
                        Utility.showAlert("", message: "Please add friend for tag", delegate: nil)
                    }
                    self.tblVwFriendsTag.reloadData()
                }else{
                    
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
    
    @IBAction func btnPressed_RemoveMusic(sender: AnyObject) {
        if objMusicPlayer.playbackState == MPMusicPlaybackState.Playing {
            objMusicPlayer.stop()
        }
        vwMusic.hidden = true
        selectedSongIndex = nil
        tblVwFriendsTag.reloadData()
    }
    
    @IBAction func btnPressed_PlayMusic(sender: AnyObject) {
        if (selectedSongIndex != nil) {
            let mpItem = arrLibSongs.objectAtIndex(selectedSongIndex.row).valueForKey("mpItem") as! MPMediaItem
            let songName: String = mpItem.valueForProperty(MPMediaItemPropertyTitle) as! String
            
            let query: MPMediaQuery = MPMediaQuery.songsQuery()
            
            let hasSong = MPMediaPropertyPredicate(value:songName,
                forProperty:MPMediaItemPropertyTitle,
                comparisonType:.Contains)
            let localSong = MPMediaPropertyPredicate(value:NSNumber(bool: false),
                forProperty:MPMediaItemPropertyIsCloudItem)
            query.addFilterPredicate(localSong)
            query.addFilterPredicate(hasSong)
            
            objMusicPlayer.setQueueWithQuery(query)
            objMusicPlayer.prepareToPlay()
            objMusicPlayer.play()
        }
        
        
    }
    
    @IBAction func btnPressed_AddMusic(sender: AnyObject) {
        vwMusic.hidden = false
        if objMusicPlayer.playbackState == MPMusicPlaybackState.Playing {
            objMusicPlayer.stop()
        }
        let pointInTable: CGPoint = sender.convertPoint(sender.bounds.origin, toView: tblVwFriendsTag)
        let cellIndexPath: NSIndexPath = tblVwFriendsTag.indexPathForRowAtPoint(pointInTable)!
        let cell: UITableViewCell = tblVwFriendsTag.cellForRowAtIndexPath(cellIndexPath)!
        let btnSelectSong:UIButton = (cell.viewWithTag(7003) as? UIButton)!
        
        btnSelectSong.setImage(UIImage(named: "AddSongSel"), forState:UIControlState.Normal)
        tblVwFriendsTag.reloadData()
        selectedSongIndex = cellIndexPath
    }
    
    func exportAsset(asset:AVAsset, fileName:String){
        let documentsDirectory = NSFileManager.defaultManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask)[0]
        let trimmedSoundFileURL = documentsDirectory.URLByAppendingPathComponent(fileName)
        print("saving to \(trimmedSoundFileURL.absoluteString)")
        
        AudioData.removeImage("trimmed.m4a")
        
        let exporter = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetAppleM4A)
        exporter!.outputFileType = AVFileTypeAppleM4A
        exporter!.outputURL = trimmedSoundFileURL
        
        let duration = CMTimeGetSeconds(asset.duration)
        if (duration < 20.0) {
            print("sound is not long enough")
            return
        }
        // e.g. the first 5 seconds
        let startTime = CMTimeMake(0, 1)
        let stopTime = CMTimeMake(20, 1)
        let exportTimeRange = CMTimeRangeFromTimeToTime(startTime, stopTime)
        exporter!.timeRange = exportTimeRange
        
        // do it
        exporter!.exportAsynchronouslyWithCompletionHandler({
            switch exporter!.status {
            case  AVAssetExportSessionStatus.Failed:
                print("export failed \(exporter!.error)")
                //                self.fnGetTrimmedAudio("failed", AudioPath: "")
            case AVAssetExportSessionStatus.Cancelled:
                print("export cancelled \(exporter!.error)")
                //                self.fnGetTrimmedAudio("cancelled", AudioPath: "")
            default:
                print("export complete")
                self.fnGetTrimmedAudio("complete", AudioPath: trimmedSoundFileURL)
            }
        })
    }
    
    func fnGetTrimmedAudio(value:NSString, AudioPath:NSURL) {
        if value == "complete" {
            audioDataTrimmed = NSData(contentsOfURL: AudioPath)!
            if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                let dict:NSDictionary = [
                    "userId": userId,
                    "statusText": txtVw_Comment.text,
                    "type": "1",
                    "location": self.strLocation,
                    "taggedFriends": strSelectedFriends,
                    "hashTags": ""
                ]
                print("\(dict)")
                fnPostImageWebServiceWithPostDic(dict)
            }
        }else{
            Utility.showAlert("", message: "Error occured in trimming the audio.", delegate: nil)
        }
    }
    
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
}
