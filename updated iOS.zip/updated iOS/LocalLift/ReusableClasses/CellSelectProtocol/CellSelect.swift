//
//  CellSelect.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/23/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import Foundation

protocol ColectionCellSelectProtocol {
    func select()
}

protocol SelectPassValueProtocol {
    func selectCell(value:String)
}