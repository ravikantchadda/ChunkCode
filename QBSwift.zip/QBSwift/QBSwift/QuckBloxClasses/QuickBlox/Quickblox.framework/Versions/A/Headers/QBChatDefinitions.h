//
//  Definitions.h
//  Chat
//
//  Created by IgorKh on 9/12/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

#import <Quickblox/ChatEnums.h>
#import <Quickblox/ChatDelegates.h>
#import <Quickblox/ChatConsts.h>
