//
//  NotificationSettingViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 14/10/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class NotificationSettingViewController: UIViewController {
    
    @IBOutlet weak var tblNotificationSettings: UITableView!
    var arrData = ["Notify when someone sends pair request","Notify when someone view my post or status","Notify when someone comments on my status/photo","Notify when someone sends me messages","Notify when my friend updates status/photo ","Notify when there is a system Message from admin"]
    var arrNotificationData: NSMutableArray! = ["Y","Y","Y","Y","Y","Y"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationItem.titleView = Utility.navBarTitleLabel("Notification")
//        self.navigationItem.hidesBackButton = true
//        self.navigationItem.leftBarButtonItem = Utility.navBarLeftButton(UIImage(named: "btnBack")!, viewController: self)
        self.navigationItem.rightBarButtonItem = Utility.navBarRightButton(UIImage(named: "savePost")!, viewController: self)
        tblNotificationSettings.tableFooterView = UIView(frame: CGRectZero)
        if (Utility.checkNetwork() == true){
            if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                let dict:NSDictionary = [
                    "userId": userId
                ]
                print("\(dict)")
                fnGetNotificationSettingsWebServiceWithPostDic(dict)
            }
        }
    }
    
//     MARK: - NavigationBar LeftBarButton Method
    func fnLeftBarButton(){
        self.navigationController?.popViewControllerAnimated(true)
    }
    // MARK: - NavigationBar RightBarButton Method
    func fnRightBarButton(){
        if (Utility.checkNetwork() == true){
            if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                let dict:NSDictionary = [
                    "userId": userId,
                    "friendRequestNotificationEnabled": self.arrNotificationData.objectAtIndex(0),
                    "likePhotoNotificationEnabled": self.arrNotificationData.objectAtIndex(1),
                    "commentPhotoNotificationEnabled": self.arrNotificationData.objectAtIndex(2),
                    "messageNotificationEnabled": self.arrNotificationData.objectAtIndex(3),
                    "friendStatusUpdateNotificationEnabled": self.arrNotificationData.objectAtIndex(4),
                    "adminMessageNotificationEnabled": self.arrNotificationData.objectAtIndex(5)
                ]
                print("\(dict)")
                fnSaveNotificationSettingsWebServiceWithPostDic(dict)
            }
        }
    }
    
    // MARK: - Webservice Call Methods
    //GetNotifications API
    func fnGetNotificationSettingsWebServiceWithPostDic(dict: NSDictionary!) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        //        ObjWebserviceCall.cachePolicy = WebserviceCallCachePolicyRequestFromCacheFirstAndThenFromUrlAndUpdateInCache
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            ObjWebserviceCall.isShowLoader = true
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceGetNotiSettings)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("NotificationSettings--- \(response.webserviceResponse)")
                
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    //Notification Model
                    let arrData = response.webserviceResponse.valueForKey("settings") as! NSDictionary
                    let objNotification = NotificationSettings().fillDataInModel(arrData)
                    if objNotification.friendRequestNotificationEnabled == "Y"{
                        self.arrNotificationData.replaceObjectAtIndex(0, withObject: "Y")
                    }else{
                        self.arrNotificationData.replaceObjectAtIndex(0, withObject: "N")
                    }
                    if objNotification.likePhotoNotificationEnabled == "Y"{
                        self.arrNotificationData.replaceObjectAtIndex(1, withObject: "Y")
                    }else{
                        self.arrNotificationData.replaceObjectAtIndex(1, withObject: "N")
                    }
                    if objNotification.commentPhotoNotificationEnabled == "Y"{
                        self.arrNotificationData.replaceObjectAtIndex(2, withObject: "Y")
                    }else{
                        self.arrNotificationData.replaceObjectAtIndex(2, withObject: "N")
                    }
                    if objNotification.messageNotificationEnabled == "Y"{
                        self.arrNotificationData.replaceObjectAtIndex(3, withObject: "Y")
                    }else{
                        self.arrNotificationData.replaceObjectAtIndex(3, withObject: "N")
                    }
                    if objNotification.friendStatusUpdateNotificationEnabled == "Y"{
                        self.arrNotificationData.replaceObjectAtIndex(4, withObject: "Y")
                    }else{
                        self.arrNotificationData.replaceObjectAtIndex(4, withObject: "N")
                    }
                    if objNotification.adminMessageNotificationEnabled == "Y"{
                        self.arrNotificationData.replaceObjectAtIndex(5, withObject: "Y")
                    }else{
                        self.arrNotificationData.replaceObjectAtIndex(5, withObject: "N")
                    }
                
                }else{
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                self.tblNotificationSettings.reloadData()
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
    
    // SaveNotifications API
    func fnSaveNotificationSettingsWebServiceWithPostDic(dict: NSDictionary!) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        //        ObjWebserviceCall.cachePolicy = WebserviceCallCachePolicyRequestFromCacheFirstAndThenFromUrlAndUpdateInCache
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            ObjWebserviceCall.isShowLoader = true
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceSaveNotiSettings)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("NotificationSettings--- \(response.webserviceResponse)")
                
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
//                    if #available(iOS 8.0, *) {
                    
                        let alert = UIAlertController(title: "", message: response.webserviceResponse.valueForKey("status") as? String, preferredStyle: .Alert)
                        let action = UIAlertAction(title: "OK", style: .Default) { _ in
                            self.navigationController?.popViewControllerAnimated(true)
                        }
                        alert.addAction(action)
                        self.presentViewController(alert, animated: true, completion: nil)
                        
//                    } else {
//                        // Fallback on earlier versions
//                        Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: self)
//                    }
                    
                }else{
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                self.tblNotificationSettings.reloadData()
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
    func alertView(View: UIAlertView, clickedButtonAtIndex buttonIndex: Int){
        
        if (buttonIndex == 0){
            self.navigationController?.popViewControllerAnimated(true)
        }
    }

    @IBAction func valueChanged_Switch(sender: UISwitch) {
        let pointInTable: CGPoint = sender.convertPoint(sender.bounds.origin, toView: tblNotificationSettings)
        let cellIndexPath: NSIndexPath = tblNotificationSettings.indexPathForRowAtPoint(pointInTable)!
        if sender.on{
            self.arrNotificationData.replaceObjectAtIndex(cellIndexPath.row, withObject: "Y")
        }else{
            self.arrNotificationData.replaceObjectAtIndex(cellIndexPath.row, withObject: "N")
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - TableView DataSource/Delegate
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return arrData.count
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if(tableView.respondsToSelector(Selector("setSeparatorInset:"))){
            tableView.separatorInset = UIEdgeInsetsZero
        }
        if(tableView.respondsToSelector(Selector("setLayoutMargins:"))){
            
            tableView.layoutMargins = UIEdgeInsetsZero
            
        }
        if(cell.respondsToSelector(Selector("setLayoutMargins:"))){
           
            cell.layoutMargins = UIEdgeInsetsZero
            
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(
            "cell", forIndexPath: indexPath)
        
        if let lblName = cell.viewWithTag(1001) as? UILabel {
            lblName.text = arrData[indexPath.row]
        }
        if let switchSelection = cell.viewWithTag(1002) as? UISwitch {
            if self.arrNotificationData.objectAtIndex(indexPath.row) as! String == "Y"{
                switchSelection.setOn(true, animated: false)
            }else{
                switchSelection.setOn(false, animated: false)
            }
            
        }
        return cell
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
