/*
 *  Models.h
 *  BaseService
 *
 *
 */
#import <Quickblox/QBCEntity.h>
