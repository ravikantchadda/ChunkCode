//
//  AddUserInGroup.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/23/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class AddUserInGroup: BaseViewController,SelectPassValueProtocol {

    enum invitation:Int {case FromContact = 0, FromSocialSite = 1}
    var invitationType:invitation!
    
    @IBOutlet weak var viewShowInvitationType: InvitationTableView!
    @IBOutlet weak var viewThumbnail: ThumbnailView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setNavigationBarButton()
        self.intializtion()
    }

    //MARK: - Set Bar button in navigation
    func setNavigationBarButton() {
        let btnBack = UIBarButtonItem(title: "Back", style: .Plain, target: nil, action: nil)
        self.navigationItem.backBarButtonItem = btnBack;
        self.navigationItem.title = "Invite Group Members"
    }
    
    func intializtion() {
        if invitationType == .FromContact {
            viewShowInvitationType.type = .FromContact
            viewShowInvitationType.delegate = self
            viewShowInvitationType.fetchInvitationType()
        }
        else {
            viewShowInvitationType.type = .FromSocialSite
            viewShowInvitationType.delegate = self
            viewShowInvitationType.fetchInvitationType()
        }
    }
    
    //MARK:- Protocol method to load this view for different table 
    func selectCell(value:String) {
        
        switch value {
        case "Contact":
            let invitationType = NSIUtility.fetchViewControllerWithName("ContactVC", storyBoardName: "Main") as! ContactVC
            self.navigationController?.pushViewController(invitationType, animated: true)
            
        case "Social":
            let invitationType = NSIUtility.fetchViewControllerWithName("AddUserInGroup", storyBoardName: "Main") as! AddUserInGroup
            invitationType.invitationType = .FromSocialSite
            self.navigationController?.pushViewController(invitationType, animated: true)
        
        case "Facebook":
            print("Type is Facebook")
            
        case "WhatsApp":
            print("Type is WhatsApp")
            
        case "Email":
            print("Type is Email")
        default:
            print("Type is something else")
        }
        
       
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
