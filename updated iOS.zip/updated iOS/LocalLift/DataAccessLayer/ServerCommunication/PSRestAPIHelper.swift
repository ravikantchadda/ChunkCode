//
//  PSRestAPIHelper.swift
//  LocalLift
//
//  Created by prabhjot singh on 10/28/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit
import CMLibrary

let isDevActive = true

// Base URL
//let serverAddress = "http://107.151.2.82:1001/" Testing
//let serverAddress = "http://107.151.2.82:1005/" Local

//-DDEBUG


// Testing


// Completion Closure
typealias CompletionHandler = (obj:AnyObject?, success:Bool?) -> Void

class PSRestAPIHelper: NSObject {
    
// Singleton Object
//    static let sharedInstance = PSRestAPIHelper()

// service URL property
     var serviceURL:String = String()
        {didSet
        {
            self.serviceURL =  self.baseURL + serviceURL
            
        }
    }
    
    var baseURL:String = LocaliftSharedObj.sharedInstance.serverAddress + "LocaliftService.svc/"
    
    
// Server communication API property
    let webservice:WebserviceCall = WebserviceCall()
    
    
// Add Content Type function
    func setContentTypeHeaders(){
        let userObject:UserBO = UserBO.sharedInstanceOfUser
        self.webservice.headerFieldsDict = ["Content-Type":"application/json","api_key":userObject.userAccessToken,"device_Id":NSIUtility.getUniqueIdentifier(),"user_Id":String(userObject.userID) ]
    }
    

// Method use to handle the failure operation
    func handleFailureWithOperation(op:WebserviceResponse) -> Bool
    {
        if op.webserviceResponse != nil{
        
            if var failureReason:String? =  op.webserviceResponse.valueForKeyPath("Message") as? String{
            
                let failureStatus:String? =  String(op.webserviceResponse.valueForKeyPath("Status")!)
                print("failureReason \(failureReason!) and failureStatus \(failureStatus!)")
                
                if (failureReason! == "OK" || failureStatus! == "0" || failureStatus! == "200")
                {return true}
                if failureReason!.length == 0 && op.webserviceResponse != nil
                {failureReason = op.webserviceResponse.description as String}
                if failureReason!.length == 0 && op.webserviceResponse.length > 0
                {failureReason = op.webserviceResponse as? String;}
                if (failureReason!.length == 0)
                {failureReason = "Unknown server interaction error";}
                let failedMethod:String = op.webserviceUrl + " " + (op.isResponseFromCache ? "has Response from Cache":"Dont have response from cache")
                print(failedMethod + " - " + failureReason!)
                return false
                }
        }
        return false
    }
    
    func requestforPOST(params:[NSObject:AnyObject!], withCompletionHandler handler:CompletionHandler)
    {
        self.disableUserIntractionOnMain()
        webservice.POST(NSURL(string: serviceURL), parameters: params as [NSObject : AnyObject]!, withSuccessHandler: { (response:WebserviceResponse!) -> Void in
                if self.handleFailureWithOperation(response){
                    handler(obj: response.webserviceResponse, success: true)
                } else{
                    handler(obj: response.webserviceResponse, success: false)
                }
            self.enableUserIntractionOnMain()
            }) { (error:NSError!) -> Void in
                self.enableUserIntractionOnMain()
                
        }
    }
    
    func requestforGET(params:[NSObject:AnyObject!], withCompletionHandler handler:CompletionHandler)
    {
        
        self.disableUserIntractionOnMain()
        webservice.GET(NSURL(string: serviceURL), parameters: params as [NSObject : AnyObject]!, withSuccessHandler: { (response:WebserviceResponse!) -> Void in
                if self.handleFailureWithOperation(response)
                {
                    handler(obj: response.webserviceResponse, success: true)
                }
                else{
                    handler(obj: response, success: false)
                }
            self.enableUserIntractionOnMain()
            
            }) { (error:NSError!) -> Void in
                self.enableUserIntractionOnMain()
        }
    }
    
    
    
//----- Services for different API's -----//
    
    func requestforGETWithoutServiceURL(params:[NSObject:AnyObject!], withURL urlString:String, withCompletionHandler handler:CompletionHandler)
    {
        self.disableUserIntractionOnMain()
        
        webservice.GET(NSURL(string: urlString), parameters: params as [NSObject : AnyObject]!, withSuccessHandler: { (response:WebserviceResponse!) -> Void in
            
            if let resposeDic:NSDictionary = response.webserviceResponse as? NSDictionary
            {
                handler(obj: resposeDic, success: true)
            }
            else{
                handler(obj: response, success: false)
            }
            self.enableUserIntractionOnMain()
            
            }) { (error:NSError!) -> Void in
                self.enableUserIntractionOnMain()
        }
    }
    
    func disableUserIntractionOnMain(){
        dispatch_async(dispatch_get_main_queue()) { () -> Void in
            Constants.appDelegate.window?.userInteractionEnabled = false
        }
    }
    
    func enableUserIntractionOnMain(){
        dispatch_async(dispatch_get_main_queue()) { () -> Void in
            Constants.appDelegate.window?.userInteractionEnabled = true
        }
    }
}


