//
//  NotificationDL.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/9/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

//import UIKit
//
//class NotificationBO:NSObject{
//
//    var arrayOfOfLift = NSMutableArray()
//    var dateOfLifts:NSDate!
//    var dateString:String!
//    //MARK: Convert date into string
//    func setDateString() {
//        if(self.dateOfLifts.isToday()) {
//        self.dateString = "Today, \(self.dateOfLifts.toString(format: .Custom(Constants.DateFormatwithAMPM)))"
//        }
//        else if(self.dateOfLifts.isYesterday()) {
//            self.dateString = "Yesterday, \(self.dateOfLifts.toString(format: .Custom(Constants.DateFormatwithAMPM)))"
//        }
//        else {
//        self.dateString = self.dateOfLifts.toString(format: .Custom(Constants.DateFormatwithAMPM))
//       }
//    }
//}
//
//class NotificationDL: PSRestAPIHelper {
//
//    //MARK: - Service calling to get Notifications
//    func requestForGetNotificatio(handler:CompletionHandler) {
//        let arrayOfNotification = NSMutableArray()
//        for (var j=0; j <= 3 ; j++) {
//                let notificationBO = NotificationBO()
//                notificationBO.dateOfLifts = NSDate()
//                notificationBO.setDateString()
//            for (var i = 0 ; i <= 5 ; i++) {
//                let liftBO = LiftBO()
//                liftBO.liftRequesterName = "ABC \(i)"
//                liftBO.message = "accepted your invitation"
//                let addressBO = AddressBO()
//                addressBO.addressName = "Address Name \(i)"
//                liftBO.addressBO = addressBO
//                
//                notificationBO.arrayOfOfLift.addObject(liftBO)
//            }
//            arrayOfNotification.addObject(notificationBO)
//        }
//        handler(obj: arrayOfNotification, success: true)
//    }
//}
