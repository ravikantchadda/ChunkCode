//
//  OfferDL.swift
//  LocalLift
//
//  Created by prabhjot singh on 12/15/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class OfferBO:NSObject {
    
    var offerId     :NSNumber!
    var offerorId   :NSNumber!
    var offerDatetime:NSDate!
    var message         :String!
    var isRecurring     :Bool!
    var startLocationId :NSNumber!
    var endLocationId   :NSNumber!
    var offereeId       :NSArray!
    var newStartLocation:AddressBO!
    var newEndLocation  :AddressBO!
    var seatAvailability:NSNumber!
    var isImmidiate     :Bool!
    var offerEndDate    :NSDate!
    var liftFrequencyTypeId:NSNumber!

//    
//    
//    var extraPassengers:NSNumber!
//    var requestDatetime:String!
//
//    var requestPassengers:NSArray!
//
//    var requestEndDate:String!
//
//    var requesterName:String!
//    var requestName:String!
//    
//    var arratLiftPassengers:NSMutableArray?
//    var arrayRecurringLiftRequests:NSMutableArray?
    
}

class OfferDL: PSRestAPIHelper {

    func requestForCreateOfferLift(offerBO:OfferBO,  handler:CompletionHandler)
    {
        self.serviceURL = "CreateLiftOffer"
        self.webservice.isShowLoader = true
        self.setContentTypeHeaders()
        
        
        var dicParamMutable:NSMutableDictionary!
        //        (requestBO.newStartLocation == nil  ? NSNull():requestBO.newStartLocation)
        var dicOfStartAddress = NSDictionary()
        if offerBO.startLocationId == 0{
            dicOfStartAddress = ["AddressName":offerBO.newStartLocation.addressName,"City":offerBO.newStartLocation.city,"Country":offerBO.newStartLocation.country,"State":offerBO.newStartLocation.state,"StreetAddress":offerBO.newStartLocation.streetAddress,"Unit":"","ZipCode":offerBO.newStartLocation.zipCode,"Latitude":offerBO.newStartLocation.locationCords.latitude,"Longitude":offerBO.newStartLocation.locationCords.longitude,"IsPrimary":false,"IsNew":true,"AddressID":0]
        }
        
        var dicOfEndAddress = NSDictionary()
        if offerBO.endLocationId == 0{
            dicOfEndAddress = ["AddressName":offerBO.newEndLocation.addressName,"City":offerBO.newEndLocation.city,"Country":offerBO.newEndLocation.country,"State":offerBO.newEndLocation.state,"StreetAddress":offerBO.newEndLocation.streetAddress,"Unit":"","ZipCode":offerBO.newEndLocation.zipCode,"Latitude":offerBO.newEndLocation.locationCords.latitude,"Longitude":offerBO.newEndLocation.locationCords.longitude,"IsPrimary":false,"IsNew":true,"AddressID":0]
        }
        
        dicParamMutable = ["OfferorId":offerBO.offerorId,"OfferDatetime":offerBO.offerDatetime.toString(format: .Custom(Constants.DateTimeSlashFormat)),"IsRecurring":offerBO.isRecurring,"StartLocationId":offerBO.startLocationId,"EndLocationId":offerBO.endLocationId,"OffereeId":offerBO.offereeId,"SeatAvailability":offerBO.seatAvailability,"IsImmediate":offerBO.isImmidiate,"Message":offerBO.message]
        
        dicParamMutable.setObject((offerBO.newStartLocation == nil  ? NSNull():dicOfStartAddress), forKey: "NewStartLocation")
        dicParamMutable.setObject((offerBO.newEndLocation == nil  ? NSNull():dicOfEndAddress), forKey: "NewEndLocation")
        
        if offerBO.isRecurring == true  {
            dicParamMutable.setValue(offerBO.liftFrequencyTypeId, forKey: "LiftFrequencyTypeId")
            dicParamMutable.setValue(offerBO.offerEndDate.toString(format: .Custom(Constants.DateTimeSlashFormat)), forKey: "OfferEndDate")
        }
        
        
        
        let  dicParam:NSDictionary = dicParamMutable as NSDictionary
        
//        NSIUtility.showJsonData(dicParam)
        
        self.requestforPOST(dicParam as! [NSObject : AnyObject!]) { (obj, success) -> Void in
            if success == true{
                if let dicResponse:NSDictionary = obj as? NSDictionary{
                    handler(obj: dicResponse, success: true)
                }
            }
            else{
                handler(obj: obj, success: false)
            }
        }
        
    }
    
}
