//
//  UserDetails.swift
//  Aashiqui
//
//  Created by ketan saini on 23/10/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class UserDetails: NSObject {
    /*
    {
    "userId": "2765",
    "firstName": "Nitin",
    "lastName": "Saluja",
    "nickName": "",
    "profilePic": "",
    "usStatusText": “”
    }
    */
    
    var userId:String!
    var firstName:String!
    var lastName:String!
    var statusText:String!
    var profilePic:String!
    var friendshipId:String!
    
    // MARK: NSCoding
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.userId = (decoder.decodeObjectForKey("userId") as! String?)!
        self.firstName = (decoder.decodeObjectForKey("firstName") as! String?)!
        self.lastName = (decoder.decodeObjectForKey("lastName") as! String?)!
        self.statusText = (decoder.decodeObjectForKey("statusText") as! String?)!
        self.profilePic = (decoder.decodeObjectForKey("profilePic") as! String?)!
        self.friendshipId = (decoder.decodeObjectForKey("friendshipId") as! String?)!
        
    }
    
    func encodeWithCoder(coder: NSCoder) {
        coder.encodeObject(self.userId, forKey: "userId")
        coder.encodeObject(self.firstName, forKey: "firstName")
        coder.encodeObject(self.lastName, forKey: "lastName")
        coder.encodeObject(self.statusText, forKey: "statusText")
        coder.encodeObject(self.profilePic, forKey: "profilePic")
        coder.encodeObject(self.friendshipId, forKey: "friendshipId")
        
    }
    
    func fillDataInModel(arrData: NSArray) -> NSMutableArray {
        let arrUserData: NSMutableArray! = []
        for dict in arrData{
            let objUser = UserDetails()
            objUser.userId = dict.valueForKey("userId") as! String
            objUser.firstName = dict.valueForKey("firstName") as! String
            objUser.lastName = dict.valueForKey("lastName") as! String
            if (dict.valueForKey("profilePic")?.isKindOfClass(NSNull) != true){
                objUser.profilePic = dict.valueForKey("profilePic") as! String
            }else{
                objUser.profilePic = ""
            }
            if (dict.valueForKey("statusText")?.isKindOfClass(NSNull) != true){
                objUser.statusText = dict.valueForKey("statusText") as! String
            }else{
                objUser.statusText = ""
            }
            arrUserData.addObject(objUser)
        }
        return arrUserData
    }
    /*
    func fillDataInPairedModel(arrData: NSArray) -> NSMutableArray {
        let arrUserData: NSMutableArray! = []
        for dict in arrData{
            let objUser = UserDetails()
            objUser.userId = dict.valueForKey("userId") as! String
            objUser.firstName = dict.valueForKey("firstName") as! String
            objUser.lastName = dict.valueForKey("lastName") as! String
            if (dict.valueForKey("profilePicUrl")?.isKindOfClass(NSNull) != true){
                objUser.profilePic = dict.valueForKey("profilePicUrl") as! String
            }else{
                objUser.profilePic = ""
            }
            if (dict.valueForKey("statusText")?.isKindOfClass(NSNull) != true){
                objUser.statusText = dict.valueForKey("statusText") as! String
            }else{
                objUser.statusText = ""
            }
            arrUserData.addObject(objUser)
        }
        return arrUserData
    }
    */
    func fillDataInRequestModel(arrData: NSArray) -> NSMutableArray {
        let arrUserData: NSMutableArray! = []
        for dict in arrData{
            let objUser = UserDetails()
            objUser.userId = dict.valueForKey("userId") as! String
            objUser.firstName = dict.valueForKey("firstName") as! String
            objUser.lastName = dict.valueForKey("lastName") as! String
            if (dict.valueForKey("profilePic")?.isKindOfClass(NSNull) != true){
                objUser.profilePic = dict.valueForKey("profilePic") as! String
            }else{
                objUser.profilePic = ""
            }
            if (dict.valueForKey("friendshipId")?.isKindOfClass(NSNull) != true){
                objUser.friendshipId = dict.valueForKey("friendshipId") as! String
            }else{
                objUser.friendshipId = ""
            }
            
            arrUserData.addObject(objUser)
        }
        return arrUserData
    }

}
