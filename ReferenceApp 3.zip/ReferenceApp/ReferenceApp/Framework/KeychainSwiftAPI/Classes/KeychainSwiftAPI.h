//
//  KeychainSwiftAPI.h
//  KeychainSwiftAPI
//
//  Created by Denis Krivitski on 22/7/14.
//  Copyright (c) 2014 Checkmarx. All rights reserved.
//

#import <UIKit/UIKit.h>


//! Project version number for KeychainSwiftAPI.
FOUNDATION_EXPORT double KeychainSwiftAPIVersionNumber;

//! Project version string for KeychainSwiftAPI.
FOUNDATION_EXPORT const unsigned char KeychainSwiftAPIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KeychainSwiftAPI/PublicHeader.h>

#import "CXKeychainHelper.h"
