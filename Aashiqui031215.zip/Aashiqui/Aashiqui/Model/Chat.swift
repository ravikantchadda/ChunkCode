//
//  Chat.swift
//  Aashiqui
//
//  Created by ketan saini on 10/11/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class Chat: NSObject {
    
    /*
    "messages": [
    {
    "messageSenderFirstName": "Nitin",
    "messageSenderLastName": "Saluja",
    "messageSenderProfilePicUrl": "http://gsu-miscwork02-qa.netsol.in/images/2741/profilepic/bf84f16535f5939236427a941f04a59b.jpeg",
    "messageSenderId": "2741",
    "messageText": "hello",
    "messageTime": "2015-10-27 15:32:00",
    "minutesAgo": "4",
    "messageId": "17717"
    }
    ]
    */
    
    var messageSenderFirstName:String!
    var messageSenderLastName:String!
    var messageSenderProfilePicUrl:String!
    var messageSenderId:String!
    var messageText:String!
    var messageTime:String!
    var minutesAgo:String!
    var messageId:String!
    
    
    // MARK: NSCoding
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.messageSenderFirstName = (decoder.decodeObjectForKey("messageSenderFirstName") as! String?)!
        self.messageSenderLastName = (decoder.decodeObjectForKey("messageSenderLastName") as! String?)!
        self.messageSenderProfilePicUrl = (decoder.decodeObjectForKey("messageSenderProfilePicUrl") as! String?)!
        self.messageSenderId = (decoder.decodeObjectForKey("messageSenderId") as! String?)!
        self.messageText = (decoder.decodeObjectForKey("messageText") as! String?)!
        self.messageTime = (decoder.decodeObjectForKey("messageTime") as! String?)!
        self.minutesAgo = (decoder.decodeObjectForKey("minutesAgo") as! String?)!
        self.messageId = (decoder.decodeObjectForKey("messageId") as! String?)!
        
    }
    
    func encodeWithCoder(coder: NSCoder) {
        coder.encodeObject(self.messageSenderFirstName, forKey: "messageSenderFirstName")
        coder.encodeObject(self.messageSenderLastName, forKey: "messageSenderLastName")
        coder.encodeObject(self.messageSenderProfilePicUrl, forKey: "messageSenderProfilePicUrl")
        coder.encodeObject(self.messageSenderId, forKey: "messageSenderId")
        coder.encodeObject(self.messageText, forKey: "messageText")
        coder.encodeObject(self.messageTime, forKey: "messageTime")
        coder.encodeObject(self.minutesAgo, forKey: "minutesAgo")
        coder.encodeObject(self.messageId, forKey: "messageId")
    }
    
    func fillDataInModel(arrData: NSArray) -> NSMutableArray {
        let arrListData: NSMutableArray! = []
        for dict in arrData{
            let objChatList = Chat()
            objChatList.messageId = dict.valueForKey("messageId") as! String
            objChatList.minutesAgo = dict.valueForKey("minutesAgo") as! String
            objChatList.messageTime = dict.valueForKey("messageTime") as! String
            objChatList.messageSenderFirstName = dict.valueForKey("messageSenderFirstName") as! String
            objChatList.messageSenderLastName = dict.valueForKey("messageSenderLastName") as! String
            objChatList.messageSenderId = dict.valueForKey("messageSenderId") as! String
            if (dict.valueForKey("messageSenderProfilePicUrl")?.isKindOfClass(NSNull) != true){
                objChatList.messageSenderProfilePicUrl = dict.valueForKey("messageSenderProfilePicUrl") as! String
            }else{
                objChatList.messageSenderProfilePicUrl = ""
            }
            if (dict.valueForKey("messageText")?.isKindOfClass(NSNull) != true){
                objChatList.messageText = dict.valueForKey("messageText") as! String
            }else{
                objChatList.messageText = ""
            }
            arrListData.addObject(objChatList)
        }
        return arrListData
    }
}
