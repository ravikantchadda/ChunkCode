//
//  LiftGroupCell.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/21/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class LiftGroupCell: UICollectionViewCell {

    @IBOutlet weak var imageViewLiftGroupThumb: UIImageView!
    @IBOutlet weak var lblLiftGroupTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
