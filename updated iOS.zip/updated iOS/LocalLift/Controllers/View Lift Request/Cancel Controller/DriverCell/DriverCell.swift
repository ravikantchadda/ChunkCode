//
//  DriverCell.swift
//  LocalLift
//
//  Created by prabhjot singh on 12/23/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class DriverCell: UITableViewCell {

    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var lblName: UILabel!
    @IBOutlet var imgOfUser: UIImageView!
    @IBOutlet var lblUserName: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    
}
