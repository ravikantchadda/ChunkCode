//
//  MyLiftCell.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/16/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class MyLiftCell: UITableViewCell {
    
    @IBOutlet weak var lblGoingTo: UILabel!
    @IBOutlet weak var progressVW: UIView!
    @IBOutlet weak var liftRequesterPhoto: UIImageView!
    @IBOutlet weak var offerOrRequestImage: UIImageView!
    @IBOutlet weak var liftRequesterName: UILabel!
    @IBOutlet weak var liftDate: UILabel!
    @IBOutlet weak var liftAddress: UILabel!
    @IBOutlet weak var passengerCount: UILabel!
    @IBOutlet weak var groupIconForPassengerCount: UIImageView!
    
    func setRequesterNameForCell(liftRequesterName:String,withOfferRequest isOfferRequest:Bool) {
        let buddy = "\(liftRequesterName)  \(liftRequesterName.characters.count == 0 ? "" : isOfferRequest == true ? " Offered" : " requested")" as NSString
        
        let attrbtdStrngBuddyMessage = NSMutableAttributedString(string: buddy as String)
        let firstAttributesBlackColor = [NSForegroundColorAttributeName: UIColor.blackColor()]
        let secondAttributesGrayColor = [NSForegroundColorAttributeName: UIColor.blackColor()]
        attrbtdStrngBuddyMessage.addAttributes(firstAttributesBlackColor, range: buddy.rangeOfString(liftRequesterName))
        attrbtdStrngBuddyMessage.addAttributes(secondAttributesGrayColor, range: buddy.rangeOfString((isOfferRequest == true ? " Offered" : " requested")))
        attrbtdStrngBuddyMessage.addAttribute(NSFontAttributeName, value: UIFont.systemFontOfSize(9.0), range: buddy.rangeOfString((isOfferRequest == true ? " Offered" : " requested")))
        
        self.liftRequesterName.attributedText = attrbtdStrngBuddyMessage
     }

}
