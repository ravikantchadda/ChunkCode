//
//  ViewLiftTimeCell.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/10/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

protocol ViewLiftTimeProtocol
{
    func reloadTimeTable()
}

class ViewLiftTimeCell: UITableViewCell,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet var tblViewForTime: UITableView!
    @IBOutlet var contentViewForTbl: UIView!
//    var liftRequestVCCallBack:ViewLiftRequestVC!
    var delegate:ViewLiftTimeProtocol?
    var arrayViewLiftTime = NSMutableArray()
    var requestID:NSNumber!
    
    let rowHeightTbl = 105
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.initialInitilization()
//        self.fetchLift()
    }
    
    func initialInitilization(){
        tblViewForTime.registerNib(UINib.init(nibName: "ShowTimeViewLiftCell", bundle: nil), forCellReuseIdentifier: "showTimeViewLiftCell")
        self.tblViewForTime.delegate = self
        self.tblViewForTime.dataSource = self
     }

//MARK: - Fetch data from web service
    func fetchReccuringLift() {
        let reuestDL = RequestDL()
        reuestDL.requestForGetRequestLift(requestID, lastIndex: arrayViewLiftTime.count+1 ,hasMaxCount:false) { (obj, success) -> Void in
            if success == true{
                
                if let requestBO = obj as? RequestBO{
                    if requestBO.arrayRecurringLiftRequests?.count != 0{
                    self.arrayViewLiftTime.addObjectsFromArray(requestBO.arrayRecurringLiftRequests! as [AnyObject])
                    self.tblViewForTime.reloadData()
                    if(self.delegate != nil) {
                        self.delegate?.reloadTimeTable()
                    }
                    }
                }
 
            }
        }
        
        
//        liftDL.requestForViewLift{ (obj, success) -> Void in
//            if success == true {
//                self.arrayViewLiftTime.addObjectsFromArray(obj as! NSArray as [AnyObject])
////                print(self.arrayViewLiftTime)
//                self.tblViewForTime.reloadData()
//            }
//        }
    }
    
    
//MARK: - Button Methods
    
    @IBAction func viewMoreLiftForUser(sender: AnyObject) {
        self.fetchReccuringLift()
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
//MARK: - TableView Delegate
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) ->Int
    {return self.arrayViewLiftTime.count}
   
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return CGFloat(self.rowHeightTbl)
    }

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) ->UITableViewCell {
        let showTimeViewLiftCell  = tblViewForTime.dequeueReusableCellWithIdentifier("showTimeViewLiftCell") as! ShowTimeViewLiftCell
        showTimeViewLiftCell.selectionStyle = .None
        
        let dicOfLiftTime = self.arrayViewLiftTime[indexPath.row] as? RecurringLiftRequestsBO
        showTimeViewLiftCell.lblShowTime.text = dicOfLiftTime?.liftTime
        showTimeViewLiftCell.lblShowDate.text = dicOfLiftTime?.dateString
        
        if (!(dicOfLiftTime!.isLiftSelected))  {
            showTimeViewLiftCell.btnSelectedLift.setImage(UIImage(named: "blue_unchecked"), forState: UIControlState.Normal)
            showTimeViewLiftCell.btnSelectedLift.setImage(UIImage(named: "blue_unchecked"), forState: UIControlState.Selected)
        }
        else {
            showTimeViewLiftCell.btnSelectedLift.setImage(UIImage(named: "blue_checked"), forState: UIControlState.Normal)
        }
        return showTimeViewLiftCell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        let dicOfLiftTime = self.arrayViewLiftTime[indexPath.row] as? RecurringLiftRequestsBO
        dicOfLiftTime?.isLiftSelected = !(dicOfLiftTime!.isLiftSelected)
        self.arrayViewLiftTime[indexPath.row]  = dicOfLiftTime!
        tableView.reloadRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.None)
        
    }
}
