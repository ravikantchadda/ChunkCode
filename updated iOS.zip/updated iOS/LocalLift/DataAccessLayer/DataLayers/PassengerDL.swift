//
//  PassengerDL.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/27/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

// --- - -- - -- - - - -Nexmo Model ---- -- - - -- -//

class PassengerBO:NSObject
{
    var countryCodeID:NSNumber!
    var emailAddress:String!
    var firstName:String!
    var gender:NSNumber!
    var imagePath:String!
    var lastName:String!
    var mobileNumber:String!
    var passengerId:NSNumber!
    var photo:String!
    var requestID:NSNumber!
    var userID:NSNumber!
    var age:NSNumber!
    var address:String!
    var isActive:Bool!
}



class PassengerDL: PSRestAPIHelper {
    
    func requestforPassengers(requestID:NSNumber,handler:CompletionHandler)
    {
        self.serviceURL = "LiftLinkedPassengers"
        self.setContentTypeHeaders()
        self.webservice.isShowLoader = true
        
        let dicParam:NSDictionary = ["lrid":requestID,"si":1,"nor":1000]
        
        self.requestforGET(dicParam as! [NSObject : AnyObject!]) { (obj, success) -> Void in
            
            if success == true
            {
                let arrayOfPsngr:NSMutableArray = NSMutableArray()
                
                if let arrayOfParams:NSArray = obj!.valueForKey("Data") as? NSArray
                {
                    for item in arrayOfParams {
                        let dicBlock = item as! NSDictionary
                        let psengerOBJ = PassengerBO()
                    
                        psengerOBJ.countryCodeID = NSIUtility.getObjectForKey("CountryCodeID", dictResponse: dicBlock) as! NSNumber
                        psengerOBJ.emailAddress = NSIUtility.getObjectForKey("EmailAddress", dictResponse: dicBlock) as! String
                        psengerOBJ.firstName = NSIUtility.getObjectForKey("FirstName", dictResponse: dicBlock) as! String
                        psengerOBJ.lastName = NSIUtility.getObjectForKey("LastName", dictResponse: dicBlock) as! String
                        psengerOBJ.mobileNumber = NSIUtility.getObjectForKey("MobileNumber", dictResponse: dicBlock) as! String
                        psengerOBJ.passengerId = NSIUtility.getObjectForKey("PassengerId", dictResponse: dicBlock) as! NSNumber
                        psengerOBJ.address = NSIUtility.getObjectForKey("Address", dictResponse: dicBlock) as! String
                        psengerOBJ.gender = NSIUtility.getObjectForKey("Gender", dictResponse: dicBlock) as! NSNumber
                        psengerOBJ.imagePath = NSIUtility.getObjectForKey("ImagePath", dictResponse: dicBlock) as! String
                        psengerOBJ.isActive = NSIUtility.getObjectForKey("IsActive", dictResponse: dicBlock) as! Bool
                        psengerOBJ.requestID = NSIUtility.getObjectForKey("RequestID", dictResponse: dicBlock) as! NSNumber
                        psengerOBJ.userID = NSIUtility.getObjectForKey("UserID", dictResponse: dicBlock) as! NSNumber
                        
                        
                        arrayOfPsngr.addObject(psengerOBJ)
                    }
                    
                    handler(obj: arrayOfPsngr, success: true)
                    return
                }
                
                handler(obj: nil, success: false)
                print("Data is nil")
            }else{
//                let arrayOfPsngr:NSMutableArray = NSMutableArray()
//                
//                let arrayOfLinkedPassenger = ["Sonakshi Aggarwal", "Nitin Obroy", "Riya Malhotra", "Jameson Quave", "James", "Minakshi", "Andrew Arora","ZIBar"];
//                for strObj in arrayOfLinkedPassenger{
//                    let psengerOBJ = PassengerBO()
//                    psengerOBJ.emailAddress = strObj + ".com"
//                    psengerOBJ.firstName = strObj
//                    arrayOfPsngr.addObject(psengerOBJ)
//                }
                handler(obj: obj, success: false)
            }
        }
    }
    
    
// Create Passenger
    func requestForCreatePassenger(passengerBO:PassengerBO, handler:CompletionHandler)
    {
        self.serviceURL = "AddEditPassenger"
        self.webservice.isShowLoader = true
        self.setContentTypeHeaders()
        
        let dicParam:NSDictionary = NSDictionary() /*["AddressName":addresBO.addressName,"City":addresBO.city,"Country":addresBO.country,"State":addresBO.state,"StreetAddress":addresBO.streetAddress,"Unit":addresBO.unit,"ZipCode":addresBO.zipCode,"IsPrimary":false]*/
        
        self.requestforPOST(dicParam as! [NSObject : AnyObject!]) { (obj, success) -> Void in
            
            if success == true{
                if let dicResponse:NSDictionary = obj as? NSDictionary{
                    
                    handler(obj: dicResponse, success: true)
                }
            }
            else{
                handler(obj: obj, success: false)
            }
        }
        
    }
    

}
