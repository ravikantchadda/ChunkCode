//
//  ChatHistoryViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 13/11/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class ChatHistoryViewController: UIViewController {
    @IBOutlet weak var btnChatHistory: UIButton!
    var dictOptions: NSDictionary = ["title":["7 Days","15 Days","1 Month","1 Year","Forever"],"value":["7","15","30","365","99000"]]
    @IBOutlet weak var tblHistoryOption: UITableView!
    var strSelection: String = "99000"
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationItem.titleView = Utility.navBarTitleLabel("Chat History")
//        self.navigationItem.hidesBackButton = true
//        self.navigationItem.leftBarButtonItem = Utility.navBarLeftButton(UIImage(named: "btnBack")!, viewController: self)
        btnChatHistory.setTitle("Forever", forState: .Normal)
    }
    // MARK: - NavigationBar LeftBarButton Method
    func fnLeftBarButton(){
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    @IBAction func btnPressed_ChatHistory(sender: AnyObject) {
        tblHistoryOption.hidden = false
    }
    @IBAction func btnPressed_Save(sender: AnyObject) {
        if (Utility.checkNetwork() == true){
            if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                let dict:NSDictionary = [
                    "userId": userId,
                    "chatHistory": strSelection
                ]
                print("\(dict)")
                fnSaveChatHistoryWebServiceWithPostDic(dict)
            }
        }
    }
    @IBAction func btnPressed_ClearHistory(sender: AnyObject) {
        if (Utility.checkNetwork() == true){
            if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                let dict:NSDictionary = [
                    "userId": userId
                ]
                print("\(dict)")
                fnClearChatHistoryWebServiceWithPostDic(dict)
            }
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - TableView DataSource/Delegate
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return dictOptions.valueForKey("title")!.count
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if(tableView.respondsToSelector(Selector("setSeparatorInset:"))){
            tableView.separatorInset = UIEdgeInsetsZero
        }
        if(tableView.respondsToSelector(Selector("setLayoutMargins:"))){
            
            tableView.layoutMargins = UIEdgeInsetsZero
            
        }
        if(cell.respondsToSelector(Selector("setLayoutMargins:"))){
            
            cell.layoutMargins = UIEdgeInsetsZero
            
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(
            "cell", forIndexPath: indexPath)
        
        if let lblName = cell.viewWithTag(1001) as? UILabel {
            lblName.text = dictOptions.valueForKey("title")?.objectAtIndex(indexPath.row) as? String
        }
    
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
            tblHistoryOption.hidden = true
            strSelection = (dictOptions.valueForKey("value")?.objectAtIndex(indexPath.row) as? String)!
            btnChatHistory.setTitle(dictOptions.valueForKey("title")?.objectAtIndex(indexPath.row) as? String, forState: .Normal)
        
        }

    // MARK: - Webservice Call Methods
    // SaveHistory API
    func fnSaveChatHistoryWebServiceWithPostDic(dict: NSDictionary!) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            ObjWebserviceCall.isShowLoader = true
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceChatHistory)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("Save History--- \(response.webserviceResponse)")
                
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    
                    let alert = UIAlertController(title: "", message: response.webserviceResponse.valueForKey("status") as? String, preferredStyle: .Alert)
                    let action = UIAlertAction(title: "OK", style: .Default) { _ in
                        self.navigationController?.popViewControllerAnimated(true)
                    }
                    alert.addAction(action)
                    self.presentViewController(alert, animated: true, completion: nil)
                    
                    
                }else{
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
    
    // ClearChatHistory API
    func fnClearChatHistoryWebServiceWithPostDic(dict: NSDictionary!) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            ObjWebserviceCall.isShowLoader = true
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceClearHistory)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("Clear History--- \(response.webserviceResponse)")
                
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    
                    let alert = UIAlertController(title: "", message: response.webserviceResponse.valueForKey("status") as? String, preferredStyle: .Alert)
                    let action = UIAlertAction(title: "OK", style: .Default) { _ in
                        self.navigationController?.popViewControllerAnimated(true)
                    }
                    alert.addAction(action)
                    self.presentViewController(alert, animated: true, completion: nil)
                    
                    
                }else{
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
    
    func alertView(View: UIAlertView, clickedButtonAtIndex buttonIndex: Int){
        
        if (buttonIndex == 0){
            self.navigationController?.popViewControllerAnimated(true)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
