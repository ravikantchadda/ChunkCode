//
//  UserDL.swift
//  LocalLift
//
//  Created by prabhjot singh on 10/29/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit
import CoreLocation


// --- - -- - -- - - - -Users Model ---- -- - - -- -//

class UserBO: NSObject {
    
    static let sharedInstanceOfUser = UserBO()
    
    var userCountryObj :CountryCodeBO!
    var userAddress:AddressBO!
    var userID:NSNumber!
    var userFirstName:String!
    var userLastName:String!
    var userEmailAddress:String!
    var userPassword:String!
    var userMobileNo:String!
    var userAge:NSNumber!
    var userGender:NSNumber!
    var userImagePath:String!
    var userIsActive:Bool!
    var userMonth:NSNumber!
    var userNickName:String!
    var userPhoto:String!
    var userName:String!
    var userYear:NSNumber!
    var userAccessToken:String!
     var myProfileBOObj :MyProfileBO!
}

class MyProfileBO: NSObject {
    
    static let sharedInstanceOfUser = MyProfileBO()
    var userPhoto:String!
    var userGender:NSNumber!
    var userSpecialDesc:String!
    var userAddress : AddressBO!
    var userMonth : NSNumber!
    var userYear : NSNumber!
    var userDay : NSNumber!
    var isAdult : Bool!
//    "Address": {
//    "AddressName": "home",
//    "City": "sydney",
//    "Country": "australia",
//    "State": "nsw",
//    "StreetAddress": "79-89 westmead",
//    "Unit": "91",
//    "ZipCode": "2128",
//    
//    "Latitude": "-33.8116404",
//    "Longitude": "150.986044"
//    },
    
}

class AddressBO: NSObject {
    var addressID:NSNumber!
    var addressName:String!
    var city:String!
    var country:String!
    var isActive:Bool!
    var isNew:Bool!
    var isPrimary:Bool!
    var state:String!
    var streetAddress:String!
    var unit:String!
    var zipCode:String!
    var addressType:String!
    var locationCords:CLLocationCoordinate2D!
    
    func addSafelyAddtoLocation(dicAddress:NSDictionary, keyOfLatitude:String, keyOfLongitude:String){
        if let latitudeString = dicAddress.objectForKey(keyOfLatitude) as? String{
            if latitudeString.length != 0{
                let lactionLatitude:Double? = Double(latitudeString)
                if let laongitudeString = dicAddress.objectForKey(keyOfLongitude) as? String{
                    let lactionLongitude:Double? = Double(laongitudeString)
                    self.locationCords = CLLocationCoordinate2D(latitude: lactionLatitude!, longitude: lactionLongitude!)
                }
                else{
                    self.locationCords = CLLocationCoordinate2D(latitude: NSIUtility.randomFloat(-90, max: 90), longitude: NSIUtility.randomFloat(-180, max: 180))
                }
            }
        }else{
        self.locationCords = CLLocationCoordinate2D(latitude: NSIUtility.randomFloat(-90, max: 90), longitude: NSIUtility.randomFloat(-180, max: 180))
        }
    }
}




// --- - -- - -- - - - -USER DATA LAYERS ---- -- - - -- -//

class UserDL: PSRestAPIHelper {

// User Login Request
    func requestforUserLogin(userCredentials:(strUserName:String, strPassword:String), withCompletionHandler handler:CompletionHandler)
    {
        self.serviceURL = "Login"
        self.webservice.isShowLoader = true
        
        let dicParam:NSDictionary = ["UserName": userCredentials.0, "Password":userCredentials.1,"DeviceType":"IOS","DeviceID":NSIUtility.getUniqueIdentifier()]
        
        
        self.requestforPOST(dicParam as! [NSObject : AnyObject!], withCompletionHandler:{ (obj, success) -> Void in
            if let dicResponse:NSDictionary = obj as? NSDictionary{
                if success == true{
                    if let arrData:NSArray = NSIUtility.getObjectForKey("Data", dictResponse:dicResponse) as? NSArray
                    {
                        if let dicData:NSDictionary = arrData.objectAtIndex(0) as? NSDictionary
                        {
                            let userObject:UserBO = UserBO.sharedInstanceOfUser
//                            userObject.userCountryObj =
                            
                            userObject.userAccessToken = NSIUtility.getObjectForKey("AccessToken", dictResponse:dicData) as! String
                            
                            let dicUser:NSDictionary = NSIUtility.getObjectForKey("User", dictResponse:dicData) as! NSDictionary

// Saving Array of Address
                            if let dicAddress:NSDictionary = NSIUtility.getObjectForKey("Address", dictResponse:dicUser) as? NSDictionary{
                                
                                let addressObj:AddressBO = AddressBO()
                                addressObj.addressID = NSIUtility.getObjectForKey("AddressID", dictResponse:dicAddress) as! Bool
                                addressObj.addressName = NSIUtility.getObjectForKey("AddressName", dictResponse:dicAddress) as! String
                                addressObj.city = NSIUtility.getObjectForKey("City", dictResponse:dicAddress) as! String
                                addressObj.country = NSIUtility.getObjectForKey("Country", dictResponse:dicAddress) as! String
                                addressObj.isActive = NSIUtility.getObjectForKey("IsActive", dictResponse:dicAddress) as! Bool
                                addressObj.isNew = NSIUtility.getObjectForKey("IsNew", dictResponse:dicAddress) as! Bool
                                addressObj.isPrimary = NSIUtility.getObjectForKey("IsPrimary", dictResponse:dicAddress) as! Bool
                                addressObj.state = NSIUtility.getObjectForKey("State", dictResponse:dicAddress) as! String
                                addressObj.streetAddress = NSIUtility.getObjectForKey("StreetAddress", dictResponse:dicAddress) as! String
                                addressObj.unit = NSIUtility.getObjectForKey("Unit", dictResponse:dicAddress) as! String
                                addressObj.zipCode = NSIUtility.getObjectForKey("ZipCode", dictResponse:dicAddress) as! String
//                                addressObj.locationCords = CLLocationCoordinate2D(latitude: NSIUtility.randomFloat(-90, max: 90), longitude: NSIUtility.randomFloat(-180, max: 180))
                                addressObj.addressType = "Home"
                                userObject.userAddress = addressObj
                        
                                
                            }
                            
                            userObject.userID = NSIUtility.getObjectForKey("UserID", dictResponse:dicUser) as! NSNumber
                            userObject.userFirstName = NSIUtility.getObjectForKey("FirstName", dictResponse:dicUser) as! String
                            userObject.userLastName = NSIUtility.getObjectForKey("LastName", dictResponse:dicUser) as! String
                            userObject.userEmailAddress = NSIUtility.getObjectForKey("EmailAddress", dictResponse:dicUser) as! String
                            userObject.userPassword = NSIUtility.getObjectForKey("Password", dictResponse:dicUser) as! String
                            userObject.userMobileNo = NSIUtility.getObjectForKey("MobileNumber", dictResponse:dicUser) as! String
                            userObject.userAge = NSIUtility.getObjectForKey("Age", dictResponse:dicUser) as! NSNumber
                            userObject.userGender = NSIUtility.getObjectForKey("Gender", dictResponse:dicUser) as! NSNumber
                            userObject.userImagePath = NSIUtility.getObjectForKey("ImagePath", dictResponse:dicUser) as! String
                            userObject.userIsActive = NSIUtility.getObjectForKey("IsActive", dictResponse:dicUser) as! Bool
                            userObject.userMonth = NSIUtility.getObjectForKey("Month", dictResponse:dicUser) as! NSNumber
                            userObject.userNickName = NSIUtility.getObjectForKey("NickName", dictResponse:dicUser) as! String
                            userObject.userPhoto = NSIUtility.getObjectForKey("Photo", dictResponse:dicUser) as! String
                            userObject.userName = NSIUtility.getObjectForKey("UserName", dictResponse:dicUser) as! String
                            userObject.userYear = NSIUtility.getObjectForKey("Year", dictResponse:dicUser) as! NSNumber
                            
                            
                            handler(obj: userObject, success: true)
                        }
                        else{
                            handler(obj: arrData, success: false)
                        }
                    }
                    else{
                        handler(obj:dicResponse, success: false)
                    }
                }
                else{
                    if let message:String = NSIUtility.getObjectForKey("Message", dictResponse: dicResponse)as? String{
                            NSIUtility.show(message)
                    }
                    handler(obj: obj, success: false)
                }
            }
            
        })
    }
    
// User Creation Request
    func requestForUserCreation(handler:CompletionHandler)
    {
        self.serviceURL = "CreateUser"

        let obj = UserBO.sharedInstanceOfUser
        
        let dicParam:NSDictionary = ["FirstName": obj.userFirstName, "LastName":obj.userLastName,"EmailAddress":obj.userEmailAddress,"Password":obj.userPassword,"CountryCodeID":obj.userCountryObj.countryId,"MobileNumber":obj.userMobileNo]
        
        self.requestforPOST(dicParam as! [NSObject : AnyObject!], withCompletionHandler:{ (obj, success) -> Void in
            if success == true{
                if let dicResponse:NSDictionary = obj as? NSDictionary{
                    handler(obj: dicResponse, success: true)
                }
            }
            else {
                if let response:NSDictionary = obj as? NSDictionary {
                    if let status = response.valueForKey("Status") as? Int {
                        if status == 400
                        {
                            NSIUtility.show("User already exist")
                        }
                    }
                    handler(obj: obj, success: false)
                }
                else
                {
                    NSIUtility.show("Something went wrong. Please try again")
                    handler(obj: obj, success: false)
                }
            }
            
        })
    }
    
// User Activation
    func requestForUserActivation(handler:CompletionHandler)
    {
        self.serviceURL = "ActivateAccount"
        let objUser = UserBO.sharedInstanceOfUser
        
        let dicParam:NSDictionary = ["uid": objUser.userID]
        
        self.requestforGET(dicParam as! [NSObject : AnyObject!]) { (obj, success) -> Void in
            if success == true{
                if let dicResponse:NSDictionary = obj as? NSDictionary{
                    handler(obj: dicResponse, success: true)
                }
            }
            else{
                handler(obj: obj, success: true)
            }

        }
    }
    
// Resend Password
    func requestForForgetPassword(emailAddress:String, handler:CompletionHandler)
    {
        self.serviceURL = "ForgotPassword/\(emailAddress)"
        self.webservice.isShowLoader = true
        
        let dicParam:NSDictionary = ["":""]
        
        self.requestforPOST(dicParam as! [NSObject : AnyObject!]) { (obj, success) -> Void in
            
            if success == true{
                if let dicResponse:NSDictionary = obj as? NSDictionary{
                    
                    handler(obj: dicResponse, success: true)
                }
            }
            else{
                handler(obj: obj, success: false)
            }
        }
        
            
        
    }
    
    
// Fetch Addresses
    
    func requestforAddresses(handler:CompletionHandler)
    {
        self.serviceURL = "UserAddresses"
        self.setContentTypeHeaders()
        self.webservice.isShowLoader = true
        
        let userObj = UserBO.sharedInstanceOfUser
        let dicParam:NSDictionary = ["uid":userObj.userID,"si":1,"nor":1000]
        
        self.requestforGET(dicParam as! [NSObject : AnyObject!]) { (obj, success) -> Void in
            
            if success == true
            {
                let arrayOfPsngr:NSMutableArray = NSMutableArray()
                
                if let arrayOfParams:NSArray = obj!.valueForKey("Data") as? NSArray
                {
                    for item in arrayOfParams {
                        let dicBlock = item as! NSDictionary
                        let addressObj:AddressBO = AddressBO()
                        addressObj.addressID = NSIUtility.getObjectForKey("AddressID", dictResponse:dicBlock) as! NSNumber
                        addressObj.addressName = NSIUtility.getObjectForKey("AddressName", dictResponse:dicBlock) as! String
                        addressObj.city = NSIUtility.getObjectForKey("City", dictResponse:dicBlock) as! String
                        addressObj.country = NSIUtility.getObjectForKey("Country", dictResponse:dicBlock) as! String
                        addressObj.isActive = NSIUtility.getObjectForKey("IsActive", dictResponse:dicBlock) as! Bool
                        addressObj.isNew = NSIUtility.getObjectForKey("IsNew", dictResponse:dicBlock) as! Bool
                        addressObj.isPrimary = NSIUtility.getObjectForKey("IsPrimary", dictResponse:dicBlock) as! Bool
                        addressObj.state = NSIUtility.getObjectForKey("State", dictResponse:dicBlock) as! String
                        addressObj.streetAddress = NSIUtility.getObjectForKey("StreetAddress", dictResponse:dicBlock) as! String
                        addressObj.unit = NSIUtility.getObjectForKey("Unit", dictResponse:dicBlock) as! String
                        addressObj.zipCode = NSIUtility.getObjectForKey("ZipCode", dictResponse:dicBlock) as! String
                        addressObj.addressType = "Home"
                        
                        if let latitudeString = dicBlock.objectForKey("Latitude") as? String{
                            let lactionLatitude:Double? = Double(latitudeString)
                            if let laongitudeString = dicBlock.objectForKey("Longitude") as? String{
                                let lactionLongitude:Double? = Double(laongitudeString)
                                addressObj.locationCords = CLLocationCoordinate2D(latitude: lactionLatitude!, longitude: lactionLongitude!)
                            }
                        }else{
                            addressObj.locationCords = CLLocationCoordinate2D(latitude: NSIUtility.randomFloat(-90, max: 90), longitude: NSIUtility.randomFloat(-180, max: 180))
                        }
                        
//                        if let lactionLatitude:Double? =  Double(dicBlock.objectForKey("Latitude") as! String){
//                             if let lactionLongitude:Double? = Double(dicBlock.objectForKey("Longitude") as! String){
//                                 addressObj.locationCords = CLLocationCoordinate2D(latitude: lactionLatitude!, longitude: lactionLongitude!)
//                             }
//                        }else{
//                             addressObj.locationCords = CLLocationCoordinate2D(latitude: NSIUtility.randomFloat(-90, max: 90), longitude: NSIUtility.randomFloat(-180, max: 180))
//                        }

                        arrayOfPsngr.addObject(addressObj)
                    }
                    
                    handler(obj: arrayOfPsngr, success: true)
                    return
                }
                
                handler(obj: nil, success: false)
                print("Data is nil")
            }
        }
    }
    
    // Create Address
    func requestForCreateAddress(addresBO:AddressBO, handler:CompletionHandler)
    {
        self.serviceURL = "CreateAddress/\(UserBO.sharedInstanceOfUser.userID)"
        self.webservice.isShowLoader = true
        self.setContentTypeHeaders()
        
        let dicParam:NSDictionary = ["AddressName":addresBO.addressName,"City":addresBO.city,"Country":addresBO.country,"State":addresBO.state,"StreetAddress":addresBO.streetAddress,"Unit":addresBO.unit,"ZipCode":addresBO.zipCode,"IsPrimary":false,"Latitude":addresBO.locationCords.latitude,"Longitude":addresBO.locationCords.longitude]
       
        self.requestforPOST(dicParam as! [NSObject : AnyObject!]) { (obj, success) -> Void in
            
            if success == true{
                if let dicResponse:NSDictionary = obj as? NSDictionary{
                    
                    handler(obj: dicResponse, success: true)
                }
            }
            else{
                handler(obj: obj, success: false)
            }
        }
        
    }
    
    // User Profile Creation Request
    func requestForUpdateUserProfile(addresBO:AddressBO, handler:CompletionHandler)
    {
        self.serviceURL = "UpdateUserProfile"
        self.webservice.isShowLoader = true
        self.setContentTypeHeaders()
        
        let addressParam:NSDictionary = ["AddressName":addresBO.addressName,"City":addresBO.city,"Country":addresBO.country,"State":addresBO.state,"StreetAddress":addresBO.streetAddress,"Unit":addresBO.unit,"ZipCode":addresBO.zipCode,"Latitude":addresBO.locationCords.latitude,"Longitude":addresBO.locationCords.longitude]
        
        
//        var data = [Dictionary<String, String>]()
//        //append items
//        var jsonObj = JSON(data)
        
        let postParam:NSDictionary = ["Address" :addressParam,"UserID":UserBO.sharedInstanceOfUser.userID, "Gender":MyProfileBO.sharedInstanceOfUser.userGender, "Month":MyProfileBO.sharedInstanceOfUser.userMonth,"Year":MyProfileBO.sharedInstanceOfUser.userYear,"Day":MyProfileBO.sharedInstanceOfUser.userDay,"SpecialNeed":MyProfileBO.sharedInstanceOfUser.userSpecialDesc,"IsAdult":MyProfileBO.sharedInstanceOfUser.isAdult,"Photo":MyProfileBO.sharedInstanceOfUser.userPhoto]
        print(postParam);
        self.requestforPOST(postParam as! [NSObject : AnyObject!]) { (obj, success) -> Void in
            
            if success == true{
                if let dicResponse:NSDictionary = obj as? NSDictionary{
                    
                    handler(obj: dicResponse, success: true)
                }
            }
            else{
                handler(obj: obj, success: false)
            }
        }
    }
    
    
}
