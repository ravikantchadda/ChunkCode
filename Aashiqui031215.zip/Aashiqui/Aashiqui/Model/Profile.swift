//
//  Profile.swift
//  Aashiqui
//
//  Created by ketan saini on 20/10/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class Profile: NSObject {

    var aboutMe:String!
    var firstName:String!
    var lastName:String!
    var friendsCount:String!
    var postCount:String!
    var profileGotLikedCount:String!
    var uploadedPhotosCount:String!
    var profilePic:String!
    var profileId:String!
    var coverImage:String!
    var isFriend:Bool!
    var isLike:Bool!
    
    
    let aboutMeKey = "aboutMe"
    let firstNameKey = "firstName"
    let lastNameKey = "lastName"
    let friendsCountKey = "friendsCount"
    let postCountKey = "postCount"
    let profileGotLikedCountKey = "profileGotLikedCount"
    let uploadedPhotosCountKey = "uploadedPhotosCount"
    let profilePicKey = "profilePic"
    let profileIdKey = "profileId"
    let coverImgKey = "coverPhoto"
    let isFriendKey = "isFriend"
    let isLikeKey = "isLike"
    
    // MARK: NSCoding
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.aboutMe = (decoder.decodeObjectForKey(aboutMeKey) as! String?)!
        self.firstName = (decoder.decodeObjectForKey(firstNameKey) as! String?)!
        self.lastName = (decoder.decodeObjectForKey(lastNameKey) as! String?)!
        self.friendsCount = (decoder.decodeObjectForKey(friendsCountKey) as! String?)!
        self.postCount = (decoder.decodeObjectForKey(postCountKey) as! String?)!
        self.profileGotLikedCount = (decoder.decodeObjectForKey(profileGotLikedCountKey) as! String?)!
        self.uploadedPhotosCount = (decoder.decodeObjectForKey(uploadedPhotosCountKey) as! String?)!
        self.profilePic = (decoder.decodeObjectForKey(profilePicKey) as! String?)!
        self.profileId = (decoder.decodeObjectForKey(profileIdKey) as! String?)!
        self.coverImage = (decoder.decodeObjectForKey(coverImgKey) as! String?)!
        self.isFriend = (decoder.decodeObjectForKey(isFriendKey) as! Bool?)!
        self.isLike = (decoder.decodeObjectForKey(isLikeKey) as! Bool?)!
        
    }
    
    func encodeWithCoder(coder: NSCoder) {
        coder.encodeObject(self.aboutMe, forKey: aboutMeKey)
        coder.encodeObject(self.firstName, forKey: firstNameKey)
        coder.encodeObject(self.lastName, forKey: lastNameKey)
        coder.encodeObject(self.friendsCount, forKey: friendsCountKey)
        coder.encodeObject(self.postCount, forKey: postCountKey)
        coder.encodeObject(self.profileGotLikedCount, forKey: profileGotLikedCountKey)
        coder.encodeObject(self.uploadedPhotosCount, forKey: uploadedPhotosCountKey)
        coder.encodeObject(self.profilePic, forKey: profilePicKey)
        coder.encodeObject(self.profileId, forKey: profileIdKey)
        coder.encodeObject(self.coverImage, forKey: coverImgKey)
        coder.encodeObject(self.isFriend, forKey: isFriendKey)
        coder.encodeObject(self.isLike, forKey: isLikeKey)
        
    }
    
    func fillProfileDataInModel(dictData: NSDictionary) -> Profile {
        let objProfile = Profile()
        
        if (dictData.valueForKey(aboutMeKey)?.isKindOfClass(NSNull) != true){
            objProfile.aboutMe = dictData.valueForKey(aboutMeKey) as! String
        }else{
            objProfile.aboutMe = " "
        }
        objProfile.firstName = dictData.valueForKey(firstNameKey) as! String
        objProfile.lastName = dictData.valueForKey(lastNameKey) as! String
        objProfile.friendsCount = dictData.valueForKey("count")!.valueForKey(friendsCountKey) as! String
        objProfile.postCount = dictData.valueForKey("count")!.valueForKey(postCountKey) as! String
        objProfile.profileGotLikedCount = dictData.valueForKey("count")!.valueForKey(profileGotLikedCountKey) as! String
        objProfile.uploadedPhotosCount = dictData.valueForKey("count")!.valueForKey(uploadedPhotosCountKey) as! String
        objProfile.isFriend = dictData.valueForKey(isFriendKey) as! Bool
        objProfile.isLike = dictData.valueForKey(isLikeKey) as! Bool
        if (dictData.valueForKey(profilePicKey)?.isKindOfClass(NSNull) != true){
            objProfile.profilePic = dictData.valueForKey(profilePicKey) as! String
        }else{
            objProfile.profilePic = "sgfgdfs"
        }
        if (dictData.valueForKey(coverImgKey)?.isKindOfClass(NSNull) != true){
            objProfile.coverImage = dictData.valueForKey(coverImgKey) as! String
        }else{
            objProfile.coverImage = "sgsdgdfgs"
        }
        objProfile.profileId = dictData.valueForKey(profileIdKey) as! String
        
        return objProfile
    }

}

class PhotosTab: NSObject{
    
    var photoUrl:String!
    
    // MARK: NSCoding
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.photoUrl = (decoder.decodeObjectForKey("photoUrl") as! String?)!
    }
    
    func encodeWithCoder(coder: NSCoder) {
        coder.encodeObject(self.photoUrl, forKey: "photoUrl")
    }
    
    func fillPhotosInModel(arrData: NSArray) -> NSMutableArray {
        let arrUserData: NSMutableArray! = []
        for dict in arrData{
            let objPhotos = PhotosTab()
            if (dict.valueForKey("photoUrl")?.isKindOfClass(NSNull) != true){
                objPhotos.photoUrl = dict.valueForKey("photoUrl") as! String
            }else{
                objPhotos.photoUrl = ""
            }
            arrUserData.addObject(objPhotos)
        }
        return arrUserData
    }
}

class PairedLikesTab: NSObject{
    
    var profilePicUrl:String!
    var firstName:String!
    var lastName:String!
    var userId:String!
    
    // MARK: NSCoding
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.profilePicUrl = (decoder.decodeObjectForKey("profilePic") as! String?)!
        self.firstName = (decoder.decodeObjectForKey("firstName") as! String?)!
        self.lastName = (decoder.decodeObjectForKey("lastName") as! String?)!
        self.userId = (decoder.decodeObjectForKey("userId") as! String?)!
    }
    
    func encodeWithCoder(coder: NSCoder) {
        coder.encodeObject(self.profilePicUrl, forKey: "profilePic")
        coder.encodeObject(self.firstName, forKey: "firstName")
        coder.encodeObject(self.lastName, forKey: "lastName")
        coder.encodeObject(self.userId, forKey: "userId")
    }
    
    func fillPairedLikeInModel(arrData: NSArray) -> NSMutableArray {
        let arrUserData: NSMutableArray! = []
        for dict in arrData{
            let objPairedLikes = PairedLikesTab()
            if (dict.valueForKey("profilePic")?.isKindOfClass(NSNull) != true){
                objPairedLikes.profilePicUrl = dict.valueForKey("profilePic") as! String
            }else{
                objPairedLikes.profilePicUrl = ""
            }
            if (dict.valueForKey("firstName")?.isKindOfClass(NSNull) != true){
                objPairedLikes.firstName = dict.valueForKey("firstName") as! String
            }else{
                objPairedLikes.firstName = ""
            }
            if (dict.valueForKey("lastName")?.isKindOfClass(NSNull) != true){
                objPairedLikes.lastName = dict.valueForKey("lastName") as! String
            }else{
                objPairedLikes.lastName = ""
            }
            if (dict.valueForKey("userId")?.isKindOfClass(NSNull) != true){
                objPairedLikes.userId = dict.valueForKey("userId") as! String
            }else{
                objPairedLikes.userId = ""
            }
            arrUserData.addObject(objPairedLikes)
        }
        return arrUserData
    }}
/*
class LikesTab: NSObject{
    
    var profilePic:String!
    var firstName:String!
    var lastName:String!
    var userId:String!
    
    // MARK: NSCoding
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.profilePic = (decoder.decodeObjectForKey("profilePic") as! String?)!
        self.firstName = (decoder.decodeObjectForKey("firstName") as! String?)!
        self.lastName = (decoder.decodeObjectForKey("lastName") as! String?)!
        self.userId = (decoder.decodeObjectForKey("userId") as! String?)!
    }
    
    func encodeWithCoder(coder: NSCoder) {
        coder.encodeObject(self.profilePic, forKey: "profilePic")
        coder.encodeObject(self.firstName, forKey: "firstName")
        coder.encodeObject(self.lastName, forKey: "lastName")
        coder.encodeObject(self.userId, forKey: "userId")
    }
    
    func fillLikesInModel(arrData: NSArray) -> NSMutableArray {
        let arrUserData: NSMutableArray! = []
        for dict in arrData{
            let objLikes = LikesTab()
            if (dict.valueForKey("profilePic")?.isKindOfClass(NSNull) != true){
                objLikes.profilePic = dict.valueForKey("profilePic") as! String
            }else{
                objLikes.profilePic = ""
            }
            if (dict.valueForKey("firstName")?.isKindOfClass(NSNull) != true){
                objLikes.firstName = dict.valueForKey("firstName") as! String
            }else{
                objLikes.firstName = ""
            }
            if (dict.valueForKey("lastName")?.isKindOfClass(NSNull) != true){
                objLikes.lastName = dict.valueForKey("lastName") as! String
            }else{
                objLikes.lastName = ""
            }
            if (dict.valueForKey("userId")?.isKindOfClass(NSNull) != true){
                objLikes.userId = dict.valueForKey("userId") as! String
            }else{
                objLikes.userId = ""
            }
            arrUserData.addObject(objLikes)
        }
        return arrUserData
    }

}
*/