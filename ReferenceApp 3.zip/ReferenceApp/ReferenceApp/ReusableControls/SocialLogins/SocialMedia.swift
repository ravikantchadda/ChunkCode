//
//  SocialMedia.swift
//  SocialMediaIntegartion
//
//  Created by Aanchal Jain on 01/07/15.
//  Copyright (c) 2015 Aanchal Jain. All rights reserved.
//

import UIKit
import FBSDKCoreKit
import FBSDKLoginKit
import IOSLinkedInAPI
import TwitterKit

//enum LoginType:Int {
//    case LoginSourcetypeNormal = 0
//    case LoginSourcetypeFacebook = 1
//    case LoginSourcetypeGooglePlus = 2
//    case LoginSourcetypeLinkedIn = 3
//    case LoginSourcetypeTwitter = 4
//}

/*

//state: the state used to prevent Cross Site Request Forgery. Should be something that is hard to guess.
let APP_LINKEDIN_STATE = "DCEEFWF45453sdffef424"
//redirectURL: has to be a http or https url (required by LinkedIn), but other than that, the endpoint doesn't have to respond anything. The library only uses the endpoint to know when to intercept calls in the UIWebView.
let APP_LINKEDIN_REDIRECTURL = "https://www.google.com"

var responseBlock:CompleteSocialLoginBlock?
var signIn:GPPSignIn?
var client:LIALinkedInHttpClient?

class SocialMedia: NSObject, GPPSignInDelegate
{
    
    // MARK: - Log In With Twitter
    func signInWithTwitter(vc:UIViewController!,responseBlock:CompleteSocialLoginBlock){
        
        Twitter.sharedInstance().logInWithCompletion { session, error in
            if let unwrappedSession = session {
                let alert = UIAlertController(title: "Logged In",
                    message: "User \(unwrappedSession.userName) has logged in",
                    preferredStyle: UIAlertControllerStyle.Alert
                )
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
                vc.presentViewController(alert, animated: true, completion: nil)
                
                responseBlock(true,LoginType.LoginSourcetypeTwitter,unwrappedSession.userID)
            } else {
                NSLog("Login error: %@", error!.localizedDescription);
            }
        }
        
        
    }
    
    
    
    // MARK: - Log In With FB
    func signInWithFacebook(vc:UIViewController!,responseBlock:CompleteSocialLoginBlock)
    {
        let facebookReadPermissions = ["public_profile","email"]
        FBSDKLoginManager().logInWithReadPermissions(facebookReadPermissions, fromViewController: vc, handler: {(result:FBSDKLoginManagerLoginResult!,error:NSError!) -> Void in
            if error != nil {
                // Process Error
            }
            else if result.isCancelled {
                // Cancelled by User
            }
            else {
                
                
            NSIUtility.DBlog(result)
                
                responseBlock(true,LoginType.LoginSourcetypeFacebook,FBSDKAccessToken.currentAccessToken().tokenString)
            }
        })
    }
    
    //MARK: - Log In With Google Plus[[GPPSignIn sharedInstance] trySilentAuthentication]
    func signInWithGoogle(block:CompleteSocialLoginBlock)
    {
        responseBlock = block
        signIn = GPPSignIn.sharedInstance()
        signIn?.shouldFetchGooglePlusUser = true
        signIn?.shouldFetchGoogleUserID = true
        signIn?.shouldFetchGoogleUserEmail = true
        signIn?.scopes = [kGTLAuthScopePlusLogin]
        signIn?.delegate = self;
        signIn?.authenticate()
    }
    
    //MARK: -  Google Plus Delegate Methods
    func didDisconnectWithError(error:NSError!) {
        
        responseBlock!(false,LoginType.LoginSourcetypeGooglePlus,"")
    }
    
    func finishedWithAuth(auth: GTMOAuth2Authentication!, error:NSError!)
    {
        if error != nil {
            // handle Error
            responseBlock!(false,LoginType.LoginSourcetypeGooglePlus,auth.valueForKey("accessToken") as! String)
        }
        else {
            print("Auth = %@",auth)
            responseBlock!(true,LoginType.LoginSourcetypeGooglePlus,auth.valueForKey("accessToken") as! String)
        }
    }
    
    
    //MARK: - Log In With Linked In
    func signInWithLinkedIn(block:CompleteSocialLoginBlock)
    {
        self.client().getAuthorizationCode({ (code:String!) -> Void in
            self.client().getAccessToken(code, success: { (accessTokenData:[NSObject : AnyObject]!) -> Void in
                let strToken = accessTokenData["access_token"] as? String
                block(true,LoginType.LoginSourcetypeLinkedIn,strToken)
                }, failure: { (error:NSError!) -> Void in
                    block(false,LoginType.LoginSourcetypeLinkedIn,"")
            })
            }, cancel: { () -> Void in
                block(false,LoginType.LoginSourcetypeLinkedIn,"")
            }) { (error:NSError!) -> Void in
                block(false,LoginType.LoginSourcetypeLinkedIn,"")
        }
    }
    
    func client()->LIALinkedInHttpClient {
        let app = LIALinkedInApplication.applicationWithRedirectURL(APP_LINKEDIN_REDIRECTURL, clientId:Constants.APP_LINKEDIN_CLIENTID, clientSecret: Constants.APP_LINKEDIN_CLIENTSECRET, state:APP_LINKEDIN_STATE, grantedAccess:["r_basicprofile"]) as? LIALinkedInApplication
        return LIALinkedInHttpClient.init(forApplication: app, presentingViewController: nil)
    }
    
}
*/