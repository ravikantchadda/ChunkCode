//
//  NotificationCell.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/9/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class NotificationCell: UITableViewCell {

    @IBOutlet weak var lblNotificationBuddy: UILabel!
    @IBOutlet weak var lblNoticationBuddyDestination: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    //uppper label in uitableviewcell change (name of buddy)
    func setBuddyNameForCell(buddyName:String,withbuddyMessage buddyMessage:String) {
        let buddy = "\(buddyName) \(buddyMessage)" as NSString
        
        let attrbtdStrngBuddyMessage = NSMutableAttributedString(string: buddy as String)
        let firstAttributesBlackColor = [NSForegroundColorAttributeName: UIColor.blackColor()]
        let secondAttributesGrayColor = [NSForegroundColorAttributeName: UIColor.colorWithRGB(133, green: 136, blue: 140, alpha:1.0)]
         attrbtdStrngBuddyMessage.addAttributes(firstAttributesBlackColor, range: buddy.rangeOfString(buddyName))
        attrbtdStrngBuddyMessage.addAttributes(secondAttributesGrayColor, range: buddy.rangeOfString(buddyMessage))
        
        self.lblNotificationBuddy.attributedText = attrbtdStrngBuddyMessage
        
    }
    
    //change text of second lable in uitableviewcell
    func setBuddyDestinationForCell(buddyDestination:String) {
        self.lblNoticationBuddyDestination.text =  buddyDestination
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
}
