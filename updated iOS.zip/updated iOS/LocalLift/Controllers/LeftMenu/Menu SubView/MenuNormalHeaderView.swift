//
//  MenuNormalHeaderView.swift
//  LocalLift
//
//  Created by neeru thakur on 12/9/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class MenuNormalHeaderView: UIView {
    
    @IBOutlet weak var btnNormalMenu: UIButton!
    
    weak var leftMenuVCCallBack:LeftMenuVC!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }
    
    override init(frame: CGRect) {

        super.init(frame: frame)
        
        let views = NSBundle.mainBundle().loadNibNamed("MenuNormalHeaderView", owner: self, options: nil)
        let view = views.first as? UIView
        
        self.addSubview(view!)
        
        self.initializer()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func initializer(){
        self.btnNormalMenu.setTitleColor(UIColor.whiteColor(), forState: UIControlState.Normal)
    }
    func setButtonTile(title:String, section:Int){
       
       self.btnNormalMenu.setTitle(title, forState: UIControlState.Normal)
        self.btnNormalMenu.tag = section
    }
    
    @IBAction func normalMenuViewBtnPressed(sender: AnyObject) {
        if (leftMenuVCCallBack != nil ){
            leftMenuVCCallBack.didSelectMenuOption(sender.tag)
        }
        
    }
    
    deinit{
        leftMenuVCCallBack = nil
    }
}

