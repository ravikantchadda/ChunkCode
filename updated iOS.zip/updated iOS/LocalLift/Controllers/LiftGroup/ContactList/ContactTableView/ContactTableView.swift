//
//  ContactTableView.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/23/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit



class ContactTableView: UIView {

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
