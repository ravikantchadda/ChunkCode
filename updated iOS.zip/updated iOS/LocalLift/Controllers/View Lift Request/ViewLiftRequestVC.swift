//
//  ViewLiftRequestVC.swift
//  LocalLift
//
//  Created by prabhjot singh on 12/9/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit
import UIAlertView_Blocks

class ViewLiftRequestVC: BaseViewController,UITableViewDelegate,UITableViewDataSource,ViewLiftTimeProtocol,GroupsOfPeopleProtocol {

    
    enum LoactionType:Int {case FromLocation = 0, ToLocation = 1}
    
    enum AcceptanceType:Int {case ActionTypeCancel = 0, ActionTypeAccept = 1}
    
    @IBOutlet var tblView: UITableView!
    
    var viewSetLoc:ViewOfSetLocation!
    var cellOfMap: MapViewCell!
    var cellOfMessage:AddMessageCell!
    var requestBO:RequestBO!
    var viewForTime: ViewLiftTimeCell!
    var cellShowTimeView: ShowTimeViewLiftCell!
    var cellGroupOfPassenger: GroupsOfPeopleCell!
    var liftBO:LiftBO!
    
    var acceptanceType:AcceptanceType!
    
    @IBOutlet var btnAcceptLift: UIButton!
    
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBar(.BlueNavigationType)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialInitilization()
        self.fetchRequestDetails()
    }
    
//MARK:- Button Methods
    
    
    @IBAction func actionPressed(sender: UIButton) {
        
        if acceptanceType == .ActionTypeAccept{
            self.toAccept()
        }else{
            self.toCancel()
        }
    }
    
    
    func toCancel() {
        
    }
    
    func toAccept() {
        
//        let predicateFrom:NSPredicate = NSPredicate(format: "isLiftSelected == %@", argumentArray:[true])
        var arrayFiltered = NSArray()

        if requestBO.isRecurring == true{
//            let predicateFrom:NSPredicate = NSPredicate(format: "self.isLiftSelected == 0")
            print( (self.requestBO.arrayRecurringLiftRequests?[0] as! RecurringLiftRequestsBO).isLiftSelectedNumber )
            let predicateFrom:NSPredicate = NSPredicate(format: "isLiftSelectedNumber == 1")
            arrayFiltered = (self.requestBO.arrayRecurringLiftRequests?.filteredArrayUsingPredicate(predicateFrom))!
            
            if arrayFiltered.count == 0{
                NSIUtility.show("Please select atleast one Date")
                return
            }
        }
        
        var strMeassage:String
        if requestBO.isRecurring == false{
            strMeassage = "A response will be sent back to \(liftBO.liftRequesterName) confirming you can give him/her a lift ASAP"
        }else{
            strMeassage = "A response will be sent back to \(liftBO.liftRequesterName) confirming you can give him/her a lift ASAP on selected dates"
        }
        if self.liftBO.requestId != nil && self.requestBO != nil{
        
            UIAlertView.showWithTitle("Localift", message: strMeassage, cancelButtonTitle: "Cancel", otherButtonTitles:["Okay"]) { (alertView, buttonIndex) -> Void in
                if buttonIndex != alertView.cancelButtonIndex{
                    let liftDL = LiftDL()
                    liftDL.requestForAcceptLift(self.liftBO.requestId, requestBO: self.requestBO, isAccepted: true,selectedArray:arrayFiltered ) { (obj, success) -> Void in
                        if success == true{
                            NSIUtility.show("Request has been successfully accepted")
                            if let homeVC:HomeVC = self.lastViewController() as? HomeVC{
                                homeVC.fetchLiftsForUser()
                                self.navigationController?.popToViewController(homeVC, animated: true)
                            }else{
                                
                            }
                        }else{
                            NSIUtility.show("Oops! Something went wrong")
                        }
                    }
                }else{}
            }
        }
        
        
    }
    
    
//MARK:- Other Methods
    
    func initialInitilization(){
        acceptanceType = .ActionTypeAccept
        
        viewSetLoc = UIView.viewFromNibName("ViewOfSetLocation") as? ViewOfSetLocation
        viewSetLoc.btnDestinationLoc.userInteractionEnabled = false
        viewSetLoc.btnPickupLoc.userInteractionEnabled = false
        
        if acceptanceType == .ActionTypeAccept{
            self.btnAcceptLift.setTitle("Accept", forState: .Normal)
        }else{
            self.btnAcceptLift.setTitle("Cancel", forState: .Normal)
        }
        
        tblView.registerNib(UINib.init(nibName: "MapViewCell", bundle: nil), forCellReuseIdentifier: "mapViewCell")
        tblView.registerNib(UINib.init(nibName: "AddMessageCell", bundle: nil), forCellReuseIdentifier: "addMessageCell")
        tblView.registerNib(UINib.init(nibName: "ViewLiftTimeCell", bundle: nil), forCellReuseIdentifier: "viewLiftTimeCell")
        tblView.registerNib(UINib.init(nibName: "ShowTimeViewLiftCell", bundle: nil), forCellReuseIdentifier: "showTimeViewLiftCell")
        tblView.registerNib(UINib.init(nibName: "GroupsOfPeopleCell", bundle: nil), forCellReuseIdentifier: "groupsOfPeopleCell")
        
        self.cellOfMap  = tblView.dequeueReusableCellWithIdentifier("mapViewCell") as! MapViewCell
        self.cellOfMap.callBack = self
        self.cellOfMap.titleView.hidden = true
        self.cellOfMap.mapCenterPinImage.hidden = true
        
        
        self.cellOfMessage  = tblView.dequeueReusableCellWithIdentifier("addMessageCell") as! AddMessageCell
        self.cellOfMessage.constraintVerticalTop.constant = 0
        
        self.viewForTime  = tblView.dequeueReusableCellWithIdentifier("viewLiftTimeCell") as! ViewLiftTimeCell
        self.viewForTime.delegate = self
        
        self.cellShowTimeView  = tblView.dequeueReusableCellWithIdentifier("showTimeViewLiftCell") as! ShowTimeViewLiftCell
        self.cellShowTimeView.btnSelectedLift.hidden = true
        
        self.cellGroupOfPassenger  = tblView.dequeueReusableCellWithIdentifier("groupsOfPeopleCell") as! GroupsOfPeopleCell
        self.cellGroupOfPassenger.delegate = self
        self.cellGroupOfPassenger.collectionType = .CollectionPassenger
        
    }
    
    func fetchRequestDetails(){
        let requestDL = RequestDL()
        requestDL.requestForGetRequestLift(liftBO.requestId,lastIndex:1, hasMaxCount:false) { (obj, success) -> Void in
            if success == true{
                if let requestBO = obj as? RequestBO{
                    self.requestBO = requestBO
                    self.tblView.delegate = self
                    self.tblView.dataSource = self
                    self.setTheData()
                }
            }
        }
    }
    
    func fetchPassengers(){
        let passengertDL = PassengerDL()
        passengertDL.requestforPassengers(self.liftBO.requestId) { (obj, success) -> Void in
            if success == true{
                if let arrayOfPassengers = obj as? NSMutableArray{
                    self.cellGroupOfPassenger.arrayOfPassenger = arrayOfPassengers
                    self.cellGroupOfPassenger.collOfPsgr.reloadData()
                }
            }
        }
    }
    
    
    func setTheData(){
        
        viewForTime.requestID = self.liftBO.requestId
        
        self.cellOfMap.addMarkerToPickupLocation(self.requestBO.newStartLocation, title: "")
        self.cellOfMap.addMarkerToDestinationLocation(self.requestBO.newEndLocation, title: "")
        self.cellOfMap.addRouteToMap(self.requestBO.newStartLocation.locationCords, withDestinationLoc: self.requestBO.newEndLocation.locationCords)
        self.cellOfMap.viewShowDistance.hidden = false
        
        
        self.cellOfMessage.txtMessage.editable = false
        self.cellOfMessage.txtMessage.text = self.requestBO.message
        
        self.viewSetLoc.btnPickupLoc.setTitle(self.requestBO.newStartLocation.streetAddress, forState: .Normal)
        self.viewSetLoc.btnDestinationLoc.setTitle(self.requestBO.newEndLocation.streetAddress, forState: .Normal)
        
        if self.requestBO.arratLiftPassengers != nil{
            self.cellGroupOfPassenger.arrayOfPassenger = self.requestBO.arratLiftPassengers!
        }else{
            self.fetchPassengers()
        }
        
        if self.requestBO.arrayRecurringLiftRequests != nil{
            if self.requestBO.arrayRecurringLiftRequests!.count  == 0{
                
                let recurringLiftRequestsBO = RecurringLiftRequestsBO()
                recurringLiftRequestsBO.requestReccuringID = requestBO.requestId
                recurringLiftRequestsBO.liftDate = requestBO.requestDatetimeDATE
                recurringLiftRequestsBO.dateString =  requestBO.requestDatetimeDATE.toString(format: .Custom(Constants.DateFormatwithAMPM))
                recurringLiftRequestsBO.liftTime = requestBO.requestDatetimeDATE.toString(format: .Custom(Constants.TimeFormat))
                recurringLiftRequestsBO.isLiftSelected = false
                self.requestBO.arrayRecurringLiftRequests!.addObject(recurringLiftRequestsBO)
                
            }
            self.viewForTime.arrayViewLiftTime = self.requestBO.arrayRecurringLiftRequests!
            
        }
        
        self.cellGroupOfPassenger.constraintTopView.constant = 0
        self.cellGroupOfPassenger.collOfPsgr.updateConstraintsIfNeeded()
        
        self.cellShowTimeView.lblShowDate.text! = requestBO.requestDatetimeDATE.toString(format: .Custom(Constants.DateFormatwithAMPM))
        self.cellShowTimeView.lblShowTime.text! = requestBO.requestDatetimeDATE.toString(format: .Custom(Constants.TimeFormat))
        
        
        
        self.title = self.liftBO.liftRequesterName
        
        self.tblView.reloadData()
//        self.cellGroupOfPassenger.collOfPsgr.reloadData()
        
    }
    
    func reloadTimeTable() {
        self.tblView.reloadData()
    }
    
    
//MARK:- CallBack Delgates
    //Collection Delegates
    
    func didSelectTheCell() {
        
    }
    
    // MARK:- Tableview Delgates
    
    // View of Footer nad Header View
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?{
        return viewSetLoc
    }
    
    // Height of Footer nad Header View
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat{
        return viewSetLoc.height
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) ->Int
    {return 1}
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) ->Int
    {return 4}
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat
    {
        switch indexPath.row {
        case 0:
            return 300
        case 1:
            return 105
        case 2:
            if self.requestBO.isRecurring == true{
                let height = CGFloat(viewForTime.arrayViewLiftTime.count)*CGFloat(viewForTime.rowHeightTbl);
                var tableFrame = viewForTime.tblViewForTime.frame;
                tableFrame.size.height = height;
                
                viewForTime.tblViewForTime.frame = tableFrame;
                viewForTime.contentViewForTbl.frame = tableFrame;

                return viewForTime.contentViewForTbl.height+58
            }else{
                return 105
            }
        case 3:
            return 105
        default:
            return 75
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) ->UITableViewCell
    {
        cellOfMap.selectionStyle = .None

        cellOfMessage.selectionStyle = .None
        cellGroupOfPassenger.selectionStyle = .None
        cellShowTimeView.selectionStyle = .None
        
        switch indexPath.row{
        case 0:
            return cellOfMap
        case 1:
            return self.cellGroupOfPassenger
        case 2:
            if self.requestBO.isRecurring == true{
                return viewForTime
            }else{
                return self.cellShowTimeView
            }
        case 3:
            return cellOfMessage

        default:
            return UITableViewCell()
        }
        
    }
    
    
}
