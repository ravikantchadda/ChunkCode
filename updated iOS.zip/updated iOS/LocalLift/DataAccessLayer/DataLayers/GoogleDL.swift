//
//  GoogleDL.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/29/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class GoogleDL: PSRestAPIHelper {
    
    let googleAPI = "https://maps.googleapis.com/maps/api/directions/json"
    
    func requestTheGetDirections(mobile_number:String, withCompletionHandler handler:CompletionHandler)
    {
//        Sahibzada+Ajit+Singh+Nagar,+Punjab
//        Chandigarh
        let dicParam:NSDictionary = ["origin":"Sahibzada+Ajit+Singh+Nagar,+Punjab","destination":"Chandigarh","key":"AIzaSyAORhHzkaIUZEseT3MNJSlcTJg1K_-vqfE"]
        self.webservice.isShowLoader = true
        
        self.requestforGETWithoutServiceURL(dicParam as! [NSObject : AnyObject!], withURL: googleAPI) { (obj, success) -> Void in
            
            if success == true
            {
                if let response:NSDictionary = obj as? NSDictionary {
                    let status = response.objectForKey("status") as! String
                    if status == "0"{
                    }
                }
            }else{
                handler(obj: obj, success: false)
            }
        }
    }

}
