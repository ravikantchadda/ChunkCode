//
//  AddPassenger.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/28/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class AddPassengerVC: BaseViewController {

    
    @IBOutlet var scrlView: UIScrollView!
    @IBOutlet var segYesNoSmart: UISegmentedControl!
    @IBOutlet var txtMobileNo: UITextField!
    @IBOutlet var txtEmailAdd: UITextField!
    @IBOutlet var txtLastName: UITextField!
    @IBOutlet var txtFirstName: UITextField!
    @IBOutlet var txtViewImpIfo: UITextView!
    @IBOutlet var imgPassengrImage: UIImageView!
    @IBOutlet var btnContryCode:UIButton!
    @IBOutlet var btnSaveChanges: UIButton!
    var countryObj:CountryCodeBO!
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.assignTheValues()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.initialInitialization()
    }
    
    func assignTheValues()
    {
        if countryObj != nil
        {
            btnContryCode.setTitle(countryObj.countryName + "  " + countryObj.countryCode, forState:UIControlState.Normal)
            self.toSelectBtnValidation()
        }
    }
    
    func initialInitialization()
    {
        btnContryCode.roundCorner(5)
        btnContryCode.layer.borderColor = UIColor.lightGrayColor().CGColor
        btnContryCode.layer.borderWidth = 1
        // Initially it will be Australia
        let objCountry = CountryCodeBO()
        objCountry.countryCode = "+61"
        objCountry.countryId = 13
        objCountry.countryName = "Australia"
        countryObj = objCountry
    }
    
// MARK:- Button Methods
    
    @IBAction func toCountryVC(sender: AnyObject) {
        let countryVC = CountryCodeVC()
        self.presentViewController(countryVC, animated: true, completion: nil)
    }
    
    @IBAction func btnUploadPic(sender: AnyObject) {
        
    }
    @IBAction func toSaveChanges(sender: AnyObject) {
        
        if NSIUtility.validateTextFieldArray(["First Name","Last Name","Email Address","Mobile Number"],arrayOFFields: [txtFirstName,txtLastName,txtEmailAdd,txtMobileNo])
        {
            if (countryObj != nil)
            {
                if NSIUtility.validateEmail(txtEmailAdd.text!) == false {return}
                if txtMobileNo.text?.length <= 5 {NSIUtility.show(Constants.kValidMobileNo);return}
                
                let pssgerDL = PassengerDL()
                let pssgerBO = PassengerBO()
                
                pssgerDL.requestForCreatePassenger(pssgerBO, handler: { (obj, success) -> Void in
                    
                })
            }
            else{
                NSIUtility.show("Please select the Country Code")
            }
            }
        
    }
    
//MARK: - Text Field Delegates
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
        
        if textField == txtMobileNo
        {
            return UITextField.textField(textField, shouldChangeCharactersInRange: range, replacementString: string,
                withMaxLength: UITextField.MaxLength.MobileNoMax, spaceAllowed: false)
        }
        
        return UITextField.textField(textField, shouldChangeCharactersInRange: range, replacementString: string,
            withMaxLength: UITextField.MaxLength.DefaultMax, spaceAllowed: false)
        
    }
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool{
        
        return UITextView.textView(textView, shouldChangeCharactersInRange: range, replacementString: text,
            withMaxLength:200, spaceAllowed: true)
    }
    
    
    func toSelectBtnValidation()
    {
        if (self.isAllTextFieldFilled(self.scrlView) == false || countryObj == nil || txtMobileNo.text?.length <= 5 ){
            btnSaveChanges.backgroundColor = UIColor.colorWithRGB(31, green: 81, blue: 108, alpha:0.7)
            //            btnConnect.userInteractionEnabled = false
        }
        else{
            btnSaveChanges.backgroundColor = Constants.APP_THEME_COLOR
            //            btnConnect.userInteractionEnabled = true
        }
    }
}
