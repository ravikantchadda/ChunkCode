//
//  Facebook.swift
//  ReferenceApp
//
//  Created by ravi kant on 11/26/15.
//  Copyright © 2015 Netsol. All rights reserved.
//

import Foundation
import FBSDKCoreKit
import FBSDKLoginKit
import FBSDKShareKit
typealias UserProfileCompletionHandler = (data :AnyObject?, success:Bool?) -> Void
class Facebook: NSObject,FBSDKSharingDelegate,FBSDKAppInviteDialogDelegate
{
    
    var responseBlock:CompleteSocialLoginBlock?
    var viewCont = UIViewController()
    
    
    // MARK: - Log In With FB
    func signInWithFacebook(vc:UIViewController!,responseBlock:CompleteSocialLoginBlock)
    {
        
        
        let facebookReadPermissions = ["public_profile","email","user_friends"]
        FBSDKLoginManager().loginBehavior = FBSDKLoginBehavior.Web
        FBSDKLoginManager().logInWithReadPermissions(facebookReadPermissions, fromViewController: vc, handler: {(result:FBSDKLoginManagerLoginResult!,error:NSError!) -> Void in
            if error != nil {
                // Process Error
                responseBlock(false,LoginType.LoginSourcetypeFacebook,error.description)
                
              
            }
            else if result.isCancelled {
                // Cancelled by User
                responseBlock(false,LoginType.LoginSourcetypeFacebook,"")
            }
            else {
                
                NSIUtility.DBlog(result.description)

                responseBlock(true,LoginType.LoginSourcetypeFacebook,FBSDKAccessToken.currentAccessToken().tokenString)
            }
        })
    }
    
    //MARK: - Method to Logout
    func logout(){
    
        FBSDKLoginManager().logOut()
    
    }
    //MARK: - Method to Get UserProfile
    func requestProfile(responseBlock:UserProfileCompletionHandler){
        
        let fbRequest = FBSDKGraphRequest(graphPath:"me?fields=id,name,email,first_name,gender,hometown,last_name,location,relationship_status,cover,religion,middle_name,education,birthday,about", parameters: nil);
        fbRequest.startWithCompletionHandler { (connection : FBSDKGraphRequestConnection!, result : AnyObject!, error : NSError!) -> Void in
            
            if error == nil {
                
                NSIUtility.DBlog("User Info : \(result)")
                
                
                responseBlock(data: result, success: true)
                
               let facebookid = result.valueForKey("id") as? String
               let userName = result.valueForKey("name") as? String
               let firstName = result.valueForKey("first_name") as? String
               let lastName = result.valueForKey("name") as? String
               let userEmail = result.valueForKey("email") as? String
               NSIUtility.DBlog("facebookid: \(facebookid)")
               NSIUtility.DBlog("userName: \(userName)")
               NSIUtility.DBlog("firstName: \(firstName)")
               NSIUtility.DBlog("lastName: \(lastName)")
               NSIUtility.DBlog("userEmail: \(userEmail)")
               let userID = result.valueForKey("id") as? String
                let facebookProfileUrl = "http://graph.facebook.com/\(userID!)/picture?type=large"
                
                NSIUtility.setValueToUserDefaultsForKey("userimageurl", value: facebookProfileUrl)
                NSIUtility.setValueToUserDefaultsForKey("username", value: userName)
                
               
                
            } else {
                NSIUtility.DBlog("Error Getting Info \(error)");
                
                responseBlock(data:nil, success: false)
                
            }
            
            
        }
    }
    
    //MARK: - Method Post to TimeLine

    func postToTimeLineFaceBook(vc:UIViewController!){
        
     
        let content : FBSDKShareLinkContent = FBSDKShareLinkContent()
        content.contentURL = NSURL(string: "https://www.facebook.com/")
        content.contentTitle = "I have 100 scores in 50 seconds. Come and beat me !"
        content.contentDescription = "City Defender News"
        
        FBSDKShareDialog.showFromViewController(vc, withContent: content, delegate: self)
        
        
    }
     //MARK: - Method Post To Pages of FaceBook
    func postToPagesFaceBook(vc:UIViewController!){
        
        
        let sharePhoto = FBSDKSharePhoto()
        sharePhoto.caption = "TestPost"
        sharePhoto.image = UIImage(named: "imageup.png")
        
        let content = FBSDKSharePhotoContent()
        content.photos = [sharePhoto]
        
        FBSDKShareAPI.shareWithContent(content, delegate: self)
        
        
    }
    //MARK: - Method to Get FriendList
    func getFriendList(){
        
        let fbRequest = FBSDKGraphRequest(graphPath:"/me/friends", parameters: nil);
        fbRequest.startWithCompletionHandler { (connection : FBSDKGraphRequestConnection!, result : AnyObject!, error : NSError!) -> Void in
            
            if error == nil {
                
                NSIUtility.DBlog("User FriendList : \(result)")
                
            } else {
                NSIUtility.DBlog("Error Getting Info \(error)");
                
            }
        }
    }
    
    //MARK: - Method to Invite Peoples
    func invitePeoples(vc:UIViewController!){
    
        let content = FBSDKAppInviteContent()
        
        content.appLinkURL = NSURL(string: "https://www.mydomain.com/myapplink")
        //optionally set previewImageURL
        content.appInvitePreviewImageURL = NSURL(string: "https://www.mydomain.com/my_invite_image.jpg")
        // present the dialog. Assumes self implements protocol `FBSDKAppInviteDialogDelegate`
        
        FBSDKAppInviteDialog.showFromViewController(vc, withContent: content, delegate: self)
    
    
    }
    
    
    
    //MARK: - Facebook Invite Delegate Methods

    func appInviteDialog(appInviteDialog: FBSDKAppInviteDialog!, didCompleteWithResults results: [NSObject : AnyObject]!) {
       //NSIUtility.DBlog(results as NSDictionary)
    }
    
    func appInviteDialog(appInviteDialog: FBSDKAppInviteDialog!, didFailWithError error: NSError!) {
        NSIUtility.DBlog(error.description)

    }
    
    
    
    //MARK: - Facebook Share Delegate Methods
    func sharer(sharer: FBSDKSharing!, didCompleteWithResults results: [NSObject : AnyObject]!) {
        
        
        NSIUtility.DBlog(results as NSDictionary)
        
        if results.count > 0{
        
            let alert = UIAlertController(title: "Success",
                message: "Share successfully.",
                preferredStyle: UIAlertControllerStyle.Alert
            )
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
            viewCont.presentViewController(alert, animated: true, completion: nil)
        }
        else{
            let alert = UIAlertController(title: "",
                message: "Share Request Canceled.",
                preferredStyle: UIAlertControllerStyle.Alert
            )
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
            viewCont.presentViewController(alert, animated: true, completion: nil)

        
        
        }
        
       

    }
    func sharer(sharer: FBSDKSharing!, didFailWithError error: NSError!) {
        let alert = UIAlertController(title: "Error",
            message:error.description,
            preferredStyle: UIAlertControllerStyle.Alert
        )
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
        viewCont.presentViewController(alert, animated: true, completion: nil)

    }
    
    func sharerDidCancel(sharer: FBSDKSharing!) {
        
    }
}