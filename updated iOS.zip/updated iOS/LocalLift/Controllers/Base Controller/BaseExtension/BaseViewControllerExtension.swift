//
//  BaseViewControllerExtension.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/10/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import Foundation

extension BaseViewController{
   
    func setUpCustomBarButton() {
        self.navigationItem.setHidesBackButton(true, animated:true);
        setLeftBarButtonItems()
        setRightBarButtonItems()
    }
    
    //MARK:- LeftNav Bar Items
    func setLeftBarButtonItems() {
        let barBtnMenu = UIBarButtonItem(image: UIImage(named: "MenuIcon"), style: .Plain, target: self, action: "leftMenuButtonClick:")
        let imgLogo = UIImageView(frame: CGRect(x:0, y: 0, width: 96, height: 25))
        imgLogo.image = UIImage(named: "logoOfLocalift")
        let barBtnLogo = UIBarButtonItem(customView: imgLogo)
        // Set -7px of fixed space before the two UIBarButtonItems so that they are aligned to the edge
//        let negativeSpace:UIBarButtonItem = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.FixedSpace, target: nil, action: nil)
//        negativeSpace.width = -10.0
        navigationItem.leftItemsSupplementBackButton = true
        navigationItem.setLeftBarButtonItems([barBtnMenu, barBtnLogo], animated: true)
    }
    
    //MARK:- RightNav Bar Items
    func setRightBarButtonItems() {
        
//        UIBarButtonItem *flexibleItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        let barBtnCalender = UIBarButtonItem(image: UIImage(named: "calculatorIcon"), style: .Plain, target: self, action: "calenderButPressed:")
        let barBtnNotes = UIBarButtonItem(image: UIImage(named: "PaperIcon"), style: .Plain, target: self, action: "notesButPressed:")
        
       let imageNotification = UIImage(named: "bellIcon")
        let buttonNotification = UIButton(type: .Custom)
        if let knownImage = imageNotification {
            buttonNotification.frame = CGRectMake(0.0, 0.0, knownImage.size.width, knownImage.size.height)
        } else {
            buttonNotification.frame = CGRectZero;
        }
        buttonNotification.setBackgroundImage(imageNotification, forState: UIControlState.Normal)
        buttonNotification.addTarget(self,
            action: "notificationPressed:",
            forControlEvents: UIControlEvents.TouchUpInside)
        let barBtnNotification = ENMBadgedBarButtonItem(customView: buttonNotification, value: "\(countNotification)")
        BarButtonNotification = barBtnNotification
        navigationItem.setRightBarButtonItems([barBtnNotes, barBtnCalender], animated: true)
//        navigationItem.setRightBarButtonItems([barBtnNotes, barBtnCalender, BarButtonNotification!], animated: true)
      }
    
    func notificationPressed(sender : AnyObject){
        
        NSIUtility .showUnderDevelopmentAlert()
    }
    
    func notesButPressed(sender : AnyObject){
        NSIUtility .showUnderDevelopmentAlert()
    }
    
    
}