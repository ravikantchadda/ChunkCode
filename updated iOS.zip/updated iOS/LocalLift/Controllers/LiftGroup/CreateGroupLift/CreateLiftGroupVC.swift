//
//  CreateLiftGroupVC.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/21/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class SelectedLiftGroupBO: NSObject {
    
    var groupName: String?
    var groupType: String?
    var descrition: String?
}

class CreateLiftGroupVC: BaseViewController,ShowGroupTypeProtocol,UIImagePickerControllerDelegate, UINavigationControllerDelegate,ColectionCellSelectProtocol {

   let liftGroupBO = SelectedLiftGroupBO()
   @IBOutlet weak var viewProfileImageView: ProfilePicView!
   @IBOutlet weak  var viewShowingtextfield: CreateGroupTextVW!
    @IBOutlet weak var btnContinue: UIButton!
    
    // MARK: UIImagePickerController object
    let imagePickerForUserPic = UIImagePickerController()
    
    //MARK:- viewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Create Lift Group"
        self.intilization()
        
    }
    //MARK:- intial function
    func intilization() {
        self.setNavigationBarButton()
        viewShowingtextfield.delegate = self
        viewProfileImageView.delegate = self
        //_______imagepicker delegate
        imagePickerForUserPic.delegate = self
     }
    
    //MARK:- viewWillAppear
    override func viewWillAppear(animated: Bool) {
        self.checkToEnableContinue()
    }
    
    //MARK:- update view when we add group name and group type
    func checkToEnableContinue() {
        liftGroupBO.groupName = viewShowingtextfield.txtFiledGroupName.text!
        liftGroupBO.descrition = viewShowingtextfield.txtViewDescription.text!
        viewShowingtextfield.lblGroupType.text = ((liftGroupBO.groupType?.trim())?.characters.count > 0) ? liftGroupBO.groupType?.trim() : "Group Type *"
        
        if((liftGroupBO.groupName?.trim())?.characters.count > 0 && (liftGroupBO.groupType?.trim())?.characters.count > 0) {
            self.btnContinue.alpha = 1.0
            self.btnContinue.backgroundColor = UIColor.colorWithRGB(226, green: 27, blue: 97, alpha: 1.0)
            self.btnContinue.userInteractionEnabled = true
        }
        else {
            self.btnContinue.alpha = 0.4
            self.btnContinue.backgroundColor = UIColor.colorWithRGB(96, green: 132, blue: 151, alpha: 1.0)
           self.btnContinue.userInteractionEnabled = true // DemoDelete  self.btnContinue.userInteractionEnabled = false
        }
        print(liftGroupBO.groupName)
        print(liftGroupBO.groupType)
        print(liftGroupBO.descrition)
    }
    
    //MARK: - Left and Right side of navigation
    func setNavigationBarButton() {
        let btnLater = UIBarButtonItem(title: "Cancel", style: .Plain, target: self, action: "CancelPressed:")
        navigationItem.setRightBarButtonItem(btnLater, animated: true)
        let btnBack = UIBarButtonItem(title: "Back", style: .Plain, target: nil, action: nil)
        self.navigationItem.backBarButtonItem = btnBack;
    }
    // Cancel button in Right of navigation pressed
    func CancelPressed(sender: UIButton) {
        
    }
    //MARK: -Show group type table
    func showGroupType() {
        let groupType = NSIUtility.fetchViewControllerWithName("GroupTypeVC", storyBoardName: "Main") as! GroupTypeVC
        self.navigationController?.pushViewController(groupType, animated: true)
    }
    
    //MARK:- Delegate function from ShowGroupTypeProtocol is called to load view when textfield value is changes
    func changeGroupTypeNameText() {
        self.checkToEnableContinue()
    }
    
    //MARK:- Create Lift Group
    @IBAction func ContinueAction(sender: AnyObject) {
        var liftGroupVC:MyLiftGroupVC?
        liftGroupVC = self.fetchPreviousControllerFromNavigationStack(1) as? MyLiftGroupVC
        liftGroupVC?.viewGroupItems.arrayViewForLiftGroup.addObject(liftGroupBO)
        
        let groupType = NSIUtility.fetchViewControllerWithName("SelectedLiftGroupVC", storyBoardName: "Main") as! SelectedLiftGroupVC
        self.navigationController?.pushViewController(groupType, animated: true)
    }
    
    // MARK: ActionSheet for image picker
     func select() {
        let optionMenu = UIAlertController(title: nil, message: "Choose", preferredStyle: .ActionSheet)
        //________get Photo From Gallery
        let chooseImageFromGalleryAction = UIAlertAction(title: "Gallery", style: .Default, handler: {
            (alert: UIAlertAction!) -> Void in
            self.shootPhotoFromGallery()
        })
        //________get Photo From Camera
        let chooseImageFromCamera = UIAlertAction(title: "Camera", style: .Default, handler: {
            (alert: UIAlertAction!) -> Void in
            self.shootPhotoFromCamera()
        })
        //________Cancel
        let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: {
            (alert: UIAlertAction!) -> Void in
        })
        //________Add button of actionsheet in controller
        optionMenu.addAction(chooseImageFromGalleryAction)
        optionMenu.addAction(chooseImageFromCamera)
        optionMenu.addAction(cancelAction)
        self.presentViewController(optionMenu, animated: true, completion: nil)
    }

    // MARK: Get photo from camera
    func shootPhotoFromCamera() {
        if UIImagePickerController.availableCaptureModesForCameraDevice(.Rear) != nil {
            self.imagePickerForUserPic.allowsEditing = false
            self.imagePickerForUserPic.sourceType = UIImagePickerControllerSourceType.Camera
            self.imagePickerForUserPic.cameraCaptureMode = .Photo
            self.imagePickerForUserPic.modalPresentationStyle = .FullScreen
            presentViewController(self.imagePickerForUserPic,
                animated: true,
                completion: nil)
        } else {
             NSIUtility.show("Sorry, this device has no camera")
        }
    }
    
    // MARK: Get photo from Gallery
    func shootPhotoFromGallery() {
        self.imagePickerForUserPic.allowsEditing = false
        self.imagePickerForUserPic.sourceType = .PhotoLibrary
        self.presentViewController(self.imagePickerForUserPic, animated: true, completion: nil)
    }
    
    // MARK: imagePickerController delegate
    
    // _____cancel  controller
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    // _____open image  controller
    func imagePickerController(
        picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [String : AnyObject]) {
            let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage
            viewProfileImageView.imgVwProfile.contentMode = .ScaleAspectFit
            viewProfileImageView.imgVwProfile.image = chosenImage
            viewProfileImageView.btnUploadImage.setTitle("Change Photo", forState: UIControlState.Normal)
            
            dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    // MARK: de init method
    deinit {
        viewProfileImageView = nil
        viewShowingtextfield = nil
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
