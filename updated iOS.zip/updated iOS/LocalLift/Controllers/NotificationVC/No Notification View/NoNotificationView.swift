//
//  NoNotificationView.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/9/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class NoNotificationView: UIView {

    @IBOutlet weak var lblTodayDate: UILabel!
}
