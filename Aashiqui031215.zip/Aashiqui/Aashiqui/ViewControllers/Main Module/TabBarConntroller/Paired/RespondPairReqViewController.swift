//
//  RespondPairReqViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 23/10/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class RespondPairReqViewController: UIViewController {
    @IBOutlet weak var tblFriendRequest: UITableView!
    var arrRequestsList: NSMutableArray! = []
    var pageUser = 1
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationItem.titleView = Utility.navBarTitleLabel("Paired")
//        self.navigationItem.hidesBackButton = true
//        self.navigationItem.leftBarButtonItem = Utility.navBarLeftButton(UIImage(named: "btnBack")!, viewController: self)
        
        tblFriendRequest.tableFooterView = UIView(frame: CGRectZero)
        tblFriendRequest.addInfiniteScrollingWithHandler {
            if (Utility.checkNetwork() == true){
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), { () ->  Void in
                self.pageUser += 1
                let dict:NSDictionary = [
                    "userId": NSIConstants.userDefaults.valueForKey("userId") as! String,
                    "page": "\(self.pageUser)"
                ]
                print("\(dict)")
                self.fnGetRequestsWebServiceWithPostDic(dict, showLoader: false)
            })
        }
        }
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        if (Utility.checkNetwork() == true){
            arrRequestsList.removeAllObjects()
            if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                let dict:NSDictionary = [
                    "userId": userId,
                    "page": "1"
                ]
                print("\(dict)")
                fnGetRequestsWebServiceWithPostDic(dict, showLoader: true)
            }
        }
    }
    
    // MARK: - NavigationBar LeftBarButton Method
    func fnLeftBarButton(){
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    @IBAction func btnPressed_Accept(sender: AnyObject) {
        self.fnRespondFriendRequest("1", friendId: self.fnGetFriendshipId(sender as! UIButton))
    }
    @IBAction func btnPressed_Decline(sender: AnyObject) {
        self.fnRespondFriendRequest("2", friendId: self.fnGetFriendshipId(sender as! UIButton))
    }
    func fnGetFriendshipId(btn: UIButton) -> String{
        let pointInTable: CGPoint = btn.convertPoint(btn.bounds.origin, toView: tblFriendRequest)
        let cellIndexPath: NSIndexPath = tblFriendRequest.indexPathForRowAtPoint(pointInTable)!
        let objUserCell:UserDetails = arrRequestsList.objectAtIndex(cellIndexPath.row) as! UserDetails
        return objUserCell.friendshipId
    }
    func fnRespondFriendRequest(type: String, friendId: String){
//        { 	"userId": "2741", "friendshipId":"2070","status":"1" }
        if let userId = NSIConstants.userDefaults.valueForKey("userId") {
            let dict:NSDictionary = [
                "userId": userId,
                "friendshipId": friendId,
                "status": type
            ]
            print("\(dict)")
            fnUpdateRequestWebServiceWithPostDic(dict, showLoader: true)
        }
    }
    
    // MARK: - Webservice Call Methods
    //GetFriends API
    func fnGetRequestsWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        //        ObjWebserviceCall.cachePolicy = WebserviceCallCachePolicyRequestFromCacheFirstAndThenFromUrlAndUpdateInCache
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceFriendRequests)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("getFriends--- \(response.webserviceResponse)")
                if (response.webserviceResponse != nil) {
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    //UserDetails Model
                    let arrData = response.webserviceResponse.valueForKey("list") as! NSArray
                    let arrModelData = UserDetails().fillDataInRequestModel(arrData)
                    arrModelData.enumerateObjectsUsingBlock({ object, index, stop in
                        self.arrRequestsList.addObject(arrModelData.objectAtIndex(index))
                    })
                    print("arrUserData-- \(self.arrRequestsList)")
                
                }else{
                    if response.webserviceResponse.valueForKey("status") as! String != "No more data" && response.webserviceResponse.valueForKey("status") as! String != "Result not found" {
                        Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                    }
                    if self.arrRequestsList.count == 0 {
                        let lblMsg = UILabel(frame: CGRectMake(0, 0, self.tblFriendRequest.frame.size.width, 50))
                        lblMsg.center = self.tblFriendRequest.center
                        lblMsg.text = "You don't have any pairing request."
                        lblMsg.numberOfLines = 0
                        lblMsg.textAlignment = NSTextAlignment.Center
                        lblMsg.font = UIFont(name: "Lato-Regular", size: 16)
                        lblMsg.textColor = UIColor.blackColor()
                        self.tblFriendRequest.backgroundView = lblMsg
                        self.tblFriendRequest.scrollEnabled = false
                        
                    }else{
                        self.tblFriendRequest.backgroundView = nil
                        self.tblFriendRequest.scrollEnabled = true
                    }
                }
                }
                self.tblFriendRequest.reloadData()
                self.tblFriendRequest.infiniteScrollingView?.stopAnimating()
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
    }
    
    //Update Friend Request API
    func fnUpdateRequestWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceupdateFriendRequest)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("getFriends--- \(response.webserviceResponse)")
                if (response.webserviceResponse != nil) {
                self.arrRequestsList.removeAllObjects()
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    self.arrRequestsList.removeAllObjects()
                    if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                        let dict:NSDictionary = [
                            "userId": userId,
                            "page": "1"
                        ]
                        print("\(dict)")
                        self.fnGetRequestsWebServiceWithPostDic(dict, showLoader: true)
                    }
                }else{
                    if response.webserviceResponse.valueForKey("status") as! String != "Result not found" {
                        Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                    }
                    
                }
                }
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
    
    
    //MARK - TableView DataSource/Delegate
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrRequestsList.count
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if(tableView.respondsToSelector(Selector("setSeparatorInset:"))){
            tableView.separatorInset = UIEdgeInsetsZero
        }
        if(tableView.respondsToSelector(Selector("setLayoutMargins:"))){
            
                tableView.layoutMargins = UIEdgeInsetsZero
            
//            if #available(iOS 8.0, *) {
//                tableView.layoutMargins = UIEdgeInsetsZero
//            } else {
//                // Fallback on earlier versions
//                tableView.separatorInset = UIEdgeInsetsZero
//            }
        }
        if(cell.respondsToSelector(Selector("setLayoutMargins:"))){

                cell.layoutMargins = UIEdgeInsetsZero

//            if #available(iOS 8.0, *) {
//                cell.layoutMargins = UIEdgeInsetsZero
//            } else {
//                // Fallback on earlier versions
//                cell.separatorInset = UIEdgeInsetsZero
//            }
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath)
        
        let objUserCell:UserDetails = arrRequestsList.objectAtIndex(indexPath.row) as! UserDetails
        //UIImage Profile Image
        if let imgVwProfile:AsyncImageView = cell.viewWithTag(1001) as? AsyncImageView {
            imgVwProfile.image = UIImage(named: "placeholder")
            if let variableName: String = objUserCell.profilePic{
                imgVwProfile.imageURL = NSURL(string: variableName)
            }
        }
        if let lblName = cell.viewWithTag(1002) as? UILabel {
            lblName.text = objUserCell.firstName + " " + objUserCell.lastName + " has sent you pairing request"
        }
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let objUserCell:UserDetails = arrRequestsList.objectAtIndex(indexPath.row) as! UserDetails
        let objProfileVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("ProfileViewController") as! ProfileViewController
        objProfileVC.userID = objUserCell.userId
        self.navigationController!.pushViewController(objProfileVC, animated: false)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
