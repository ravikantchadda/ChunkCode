//
//  SettingsViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 18/09/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {
    var dictTableData:NSDictionary!
    @IBOutlet weak var tblItems: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationItem.title = ""
        self.navigationItem.titleView = Utility.navBarTitleLabel("Settings")
        self.navigationController?.navigationBar.translucent = false
        tblItems.tableFooterView = UIView(frame: CGRectZero)
        if NSIConstants.userDefaults.valueForKey("userType") as! String == "0" {
            let arrImages = ["profile","updateProfile","changeUsername","changePassword","notification","terms","chatHistory","logout"]
            let arrName = ["Profile","Update Profile","Change Username","Change Password","Notification","Terms & Policies","Chat History","Logout"]
            dictTableData = ["image": arrImages, "name": arrName]
        }else{
            let arrImages = ["profile","updateProfile","notification","terms","chatHistory","logout"]
            let arrName = ["Profile","Update Profile","Notification","Terms & Policies","Chat History","Logout"]
            dictTableData = ["image": arrImages, "name": arrName]
        }
        
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.navigationBarHidden = false
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - TableView DataSource/Delegate
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if NSIConstants.userDefaults.valueForKey("userType") as! String == "0" {
            return 8
        }else{
            return 6
        }
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if(tableView.respondsToSelector(Selector("setSeparatorInset:"))){
            tableView.separatorInset = UIEdgeInsetsZero
        }
        if(tableView.respondsToSelector(Selector("setLayoutMargins:"))){
        
            tableView.layoutMargins = UIEdgeInsetsZero
           
        }
        if(cell.respondsToSelector(Selector("setLayoutMargins:"))){
            
            cell.layoutMargins = UIEdgeInsetsZero
           
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(
            "cellSettings", forIndexPath: indexPath)
            
        
        if let imgVwLogo = cell.viewWithTag(1001) as? UIImageView {
            let imgName: String = dictTableData.valueForKey("image")?.objectAtIndex(indexPath.row) as! String
            imgVwLogo.image = UIImage(named:"\(imgName)")
        }
        if let lblName = cell.viewWithTag(1002) as? UILabel {
            let name: String = dictTableData.valueForKey("name")?.objectAtIndex(indexPath.row) as! String
            lblName.text = name
        }
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if NSIConstants.userDefaults.valueForKey("userType") as! String == "0" {
        switch (indexPath.row){
        case 0:
            let objProfileVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("ProfileViewController") as! ProfileViewController
            self.navigationController!.pushViewController(objProfileVC, animated: true)
            break

        case 1:
            let objUpdateProfileVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("UpdateProfileViewController") as! UpdateProfileViewController
            self.navigationController!.pushViewController(objUpdateProfileVC, animated: true)
            break
            
        case 2:
            let objChangeUsernameVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("ChangeUsernameViewController") as! ChangeUsernameViewController
            self.navigationController!.pushViewController(objChangeUsernameVC, animated: true)
            break
            
        case 3:
            let objChangePasswordVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("ChangePasswordViewController") as! ChangePasswordViewController
            self.navigationController!.pushViewController(objChangePasswordVC, animated: true)
            break
            
        case 4:
            let objNotificationSettingVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("NotificationSettingViewController") as! NotificationSettingViewController
            self.navigationController!.pushViewController(objNotificationSettingVC, animated: true)
            break
            
        case 5:
            let objTermsVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("TermsViewController") as! TermsViewController
            self.navigationController!.pushViewController(objTermsVC, animated: true)
            break
            
        case 6:
            let objChatHistoryVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("ChatHistoryViewController") as! ChatHistoryViewController
            self.navigationController!.pushViewController(objChatHistoryVC, animated: true)
            break
            
        case 7:
            if (Utility.checkNetwork() == true){
                if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                    let dict:NSDictionary = [
                        "userId": userId
                    ]
                    print("\(dict)")
                    self.fnLogoutWebServiceWithPostDic(dict, showLoader: true)
                }
            }
            break
    
        default:
            break
            
        }
        }else{
            switch (indexPath.row){
            case 0:
                let objProfileVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("ProfileViewController") as! ProfileViewController
                self.navigationController!.pushViewController(objProfileVC, animated: true)
                break
                
            case 1:
                let objUpdateProfileVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("UpdateProfileViewController") as! UpdateProfileViewController
                self.navigationController!.pushViewController(objUpdateProfileVC, animated: true)
                break
                
            case 2:
                let objNotificationSettingVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("NotificationSettingViewController") as! NotificationSettingViewController
                self.navigationController!.pushViewController(objNotificationSettingVC, animated: true)
                break
                
            case 3:
                let objTermsVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("TermsViewController") as! TermsViewController
                self.navigationController!.pushViewController(objTermsVC, animated: true)
                break
                
            case 4:
                let objChatHistoryVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("ChatHistoryViewController") as! ChatHistoryViewController
                self.navigationController!.pushViewController(objChatHistoryVC, animated: true)
                break
                
            case 5:
                if (Utility.checkNetwork() == true){
                    if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                        let dict:NSDictionary = [
                            "userId": userId
                        ]
                        print("\(dict)")
                        self.fnLogoutWebServiceWithPostDic(dict, showLoader: true)
                    }
                }
                break
                
            default:
                break
                
            }
        }
    }
    
    // MARK: - Webservice Call Methods
    //Logout API
    func fnLogoutWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        //        ObjWebserviceCall.cachePolicy = WebserviceCallCachePolicyRequestFromCacheFirstAndThenFromUrlAndUpdateInCache
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            var DToken = NSIConstants.userDefaults.valueForKey("DEVICETOKEN")
            if  (DToken != nil) {
                DToken = NSIConstants.userDefaults.valueForKey("DEVICETOKEN")
            }else{
                DToken = "wefbversbtvsbtvs78rtbhyrt78bgvy4578yh45g45"
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken, "DEVICETOKEN":DToken as! String]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceLogout)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("logout--- \(response.webserviceResponse)")
                
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    
                    NSIConstants.userDefaults.removeObjectForKey("AUTHTOKEN")
                    NSIConstants.userDefaults.removeObjectForKey("userId")
                    NSIConstants.userDefaults.synchronize()
                    NSIConstants.appDelegate.fnLoginViewController()
                }else{
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
