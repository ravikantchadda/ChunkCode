//
//  TaggedFriendListView.swift
//  Aashiqui
//
//  Created by ketan saini on 05/11/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

protocol TaggedFriendsViewDelegate
{
    func taggedFriendTapped(userId:String)
    
}

class TaggedFriendListView: UIView {
    @IBOutlet weak var tblFriends: UITableView!
    @IBOutlet weak var vwContainer: UIView!
    @IBOutlet weak var tempView: UIView!
    var delegate: TaggedFriendsViewDelegate!
    
    var arrTaggedFriends:NSArray = []
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */
    override init(frame: CGRect) { // for using CustomView in code
        super.init(frame: frame)
        self.commonInit()
    }
    required init(coder aDecoder: NSCoder) { // for using CustomView in IB
        super.init(coder: aDecoder)!
        self.commonInit()
    }
    private func commonInit() {
        NSBundle.mainBundle().loadNibNamed("TaggedFriendListView", owner: self, options: nil)
        self.addSubview(tempView)
        tempView.frame = CGRectMake(0, 0, NSIConstants.ScreenSize.SCREEN_WIDTH, NSIConstants.ScreenSize.SCREEN_HEIGHT)
        if NSIConstants.DeviceType.IS_IPHONE_4_OR_LESS {
            vwContainer.frame = CGRectMake(0, 0, 280,300)
        }else if NSIConstants.DeviceType.IS_IPHONE_5 {
            vwContainer.frame = CGRectMake(0, 0, 280,428)
        }else {
            vwContainer.frame = CGRectMake(0, 0, 320,428)
        }
        vwContainer.center = CGPointMake(NSIConstants.ScreenSize.SCREEN_WIDTH/2, NSIConstants.ScreenSize.SCREEN_HEIGHT/2 - 64)
        
        tblFriends.tableFooterView = UIView(frame: CGRectZero)
        tblFriends.reloadData()
    }

    @IBAction func btnPressed_Close(sender: AnyObject) {
        self.removeFromSuperview()
    }
    
    func setUpTaggedFriendView(dict: NSDictionary) {
        print("tagList\(dict)")
        arrTaggedFriends = dict.valueForKey("tagList") as! NSArray
        tblFriends.reloadData()
    }
    
    //MARK - TableView DataSource/Delegate
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrTaggedFriends.count
    }
    
    func tableView(tableView: UITableView!, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if(tableView.respondsToSelector(Selector("setSeparatorInset:"))){
            tableView.separatorInset = UIEdgeInsetsZero
        }
        if(tableView.respondsToSelector(Selector("setLayoutMargins:"))){
            
            tableView.layoutMargins = UIEdgeInsetsZero
            
        }
        if(cell.respondsToSelector(Selector("setLayoutMargins:"))){
            
            cell.layoutMargins = UIEdgeInsetsZero
            
        }
    }

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
      
        var cell = tableView.dequeueReusableCellWithIdentifier("\(indexPath.row)") as UITableViewCell!
        let objTagged: TagFriendList = arrTaggedFriends.objectAtIndex(indexPath.row) as! TagFriendList
        if (cell == nil) {
            cell = UITableViewCell(style: UITableViewCellStyle.Value1, reuseIdentifier: "\(indexPath.row)")
            cell.selectionStyle = UITableViewCellSelectionStyle.None
    
            let lblStatus: UILabel = UILabel(frame: CGRectMake(55, 15, cell.frame.size.width - 65, 30))
            let imgVwProfile: AsyncImageView = AsyncImageView(frame: CGRectMake(10, 5, 40, 40))
            
            imgVwProfile.layer.cornerRadius = 20.0;
            imgVwProfile.clipsToBounds = true
            imgVwProfile.image = UIImage(named: "placeholder")
            if let variableName: String = objTagged.profilePic {
                imgVwProfile.imageURL = NSURL(string: variableName)
            }
            cell.addSubview(imgVwProfile)
            
            lblStatus.textAlignment = NSTextAlignment.Left
            lblStatus.text = objTagged.nickName
            lblStatus.numberOfLines = 1
            lblStatus.font = UIFont(name: "Lato-Regular", size: 14)
            lblStatus.lineBreakMode = NSLineBreakMode.ByWordWrapping
            lblStatus.sizeToFit()
            cell.addSubview(lblStatus)
        }
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let objTagged: TagFriendList = arrTaggedFriends.objectAtIndex(indexPath.row) as! TagFriendList
        delegate.taggedFriendTapped(objTagged.userId)
    }
}
