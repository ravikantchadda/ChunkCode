//
//  Constants.swift
//  ReferenceApp
//
//  Created by Aditya Aggarwal on 8/27/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit

struct Constants {
    //Color Constants
    static let APP_THEME_COLOR:UIColor = UIColor(red: 89.0/255.0, green: 199.0/255.0, blue: 198.0/255.0, alpha: 1.0)
    
    
    //Header for Outh Constants
    static let kOuthHeader = "client_id=bgZJ90Q1CWdhHiIQi75ky9JUNmiWSbaABVmrS&client_secret=0Mv6IE6SDyvd6N1JC0QXU3pUGbpPqQx6pj2Vxbo60yUBhmAsVEAm8WzQGRd1DEFt525ldqbksTx3kcplpxdNoQI4o0xYDTY8mxLjRS6B&grant_type=client_credentials"
    //TestHeader
   // static let kOuthHeader = "client_id=E9QyfM02pHNESNyWA28a9X7nr6ihZa123j&client_secret=pXbjPMaPYRXmI1tneklPO8FFqiOFt3pCunlfrd1cdAeZQdUt5trD2fHrxWQgJsFEoC0Vy8OXmnTqrYPfYq9V6PtoaFu8efToFbXhvc3VXHIaIxbGltfN&grant_type=client_credentials"
    
    

    
    //KeyParamets Constants
    static let keyAccessToken = "access_token"
    static let keyTokenType = "token_type"
    static let keyOuthToken = "outhtoken"
    static let keyStatusCode = "status_code"
    static let keyResponse = "response"
    static let keyDefinedTokenType = "Bearer"
    
    //MARK:- StoryBoard Constants
    static let ObjLoginModuleStoryboard: UIStoryboard = UIStoryboard(name: "LoginModule", bundle: nil)
    
    
    //MARK:- Social Network APP IDs
    static let APP_LINKEDIN_CLIENTID = "758gvsqekbuvi4"
    static let APP_LINKEDIN_CLIENTSECRET = "BQN3gaEk7o22RcbA"
    static let APP_GOOGLE_CLIENTID = "616225185552-296migtdil9gp1vjcr2s9fjchu53smhj.apps.googleusercontent.com"
    
    
    //MARK:- UI Alerts Constants
    
    static let kAlertTitle: String = "Error!"
    static let kEnterEmailAddress: String = "Please enter email address."
    static let kEnterPassword: String = "Please enter password."
    static let kEnterRepeatPassword: String = "Please enter repeat password."
    static let kEnterValidEmailAddress: String = "Please enter a valid email address."
    static let kEnterUserName: String = "Please enter username."
    static let kEnterFirstName: String = "Please enter first name."
    static let kEnterLastName: String = "Please enter last name."
    static let kEnterPassowrdRepeatPassowrdMatch: String = "Your password & repeat password do not match."
    static let kAlertEmailExist: String = "Email  already exists."
     static let kAlertServerError: String = "Server not responding."
    
    //MARK:- Device Type Constants
    enum UIUserInterfaceIdiom : Int
    {
        case Unspecified
        case Phone
        case Pad
    }
    
    struct ScreenSize
    {
        static let SCREEN_WIDTH         = UIScreen.mainScreen().bounds.size.width
        static let SCREEN_HEIGHT        = UIScreen.mainScreen().bounds.size.height
        static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
        static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    }
    
    struct DeviceType
    {
        static let IS_IPHONE_4_OR_LESS  = UIDevice.currentDevice().userInterfaceIdiom == .Phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
        static let IS_IPHONE_5          = UIDevice.currentDevice().userInterfaceIdiom == .Phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
        static let IS_IPHONE_6          = UIDevice.currentDevice().userInterfaceIdiom == .Phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
        static let IS_IPHONE_6P         = UIDevice.currentDevice().userInterfaceIdiom == .Phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
        static let IS_IPAD              = UIDevice.currentDevice().userInterfaceIdiom == .Pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
    }
    
    //MARK:- iOS Versions Constants
    struct Version{
        static let SYS_VERSION_FLOAT = (UIDevice.currentDevice().systemVersion as NSString).floatValue
        static let iOS7 = (Version.SYS_VERSION_FLOAT < 8.0 && Version.SYS_VERSION_FLOAT >= 7.0)
        static let iOS8 = (Version.SYS_VERSION_FLOAT >= 8.0 && Version.SYS_VERSION_FLOAT < 9.0)
        static let iOS9 = (Version.SYS_VERSION_FLOAT >= 9.0 && Version.SYS_VERSION_FLOAT < 10.0)
    }
    

    
    
    
    
    
}