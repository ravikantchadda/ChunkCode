//
//  ChangePasswordViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 13/11/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class ChangePasswordViewController: UIViewController {
    @IBOutlet weak var txtCurrentPassword: UITextField!
    @IBOutlet weak var txtNewPassword: UITextField!
    @IBOutlet weak var txtConfirmPassword: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationItem.titleView = Utility.navBarTitleLabel("Change Password")
//        self.navigationItem.hidesBackButton = true
//        self.navigationItem.leftBarButtonItem = Utility.navBarLeftButton(UIImage(named: "btnBack")!, viewController: self)
    }
    // MARK: - NavigationBar LeftBarButton Method
    func fnLeftBarButton(){
        self.navigationController?.popViewControllerAnimated(true)
    }
    @IBAction func btnPressed_Submit(sender: AnyObject) {
        if (Utility.checkNetwork() == true){
            let strError = fnCheckValidation()
            if strError == ""{
                if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                    let dict:NSDictionary = [
                        "userId": userId,
                        "currentPassword": txtCurrentPassword.text!,
                        "password": txtNewPassword.text!
                    ]
                    print("\(dict)")
                    fnSaveSettingsWebServiceWithPostDic(dict)
                }
            }else{
                Utility.showAlert("", message: strError as String, delegate: nil)
            }
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Webservice Call Methods
    // SaveSettings API
    func fnSaveSettingsWebServiceWithPostDic(dict: NSDictionary!) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            ObjWebserviceCall.isShowLoader = true
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceChangePassword)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("ChangePassword--- \(response.webserviceResponse)")
                
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    
                    let alert = UIAlertController(title: "", message: response.webserviceResponse.valueForKey("status") as? String, preferredStyle: .Alert)
                    let action = UIAlertAction(title: "OK", style: .Default) { _ in
                        self.navigationController?.popViewControllerAnimated(true)
                    }
                    alert.addAction(action)
                    self.presentViewController(alert, animated: true, completion: nil)
                    
                    
                }else{
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
    func alertView(View: UIAlertView, clickedButtonAtIndex buttonIndex: Int){
        
        if (buttonIndex == 0){
            self.navigationController?.popViewControllerAnimated(true)
        }
    }
    
    // MARK: - Validations check
    func fnCheckValidation() -> NSString{
        var strError = String()
        
        if !Utility.checkIfStringContainsText(txtCurrentPassword.text){
            strError = "Please enter current password."
        }else if !Utility.checkIfStringContainsText(txtNewPassword.text){
            strError = "Please enter new password."
        }else if !Utility.checkIfStringContainsText(txtConfirmPassword.text){
            strError = "Please enter confirm password."
        }else if txtNewPassword.text != txtConfirmPassword.text{
            strError = "New password and confirm password does not match."
        }
        
        return strError
    }
    
    // MARK: - UITextField Delegate Method
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        let nextTag:NSInteger = textField.tag + 1
        // Try to find next responder
        let nextResponder = textField.superview?.viewWithTag(nextTag)
        if (nextResponder != nil){
            nextResponder!.becomeFirstResponder()
        }else{
            textField.resignFirstResponder()
        }
        return true
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
