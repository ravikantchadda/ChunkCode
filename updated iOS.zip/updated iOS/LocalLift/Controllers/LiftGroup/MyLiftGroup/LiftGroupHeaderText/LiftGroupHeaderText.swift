//
//  LiftGroupHeaderText.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/21/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class LiftGroupHeaderText: UIView {
    
    @IBOutlet weak var lblHeaderText: UILabel!
    
    // MARK:-  Our custom view from the XIB file
    var view: UIView!
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadViewFromNib ()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        loadViewFromNib ()
    }
    func loadViewFromNib() {
        let bundle = NSBundle(forClass: self.dynamicType)
        let nib = UINib(nibName: "LiftGroupHeaderText", bundle: bundle)
        let view = nib.instantiateWithOwner(self, options: nil)[0] as! UIView
        view.frame = bounds
        view.autoresizingMask = [.FlexibleWidth, .FlexibleHeight]
        self.addSubview(view);
    }
}
