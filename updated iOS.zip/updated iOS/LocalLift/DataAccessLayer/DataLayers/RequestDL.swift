//
//  RequestDL.swift
//  LocalLift
//
//  Created by prabhjot singh on 12/1/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit
import CoreLocation


//class RecurringLiftRequestsBO: NSObject {
//    var requestReccuringID:NSNumber!
//    var requestDatetime:NSDate!
//}

class RecurringLiftRequestsBO: NSObject {
    
    var requestReccuringID:NSNumber!
    var liftTime: String!
    var liftDate: NSDate!
    var dateString: String!
    var isLiftSelected: Bool!{
        didSet{
            self.isLiftSelectedNumber = NSNumber(bool: isLiftSelected)
        }
    }
    var isLiftSelectedNumber:NSNumber!
    //MARK: Convert date into string
    
}

class RequestBO:NSObject{
    
    var requestId:NSNumber!
    var requesterId:NSNumber!
    var extraPassengers:NSNumber!
    var requestDatetime:String!
    var requestDatetimeDATE:NSDate!
    var startLocationId:NSNumber!
    var endLocationId:NSNumber!
    var requestPassengers:NSArray!
    var requestedUsers:NSArray!
    var newStartLocation:AddressBO!
    var newEndLocation:AddressBO!
    var liftFrequencyTypeId:NSNumber!
    var requestEndDate:String!
    var requestEndDateDATE:NSDate!
    var isRecurring:Bool!
    var message:String!
    
    var isImmidiate:Bool!
    
    var requesterName:String!
    var requestName:String!
    
    var arratLiftPassengers:NSMutableArray?
    var arrayRecurringLiftRequests:NSMutableArray?
    
    
}


class RequestDL: PSRestAPIHelper {

    func requestForCreateRequestLift(requestBO:RequestBO,  handler:CompletionHandler)
    {
        self.serviceURL = "CreateliftRequest"
        self.webservice.isShowLoader = true
        self.setContentTypeHeaders()
        
        var dicParamMutable:NSMutableDictionary!

        var dicOfStartAddress = NSDictionary()
        if requestBO.startLocationId == 0{
            dicOfStartAddress = ["AddressName":requestBO.newStartLocation.addressName,"City":requestBO.newStartLocation.city,"Country":requestBO.newStartLocation.country,"State":requestBO.newStartLocation.state,"StreetAddress":requestBO.newStartLocation.streetAddress,"Unit":"","ZipCode":requestBO.newStartLocation.zipCode,"Latitude":requestBO.newStartLocation.locationCords.latitude,"Longitude":requestBO.newStartLocation.locationCords.longitude,"IsPrimary":false,"IsNew":true,"AddressID":0]
        }
        
        var dicOfEndAddress = NSDictionary()
        if requestBO.endLocationId == 0{
            dicOfEndAddress = ["AddressName":requestBO.newEndLocation.addressName,"City":requestBO.newEndLocation.city,"Country":requestBO.newEndLocation.country,"State":requestBO.newEndLocation.state,"StreetAddress":requestBO.newEndLocation.streetAddress,"Unit":"","ZipCode":requestBO.newEndLocation.zipCode,"Latitude":requestBO.newEndLocation.locationCords.latitude,"Longitude":requestBO.newEndLocation.locationCords.longitude,"IsPrimary":false,"IsNew":true,"AddressID":0]
        }
        
//        RequestDatetime
//        RequestEndDate 12/24/2015 09:15:20 AM
        dicParamMutable = ["RequesterId":requestBO.requesterId,"ExtraPassengers":requestBO.extraPassengers,"LiftStartDate":requestBO.requestDatetimeDATE.toString(format: .Custom(Constants.DateTimeSlashFormat)),"IsRecurring":requestBO.isRecurring,"StartLocationId":requestBO.startLocationId,"EndLocationId":requestBO.endLocationId,"RequestPassengers":requestBO.requestPassengers,"RequestedUsers":requestBO.requestedUsers,"Message":requestBO.message]
        
        dicParamMutable.setObject((requestBO.newStartLocation == nil  ? NSNull():dicOfStartAddress), forKey: "NewStartLocation")
        dicParamMutable.setObject((requestBO.newEndLocation == nil  ? NSNull():dicOfEndAddress), forKey: "NewEndLocation")
        
        if requestBO.isRecurring == true  {
                dicParamMutable.setValue(requestBO.liftFrequencyTypeId, forKey: "LiftFrequencyTypeId")
                dicParamMutable.setValue(requestBO.requestEndDateDATE.toString(format: .Custom(Constants.DateTimeSlashFormat)), forKey: "LiftEndDate")
        }else{
            if requestBO.isImmidiate == true{
                dicParamMutable.setValue(requestBO.isImmidiate, forKey: "IsImmediate")
            }
        }

        let  dicParam:NSDictionary = dicParamMutable as NSDictionary
        
        NSIUtility.showJsonData(dicParam)
        
        self.requestforPOST(dicParam as! [NSObject : AnyObject!]) { (obj, success) -> Void in
            if success == true{
                if let dicResponse:NSDictionary = obj as? NSDictionary{
                    handler(obj: dicResponse, success: true)
                }
            }
            else{
                handler(obj: obj, success: false)
            }
        }
        
    }
    
    
    func requestForGetRequestLift(requestID:NSNumber!,lastIndex:NSNumber,hasMaxCount:Bool, handler:CompletionHandler)
    {
        
    // DUmmy DATA
//        let addressFrom:AddressBO = AddressBO()
//        let addressTo:AddressBO = AddressBO()
//        let requestBO = RequestBO()
//        addressFrom.addressName = "Friends Colony,Patiala"
//        addressFrom.locationCords = CLLocationCoordinate2D(latitude: 30.339377, longitude: 76.386564)
//        
//        addressTo.addressName = "Sector 18D, Chandigarh"
//        addressTo.locationCords = CLLocationCoordinate2D(latitude: 30.733404, longitude: 76.781213)
//        
//        requestBO.isRecurring = true
//        requestBO.requesterName = "Amy Smith"
//        requestBO.message = "Hello Lorem Parem Demo Testing message Demo Testing message Demo Testing message Demo Testing message Demo Testing message Demo Testing message Demo Testing message Demo Testing message Demo Testing message Demo Testing message Demo Testing message Demo Testing message Demo Testing message Demo Testing message Demo Testing message Demo Testing message Demo Testing message Demo Testing message Demo Testing message"
//        requestBO.newStartLocation = addressFrom
//        requestBO.newEndLocation = addressTo
//        
//        let arrayOfPassengers = NSMutableArray()
//        let arrayOfLinkedPassenger = ["Sonakshi Aggarwal", "Nitin Obroy", "Riya Malhotra", "Jameson Quave", "James", "Minakshi", "Andrew Arora","ZIBar"];
//        for strObj in arrayOfLinkedPassenger{
//            let psengerOBJ = PassengerBO()
//            psengerOBJ.emailAddress = strObj + ".com"
//            psengerOBJ.firstName = strObj
//            arrayOfPassengers.addObject(psengerOBJ)
//        }
//        requestBO.arratLiftPassengers = arrayOfPassengers
//        
//        handler(obj: requestBO, success: true)
//        return
        
    // DUmmy DATA
        
        self.serviceURL = "GetLiftRequest"
        self.webservice.isShowLoader = true
        self.setContentTypeHeaders()
        
        var nor = Int(lastIndex) + 4
        
        if hasMaxCount == true{
            nor = 10000
        }
        let dicParam:NSDictionary = ["lrid":requestID,"si":lastIndex,"nor":nor]
        
        NSIUtility.showJsonData(dicParam)
        
        self.requestforGET(dicParam as! [NSObject : AnyObject!]) { (obj, success) -> Void in
            if success == true{
                if let dicResponse:NSDictionary = obj as? NSDictionary{
                    if let arrayOfData = NSIUtility.getObjectForKey("Data", dictResponse: dicResponse) as? NSArray{
                        if let dicRequest = arrayOfData[0] as? NSDictionary{
                            
                            let requestBO = RequestBO()
                            if let arrayOfDic = NSIUtility.getObjectForKey("LiftPassengers", dictResponse:dicRequest) as? NSMutableArray
                            {
                                let arryOfPassengers = NSMutableArray()
                                for dicOfArray in arrayOfDic
                                {
                                    if let dicOfPassenger =  dicOfArray as? NSDictionary{
                                        let pasengerBO = PassengerBO()
                                        pasengerBO.age = NSIUtility.getObjectForKey("Age", dictResponse:dicOfPassenger) as! NSNumber
                                        pasengerBO.countryCodeID = NSIUtility.getObjectForKey("CountryCodeID", dictResponse:dicOfPassenger) as! NSNumber
                                        pasengerBO.emailAddress = NSIUtility.getObjectForKey("EmailAddress", dictResponse:dicOfPassenger) as! String
                                        pasengerBO.firstName = NSIUtility.getObjectForKey("FirstName", dictResponse:dicOfPassenger) as! String
                                        pasengerBO.gender = NSIUtility.getObjectForKey("Gender", dictResponse:dicOfPassenger) as! NSNumber
                                        pasengerBO.imagePath = NSIUtility.getObjectForKey("ImagePath", dictResponse:dicOfPassenger) as! String
                                        pasengerBO.lastName = NSIUtility.getObjectForKey("LastName", dictResponse:dicOfPassenger) as! String
                                        pasengerBO.mobileNumber = NSIUtility.getObjectForKey("MobileNumber", dictResponse:dicOfPassenger) as! String
                                        pasengerBO.passengerId = NSIUtility.getObjectForKey("PassengerId", dictResponse:dicOfPassenger) as! NSNumber
                                        pasengerBO.photo = NSIUtility.getObjectForKey("Photo", dictResponse:dicOfPassenger) as! String
                                        pasengerBO.requestID = NSIUtility.getObjectForKey("RequestID", dictResponse:dicOfPassenger) as! NSNumber
                                        pasengerBO.userID = NSIUtility.getObjectForKey("UserID", dictResponse:dicOfPassenger) as! NSNumber
                                        
                                        arryOfPassengers.addObject(pasengerBO)
                                    }
                                }
                                
                                requestBO.arratLiftPassengers = arryOfPassengers
                            }
                            
                            requestBO.endLocationId = NSIUtility.getObjectForKey("EndLocationId", dictResponse:dicRequest) as! NSNumber
                            requestBO.startLocationId = NSIUtility.getObjectForKey("StartLocationId", dictResponse:dicRequest) as! NSNumber
                            
                            requestBO.requesterId = NSIUtility.getObjectForKey("RequesterId", dictResponse:dicRequest) as! NSNumber
                            
                            requestBO.extraPassengers = NSIUtility.getObjectForKey("ExtraPassengers", dictResponse:dicRequest) as! NSNumber
                            
                        // Address From
                            let addressfromBO = AddressBO()
                            addressfromBO.streetAddress = NSIUtility.getObjectForKey("FromAddress", dictResponse:dicRequest) as! String
                            addressfromBO.addSafelyAddtoLocation(dicRequest, keyOfLatitude: "FromAddressLaititude", keyOfLongitude: "FromAddressLongitude")
                            requestBO.newStartLocation = addressfromBO
                        // Address TO
                            let addressToBO = AddressBO()
                            addressToBO.streetAddress = NSIUtility.getObjectForKey("ToAddress", dictResponse:dicRequest) as! String
                            addressToBO.addSafelyAddtoLocation(dicRequest, keyOfLatitude: "ToAddressLaititude", keyOfLongitude: "ToAddressLongitude")
                            requestBO.newEndLocation = addressToBO

                            requestBO.requestId = NSIUtility.getObjectForKey("Id", dictResponse:dicRequest) as! NSNumber
                            requestBO.isRecurring = NSIUtility.getObjectForKey("IsRecurring", dictResponse:dicRequest) as! Bool
                            requestBO.liftFrequencyTypeId = NSIUtility.getObjectForKey("LiftFrequencyTypeId", dictResponse:dicRequest) as! NSNumber
                        
                            requestBO.message = NSIUtility.getObjectForKey("Message", dictResponse:dicRequest) as! String
                            
                            let strRequestDateTime = NSIUtility.getObjectForKey("RequestDatetime", dictResponse:dicRequest) as! String
                            requestBO.requestDatetimeDATE = NSDate(fromString: strRequestDateTime, format: .DotNet)
                            
                            requestBO.requestName = NSIUtility.getObjectForKey("RequestName", dictResponse:dicRequest) as! String
                            
                            let arrayreccuringLifts = NSMutableArray()
                            if requestBO.isRecurring == true{
                                if let arrayOfData:NSArray  = NSIUtility.getObjectForKey("RecurringLiftRequests", dictResponse:dicRequest) as? NSArray{
                                    for reccuringRequest in arrayOfData{
                                        if let dicRecurringRequestObj = reccuringRequest as? NSDictionary{
                                            let recurringLiftRequestsBO = RecurringLiftRequestsBO()
                                            recurringLiftRequestsBO.requestReccuringID = NSIUtility.getObjectForKey("Id", dictResponse:dicRecurringRequestObj) as! NSNumber
                                            let strDate = NSIUtility.getObjectForKey("RequestDatetime", dictResponse:dicRecurringRequestObj) as! String
                                            recurringLiftRequestsBO.liftDate = NSDate(fromString: strDate, format: .DotNet)
                                            recurringLiftRequestsBO.dateString = recurringLiftRequestsBO.liftDate.toString(format: .Custom(Constants.DateFormatwithAMPM))
                                            
                                            recurringLiftRequestsBO.liftTime = recurringLiftRequestsBO.liftDate.toString(format: .Custom(Constants.TimeFormat))
                                            
                                            recurringLiftRequestsBO.isLiftSelected = false
                                            
                                            arrayreccuringLifts.addObject(recurringLiftRequestsBO)
                                        }
                                    }
                                }
                            }
                            requestBO.arrayRecurringLiftRequests = arrayreccuringLifts
//                            requestBO.parentLiftRequestId = NSIUtility.getObjectForKey("ParentLiftRequestId", dictResponse:dicRequest) as! String
                            // USE THIS
//                            requestBO.recurringLiftRequests = NSIUtility.getObjectForKey("RecurringLiftRequests", dictResponse:dicRequest) as! String
//                            requestBO.requestEndDate = NSIUtility.getObjectForKey("RequestEndDate", dictResponse:dicRequest) as! String
                            
//                            requestBO.requestPassengers = NSIUtility.getObjectForKey("RequestPassengers", dictResponse:dicRequest) as! String
//                            requestBO.requestedUsers = NSIUtility.getObjectForKey("RequestedUsers", dictResponse:dicRequest) as! String
                            
                            
                            handler(obj: requestBO, success: true)
                            return
                        }
                        
                    }
                    handler(obj: obj, success: false)
                    return
                }
            }else{
                
                handler(obj: obj, success: false)
                return
                
            }
        }
    }

}


