//
//  ContactVC.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/23/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit
import SwiftAddressBook
import MBProgressHUD

class ContactVC: BaseViewController,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate,ViewMoreLiftrotocol {

    @IBOutlet var tableOfContact: UITableView!
    @IBOutlet var searchAddressBar: UISearchBar!
    
    var arrayOfPhoneAddresses = NSMutableArray()
    var arrayOfAddresses = NSMutableArray()
    
    var filteredAddressArray: NSMutableArray!
    
    var selectedArray = NSMutableArray()
    
    var searchActive : Bool = false
    
    @IBOutlet var btnAddSelected: UIButton!
    
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBar(.BlueNavigationType)
        self.title = "Contacts"
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialInitialization()
    }
    
    func initialInitialization()  {
        
        filteredAddressArray = NSMutableArray()
        
        tableOfContact.registerNib(UINib.init(nibName: "SelectPassengerCell", bundle: nil), forCellReuseIdentifier: "SelectPassengerCell")
        self.fetchAllContactsDataFromMobileAndGetData()
    }
    
    
    func fetchAllContactsDataFromMobileAndGetData(){
        
        MBProgressHUD.showHUDAddedTo(self.view, animated: true)
        
        
        swiftAddressBook?.requestAccessWithCompletion({ (success, error) -> Void in
            if success {
                //do something with swiftAddressBook
                
                let arrayOfUserInfo = NSMutableArray()
                
                let arrayOfEmails = NSMutableArray()
                let arrayOfMobileNo = NSMutableArray()
                if let people = swiftAddressBook?.allPeople {
                    
                    for person in people {
                        
                        let arrayOfOneUserEmails = NSMutableArray()
                        let arrayOfOneUserMobileNo = NSMutableArray()
                        
                        if person.emails != nil{
                            if let arrayOfPersonEmail:[String] = (person.emails?.map({$0.value}))!{
                                for strEmails in arrayOfPersonEmail{
                                    if NSIUtility.validateEmailWithoutAlert(strEmails){
                                        if strEmails != UserBO.sharedInstanceOfUser.userEmailAddress{
                                            arrayOfEmails.addObject(strEmails)
                                            arrayOfOneUserEmails.addObject(strEmails)
                                        }
                                    }
                                }
                            }
                        }
                        if person.phoneNumbers != nil{
                            if let arrayOfPersonNo:[String] = (person.phoneNumbers?.map({$0.value}))!{
                                for strNo in arrayOfPersonNo{
                                    arrayOfOneUserMobileNo.addObject("\(NSIUtility.removeSpecialCharsFromString(strNo))")
                                    arrayOfMobileNo.addObject("\(NSIUtility.removeSpecialCharsFromString(strNo))")
                                 }
                            }
                        }
                        
                        
                        let contactOneUserBO = ContactsBO()
                        
                        guard let arrayOffirstName:String = person.firstName! else {
                                   contactOneUserBO.firstName = ""
                         }
                        contactOneUserBO.firstName = arrayOffirstName
                        contactOneUserBO.emailAddress = arrayOfOneUserEmails.description
                        contactOneUserBO.mobileNumber = arrayOfOneUserMobileNo.description
                        contactOneUserBO.imagePath = ""
                        contactOneUserBO.lastName = ""
                        contactOneUserBO.liftRequestId = 0
                        contactOneUserBO.photo =  NSData()
                        contactOneUserBO.userID = 0
                        contactOneUserBO.isSelected = false
                        
                        arrayOfUserInfo.addObject(contactOneUserBO)
                        
                    }
                    
                    self.arrayOfPhoneAddresses = arrayOfUserInfo
                    self.arrayOfAddresses = arrayOfUserInfo
                    print(arrayOfUserInfo)
                    print(arrayOfEmails)
                    print(arrayOfMobileNo)
                    
                    self.tableOfContact.delegate = self
                    self.tableOfContact.dataSource = self
                    dispatch_async(dispatch_get_main_queue(), { () -> Void in
                        self.tableOfContact.reloadData()
                        MBProgressHUD.hideAllHUDsForView(self.view, animated: true)
                        self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
                    })
                    
                    // Fetch Array Of Contacts through giving mobile data
                    if arrayOfEmails.count != 0 || arrayOfMobileNo.count != 0{
                        let contactDL = ContactsDL()
                        contactDL.requestforContacts(arrayOfEmails, arrayOfNumbers: arrayOfMobileNo, handler: { (obj, success) -> Void in
                            
                            if success == true {
                                if let arrayAdress = obj as? NSMutableArray{
                                    self.arrayOfAddresses = arrayAdress
                                    print(self.arrayOfAddresses)
                                     self.filterTheAddress()
                                    self.tableOfContact.delegate = self
                                    self.tableOfContact.dataSource = self
                                    
                                    
                                    dispatch_async(dispatch_get_main_queue(), { () -> Void in
                                        self.tableOfContact.reloadData()
                                        MBProgressHUD.hideAllHUDsForView(self.view, animated: true)
                                        self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
                                    })
                                }
                            }else{
                                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                                    MBProgressHUD.hideAllHUDsForView(self.view, animated: true)
                                    NSIUtility.show("Unable to fetch contacts.")
                                    self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
                                })
                                
                            }
                        })
                    }else{
                        
                        dispatch_async(dispatch_get_main_queue(), { () -> Void in
                            MBProgressHUD.hideAllHUDsForView(self.view, animated: true)
                            NSIUtility.show("Unable to fetch phone contacts.")
                            self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
                        })
                        
                    }
                }
            }
            else {
                //no success. Optionally evaluate error
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                    NSIUtility.show("Please enable the access of contacts from settings")
                    self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
                })
            }
        })
        
    }
    
    func filterTheAddress(){
        if self.arrayOfAddresses.count != 0{
            for var i = 0; i < self.selectedArray.count ; i++ {
                
                if let selcetedContact:ContactsBO = selectedArray[i] as? ContactsBO{
                    let predicate:NSPredicate = NSPredicate(format: "userID == %@", argumentArray:[selcetedContact.userID])
                    let arrayFiltered = self.arrayOfAddresses.filteredArrayUsingPredicate(predicate)
                    if arrayFiltered.count != 0{
                        let contactPerson:ContactsBO = arrayFiltered[0] as! ContactsBO
                        contactPerson.isSelected = true
                    }
                }
            }
        }
    }
    
    //MARK: - Table VIew Delegates
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        if searchActive == true{
            return 1
        }
        return 2
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searchActive == true{
               return filteredAddressArray.count
        }
        else{
            if(section == 0) {
                return arrayOfAddresses.count
            } else {
                return arrayOfPhoneAddresses.count
            }
            
            
        }
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat
    {
        return 75;
    }
    
    //  Header View
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?{
        
        if let viewHeader:ViewOfLinkedPassenger = UIView.viewFromNibName("ViewOfLinkedPassenger") as? ViewOfLinkedPassenger {
            
            if(section == 0) {
                    viewHeader.lblSectionName.text = "Friends already using Locallift (\(arrayOfAddresses.count))"
            } else {
                    viewHeader.lblSectionName.text = "Invite friends to join Locallift"
            }
            return viewHeader
        }
        return UIView()
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat{
        
        if searchActive == true {
            return 0
        }
        
        if let viewHeader:ViewOfLinkedPassenger = UIView.viewFromNibName("ViewOfLinkedPassenger") as? ViewOfLinkedPassenger {
                if(section == 0) {
                    return self.arrayOfAddresses.count == 0 ? 0 : viewHeader.height
                } else {
                    return self.arrayOfPhoneAddresses.count == 0 ? 0 : viewHeader.height
                }
            }
        else{
            return 0
        }
    }
    
    
    
    
    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
       
        var viewMoreLift:LoadMyLiftMore!
        viewMoreLift = UIView.viewFromNibName("LoadMyLiftMore") as? LoadMyLiftMore
        viewMoreLift.viewMoreBtnLeftAlignment()
        viewMoreLift.imageViewDownArrow.hidden = false
        viewMoreLift.backgroundColor = UIColor.colorWithRGB(245, green: 245, blue: 245, alpha: 0.7)
        viewMoreLift.delegate=self
        
        return viewMoreLift
    }
    
    func tableView(tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        
        if searchActive == true {
            return 0
        }
        
        if(section == 0) {
            return self.arrayOfAddresses.count == 0 ? 0 : 66
        } else {
            return 0
        }
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell:SelectPassengerCell = (tableView.dequeueReusableCellWithIdentifier("SelectPassengerCell", forIndexPath: indexPath) as? SelectPassengerCell)!
        
        let contactBO:ContactsBO
            
            if searchActive == false{
                 if(indexPath.section == 0) {
                        contactBO = arrayOfAddresses[indexPath.row] as! ContactsBO
                }
                 else {
                        contactBO = arrayOfPhoneAddresses[indexPath.row] as! ContactsBO
                }
            }
            else{
                contactBO = filteredAddressArray[indexPath.row] as! ContactsBO
            }
            
            cell.lblEmailOfPassenger.text = contactBO.emailAddress
            cell.lblNameOfPassenger.text = contactBO.firstName + " " + contactBO.lastName
            cell.btnSelectedPassenger.addTarget(self, action: "toSelectPeople:", forControlEvents: .TouchUpInside)
            cell.btnSelectedPassenger.addTarget(self, action: "toSelectPeople:", forControlEvents: .TouchUpInside)
            
            cell.btnSelectedPassenger.setImage(UIImage(named: "blue_unchecked"), forState: UIControlState.Normal)
            cell.btnSelectedPassenger.setImage(UIImage(named: "blue_checked"), forState: UIControlState.Selected)
            
            cell.btnSelectedPassenger.selected = contactBO.isSelected
        
        return cell
    }
    
    func toSelectPeople(sender:UIButton){
        
        sender.selected = !sender.selected
        
        let buttonPosition:CGPoint = sender.convertPoint(CGPointZero, toView: self.tableOfContact)
        let indexPath:NSIndexPath? = self.tableOfContact.indexPathForRowAtPoint(buttonPosition)
        
        var contactBO:ContactsBO!
        
        if searchActive == false{
            if(indexPath!.section == 0) {
                 contactBO = arrayOfAddresses[indexPath!.row] as! ContactsBO
            }
            else {
                contactBO = arrayOfPhoneAddresses[indexPath!.row] as! ContactsBO
            }
        }
        else{
            contactBO =  filteredAddressArray[indexPath!.row] as! ContactsBO
        }
        
        contactBO.isSelected = sender.selected
        
        
        if sender.selected{
            if contactBO.emailAddress != UserBO.sharedInstanceOfUser.userEmailAddress{
                selectedArray.addObject(contactBO)
            }
        }else{
            let predicate:NSPredicate = NSPredicate(format: "userID == %@", argumentArray:[contactBO.userID])
            let arrayFiltered = self.selectedArray.filteredArrayUsingPredicate(predicate)
            if arrayFiltered.count != 0{
                let contactCheckedBO = arrayFiltered[0] as! ContactsBO
                selectedArray.removeObject(contactCheckedBO)
            }
            
        }
        self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.1)
    }
    
    
    
    //MARK: - Search Bar Delegates
    
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        if(filteredAddressArray.count == 0){searchActive = false;} else {searchActive = true;}}
    
    func searchBarTextDidEndEditing(searchBar: UISearchBar) {searchActive = false}
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {searchActive = false; self.view.endEditing(true); self.tableOfContact.reloadData(); searchBar.text = ""}
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {searchActive = false;self.view.endEditing(true)}
    
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        
        let predicate:NSPredicate = NSPredicate(format: "(emailAddress CONTAINS[c] %@ OR firstName CONTAINS[c] %@ OR lastName CONTAINS[c] %@)", argumentArray:[searchText,searchText,searchText])
        
        var tempNames =  NSArray()
        var tempNames1 =  NSArray()
        
        
        tempNames = self.arrayOfAddresses.filteredArrayUsingPredicate(predicate) as NSArray
        
        tempNames1 = self.arrayOfPhoneAddresses.filteredArrayUsingPredicate(predicate) as NSArray
        
        filteredAddressArray.removeAllObjects()
        
        filteredAddressArray.addObjectsFromArray(tempNames as [AnyObject])
        filteredAddressArray.addObjectsFromArray(tempNames1 as [AnyObject])
        
        if(filteredAddressArray.count == 0){
            searchActive = false;
        } else {
            searchActive = true;
        }
        self.tableOfContact.reloadData()
    }
    
    @IBAction func toAddSelectedBtn(sender: AnyObject) {
        
        print(self.selectedArray)
        
        if let liftVC =  self.fetchPreviousControllerFromNavigationStack(2) as? SelectedLiftGroupVC{
            let arraSelected = selectedArray as NSArray
            liftVC.viewLiftGroupUsersCollection.arrayUserOfLiftgroup = arraSelected as! NSMutableArray
            liftVC.viewLiftGroupUsersCollection.collectionViewSelectLiftGroup.reloadData()
            self.navigationController?.popToViewController(liftVC, animated: true)
        }
    }
    
    func toSelectBtnValidation() {
        if (self.selectedArray.count == 0){
            btnAddSelected.backgroundColor = UIColor.colorWithRGB(31, green: 81, blue: 108, alpha:0.4)
        }
        else{
            btnAddSelected.backgroundColor = Constants.APP_THEME_COLOR
        }
    }
    
    //MARK: - Load more lift
    func showMoreLift() {
        print("more")
        
    }
    
    
    
}
