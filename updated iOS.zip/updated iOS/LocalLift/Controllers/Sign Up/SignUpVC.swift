//
//  SignUpVC.swift
//  LocalLift
//
//  Created by prabhjot singh on 10/29/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit
import Foundation


class SignUpVC: BaseViewController, UITextFieldDelegate{
    
    @IBOutlet var txtFirstName: UITextField!
    @IBOutlet var txtLastName: UITextField!
    @IBOutlet var txtEmailAddress: UITextField!
    @IBOutlet var txtPassword: UITextField!
    @IBOutlet var txtMobileNumber: UITextField!
    @IBOutlet var btnContryCode: UIButton!
    @IBOutlet var btnConnect: UIButton!
//    @IBOutlet var btn: UIButton!
    @IBOutlet var scroller: UIScrollView!
    var countryObj:CountryCodeBO!
    
//MARK: - View Life Cycle Methods    

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBar(NavigationType.ClearNavigationType)
        self.assignTheValues()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.initialInitialization()
        
    }
    
    func initialInitialization()
    {
        btnContryCode.roundCorner(5)
        
// Initially it will be Australia
        let objCountry = CountryCodeBO()
        objCountry.countryCode = "+61"
        objCountry.countryId = 13
        objCountry.countryName = "Australia"
        countryObj = objCountry
    }
    

    func assignTheValues()
    {
        if countryObj != nil
        {
            btnContryCode.setTitle(countryObj.countryName + "  " + countryObj.countryCode, forState:UIControlState.Normal)
            self.toSelectBtnValidation()
        }
    }
    
    
    
//MARK: - Button Methods
    
// Facebook SignIn
    
    @IBAction func toFacebookSignUp(sender: AnyObject) {
        
        let social:SocialNetworking =  SocialNetworking()
        social.socialType = SocialNetworkingSourceType.Facebook
        social.viewController = self
        social.socialNetworkHandler { (data, success) -> Void in
        
            if (success == true  && data?.isKindOfClass(NSDictionary) != nil)
            {
                let dicOfFB:NSDictionary = data as! NSDictionary
                self.txtEmailAddress.text = NSIUtility.getObjectForKey("email", dictResponse:dicOfFB) as? String
                self.txtFirstName.text = NSIUtility.getObjectForKey("first_name", dictResponse:dicOfFB) as? String
                self.txtLastName.text = NSIUtility.getObjectForKey("last_name", dictResponse:dicOfFB) as? String
            }
            else
            {
                NSIUtility.showAlert("Facebook", message: "Not Connected")
            }
        }
    }
    
//  SignUp Button Action
    
    @IBAction func toSignUp(sender: UIButton) {
        
        if NSIUtility.validateTextFieldArray(["First Name","Last Name","Email Address","Email Address","Password","Mobile Number"],arrayOFFields: [txtFirstName,txtLastName,txtEmailAddress,txtEmailAddress,txtPassword,txtMobileNumber])
        {
            if (countryObj != nil)
            {
                if NSIUtility.validateEmail(txtEmailAddress.text!) == false {return}
                if txtMobileNumber.text?.length <= 5 {NSIUtility.show(Constants.kValidMobileNo);return}
                
                let userObj = UserBO.sharedInstanceOfUser
                userObj.userFirstName =  txtFirstName.text
                userObj.userLastName  =  txtLastName.text
                userObj.userMobileNo  =  txtMobileNumber.text
                userObj.userPassword  =  txtPassword.text
                userObj.userCountryObj = countryObj
                userObj.userEmailAddress = txtEmailAddress.text
              
                let userDL = UserDL()
                userDL.requestForUserCreation({ (obj, success) -> Void in
                    if success == true
                    {
                        let dicResponse:NSDictionary = obj as! NSDictionary
                        userObj.userID = NSIUtility.getObjectForKey("Data", dictResponse: dicResponse).objectAtIndex(0) as! NSNumber
                        
                        let verifyOTPObj:VerifyOTPVC =  NSIUtility.fetchViewControllerWithName("VerifyOTPVC",storyBoardName:"Main") as! VerifyOTPVC
                        
                        let userBO:UserBO = UserBO.sharedInstanceOfUser
                        let nexmoDL = NexmoDL()
                        nexmoDL.requestTheNexmoMobile("\(userBO.userCountryObj.countryCode+userBO.userMobileNo)" ) { (obj, success) -> Void in
                            if success == true{
                                verifyOTPObj.nexmoObject.requestID = obj?.valueForKey("requestID") as! String
                                self.navigationController!.pushViewController(verifyOTPObj, animated: true)
                                self.clearAllTextFields(self.scroller)
                            }
                            else{
                            }
                        }
                    }
                })
                
            }else{
                NSIUtility.show("Please select the Country Code")
            }
        }
        
    }
    
    @IBAction func toSignIN(sender: AnyObject)
    {
        let signINVC:SignInVC =  NSIUtility.fetchViewControllerWithName("SignInVC",storyBoardName:"Main") as! SignInVC
        self.navigationController!.pushViewController(signINVC, animated: true)
    }
    
//MARK: - Text Field Delegates
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
        
        if textField == txtMobileNumber
        {
            return UITextField.textField(textField, shouldChangeCharactersInRange: range, replacementString: string,
                withMaxLength: UITextField.MaxLength.MobileNoMax, spaceAllowed: false)
        }
        
        return UITextField.textField(textField, shouldChangeCharactersInRange: range, replacementString: string,
            withMaxLength: UITextField.MaxLength.DefaultMax, spaceAllowed: false)
        
    }
    
    
    func toSelectBtnValidation()
    {
        if (self.isAllTextFieldFilled(self.scroller) == false || countryObj == nil || txtMobileNumber.text?.length <= 5 ){
            btnConnect.backgroundColor = UIColor.colorWithRGB(31, green: 81, blue: 108, alpha:0.7)
//            btnConnect.userInteractionEnabled = false
        }
        else{
            btnConnect.backgroundColor = Constants.APP_THEME_COLOR
//            btnConnect.userInteractionEnabled = true
        }
    }
    
    
  

}
