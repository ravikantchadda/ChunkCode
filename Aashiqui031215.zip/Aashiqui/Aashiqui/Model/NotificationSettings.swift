//
//  NotificationSettings.swift
//  Aashiqui
//
//  Created by ketan saini on 14/10/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class NotificationSettings: NSObject {
    
    /*
    {
    adminMessageNotificationEnabled = Y;
    commentPhotoNotificationEnabled = Y;
    friendRequestNotificationEnabled = Y;
    friendStatusUpdateNotificationEnabled = Y;
    likePhotoNotificationEnabled = Y;
    messageNotificationEnabled = Y;
    userId = 2846;
    }
    */
    
    var userId:String!
    var adminMessageNotificationEnabled:String!
    var commentPhotoNotificationEnabled:String!
    var friendRequestNotificationEnabled:String!
    var friendStatusUpdateNotificationEnabled:String!
    var likePhotoNotificationEnabled:String!
    var messageNotificationEnabled:String!
    
    let adminMessage = "adminMessageNotificationEnabled"
    let commentPhoto = "commentPhotoNotificationEnabled"
    let friendRequest = "friendRequestNotificationEnabled"
    let friendStatus = "friendStatusUpdateNotificationEnabled"
    let likePhoto = "likePhotoNotificationEnabled"
    let message = "messageNotificationEnabled"
    
    // MARK: NSCoding
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.userId = (decoder.decodeObjectForKey("userID") as! String?)!
        self.adminMessageNotificationEnabled = (decoder.decodeObjectForKey(adminMessage) as! String?)!
        self.commentPhotoNotificationEnabled = (decoder.decodeObjectForKey(commentPhoto) as! String?)!
        self.friendRequestNotificationEnabled = (decoder.decodeObjectForKey(friendRequest) as! String?)!
        self.friendStatusUpdateNotificationEnabled = (decoder.decodeObjectForKey(friendStatus) as! String?)!
        self.likePhotoNotificationEnabled = (decoder.decodeObjectForKey(likePhoto) as! String?)!
        self.messageNotificationEnabled = (decoder.decodeObjectForKey(message) as! String?)!
        
    }
    
    func encodeWithCoder(coder: NSCoder) {
        coder.encodeObject(self.userId, forKey: "userID")
        coder.encodeObject(self.adminMessageNotificationEnabled, forKey: adminMessage)
        coder.encodeObject(self.commentPhotoNotificationEnabled, forKey: commentPhoto)
        coder.encodeObject(self.friendRequestNotificationEnabled, forKey: friendRequest)
        coder.encodeObject(self.friendStatusUpdateNotificationEnabled, forKey: friendStatus)
        coder.encodeObject(self.likePhotoNotificationEnabled, forKey: likePhoto)
        coder.encodeObject(self.messageNotificationEnabled, forKey: message)
    }
    
    func fillDataInModel(dictData: NSDictionary) -> NotificationSettings {
        let objUser = NotificationSettings()
        objUser.userId = dictData.valueForKey("userId") as! String
        objUser.adminMessageNotificationEnabled = dictData.valueForKey(adminMessage) as! String
        objUser.commentPhotoNotificationEnabled = dictData.valueForKey(commentPhoto) as! String
        objUser.friendRequestNotificationEnabled = dictData.valueForKey(friendRequest) as! String
        objUser.friendStatusUpdateNotificationEnabled = dictData.valueForKey(friendStatus) as! String
        objUser.likePhotoNotificationEnabled = dictData.valueForKey(likePhoto) as! String
        objUser.messageNotificationEnabled = dictData.valueForKey(message) as! String
        return objUser
    }
    
}
