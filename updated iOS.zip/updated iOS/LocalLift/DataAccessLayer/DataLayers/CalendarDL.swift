//
//  CalendarDL.swift
//  LocalLift
//
//  Created by neeru thakur on 12/15/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class CalendarBO: NSObject {
    var date:NSDate!
    var dateStr:String!
    var liftOfferCount:NSNumber!
    var liftRequestCount:NSNumber!
    
}

class CalendarDL: PSRestAPIHelper {
    
    func requestGetMyLiftCalendarData(month:String, year _year:String, handler:CompletionHandler){
        self.serviceURL = "GetMyLiftCalendarData"
        self.setContentTypeHeaders()
        self.webservice.isShowLoader = true
        
        let dicParam:NSDictionary = ["uid":UserBO.sharedInstanceOfUser.userID,"m": month,"y": _year]
        self.requestforGET(dicParam as! [NSObject : AnyObject!]) { (obj, success) -> Void in
            
            if success == true
            {
                if let dicResponse:NSDictionary = obj as? NSDictionary{
                    
                    print(dicResponse);
                    let arrayOfContacts = NSMutableArray()
                    
                    if let arrayOfPersons:NSArray = NSIUtility.getObjectForKey("Data", dictResponse: dicResponse) as? NSArray {
                        
//                        print(arrayOfPersons)
                        for dicOfPerson in arrayOfPersons{
                            let calendarBO = CalendarBO()
                           
                            let dateStr =  NSIUtility.getObjectForKey("Date", dictResponse:dicOfPerson as! NSDictionary) as! String
                            
                            calendarBO.date = NSDate(fromString: dateStr, format: .Custom((LocaliftSharedObj.sharedInstance.isTesting ? Constants.DateTimeSlashFormat:Constants.DateTimeHiphenFormat)))
                            
                            calendarBO.dateStr = calendarBO.date.toString(format: .Custom(Constants.DateSlashFormat))
//                            
                            calendarBO.liftOfferCount = NSIUtility.getObjectForKey("LiftOfferCount", dictResponse:dicOfPerson as! NSDictionary) as! NSNumber
                            calendarBO.liftRequestCount = NSIUtility.getObjectForKey("LiftRequestCount", dictResponse:dicOfPerson as! NSDictionary) as! NSNumber
                            arrayOfContacts.addObject(calendarBO)
                            
                            NSLog(calendarBO.dateStr)
                        }
                    }
                    handler(obj: arrayOfContacts, success: true)
                    return
                }
            }
            else{
                handler(obj: nil, success: false)
                
            }
        }
    }
}