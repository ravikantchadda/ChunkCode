//
//  UsernameSuggestionsView.swift
//  Aashiqui
//
//  Created by ketan saini on 26/11/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit
protocol UserSuggestionsDelegate
{
    func userSuggestionTapped(strSuggestion: String)
    
}
class UsernameSuggestionsView: UIView {

    @IBOutlet weak var tblSuggestions: UITableView!
    @IBOutlet weak var viewContainer: UIView!
    @IBOutlet weak var imgVwBackground: UIImageView!
    var delegate: UserSuggestionsDelegate!
    var arrList: NSArray!
    
    override init(frame: CGRect) { // for using CustomView in code
        super.init(frame: frame)
        self.commonInit()
    }
    required init(coder aDecoder: NSCoder) { // for using CustomView in IB
        super.init(coder: aDecoder)!
        self.commonInit()
    }
    private func commonInit() {
        NSBundle.mainBundle().loadNibNamed("UsernameSuggestionsView", owner: self, options: nil)
        self.addSubview(viewContainer)
        viewContainer.frame = CGRectMake(0, 0, NSIConstants.ScreenSize.SCREEN_WIDTH, NSIConstants.ScreenSize.SCREEN_HEIGHT)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "removeView")
        tapGesture.numberOfTapsRequired = 1
        imgVwBackground.addGestureRecognizer(tapGesture)
        tblSuggestions.tableFooterView = UIView(frame: CGRectZero)
        tblSuggestions.reloadData()
    }
    
    func setUpSuggestionView(arrSuggestions: NSArray) {
        print("setUpReportView\(arrSuggestions)")
        arrList = arrSuggestions
        tblSuggestions.reloadData()
    }
    
    func removeView(){
        self.removeFromSuperview()
    }
    
    //MARK: - TableView DataSource/Delegate
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if arrList != nil {
            return arrList.count
        }
        return 0
    }
    
    func tableView(tableView: UITableView!, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 44
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if(tableView.respondsToSelector(Selector("setSeparatorInset:"))){
            tableView.separatorInset = UIEdgeInsetsZero
        }
        if(tableView.respondsToSelector(Selector("setLayoutMargins:"))){
            tableView.layoutMargins = UIEdgeInsetsZero
        }
        if(cell.respondsToSelector(Selector("setLayoutMargins:"))){
            cell.layoutMargins = UIEdgeInsetsZero
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCellWithIdentifier("\(indexPath.row)") as UITableViewCell!
        if (cell == nil) {
            cell = UITableViewCell(style: UITableViewCellStyle.Value1, reuseIdentifier: "\(indexPath.row)")
            cell.selectionStyle = UITableViewCellSelectionStyle.None
    
            let lblSuggestion: UILabel = UILabel(frame: CGRectMake(10, 10, cell.frame.size.width - 10, 24))
            lblSuggestion.textAlignment = NSTextAlignment.Left
            lblSuggestion.textColor = NSIConstants.greyColor
            lblSuggestion.text = arrList.objectAtIndex(indexPath.row) as? String
            lblSuggestion.numberOfLines = 1
            lblSuggestion.font = UIFont(name: "Lato-Regular", size: 15)
            lblSuggestion.lineBreakMode = NSLineBreakMode.ByWordWrapping
            lblSuggestion.sizeToFit()
            cell.addSubview(lblSuggestion)
        }
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        self.delegate.userSuggestionTapped((arrList.objectAtIndex(indexPath.row) as? String)!)
        removeView()
    }
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
