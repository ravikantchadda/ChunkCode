//
//  Comment.swift
//  Aashiqui
//
//  Created by ketan saini on 09/11/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class Comment: NSObject {
    /*
    {
    commentText = "Hello comment";
    minutesAgo = 0;
    userFirstName = Ketan;
    userId = 2798;
    userLastName = Saini;
    userNickName = "";
    userProfilePicUrl = "http://gsu-miscwork02-qa.netsol.in/images/2798/profilepic/ff7edb8bd4847ff564e8cd51bb0c0b84.png";
    }
    */
    
    var userId:String!
    var commentText:String!
    var minutesAgo:String!
    var userFirstName:String!
    var userLastName:String!
    var userNickName:String!
    var userProfilePicUrl:String!
    
    
    // MARK: NSCoding
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.userId = (decoder.decodeObjectForKey("userID") as! String?)!
        self.commentText = (decoder.decodeObjectForKey("commentText") as! String?)!
        self.minutesAgo = (decoder.decodeObjectForKey("minutesAgo") as! String?)!
        self.userFirstName = (decoder.decodeObjectForKey("userFirstName") as! String?)!
        self.userLastName = (decoder.decodeObjectForKey("userLastName") as! String?)!
        self.userNickName = (decoder.decodeObjectForKey("userNickName") as! String?)!
        self.userProfilePicUrl = (decoder.decodeObjectForKey("userProfilePicUrl") as! String?)!
        
    }
    
    func encodeWithCoder(coder: NSCoder) {
        coder.encodeObject(self.userId, forKey: "userID")
        coder.encodeObject(self.commentText, forKey: "commentText")
        coder.encodeObject(self.minutesAgo, forKey: "minutesAgo")
        coder.encodeObject(self.userFirstName, forKey: "userFirstName")
        coder.encodeObject(self.userLastName, forKey: "userLastName")
        coder.encodeObject(self.userNickName, forKey: "userNickName")
        coder.encodeObject(self.userProfilePicUrl, forKey: "userProfilePicUrl")
    }
    
    func fillDataInModel(arrData: NSArray) -> NSMutableArray {
        let arrCommentData: NSMutableArray! = []
        for dict in arrData{
            let objComment = Comment()
            objComment.userId = dict.valueForKey("userId") as! String
            objComment.userFirstName = dict.valueForKey("userFirstName") as! String
            objComment.userLastName = dict.valueForKey("userLastName") as! String
            objComment.minutesAgo = dict.valueForKey("minutesAgo") as! String
            if (dict.valueForKey("userProfilePicUrl")?.isKindOfClass(NSNull) != true){
                objComment.userProfilePicUrl = dict.valueForKey("userProfilePicUrl") as! String
            }else{
                objComment.userProfilePicUrl = ""
            }
            if (dict.valueForKey("commentText")?.isKindOfClass(NSNull) != true){
                objComment.commentText = dict.valueForKey("commentText") as! String
            }else{
                objComment.commentText = ""
            }
            if (dict.valueForKey("userNickName")?.isKindOfClass(NSNull) != true){
                objComment.userNickName = dict.valueForKey("userNickName") as! String
            }else{
                objComment.userNickName = ""
            }
            arrCommentData.addObject(objComment)
        }
        return arrCommentData
    }

    
}
