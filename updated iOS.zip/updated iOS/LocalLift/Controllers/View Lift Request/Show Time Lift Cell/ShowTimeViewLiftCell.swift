//
//  ShowTimeViewLiftCell.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/10/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class ShowTimeViewLiftCell: UITableViewCell {

    @IBOutlet weak var lblShowTime: UILabel!
    @IBOutlet weak var lblShowDate: UILabel!
    @IBOutlet var btnSelectedLift: UIButton!
    @IBOutlet weak var constDownShowDate: NSLayoutConstraint!
    @IBOutlet weak var constShowTimeUp: NSLayoutConstraint!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        btnSelectedLift.userInteractionEnabled = false
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
