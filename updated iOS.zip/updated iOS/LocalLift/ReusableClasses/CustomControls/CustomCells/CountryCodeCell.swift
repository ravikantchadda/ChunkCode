//
//  CountryCodeCell.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/3/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class CountryCodeCell: UITableViewCell {
    
    @IBOutlet var countryName: UILabel!
    @IBOutlet var countryCode: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
