//
//  InvitationTableView.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/23/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class InvitationTypeBO: NSObject {
    
    var title: String?
    var subtitle: String?
    var type: String?
    var imageView: UIImage?
}


class InvitationTableView: UIView,UITableViewDataSource,UITableViewDelegate {

    enum invitationType:Int {case FromContact = 0, FromSocialSite = 1}
    var type:invitationType!
    var delegate:SelectPassValueProtocol?
    
    @IBOutlet weak var tableOfInvitationType: UITableView!
    
    var arrayOfInvitationType = NSMutableArray()
    
    //MARK: - table initialInitialization method
    func initialInitialization() {
        tableOfInvitationType.registerNib(UINib(nibName: "InvitationCell", bundle: nil) , forCellReuseIdentifier: "InvitationCell")
        //hide row seperator
        tableOfInvitationType.tableFooterView = UIView()
     
        tableOfInvitationType.dataSource = self
        tableOfInvitationType.delegate = self
        
        self.arrayOfInvitationType = NSMutableArray()
    }
    
    //MARK: - Fetch data e
    func fetchInvitationType() {
        
        self.arrayOfInvitationType.removeAllObjects()
        
        if type == .FromContact {
        
            let invitationContactBO = InvitationTypeBO()
            invitationContactBO.title = "Invite from Phone Contacts"
            invitationContactBO.subtitle = "Lorem from phone"
            invitationContactBO.type = "Contact"
            invitationContactBO.imageView = UIImage(named: "blue_checked")
            self.arrayOfInvitationType.addObject(invitationContactBO)
            
            let invitationBO = InvitationTypeBO()
            invitationBO.title = "Invite from Social Site"
            invitationBO.subtitle = "Lorem from Social"
            invitationBO.type = "Social"
            invitationBO.imageView = UIImage(named: "blue_checked")
            self.arrayOfInvitationType.addObject(invitationBO)
            
            
        } else {
        
            let invitationFaceboolBO = InvitationTypeBO()
            invitationFaceboolBO.title = "Invite from Facebook"
            invitationFaceboolBO.subtitle = "Lorem from facebook"
            invitationFaceboolBO.type = "Facebook"
            invitationFaceboolBO.imageView = UIImage(named: "blue_checked")
            self.arrayOfInvitationType.addObject(invitationFaceboolBO)
            
            let invitationWhatsAppBO = InvitationTypeBO()
            invitationWhatsAppBO.title = "Invite from WhatsApp"
            invitationWhatsAppBO.subtitle = "Lorem from whatsApp"
            invitationWhatsAppBO.type = "WhatsApp"
            invitationWhatsAppBO.imageView = UIImage(named: "blue_checked")
            self.arrayOfInvitationType.addObject(invitationWhatsAppBO)
            
            let invitationEmailBO = InvitationTypeBO()
            invitationEmailBO.title = "Invite from Email"
            invitationEmailBO.subtitle = "Lorem from email"
            invitationEmailBO.type = "Email"
            invitationEmailBO.imageView = UIImage(named: "blue_checked")
            self.arrayOfInvitationType.addObject(invitationEmailBO)
            
        }
        
        self.tableOfInvitationType.reloadData()
        
    }
    
    //MARK: - Table VIew Delegates
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrayOfInvitationType.count
        
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        return basicCellAtIndexPath(indexPath)
    }
    
    func basicCellAtIndexPath(indexPath:NSIndexPath) -> InvitationCell {
        let cell:InvitationCell = (tableOfInvitationType.dequeueReusableCellWithIdentifier("InvitationCell", forIndexPath: indexPath) as? InvitationCell)!
        
        let dicInvitationType = self.arrayOfInvitationType[indexPath.row] as! InvitationTypeBO
        
        cell.lblInvotationTitle.text = dicInvitationType.title
        cell.lblInvitationSubTitle.text = dicInvitationType.subtitle
        cell.btnInvitationThumbnail.setImage(UIImage(named: "blue_checked"), forState: UIControlState.Normal)
        return cell
    }

    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat{
        
        return 100
    }
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        let dicInvitationType = self.arrayOfInvitationType[indexPath.row] as! InvitationTypeBO
            if(delegate != nil) {
                delegate?.selectCell(dicInvitationType.type! )
            }
    }
    //  Header View
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?{
        
        if let viewHeader:ViewOfLinkedPassenger = UIView.viewFromNibName("ViewOfLinkedPassenger") as? ViewOfLinkedPassenger {
            viewHeader.lblSectionName.text = "Select from the list below"
            return viewHeader
        }
        return UIView()
        
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat{
        
        if let viewHeader:ViewOfLinkedPassenger = UIView.viewFromNibName("ViewOfLinkedPassenger") as? ViewOfLinkedPassenger {
            return viewHeader.height}
        else{
            return 0
        }
    }
    
    // MARK:-  Our custom view from the XIB file
    var view: UIView!
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadViewFromNib ()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        loadViewFromNib ()
    }
    func loadViewFromNib() {
        let bundle = NSBundle(forClass: self.dynamicType)
        let nib = UINib(nibName: "InvitationTableView", bundle: bundle)
        let view = nib.instantiateWithOwner(self, options: nil)[0] as! UIView
        view.frame = bounds
        view.autoresizingMask = [.FlexibleWidth, .FlexibleHeight]
        self.addSubview(view);
        initialInitialization()
    }

}
