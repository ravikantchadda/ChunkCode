//
//  BaseViewController.swift
//  LocalLift
//
//  Created by prabhjot singh on 10/27/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit
import Foundation
import IQKeyboardManagerSwift
import MFSideMenu


class BaseViewController: UIViewController {
    
    enum NavigationType:Int {case ClearNavigationType = 0, BlueNavigationType = 1, MenuNavigationType = 2}
    var BarButtonNotification: ENMBadgedBarButtonItem?
    var countNotification = 0
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        IQKeyboardManager.sharedManager().enable = true
        self.automaticallyAdjustsScrollViewInsets = false
        // Do any additional setup after loading the view.
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // Used to set the type of Navigation Bar
    
    func setNavigationBar(typeNavigation:NavigationType , withLeftMenu _withLeftMenu:Bool)
    {
        self.navigationItem.setHidesBackButton(false, animated: true)
        if typeNavigation == NavigationType.ClearNavigationType
        {
            self.navigationController!.navigationBar.translucent = true
            self.navigationController!.navigationBar.barStyle = UIBarStyle.BlackOpaque
            self.navigationController!.navigationBar.setBackgroundImage(UIImage(), forBarMetrics: UIBarMetrics.Default)
            self.navigationController!.navigationBar.shadowImage = UIImage()
            self.navigationController!.navigationBar.tintColor = UIColor.whiteColor()
            self.navigationController!.navigationBar.translucent = true
            self.navigationController?.navigationBarHidden = false
        }
        else{
            
            self.navigationController!.navigationBar.translucent = false
            self.navigationController!.navigationBar.barStyle = UIBarStyle.Black
            self.navigationController!.navigationBar.barTintColor = UIColor.colorWithRGB(8, green: 29, blue: 61, alpha: 1)
            self.navigationController!.navigationBar.tintColor = UIColor.whiteColor()
            self.navigationController!.navigationBar.setBackgroundImage(nil, forBarMetrics: UIBarMetrics.Default)
            self.navigationController!.navigationBar.shadowImage = nil
            self.navigationController?.navigationBarHidden = false
            
           if(!_withLeftMenu ){
                self.addLeftNavItemOnView()
            }
           else{
                if typeNavigation == NavigationType.MenuNavigationType {
                    setUpCustomBarButton()
                }
            }
        }
        
        
    }
    
    func setNavigationBar(typeNavigation:NavigationType)
    {
        self.navigationItem.setHidesBackButton(false, animated: true)
        if typeNavigation == NavigationType.ClearNavigationType
        {
            self.navigationController!.navigationBar.translucent = true
            self.navigationController!.navigationBar.barStyle = UIBarStyle.BlackOpaque
            self.navigationController!.navigationBar.setBackgroundImage(UIImage(), forBarMetrics: UIBarMetrics.Default)
            self.navigationController!.navigationBar.shadowImage = UIImage()
            self.navigationController!.navigationBar.tintColor = UIColor.whiteColor()
            self.navigationController!.navigationBar.translucent = true
            self.navigationController?.navigationBarHidden = false
        }
        else{
            
            self.navigationController!.navigationBar.translucent = false
            self.navigationController!.navigationBar.barStyle = UIBarStyle.Black
            self.navigationController!.navigationBar.barTintColor = UIColor.colorWithRGB(8, green: 29, blue: 61, alpha: 1)
            self.navigationController!.navigationBar.tintColor = UIColor.whiteColor()
            self.navigationController!.navigationBar.setBackgroundImage(nil, forBarMetrics: UIBarMetrics.Default)
            self.navigationController!.navigationBar.shadowImage = nil
            self.navigationController?.navigationBarHidden = false
            
            if typeNavigation == NavigationType.MenuNavigationType {
                setUpCustomBarButton()
            }
        }
    }
    
    
    
    // Add  left bar button item to navigation bar
    func addLeftNavItemOnView ()
    {
        
        // hide default navigation bar button item
        self.navigationItem.leftBarButtonItem = nil;
        self.navigationItem.hidesBackButton = true;
        // Menu Icon
        let menuButton = UIButton(type: UIButtonType.Custom)
        menuButton.frame = CGRectMake(0, 0, 40, 40)
        menuButton.setImage(UIImage(named:"backIcon.png"), forState: UIControlState.Normal)
        menuButton.addTarget(self, action: "backButtonClick:", forControlEvents: UIControlEvents.TouchUpInside)
        let menuBarButtonItem: UIBarButtonItem = UIBarButtonItem(customView: menuButton)
        
        // App Logo
        let logoButton = UIButton(type: UIButtonType.Custom)
        logoButton.frame = CGRectMake((menuButton.frame.minX + menuButton.frame.width), 0, 100, 37)
        logoButton.setImage(UIImage(named:"logoOfLocalift"), forState: UIControlState.Normal)
        let logoBarButtonItem: UIBarButtonItem = UIBarButtonItem(customView: logoButton)
        
        
//        let negativeSpace:UIBarButtonItem = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.FixedSpace, target: nil, action: nil)
//        negativeSpace.width = -10.0
        //   self.navigationItem.setLeftBarButtonItem(leftBarButtonItem, animated: false)
        self.navigationItem.setLeftBarButtonItems([menuBarButtonItem,logoBarButtonItem ], animated: true)
        
        
        
    }
    
    // Add  left bar button item to navigation bar
    func addRightNavItemOnView ()
    {
        
        // hide default navigation bar button item
        self.navigationItem.rightBarButtonItem = nil;
        // Menu Icon
        let bellButton = UIButton(type: UIButtonType.Custom)
        bellButton.frame = CGRectMake(0, 0, 33, 33)
        bellButton.setImage(UIImage(named:"bellIcon.png"), forState: UIControlState.Normal)
        bellButton.addTarget(self, action: "bellButtonClick:", forControlEvents: UIControlEvents.TouchUpInside)
        let bellBarButtonItem: UIBarButtonItem = UIBarButtonItem(customView: bellButton)
        
        // Calendar icon
        let calendarButton = UIButton(type: UIButtonType.Custom)
        calendarButton.frame = CGRectMake((bellButton.frame.minX + bellButton.frame.width), 0, 33, 33)
        calendarButton.setImage(UIImage(named:"CalendarIcon.png"), forState: UIControlState.Normal)
        calendarButton.addTarget(self, action: "calendarButtonClick:", forControlEvents: UIControlEvents.TouchUpInside)
        let calenderBarButtonItem: UIBarButtonItem = UIBarButtonItem(customView: calendarButton)
        
        
        // Calendar icon
        let flipButton = UIButton(type: UIButtonType.Custom)
        flipButton.frame = CGRectMake((calendarButton.frame.minX + calendarButton.frame.width), 0, 33, 33)
        flipButton.setImage(UIImage(named:"FlipIcon.png"), forState: UIControlState.Normal)
        flipButton.addTarget(self, action: "flipButtonClick:", forControlEvents: UIControlEvents.TouchUpInside)
        let flipBarButtonItem: UIBarButtonItem = UIBarButtonItem(customView: flipButton)
        
        
        //   self.navigationItem.setLeftBarButtonItem(leftBarButtonItem, animated: false)
        self.navigationItem.setRightBarButtonItems([bellBarButtonItem,calenderBarButtonItem,flipBarButtonItem], animated: true)
        
        
        
    }
    
    // Left menu button action
    func leftMenuButtonClick(sender:UIButton!){
        
        
        self.menuContainerViewController.toggleLeftSideMenuCompletion({
            //            let navigationController:UINavigationController = self.menuContainerViewController.centerViewController as! UINavigationController
            //            if self.menuContainerViewController.menuState == MFSideMenuStateLeftMenuOpen{
            //             navigationController.viewControllers[0].view.alpha = 0.5
            //            }
            //            else{
            //                UIView.animateWithDuration(0.5) {
            //                    navigationController.viewControllers[0].view.alpha = 1.0
            //                }
            //
            //            }
            
        })
    }
    
    
    // Used to fetch last controller from stack
    
    func lastViewController()->UIViewController
    {
        let arrayViewControllers:NSArray = self.navigationController!.viewControllers
        return arrayViewControllers[arrayViewControllers.count - 2] as! UIViewController
    }
    
    // Used to fetch any previous controller from stack
    
    func fetchPreviousControllerFromNavigationStack(stackNoFromLast:Int)->UIViewController
    {
        let arrayViewControllers:NSArray = self.navigationController!.viewControllers
        return arrayViewControllers[arrayViewControllers.count - (stackNoFromLast+1)] as! UIViewController
    }
    
    // Used to check the all textfield is filled or not of the superView
    
    func isAllTextFieldFilled(superView:UIView) -> Bool
    {
        for case let textField as UITextField in superView.subviews {
            if textField.text == "" {
                return false
            }
        }
        return true
    }
    
    
    // Used to Clear all the all textfield of the superView
    
    func clearAllTextFields(superView:UIView)
    {
        for case let textField as UITextField in superView.subviews {
            textField.text = ""
        }
    }
    
    
    
    
}
