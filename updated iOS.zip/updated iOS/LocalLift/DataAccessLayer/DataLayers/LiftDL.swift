//
//  LiftDL.swift
//  LocalLift
//
//  Created by prabhjot singh on 12/7/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit
import CoreLocation


// --- - -- - -- - - - -Cancel Model ---- -- - - -- -//

class CancelBO: NSObject {
    var requestIds:NSArray!
    var liftProviderId:NSNumber!
    var liftRequesterId:NSNumber!
    var isCancelSeries:Bool!
    var isAcceptRequest:Bool!
    var message:String!
    
}

class LiftBO: NSObject {
    

    var imagePath:String!
    var liftRequesterName:String!
    var liftRequesterPhoto:String!
    var requestId:NSNumber!
    var requestedDatetime:NSDate!
    var seats:NSNumber!
    var toAddress:String!
    
}

class MapMarkerBO:NSObject{
    var isImmediate:Bool!
    var isOfferRequest:Bool!

    var location:CLLocationCoordinate2D?
    var requestId:NSNumber!
}

class LiftDL: PSRestAPIHelper {
    
    func requestForGetMapMarkers(handler:CompletionHandler)
    {
        self.serviceURL = "GetMapData"
        self.webservice.isShowLoader = true
        self.setContentTypeHeaders()
        
        let dicParam:NSDictionary = ["uid":UserBO.sharedInstanceOfUser.userID]
        
        self.requestforGET(dicParam as! [NSObject : AnyObject!]) { (obj, success) -> Void in
            if success == true{
                if let dicResponse:NSDictionary = obj as? NSDictionary{
                    let arrayOfLifts = NSMutableArray()
                    if let arrayOfData = NSIUtility.getObjectForKey("Data", dictResponse: dicResponse) as? NSArray{
                        for dictionary in arrayOfData{
                            if let dicLift = dictionary as? NSDictionary{
                                let mapMarkerBO:MapMarkerBO = MapMarkerBO()
                                mapMarkerBO.isImmediate =  NSIUtility.getObjectForKey("IsImmediate", dictResponse:dicLift) as! Bool
                                mapMarkerBO.isOfferRequest =  NSIUtility.getObjectForKey("IsOfferRequest", dictResponse:dicLift) as! Bool
                                
                                if let latitudeString = dicLift.objectForKey("Latitude") as? String{
                                    if latitudeString.length != 0{
                                        let lactionLatitude:Double? = Double(latitudeString)
                                        if let laongitudeString = dicLift.objectForKey("Longitude") as? String{
                                            let lactionLongitude:Double? = Double(laongitudeString)
                                            mapMarkerBO.location = CLLocationCoordinate2D(latitude: lactionLatitude!, longitude: lactionLongitude!)
                                        }
                                    }else{
                                        mapMarkerBO.location = CLLocationCoordinate2D(latitude: NSIUtility.randomFloat(-90, max: 90), longitude: NSIUtility.randomFloat(-180, max: 180))
                                    }
                                }else{
                                    mapMarkerBO.location = CLLocationCoordinate2D(latitude: NSIUtility.randomFloat(-90, max: 90), longitude: NSIUtility.randomFloat(-180, max: 180))
                                }
                                mapMarkerBO.requestId =  NSIUtility.getObjectForKey("RequestId", dictResponse:dicLift) as! NSNumber
                                arrayOfLifts.addObject(mapMarkerBO)
                            }
                        }
                            handler(obj: arrayOfLifts, success: true)
                            return
                    }
                }
            
            }else
            {
                handler(obj: obj, success: false)
                return
            }
        }
    }

    
    func requestForGetMarkerInformation(markerBO:MapMarkerBO,handler:CompletionHandler)
    {
        self.serviceURL = "GetLiftInformation"
        self.webservice.isShowLoader = true
        self.setContentTypeHeaders()
//        self.webservice.
        
        let dicParam:NSDictionary = ["rqid":markerBO.requestId,"isoffer":markerBO.isOfferRequest]
        
        self.requestforGET(dicParam as! [NSObject : AnyObject!]) { (obj, success) -> Void in
            if success == true{
                if let dicResponse:NSDictionary = obj as? NSDictionary{
                    if let dictionary = (NSIUtility.getObjectForKey("Data", dictResponse: dicResponse) as? NSArray)?.objectAtIndex(0) as? NSDictionary{
                        let liftBO = LiftBO()
                        liftBO.imagePath = NSIUtility.getObjectForKey("ImagePath", dictResponse: dictionary) as? String
                        liftBO.liftRequesterName = NSIUtility.getObjectForKey("LiftRequesterName", dictResponse: dictionary) as? String
                        liftBO.liftRequesterPhoto = NSIUtility.getObjectForKey("LiftRequesterPhoto", dictResponse: dictionary) as? String
                        liftBO.requestId = NSIUtility.getObjectForKey("RequestId", dictResponse: dictionary) as? NSNumber
                        
                        let dateTimeString = NSIUtility.getObjectForKey("RequestedDatetime", dictResponse:dictionary) as! String
                        liftBO.requestedDatetime = NSDate(fromString: dateTimeString, format: .DotNet)
                        
                        liftBO.seats = NSIUtility.getObjectForKey("Seats", dictResponse: dictionary) as? NSNumber
                        liftBO.toAddress = NSIUtility.getObjectForKey("ToAddress", dictResponse: dictionary) as? String
                        handler(obj: liftBO, success: true)
                    }
                }
            }else{
                handler(obj:obj, success: false)
            }
        }
    }
    
    func requestForAcceptLift(requestID:NSNumber,requestBO:RequestBO,isAccepted:Bool, selectedArray:NSArray,  handler:CompletionHandler)
    {
        self.serviceURL = "AcceptLiftRequest"
        self.webservice.isShowLoader = true
        self.setContentTypeHeaders()

        let  dicParam:NSDictionary
        if requestBO.isRecurring == true{
              dicParam = ["RequestId":(selectedArray.valueForKey("requestReccuringID")),"LiftProviderId":UserBO.sharedInstanceOfUser.userID,"AcceptRequest":isAccepted]
        }else{
            dicParam = ["RequestId":[requestBO.requestId],"LiftProviderId":UserBO.sharedInstanceOfUser.userID,"AcceptRequest":isAccepted]
        }

         self.requestforPOST(dicParam as! [NSObject : AnyObject!]) { (obj, success) -> Void in
            if success == true{
                if let dicResponse:NSDictionary = obj as? NSDictionary{
                    handler(obj: dicResponse, success: true)
                }else{
                     handler(obj: obj, success: false)
                }
            }
            else{
                handler(obj: obj, success: false)
            }
        }
        
    }

    
    
    
    
//    func requestForGetLifts(handler:CompletionHandler)
//    {
//        self.serviceURL = "ViewLiftRequests"
//        self.webservice.isShowLoader = true
//        self.setContentTypeHeaders()
//        
//        let dicParam:NSDictionary = ["lpuid":UserBO.sharedInstanceOfUser.userID,"si":0,"nor":20000]
//        
//        self.requestforGET(dicParam as! [NSObject : AnyObject!]) { (obj, success) -> Void in
//            if success == true{
//                if let dicResponse:NSDictionary = obj as? NSDictionary{
//                    let arrayOfLifts = NSMutableArray()
//                    if let arrayOfData = NSIUtility.getObjectForKey("Data", dictResponse: dicResponse) as? NSArray{
//                        for dictionary in arrayOfData{
//                            if let dicLift = dictionary as? NSDictionary{
//                                let liftBO = LiftBO()
//                                if let dicAddress = NSIUtility.getObjectForKey("ToAddress", dictResponse:dicLift) as? NSDictionary
//                                {
//                                    let addressObj:AddressBO = AddressBO()
//                                    addressObj.addressID = NSIUtility.getObjectForKey("AddressID", dictResponse:dicAddress) as! NSNumber
//                                    addressObj.addressName = NSIUtility.getObjectForKey("AddressName", dictResponse:dicAddress) as! String
//                                    addressObj.city = NSIUtility.getObjectForKey("City", dictResponse:dicAddress) as! String
//                                    addressObj.country = NSIUtility.getObjectForKey("Country", dictResponse:dicAddress) as! String
//                                    addressObj.isActive = NSIUtility.getObjectForKey("IsActive", dictResponse:dicAddress) as! Bool
//                                    addressObj.isNew = NSIUtility.getObjectForKey("IsNew", dictResponse:dicAddress) as! Bool
//                                    addressObj.isPrimary = NSIUtility.getObjectForKey("IsPrimary", dictResponse:dicAddress) as! Bool
//                                    addressObj.state = NSIUtility.getObjectForKey("State", dictResponse:dicAddress) as! String
//                                    addressObj.streetAddress = NSIUtility.getObjectForKey("StreetAddress", dictResponse:dicAddress) as! String
//                                    addressObj.unit = NSIUtility.getObjectForKey("Unit", dictResponse:dicAddress) as! String
//                                    addressObj.zipCode = NSIUtility.getObjectForKey("ZipCode", dictResponse:dicAddress) as! String
//                                    addressObj.addressType = "Home"
//                                    
//                                    if let latitudeString = dicAddress.objectForKey("Latitude") as? String{
//                                        let lactionLatitude:Double? = Double(latitudeString)
//                                        if let laongitudeString = dicAddress.objectForKey("Longitude") as? String{
//                                            let lactionLongitude:Double? = Double(laongitudeString)
//                                            addressObj.locationCords = CLLocationCoordinate2D(latitude: lactionLatitude!, longitude: lactionLongitude!)
//                                        }
//                                    }else{
//                                        addressObj.locationCords = CLLocationCoordinate2D(latitude: NSIUtility.randomFloat(-90, max: 90), longitude: NSIUtility.randomFloat(-180, max: 180))
//                                    }
//                                    
//                                    liftBO.addressBO  = addressObj
//                                }
//                                
//                                liftBO.isImmediate = NSIUtility.getObjectForKey("IsImmediate", dictResponse:dicLift) as! Bool
//                                liftBO.isOfferRequest = NSIUtility.getObjectForKey("IsOfferRequest", dictResponse:dicLift) as! Bool
//                                liftBO.liftFrequencyType = NSIUtility.getObjectForKey("LiftFrequencyType", dictResponse:dicLift) as! String
//                                liftBO.liftName = NSIUtility.getObjectForKey("LiftName", dictResponse:dicLift) as! String
//                                liftBO.liftRequesterName = NSIUtility.getObjectForKey("LiftRequesterName", dictResponse:dicLift) as! String
//                                liftBO.liftRequesterPhoto = NSIUtility.getObjectForKey("LiftRequesterPhoto", dictResponse:dicLift) as! String
//                                liftBO.liftRequesterPhotoPath = NSIUtility.getObjectForKey("LiftRequesterPhotoPath", dictResponse:dicLift) as! String
//                                liftBO.message = NSIUtility.getObjectForKey("Message", dictResponse:dicLift) as! String
//                                liftBO.passengerCount = NSIUtility.getObjectForKey("PassengerCount", dictResponse:dicLift) as! NSNumber
//                                liftBO.requestCreatorId = NSIUtility.getObjectForKey("RequestCreatorId", dictResponse:dicLift) as! NSNumber
//                                liftBO.requestId = NSIUtility.getObjectForKey("RequestId", dictResponse:dicLift) as! NSNumber
//                                liftBO.requestStatus = NSIUtility.getObjectForKey("RequestStatus", dictResponse:dicLift) as! String
//                                let dateTimeString = NSIUtility.getObjectForKey("RequestedDatetime", dictResponse:dicLift) as! String
//                                liftBO.requestedDatetime = NSDate(fromString: dateTimeString, format: .DotNet)
//                                let endDateTime = NSIUtility.getObjectForKey("RequestEndDatetime", dictResponse:dicLift) as! String
//                                liftBO.requestEndDatetime = NSDate(fromString: endDateTime, format: .DotNet)
//                                
//                                arrayOfLifts.addObject(liftBO)
//                            }
//                        }
//                    }
//                    handler(obj: arrayOfLifts, success: true)
//                    return
//                }
//            }
//            else{
//                
//                handler(obj: obj, success: false)
//            }
//        }
//    }
    
    // Create Passenger
    func requestForCancelLiftRequest(cancelBO:CancelBO, handler:CompletionHandler)
    {
        self.serviceURL = "CancelLiftRequest"
        self.webservice.isShowLoader = true
        self.setContentTypeHeaders()
        
        let dicParam:NSDictionary = ["RequestId":cancelBO.requestIds,"LiftProviderId":cancelBO.liftProviderId,"LiftRequesterId":cancelBO.liftRequesterId,"Message":cancelBO.message,"CancelSeries":cancelBO.isCancelSeries,"AcceptRequest":cancelBO.isAcceptRequest]
        
        NSIUtility.showJsonData(dicParam)
        
        self.requestforPOST(dicParam as! [NSObject : AnyObject!]) { (obj, success) -> Void in
            if success == true{
                if let dicResponse:NSDictionary = obj as? NSDictionary{
                    handler(obj: dicResponse, success: true)
                }
            }
            else{
                handler(obj: obj, success: false)
            }
        }
        
    }
    
}
