//
//  SelectPickupAddressVC.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/27/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class SelectPickupAddressVC: BaseViewController,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate {

    @IBOutlet var tableOfSavedAdd: UITableView!
    @IBOutlet var searchAddressBar: UISearchBar!
    
    var arrayOfAddresses = NSArray()
    var filteredAddressArray = NSArray()
    var searchActive : Bool = false
    var addAdressView:AddressCell!
    
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBar(.BlueNavigationType)
        self.title = "Request Lift"
        self.navigationItem.setHidesBackButton(true, animated: true)
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.Plain, target: self, action: "toCancel")
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        if let liftRequstVC:LiftRequestVC = self.fetchPreviousControllerFromNavigationStack(1) as? LiftRequestVC{
            if liftRequstVC.locType == .ToLocation{
                searchAddressBar.placeholder = "Search Destination"
            }else{
                searchAddressBar.placeholder = "Search Pickup"
            }
        }
        
        self.initialInitialization()
    }
    
    func initialInitialization()
    {
        tableOfSavedAdd.registerNib(UINib.init(nibName: "AddressCell", bundle: nil), forCellReuseIdentifier: "AddressCell")
        self.addAdressView = tableOfSavedAdd.dequeueReusableCellWithIdentifier("AddressCell") as! AddressCell
        self.addAdressView.lblTitleType.text = "Add New Address"
        self.addAdressView.lblAddress.text = "Click here to add new Address"
        tableOfSavedAdd.tableFooterView = self.addAdressView
        
        let gesture:UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "toAddNewAddress")
        tableOfSavedAdd.tableFooterView?.addGestureRecognizer(gesture)
        
        self.fetchListOfAddresses()
    }
    
    func toAddNewAddress(){
        let adressVC = NSIUtility.fetchViewControllerWithName("AddNewAddressVC", storyBoardName: "Home")
        self.navigationController?.pushViewController(adressVC, animated: true)
    }
    
    func fetchListOfAddresses(){
        let userDL = UserDL()
        userDL.requestforAddresses { (obj, success) -> Void in
            if success == true
            {
                self.arrayOfAddresses = obj as! NSArray
                self.tableOfSavedAdd.delegate = self
                self.tableOfSavedAdd.dataSource = self
                self.tableOfSavedAdd.reloadData()
            }
        }
    }
    

    
    //MARK: - Table VIew Delegates
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searchActive == true{
            return filteredAddressArray.count
        }
        else{
            return arrayOfAddresses.count
        }
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat{
        
        return self.addAdressView.height
    }

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell:AddressCell = (tableView.dequeueReusableCellWithIdentifier("AddressCell", forIndexPath: indexPath) as? AddressCell)!
        
        let addreesBO:AddressBO
        
        if searchActive == false{
            addreesBO = arrayOfAddresses[indexPath.row] as! AddressBO
        }
        else{
            addreesBO = filteredAddressArray[indexPath.row] as! AddressBO
        }
        
        cell.lblAddress.text = addreesBO.streetAddress
        cell.lblTitleType.text = addreesBO.addressType
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let addressObj:AddressBO
        if searchActive == false{
            addressObj = arrayOfAddresses[indexPath.row] as! AddressBO
        }
        else{
            addressObj = filteredAddressArray[indexPath.row] as! AddressBO
        }
        
    // Pop To Controller
        
        if let liftRequstVC:LiftRequestVC = self.fetchPreviousControllerFromNavigationStack(1) as? LiftRequestVC{
            
            print(liftRequstVC.locType)
//            print( "\(liftRequstVC.toLocationData!.locationCords.latitude)" + "   " +  "\(liftRequstVC.toLocationData!.locationCords.longitude)")
            
            if liftRequstVC.locType == .FromLocation{
                if liftRequstVC.toLocationData != nil{
                    if liftRequstVC.toLocationData!.locationCords.latitude ==  addressObj.locationCords.latitude && liftRequstVC.toLocationData!.locationCords.longitude ==  addressObj.locationCords.longitude{
                        NSIUtility.show("Both Location should not be same")
                        return
                    }else if liftRequstVC.toLocationData!.streetAddress == addressObj.streetAddress {
                         NSIUtility.show("Both Location should not be same")
                    }
                }
            }else{
                if liftRequstVC.fromLocationData != nil{
                    if liftRequstVC.fromLocationData!.locationCords.latitude ==  addressObj.locationCords.latitude && liftRequstVC.fromLocationData!.locationCords.longitude ==  addressObj.locationCords.longitude{
                        NSIUtility.show("Both Location should not be same")
                        return
                    }else if liftRequstVC.fromLocationData!.streetAddress == addressObj.streetAddress {
                        NSIUtility.show("Both Location should not be same")
                    }
                }
            }
            
            if liftRequstVC.locType == .FromLocation{
                liftRequstVC.fromLocationData = addressObj
            }else{
                liftRequstVC.toLocationData = addressObj
            }
            self.navigationController?.popToViewController(liftRequstVC, animated: true)
        }
        
//        let signUPVCObj:SignUpVC = self.lastViewController() as! SignUpVC
//        signUPVCObj.countryObj = countryObj
//        self.navigationController!.popViewControllerAnimated(true)
        
    }
    
    //MARK: - Search Bar Delegates
    
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        if(filteredAddressArray.count == 0){searchActive = false;} else {searchActive = true;}}
    
    func searchBarTextDidEndEditing(searchBar: UISearchBar) {searchActive = false}
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {searchActive = false; self.view.endEditing(true); self.tableOfSavedAdd.reloadData(); searchBar.text = ""}
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {searchActive = false;self.view.endEditing(true)}
    
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        
        let predicate:NSPredicate = NSPredicate(format: "(addressName CONTAINS[c] %@ OR addressType CONTAINS[c] %@)", argumentArray:[searchText,searchText])
        
        filteredAddressArray = self.arrayOfAddresses.filteredArrayUsingPredicate(predicate) as NSArray
        
        if(filteredAddressArray.count == 0){
            searchActive = false;
        } else {
            searchActive = true;
        }
        self.tableOfSavedAdd.reloadData()
    }

    
    @IBAction func toCancel(){
        self.navigationController?.popViewControllerAnimated(false)
    }

}
