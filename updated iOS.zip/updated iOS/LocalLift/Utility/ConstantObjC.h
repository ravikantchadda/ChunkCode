//
//  ConstantObjC.h
//  LocalLift
//
//  Created by prabhjot singh on 10/26/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

#ifndef ConstantObjC_h
#define ConstantObjC_h


//#import "UIAlertController+Blocks.h"


// === sigleton helper

#define singleton_impl(methodname, classname) \
+ (classname *) methodname \
{ \
static id instance; \
static dispatch_once_t onceToken; \
dispatch_once(&onceToken, ^{ \
instance = [classname new]; \
}); \
return instance; \
}


// === facilities

#define UIMsg(fmt, ...)  { UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kProductName message:[NSString stringWithFormat:fmt, ##__VA_ARGS__]  delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil]; [alert show]; }

#define DEBUG_FACILITIES_ENABLED 1

#ifdef DEBUG_FACILITIES_ENABLED
#define PSLog( s, ... ) NSLog( @"<%p %@:(%d)> %@", self, [[NSString stringWithUTF8String:__FILE__] lastPathComponent], __LINE__, [NSString stringWithFormat:(s), ##__VA_ARGS__] )
#else
#define PSLog( s, ... )
#endif

// --- Singlton Macros

#define stringIfNull(obj)  if([obj isKindOfClass:[NSNull class]] || !obj || [obj isEqual:[NSNull null]]) obj = @""


#endif /* ConstantObjC_h */
