 //
//  NotifyPeopleVC.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/30/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit
import SwiftAddressBook
import MBProgressHUD





class NotifyPeopleVC: BaseViewController,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate {

    @IBOutlet var tableOfSavedAdd: UITableView!
    @IBOutlet var searchAddressBar: UISearchBar!
    
    var arrayOfAddresses = NSMutableArray()
    var filteredAddressArray = NSArray()
    var searchActive : Bool = false
    
    @IBOutlet var btnAddSelected: UIButton!
    var selectedArray = NSMutableArray()

//    var selectedArray:NSMutableArray!

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBar(.BlueNavigationType)
        self.title = "Notify People"
   
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.initialInitialization()
    }
    
    
    func fetchAllContactsDataFromMobileAndGetData(){
        
        MBProgressHUD.showHUDAddedTo(self.view, animated: true)
        
        
        swiftAddressBook?.requestAccessWithCompletion({ (success, error) -> Void in
            if success {
                //do something with swiftAddressBook
                
                let arrayOfEmails = NSMutableArray()
                let arrayOfMobileNo = NSMutableArray()
                if let people = swiftAddressBook?.allPeople {

                    for person in people {
                        
                        if person.emails != nil{
                            if let arrayOfPersonEmail:[String] = (person.emails?.map({$0.value}))!{
                                for strEmails in arrayOfPersonEmail{
                                    if NSIUtility.validateEmailWithoutAlert(strEmails){
                                        if strEmails != UserBO.sharedInstanceOfUser.userEmailAddress{
                                            arrayOfEmails.addObject(strEmails)
                                        }
                                    }
                                }
                            }
                        }
                        if person.phoneNumbers != nil{
                            if let arrayOfPersonNo:[String] = (person.phoneNumbers?.map({$0.value}))!{
                                for strNo in arrayOfPersonNo{
//                                    if strNo.length == 11{
                                        arrayOfMobileNo.addObject("\(NSIUtility.removeSpecialCharsFromString(strNo))")
//                                    }
//                                    arrayOfMobileNo.addObject(NSString(string: NSIUtility.removeSpecialCharsFromString(strNo)))
                                }
                            }
                        }
                    }
                    

            // Fetch Array Of Contacts through giving mobile data
                    if arrayOfEmails.count != 0 || arrayOfMobileNo.count != 0{
                        
//                        if arrayOfMobileNo.count == 0{ arrayOfMobileNo = ["+55556485834"] }
                        
                        let contactDL = ContactsDL()
                        contactDL.requestforContacts(arrayOfEmails, arrayOfNumbers: arrayOfMobileNo, handler: { (obj, success) -> Void in
                            
//                             )
                            if success == true {
                                if let arrayAdress = obj as? NSMutableArray{
                                    self.arrayOfAddresses = arrayAdress
                                    self.filterTheAddress()
                                    self.tableOfSavedAdd.delegate = self
                                    self.tableOfSavedAdd.dataSource = self
                                    
                                    
                                    dispatch_async(dispatch_get_main_queue(), { () -> Void in
                                        self.tableOfSavedAdd.reloadData()
                                        MBProgressHUD.hideAllHUDsForView(self.view, animated: true)
                                        self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
                                    })
                                }
                            }else{
                                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                                    MBProgressHUD.hideAllHUDsForView(self.view, animated: true)
                                    NSIUtility.show("Unable to fetch contacts.")
                                    self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
                                })

                            }
                        })
                    }else{
                        
                        dispatch_async(dispatch_get_main_queue(), { () -> Void in
                            MBProgressHUD.hideAllHUDsForView(self.view, animated: true)
                            NSIUtility.show("Unable to fetch phone contacts.")
                            self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
                        })

                    }
                }
            }
            else {
                //no success. Optionally evaluate error
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                    NSIUtility.show("Please enable the access of contacts from settings")
                    self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
                })
            }
        })
        
    }
    
    func initialInitialization()
    {
        tableOfSavedAdd.registerNib(UINib.init(nibName: "SelectPassengerCell", bundle: nil), forCellReuseIdentifier: "SelectPassengerCell")
        self.fetchAllContactsDataFromMobileAndGetData()
    }
    
    
    func filterTheAddress(){
        if self.arrayOfAddresses.count != 0{
//            if selectedArray != nil{
                for var i = 0; i < self.selectedArray.count ; i++ {
                    
                    if let selcetedContact:ContactsBO = selectedArray[i] as? ContactsBO{
                        let predicate:NSPredicate = NSPredicate(format: "userID == %@", argumentArray:[selcetedContact.userID])
                        let arrayFiltered = self.arrayOfAddresses.filteredArrayUsingPredicate(predicate)
                        if arrayFiltered.count != 0{
                            let contactPerson:ContactsBO = arrayFiltered[0] as! ContactsBO
                            contactPerson.isSelected = true
                        }
                     }
                }
//            }
        }
    }
    
    //MARK: - Table VIew Delegates
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searchActive == true{
            return filteredAddressArray.count
        }
        else{
            return arrayOfAddresses.count
        }
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat
    {
        return 75;
    }
    
    //  Header View
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?{
        
        if let viewHeader:ViewOfLinkedPassenger = UIView.viewFromNibName("ViewOfLinkedPassenger") as? ViewOfLinkedPassenger {
            viewHeader.lblSectionName.text = "My Contacts"
            return viewHeader
        }
        return UIView()
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat{
        
        if let viewHeader:ViewOfLinkedPassenger = UIView.viewFromNibName("ViewOfLinkedPassenger") as? ViewOfLinkedPassenger {
            return viewHeader.height}
        else{
            return 0
        }
    }

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell:SelectPassengerCell = (tableView.dequeueReusableCellWithIdentifier("SelectPassengerCell", forIndexPath: indexPath) as? SelectPassengerCell)!
        
        let contactBO:ContactsBO
        
        if searchActive == false{
            contactBO = arrayOfAddresses[indexPath.row] as! ContactsBO
        }
        else{
            contactBO = filteredAddressArray[indexPath.row] as! ContactsBO
        }
        
        cell.lblEmailOfPassenger.text = contactBO.emailAddress
        cell.lblNameOfPassenger.text = contactBO.firstName + " " + contactBO.lastName
        cell.btnSelectedPassenger.addTarget(self, action: "toSelectPeople:", forControlEvents: .TouchUpInside)
        cell.btnSelectedPassenger.addTarget(self, action: "toSelectPeople:", forControlEvents: .TouchUpInside)
        
        cell.btnSelectedPassenger.setImage(UIImage(named: "blue_unchecked"), forState: UIControlState.Normal)
        cell.btnSelectedPassenger.setImage(UIImage(named: "blue_checked"), forState: UIControlState.Selected)
        
        cell.btnSelectedPassenger.selected = contactBO.isSelected
        
        
        return cell
    }
    
    func toSelectPeople(sender:UIButton){
        
//        if selectedArray != nil{selectedArray = NSMutableArray() }
        
        sender.selected = !sender.selected
        
        let buttonPosition:CGPoint = sender.convertPoint(CGPointZero, toView: self.tableOfSavedAdd)
        let indexPath:NSIndexPath? = self.tableOfSavedAdd.indexPathForRowAtPoint(buttonPosition)
        
        var contactBO:ContactsBO!
        
        if searchActive == false{
            contactBO = arrayOfAddresses[indexPath!.row] as! ContactsBO
        }
        else{
            contactBO =  filteredAddressArray[indexPath!.row] as! ContactsBO
        }
        
        contactBO.isSelected = sender.selected
        
        
        if sender.selected{
            if contactBO.emailAddress != UserBO.sharedInstanceOfUser.userEmailAddress{
                selectedArray.addObject(contactBO)
            }
        }else{
                let predicate:NSPredicate = NSPredicate(format: "userID == %@", argumentArray:[contactBO.userID])
                let arrayFiltered = self.selectedArray.filteredArrayUsingPredicate(predicate)
                if arrayFiltered.count != 0{
                    let contactCheckedBO = arrayFiltered[0] as! ContactsBO
                    selectedArray.removeObject(contactCheckedBO)
                }
            
            }
//        self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
    }

    //MARK: - Search Bar Delegates
    
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        if(filteredAddressArray.count == 0){searchActive = false;} else {searchActive = true;}}
    
    func searchBarTextDidEndEditing(searchBar: UISearchBar) {searchActive = false}
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {searchActive = false; self.view.endEditing(true); self.tableOfSavedAdd.reloadData(); searchBar.text = ""}
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {searchActive = false;self.view.endEditing(true)}
    
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        
        let predicate:NSPredicate = NSPredicate(format: "(emailAddress CONTAINS[c] %@ OR firstName CONTAINS[c] %@ OR lastName CONTAINS[c] %@)", argumentArray:[searchText,searchText,searchText])
        
        filteredAddressArray = self.arrayOfAddresses.filteredArrayUsingPredicate(predicate) as NSArray
        
        if(filteredAddressArray.count == 0){
            searchActive = false;
        } else {
            searchActive = true;
        }
        self.tableOfSavedAdd.reloadData()
    }
    
    @IBAction func toAddSelectedBtn(sender: AnyObject) {

        if let liftVC =  self.fetchPreviousControllerFromNavigationStack(1) as? LiftRequestVC{
//            liftVC.cellOfPeopleToNotify.arrayOfNotifyPeople.removeAllObjects()
//            liftVC.cellOfPeopleToNotify.arrayOfNotifyPeople.arrayByAddingObjectsFromArray(selectedArray as [AnyObject])
            let arraSelected = selectedArray as NSArray
            liftVC.cellOfPeopleToNotify.arrayOfNotifyPeople = arraSelected as! NSMutableArray
            liftVC.cellOfPeopleToNotify.collOfPsgr.reloadData()
            self.navigationController?.popToViewController(liftVC, animated: true)
        }
    }

    func toSelectBtnValidation()
    {
        if (self.arrayOfAddresses.count == 0){
            btnAddSelected.backgroundColor = UIColor.colorWithRGB(31, green: 81, blue: 108, alpha:0.7)
        }
        else{
            btnAddSelected.backgroundColor = Constants.APP_THEME_COLOR
        }
    }
  
}
    
    
