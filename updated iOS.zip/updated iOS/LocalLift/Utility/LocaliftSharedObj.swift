//
//  LocaliftSharedObj.swift
//  LocalLift
//
//  Created by prabhjot singh on 12/17/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit
import ActionSheetPicker_3_0

class LocaliftSharedObj: NSObject {

    static let sharedInstance = LocaliftSharedObj()
//Just false while sending to client
    //else true that flag
//    var isDevoloping = false
    var isDevoloping = true
    var serverAddress = "http://107.151.2.82:1005/"
    var isTesting = false
    
// fetch URL
    func fetchBaseURL(){
        if LocaliftSharedObj.sharedInstance.isTesting == true{
            LocaliftSharedObj.sharedInstance.serverAddress = "http://107.151.2.82:1001/"
            
        }else{
            LocaliftSharedObj.sharedInstance.serverAddress = "http://107.151.2.82:1005/"
        }
    }
    
    func openActionPicker(delegate:UIViewController){
        
        ActionSheetStringPicker.showPickerWithTitle("Select Server URL", rows:["Testing URL","Developement URL"], initialSelection:(LocaliftSharedObj.sharedInstance.isTesting ? 0:1), doneBlock: {
            picker, index ,value in
            if index == 0{
                LocaliftSharedObj.sharedInstance.isTesting = true
            }else{
                LocaliftSharedObj.sharedInstance.isTesting = false
            }
            LocaliftSharedObj.sharedInstance.fetchBaseURL()
            
            }, cancelBlock: { ActionStringCancelBlock in return }, origin: delegate.view)
    }
    
}
