//
//  ViewOfLinkedPassenger.swift
//  LocalLift
//
//  Created by Sarishti on 11/26/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class ViewOfLinkedPassenger: UIView {

    @IBOutlet var lblSectionName: UILabel!
    
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */
    

}
