//
//  ResendPasswordVC.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/16/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class ResendPasswordVC: BaseViewController {

    @IBOutlet var lblEmailAdd: UILabel!
    
    var emailAddString:String!
    
//MARK: - View Life Cycle Methods
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationItem.setHidesBackButton(true, animated: true)
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.Plain, target: self, action: "toCancel")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblEmailAdd.text = emailAddString
    }
    
//MARK: - Button Methods
    
    @IBAction func toResendEmail(sender: UIButton) {
        
        if NSIUtility.validateEmail(emailAddString){
            
            let userDL:UserDL = UserDL()
            userDL.requestForForgetPassword(emailAddString, handler: { (obj, success) -> Void in
                if success == true{
                    if let dicResponse:NSDictionary = obj as? NSDictionary{
                        let alertMessgae:String = NSIUtility.getObjectForKey("Message", dictResponse: dicResponse) as! String
                        self.navigationController?.popViewControllerAnimated(true)
                        NSIUtility.show(alertMessgae)
                    }
                }else{
                    NSIUtility.show(Constants.kSomethingWrong)
                }
            })
        }
        
    }
    
    @IBAction func toCancel(){
        if let controller:SignInVC = self.fetchPreviousControllerFromNavigationStack(2) as? SignInVC{
            self.navigationController?.popToViewController(controller, animated: true)
        }
    }
    
}
