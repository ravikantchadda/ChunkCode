//
//  MonthYearPickerVW.swift
//  MonthYearPicker
//
//  Created by Rajesh Kapur on 12/24/15.
//  Copyright © 2015 Rajesh Kapur. All rights reserved.
//

import UIKit
protocol MonthYearPickerViewProtocol{

    func doneButtonPressed();
    func cancelMonthYearPickerView();
}


class MonthYearPickerVW: UIView {

    let expiryDatePicker = MonthYearPickerView()
    var selectedString:String?
     var delegate:MonthYearPickerViewProtocol?
    @IBAction func btnDone(sender: AnyObject) {
        if let stringMonthYear = self.selectedString {
        print(stringMonthYear)
            if(delegate != nil) {
                delegate?.doneButtonPressed()
            }
        }
        
    }
    
    @IBAction func cancelButtonPressed(sender: AnyObject) {
        if(delegate != nil) {
            delegate?.cancelMonthYearPickerView()
        }
    }
    // MARK:-  Our custom view from the XIB file
    var view: UIView!
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadViewFromNib ()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        loadViewFromNib ()
    }
    func loadViewFromNib() {
        let bundle = NSBundle(forClass: self.dynamicType)
        let nib = UINib(nibName: "MonthYearPickerVW", bundle: bundle)
        let view = nib.instantiateWithOwner(self, options: nil)[0] as! UIView
        view.frame = bounds
        view.autoresizingMask = [.FlexibleWidth, .FlexibleHeight]
        self.addSubview(view);
        let viewForPicker = self.viewWithTag(1)
//        self.expiryDatePicker.frame = viewForPicker!.bounds
        viewForPicker!.addSubview(self.expiryDatePicker)
        self.selectedString = self.expiryDatePicker.firstYear
        expiryDatePicker.onDateSelected = { (month: Int, year: Int) in
            let string = String(format: "%02d/%d", month, year)
            NSLog(string) // should show something like 05/2015
            
            self.selectedString = string
        }
    }
    
    func updatePickerBounds() {
//        self.expiryDatePicker.frame = viewForPicker!.bounds
      self.expiryDatePicker.center = CGPointMake(CGRectGetWidth(self.frame)/2, CGRectGetHeight(self.frame)/2)
    }


}
