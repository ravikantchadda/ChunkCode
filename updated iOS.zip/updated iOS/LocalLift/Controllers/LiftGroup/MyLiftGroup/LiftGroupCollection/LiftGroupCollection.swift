//
//  LiftGroupCollection.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/21/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class LiftGroupCollection: UIView,UICollectionViewDelegateFlowLayout, UICollectionViewDataSource  {

    let identifier = "LiftGroupCell"
     var delegate:ColectionCellSelectProtocol?
    var arrayViewForLiftGroup = NSMutableArray()
    
     @IBOutlet weak var collectionViewForLiftGroup: UICollectionView!
    
    //MARK:- Intial function
    func Intilization() {
          let nib = UINib(nibName: "LiftGroupCell", bundle:nil)
          self.collectionViewForLiftGroup.registerNib(nib, forCellWithReuseIdentifier: "LiftGroupCell")
          self.arrayViewForLiftGroup = NSMutableArray()
        
          collectionViewForLiftGroup.dataSource = self
          collectionViewForLiftGroup.delegate = self
    }
    
    func reloadCollectionView() {
       collectionViewForLiftGroup.reloadData()
    }
    
    //MARK:- Collection view delegate
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrayViewForLiftGroup.count + 1
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell:LiftGroupCell = (collectionView.dequeueReusableCellWithReuseIdentifier(identifier, forIndexPath: indexPath) as? LiftGroupCell)!
        if(self.arrayViewForLiftGroup.count == indexPath.row) {
            cell.lblLiftGroupTitle.text = "Create Lift Group"
        }
        else {
        let dicOfLiftGroup = self.arrayViewForLiftGroup[indexPath.row] as? SelectedLiftGroupBO
            cell.lblLiftGroupTitle.text = dicOfLiftGroup?.groupName
        }
        return cell
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize   {
        return CGSize(width: (collectionView.frame.size.width/2)-22, height: 158)
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        if(delegate != nil) {
            delegate?.select()
        }
    }
    
    // MARK:-  Our custom view from the XIB file
    var view: UIView!
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadViewFromNib ()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        loadViewFromNib ()
    }
    func loadViewFromNib() {
        let bundle = NSBundle(forClass: self.dynamicType)
        let nib = UINib(nibName: "LiftGroupCollection", bundle: bundle)
        let view = nib.instantiateWithOwner(self, options: nil)[0] as! UIView
        view.frame = bounds
        view.autoresizingMask = [.FlexibleWidth, .FlexibleHeight]
        self.addSubview(view);
    }
    
}


