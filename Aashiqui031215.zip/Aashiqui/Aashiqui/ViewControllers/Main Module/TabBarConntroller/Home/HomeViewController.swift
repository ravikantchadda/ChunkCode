//
//  HomeViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 18/09/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit
import AVFoundation

class HomeViewController: UIViewController,TaggedFriendsViewDelegate, ReportFeedDelegate {
    @IBOutlet weak var tblVwFeed: UITableView!
    var objLoginModel = Login()
    var arrFeedData: NSMutableArray! = []
    var arrIsViewed: NSMutableArray! = []
    var pageFeed = 1
    var isBookmarked: NSInteger!
    var lblCount: UILabel!
    var isAudioPlaying: Bool = false
    var audioPlayingIndex: NSIndexPath!
    var strNotificationCount: String = "0"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.navigationController?.navigationBar.translucent = false
        self.navigationItem.title = ""
        self.navigationItem.titleView = Utility.navBarTitleLabel("Aashiqui")
        self.navigationItem.hidesBackButton = false
        tblVwFeed.tableFooterView = UIView(frame: CGRectZero)
        
        if((objLoginModel.userPost) != nil){
            print("userAuthToken-- \(objLoginModel.userAuthToken)")
            NSIConstants.userDefaults.setValue(objLoginModel.userAuthToken, forKey: "AUTHTOKEN")
            NSIConstants.userDefaults.setValue(objLoginModel.userId, forKey: "userId")
            NSIConstants.userDefaults.setObject(["firstName":objLoginModel.userFirstName,"lastName":objLoginModel.userLastName,"email":objLoginModel.userEmail], forKey: "userData")
            NSIConstants.userDefaults.synchronize()
            
            //Feed Model
            let arrData = objLoginModel.userPost.mutableCopy() as! NSMutableArray
            arrFeedData = Feed().fillDataInModel(arrData)
            arrFeedData.enumerateObjectsUsingBlock({ object, index, stop in
                let objFeedCell:Feed = self.arrFeedData.objectAtIndex(index) as! Feed
                self.arrIsViewed.addObject(objFeedCell.isViewed)
            })
            print("arrFeedData-- \(arrFeedData)")
        }
        
        //Notification Count Label
        let screenSize: CGFloat = UIScreen.mainScreen().bounds.width
        let btnCenter = CGPointMake((screenSize/4)/2, 25)
        lblCount = UILabel(frame: CGRectMake(0, 0, 16, 16))
        lblCount.center = CGPointMake(btnCenter.x + 5, btnCenter.y - 12)
        lblCount.textAlignment = NSTextAlignment.Center
        lblCount.text = "0"
        lblCount.textColor = UIColor.whiteColor()
        lblCount.font = UIFont(name: "Lato-Regular", size: 10)
        lblCount.backgroundColor = UIColor(red: 251.0/255.0, green: 135.0/255.0, blue: 0.0/255.0, alpha: 1.0)
        lblCount.layer.cornerRadius = 8
        lblCount.clipsToBounds = true
        lblCount.layer.borderWidth = 1.0
        lblCount.layer.borderColor = UIColor.whiteColor().CGColor
        self.view.addSubview(lblCount)
        lblCount.hidden = true
        
        
        // MARK: - Pull to refresh and Infinite scrolling
        tblVwFeed.addPullToRefreshHandler {
            if (Utility.checkNetwork() == true){
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), { () -> Void in
                self.pageFeed = 1
                let dict:NSDictionary = [
                    "userId": NSIConstants.userDefaults.valueForKey("userId") as! String,
                    "page": "\(self.pageFeed)"
                ]
                print("\(dict)")
                self.fnGetFeedsWebServiceWithPostDic(dict, showLoader: false, isReload: true)
            })
            }
        }
        tblVwFeed.addInfiniteScrollingWithHandler {
            if (Utility.checkNetwork() == true){
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), { () ->  Void in
                self.pageFeed += 1
                let dict:NSDictionary = [
                    "userId": NSIConstants.userDefaults.valueForKey("userId") as! String,
                    "page": "\(self.pageFeed)"
                ]
                print("\(dict)")
                self.fnGetFeedsWebServiceWithPostDic(dict, showLoader: false, isReload: false)
            })
        }
        }
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        fnGetFeedAPICall()
        fnCallPushNotificationUpdate()
    }
    
    func fnCallPushNotificationUpdate(){
        //GCD Backgroung queue
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)) {
            // do your task
            let dict:NSDictionary = [
                "userId": NSIConstants.userDefaults.valueForKey("userId") as! String,
            ]
            print("\(dict)")
            self.fnGetNotificationCountWebServiceWithPostDic(dict, showLoader: false)
            dispatch_async(dispatch_get_main_queue()) {
                // update some UI
                self.fnUpdateNotificationCount()
            }
        }
    }
    
    func fnUpdateNotificationCount() {
        if strNotificationCount != "0" {
            lblCount.hidden = false
            self.lblCount.text = strNotificationCount
        }else{
            lblCount.hidden = true
        }
        
    }
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        if isAudioPlaying == true {
            if AudioPlay.sharedInstance.audioPlayerBool == true {
                AudioPlay.sharedInstance.myPlayer.stop()
            }
        }
        isAudioPlaying = false
    }
    
    func fnGetFeedAPICall(){
        pageFeed = 1
        isBookmarked = nil
        let dict:NSDictionary = [
            "userId": NSIConstants.userDefaults.valueForKey("userId") as! String,
            "page": "1"
        ]
        print("\(dict)")
        fnGetFeedsWebServiceWithPostDic(dict, showLoader: true, isReload: true)
    }
    // MARK: - Webservice Call Methods
    //Get Feed API
    func fnGetFeedsWebServiceWithPostDic(dict: NSDictionary! , showLoader: Bool, isReload: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        ObjWebserviceCall.cachePolicy = WebserviceCallCachePolicyRequestFromCacheFirstAndThenFromUrlAndUpdateInCache
        if(showLoader){
            ObjWebserviceCall.isShowLoader = true
        }else{
            ObjWebserviceCall.isShowLoader = false
        }
        
        ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":NSIConstants.userDefaults.valueForKey("AUTHTOKEN") as! String]
        ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceGetFeeds)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
            let response = response
            //            if(response.isResponseFromCache){
            //                print("GetFeedResponseCache \(response.webserviceResponse)")
            //            }else{
            print("GetFeedResponse \(response.webserviceResponse)")
            if (response.webserviceResponse != nil) {
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    if isReload {
                        if(self.arrFeedData != nil && self.arrFeedData.count > 0){
                            self.arrFeedData.removeAllObjects()
                            self.arrIsViewed.removeAllObjects()
                        }
                    }
                    //Feed Model
                    let arrData = response.webserviceResponse.valueForKey("feeds") as! NSArray
                    let arrDataModel = Feed().fillDataInModel(arrData)
                    arrDataModel.enumerateObjectsUsingBlock({ object, index, stop in
                        self.arrFeedData.addObject(arrDataModel.objectAtIndex(index))
                        let objFeedCell:Feed = arrDataModel.objectAtIndex(index) as! Feed
                        self.arrIsViewed.addObject(objFeedCell.isViewed)
                    })
                    print("arrFeedData-- \(self.arrFeedData)")
                    print("arrIsViewed-- \(self.arrIsViewed)")
                    self.tblVwFeed.reloadData()
                    self.tblVwFeed.pullToRefreshView?.stopAnimating()
                    self.tblVwFeed.infiniteScrollingView?.stopAnimating()
                    
                }else{
                    self.tblVwFeed.infiniteScrollingView?.stopAnimating()
                    if (response.webserviceResponse.valueForKey("status") as! String != "Data not found"){
                        Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                    }
                }
            }
            //            }
            }) { (error: NSError!) -> Void in
        }
    }
    
    //Save Bookmark API
    func fnSaveBookmarkWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceSaveBookmark)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("SaveBookmark--- \(response.webserviceResponse)")
                
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    
                }else{
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                
                }) { (error: NSError!) -> Void in
            }
            
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
    }
    //Delete Post API
    func fnDeletePostWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceDeletePost)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("DeletePost--- \(response.webserviceResponse)")
                if (response.webserviceResponse != nil) {
                    if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                        self.fnGetFeedAPICall()
                    }else{
                        Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                    }
                }
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
    }
    //Get Notifications Count API
    func fnGetNotificationCountWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceNotificationCount)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("GetCount--- \(response.webserviceResponse)")
                if (response.webserviceResponse != nil) {
                    if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                        self.strNotificationCount = response.webserviceResponse.valueForKey("count") as! String
                        self.fnUpdateNotificationCount()
                    }else{
                        Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                    }
                }
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
    //View Post API
    func fnViewPostWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceViewPost)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("ViewPost--- \(response.webserviceResponse)")
                if (response.webserviceResponse != nil) {
                    if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                        
                    }else{
//                        Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                    }
                }
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
    
    //MARK: - UIButton Actions
    @IBAction func btnPressed_View(sender: AnyObject) {
    }
    
    @IBAction func btnPressed_Comment(sender: AnyObject) {
        if (Utility.checkNetwork() == true){
            let pointInTable: CGPoint = sender.convertPoint(sender.bounds.origin, toView: tblVwFeed)
            let cellIndexPath: NSIndexPath = tblVwFeed.indexPathForRowAtPoint(pointInTable)!
            let objFeedCell:Feed = arrFeedData.objectAtIndex(cellIndexPath.row) as! Feed
            
            let objCommentVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("CommentsViewController") as! CommentsViewController
            objCommentVC.postId = objFeedCell.postId
            self.navigationController!.presentViewController(objCommentVC, animated: true, completion: nil)
        }
    }
    
    @IBAction func btnPressed_Inappropriate(sender: AnyObject) {
        if (Utility.checkNetwork() == true){
            let pointInTable: CGPoint = sender.convertPoint(sender.bounds.origin, toView: tblVwFeed)
            let cellIndexPath: NSIndexPath = tblVwFeed.indexPathForRowAtPoint(pointInTable)!
            let objFeedCell:Feed = arrFeedData.objectAtIndex(cellIndexPath.row) as! Feed
            
            if NSIConstants.userDefaults.valueForKey("userId") as! String == objFeedCell.userId {
                let objOptionMenu = UIAlertController(title: nil, message: "Choose option", preferredStyle: .ActionSheet)
                let deleteAction = UIAlertAction(title: "Delete Post", style: .Destructive, handler: {
                    (alert: UIAlertAction) -> Void in
                    //                "userId": "2864", "feedId":"42044"
                    if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                        let dict:NSDictionary = [
                            "userId": userId,
                            "feedId": objFeedCell.postId
                        ]
                        print("\(dict)")
                        self.fnDeletePostWebServiceWithPostDic(dict, showLoader: true)
                    }
                })
                let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: {
                    (alert: UIAlertAction) -> Void in
                    
                })
                objOptionMenu.addAction(cancelAction)
                objOptionMenu.addAction(deleteAction)
                self.presentViewController(objOptionMenu, animated: true, completion: nil)
            }else{
                let reportView = ReportInappropriateView.init(frame: CGRectMake(0, 0, self.view.frame.width, self.view.frame.height))
                reportView.delegate = self;
                let strUserId: String = NSIConstants.userDefaults.valueForKey("userId") as! String
                reportView.setUpReportView(["center":[self.view.frame.size.width/2, self.view.frame.size.height/2],"data":["userId": strUserId,"feedId":objFeedCell.postId]])
                self.view.addSubview(reportView)
            }
        }
    }
    
    func reportFeedTapped(){
        self.fnGetFeedAPICall()
    }
    
    @IBAction func btnPressed_Bookmark(sender: AnyObject) {
        if (Utility.checkNetwork() == true){
        let pointInTable: CGPoint = sender.convertPoint(sender.bounds.origin, toView: tblVwFeed)
        let cellIndexPath: NSIndexPath = tblVwFeed.indexPathForRowAtPoint(pointInTable)!
        let objFeedCell:Feed = arrFeedData.objectAtIndex(cellIndexPath.row) as! Feed
        let cell: UITableViewCell = tblVwFeed.cellForRowAtIndexPath(cellIndexPath)!
        
        //Previous cell
        if isBookmarked != nil {
            let indexPathPre = NSIndexPath(forRow: isBookmarked, inSection: 0)
            if tblVwFeed.indexPathsForVisibleRows!.contains(indexPathPre) {
                let cellPrevious: UITableViewCell = tblVwFeed.cellForRowAtIndexPath(indexPathPre)!
                if let btnBookmark:UIButton = cellPrevious.viewWithTag(1005) as? UIButton {
                    btnBookmark.setImage(UIImage(named: "btnBookmark"), forState: .Normal)
                }
            }
        }
        isBookmarked = cellIndexPath.row
        if let btnBookmark:UIButton = cell.viewWithTag(1005) as? UIButton {
            if objFeedCell.isBookmark == "1" {
                btnBookmark.setImage(UIImage(named: "btnBookmark"), forState: .Normal)
            }else{
                btnBookmark.setImage(UIImage(named: "btnBookmarkSelected"), forState: .Normal)
            }
        }
        if let userId = NSIConstants.userDefaults.valueForKey("userId") {
            let dict:NSDictionary = [
                "userId": userId,
                "postId": objFeedCell.postId
            ]
            print("\(dict)")
            fnSaveBookmarkWebServiceWithPostDic(dict, showLoader: true)
        }
        }
    }
    @IBAction func btnPressed_PlayAudio(sender: AnyObject) {
        if (Utility.checkNetwork() == true){
            let pointInTable: CGPoint = sender.convertPoint(sender.bounds.origin, toView: tblVwFeed)
            let cellIndexPath: NSIndexPath = tblVwFeed.indexPathForRowAtPoint(pointInTable)!
            let objFeedCell:Feed = arrFeedData.objectAtIndex(cellIndexPath.row) as! Feed
            let cell: UITableViewCell = tblVwFeed.cellForRowAtIndexPath(cellIndexPath)!
            if objFeedCell.audioUrl != "" {
                if isAudioPlaying == false{
                    AudioPlay.sharedInstance.fnPlayAudioURL(objFeedCell.audioUrl)
                    isAudioPlaying = true
                    audioPlayingIndex = cellIndexPath
                    //Sound Wave
                    if let btnWave:UIButton = cell.viewWithTag(1007) as? UIButton {
                        let jeremyGif = UIImage.gifWithName("waveAnimated")
                        btnWave.setBackgroundImage(jeremyGif, forState: .Normal)
                    }
                }else{
                    //Sound Wave
                    if let btnWave:UIButton = cell.viewWithTag(1007) as? UIButton {
                        audioPlayingIndex = nil
                        btnWave.setBackgroundImage(UIImage(named: "waveSimple.png"), forState: .Normal)
                    }
                    if AudioPlay.sharedInstance.audioPlayerBool == true {
                        AudioPlay.sharedInstance.myPlayer.stop()
                    }
                    isAudioPlaying = false
                }
            }
        }
    }
    
    //MARK: - TableView DataSource/Delegate
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (arrFeedData != nil){
            return arrFeedData.count
        }
        return 0
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if(tableView.respondsToSelector(Selector("setSeparatorInset:"))){
            tableView.separatorInset = UIEdgeInsetsZero
        }
        if(tableView.respondsToSelector(Selector("setLayoutMargins:"))){
            tableView.layoutMargins = UIEdgeInsetsZero
        }
        if(cell.respondsToSelector(Selector("setLayoutMargins:"))){
            cell.layoutMargins = UIEdgeInsetsZero
        }
    }
    
    func tableView(tableView: UITableView!, heightForRowAtIndexPath indexPath: NSIndexPath!) -> CGFloat {
        return self.getRowHeightFeedCell(indexPath)
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var strCellIdentifier: NSString
        let objFeedCell:Feed = arrFeedData.objectAtIndex(indexPath.row) as! Feed
        if objFeedCell.feedType == "Status" {
            strCellIdentifier = "cellStatus"
        }else{
            if(objFeedCell.audioUrl == "" && objFeedCell.photo == "" && objFeedCell.statusText != ""){
                strCellIdentifier = "cellText"
            }
            else if(objFeedCell.audioUrl != "" && objFeedCell.photo == "" && objFeedCell.statusText == ""){
                strCellIdentifier = "cellSound"
            }
            else if(objFeedCell.audioUrl != "" && objFeedCell.photo == "" && objFeedCell.statusText != ""){
                strCellIdentifier = "cellSoundText"
            }
            else if(objFeedCell.audioUrl == "" && objFeedCell.photo != "" && objFeedCell.statusText != ""){
                strCellIdentifier = "cellImgText"
            }
            else if(objFeedCell.audioUrl != "" && objFeedCell.photo != "" && objFeedCell.statusText == ""){
                strCellIdentifier = "cellImgSound"
            }else
            {
                strCellIdentifier = "cellFeedAll"
            }
        }
        let cell = tableView.dequeueReusableCellWithIdentifier(
            strCellIdentifier as String, forIndexPath: indexPath)
        
        //--------------------------UserInfo View--------------------------------
        //UIImage Profile Image
        if let imgVwProfile:AsyncImageView = cell.viewWithTag(1001) as? AsyncImageView {
            imgVwProfile.image = UIImage(named: "placeholder")
            if let variableName: String = objFeedCell.profilePic{
                imgVwProfile.imageURL = NSURL(string: variableName)
            }
        }
        //Label Name
        if let lblName:UILabel = cell.viewWithTag(1002) as? UILabel {
//            let strFname: String = objFeedCell.firstName
//            let strLname: String = objFeedCell.lastName
            let strUsername: String = objFeedCell.userName
            lblName.text = strUsername
        }
        //Label Location
        if let lblLocation:UILabel = cell.viewWithTag(1003) as? UILabel {
            lblLocation.text = objFeedCell.location
            if let imgVwLocation:UIImageView = cell.viewWithTag(4566) as? UIImageView {
                if (lblLocation.text == ""){
                    imgVwLocation.hidden = true
                }else{
                    imgVwLocation.hidden = false
                }
            }
        }
        //Label time
        if let lblTime:UILabel = cell.viewWithTag(1004) as? UILabel {
            //            let strMin: NSInteger = Int(objFeedCell.minutesAgo)! / 60
            let strSec: NSInteger = Int(objFeedCell.minutesAgo)! * 60
            let date = NSDate(timeInterval: NSTimeInterval(-strSec), sinceDate: NSDate())
            //            print("date---\(date)")
            //            print("date Ago---\(Utility.relativeDateStringForDate(date))")
            lblTime.text = Utility.relativeDateStringForDate(date)
            
        }
        //-----------------------------------------------------------------------
        
        //--------------------------Post Image--------------------------------
        //UIImage Post Image
        if let imgVwPost:AsyncImageView = cell.viewWithTag(1006) as? AsyncImageView {
            imgVwPost.image = UIImage(named: "err")
            if let variableName: String = objFeedCell.photo{
                imgVwPost.crossfadeDuration = 0.0
                imgVwPost.imageURL = NSURL(string: variableName)
            }
        }
        //-----------------------------------------------------------------------
        //--------------------------Bookmark Image--------------------------------
        if let btnBookmark:UIButton = cell.viewWithTag(1005) as? UIButton {
            if objFeedCell.isBookmark == "1" {
                btnBookmark.setImage(UIImage(named: "btnBookmarkSelected"), forState: .Normal)
            }else{
                btnBookmark.setImage(UIImage(named: "btnBookmark"), forState: .Normal)
            }
            if isBookmarked != nil {
                if indexPath.row == isBookmarked {
                    btnBookmark.setImage(UIImage(named: "btnBookmarkSelected"), forState: .Normal)
                }else{
                    btnBookmark.setImage(UIImage(named: "btnBookmark"), forState: .Normal)
                }
            }
        }
        
        //-------------------------------------------------------------------
        //----------------------------Audio Wave------------------------------
        if isAudioPlaying == true && audioPlayingIndex != nil && audioPlayingIndex == indexPath{
            //Sound Wave
            if let btnWave:UIButton = cell.viewWithTag(1007) as? UIButton {
                let jeremyGif = UIImage.gifWithName("waveAnimated")
                btnWave.setBackgroundImage(jeremyGif, forState: .Normal)
            }
        }else{
            //Sound Wave
            if let btnWave:UIButton = cell.viewWithTag(1007) as? UIButton {
                btnWave.setBackgroundImage(UIImage(named: "waveSimple.png"), forState: .Normal)
            }
        }
        //----------------------------------------------------------
        
        for view in cell.contentView.subviews{
            if(view.tag == 9852 || view.tag == 2589 || view.tag == 4563){
                view.removeFromSuperview()
            }
        }
        
        let lblStatus = UILabel()
        lblStatus.textAlignment = NSTextAlignment.Left
        if objFeedCell.feedType == "Status" {
            //Label Status
            if let txtStatusText:UITextView = cell.viewWithTag(3001) as? UITextView {
                txtStatusText.text = objFeedCell.statusText
                txtStatusText.textAlignment = NSTextAlignment.Center
                txtStatusText.scrollEnabled = false
                txtStatusText.font = UIFont(name: "ChalkDustRegularSWFTE", size: 19.0)
                lblStatus.text = " "
            }
        }else{
            lblStatus.text = objFeedCell.statusText
        }
        let lblHeight = self.heightForView(lblStatus.text!, width: cell.frame.size.width - 30)
        lblStatus.tag = 9852
        lblStatus.numberOfLines = 0
        lblStatus.font = UIFont(name: "Lato-Regular", size: 14)
        lblStatus.lineBreakMode = NSLineBreakMode.ByWordWrapping
        lblStatus.sizeToFit()
        if(strCellIdentifier == "cellSoundText"){
            lblStatus.frame = CGRectMake(15, 149, cell.frame.size.width - 30, lblHeight + 2)
            cell.contentView.addSubview(lblStatus)
        }else if(strCellIdentifier == "cellText"){
            lblStatus.frame = CGRectMake(15, 79, cell.frame.size.width - 30, lblHeight + 2)
            cell.contentView.addSubview(lblStatus)
        }else if(strCellIdentifier == "cellImgText"){
            lblStatus.frame = CGRectMake(15, 310, cell.frame.size.width - 30, lblHeight + 2)
            cell.contentView.addSubview(lblStatus)
        }else if(strCellIdentifier == "cellFeedAll"){
            lblStatus.frame = CGRectMake(15, 359, cell.frame.size.width - 30, lblHeight + 2)
            cell.contentView.addSubview(lblStatus)
        }else{
            if objFeedCell.audioUrl == "" {
                //Sound Wave
                if let btnWave:UIButton = cell.viewWithTag(1007) as? UIButton {
                    btnWave.hidden = true
                }
                lblStatus.frame = CGRectMake(15, 290, cell.frame.size.width - 30, lblHeight + 2)
                cell.contentView.addSubview(lblStatus)
            }else{
                if let btnWave:UIButton = cell.viewWithTag(1007) as? UIButton {
                    btnWave.hidden = false
                }
                lblStatus.frame = CGRectMake(15, 320, cell.frame.size.width - 30, lblHeight + 2)
                cell.contentView.addSubview(lblStatus)
            }
        }
        
        //Tagged Friends
        let arrTagedFriends = objFeedCell.taggedFriendList
        if(arrTagedFriends.count > 0){
            let strTagNames: NSMutableString = "- with "
            if(arrTagedFriends.count > 2){
                
                for var index = 0; index < 2; ++index {
                    strTagNames.appendString(arrTagedFriends.objectAtIndex(index).valueForKey("nickName") as! String)
                    strTagNames.appendString(" ,")
                }
                if (strTagNames.length > 0) {
                    strTagNames.deleteCharactersInRange(NSMakeRange(strTagNames.length-1, 1))
                }
                strTagNames.appendString("and \(arrTagedFriends.count - 2) others")
            }else{
                
                arrTagedFriends.enumerateObjectsUsingBlock({ object, index, stop in
                    let objTaggedFriends:TagFriendList = arrTagedFriends.objectAtIndex(index) as! TagFriendList
                    strTagNames.appendString(objTaggedFriends.nickName)
                    strTagNames.appendString(" ,")
                })
                if (strTagNames.length > 0) {
                    strTagNames.deleteCharactersInRange(NSMakeRange(strTagNames.length-1, 1))
                }
            }
            
            let main_string = strTagNames
            let attributedString = NSMutableAttributedString(string:main_string as String)
            attributedString.addAttribute(NSForegroundColorAttributeName, value: UIColor.blackColor() , range: NSRange(
                location:0,
                length:6))
            attributedString.addAttribute(NSForegroundColorAttributeName, value: UIColor.blueColor() , range: NSRange(
                location:7,
                length:strTagNames.length - 7))
            attributedString.addAttribute(NSFontAttributeName,
                value: UIFont(name: "Lato-Regular", size: 14)!,
                range: NSRange(
                    location: 0,
                    length: strTagNames.length))
            
            let lblTaggedFriend = UILabel()
            lblTaggedFriend.textAlignment = NSTextAlignment.Left
            lblTaggedFriend.attributedText = attributedString
            lblTaggedFriend.frame = CGRectMake(15, lblStatus.frame.origin.y + lblStatus.frame.size.height + 5, cell.frame.size.width - 30, lblHeight)
            lblTaggedFriend.tag = 4563
            lblTaggedFriend.numberOfLines = 1
            lblTaggedFriend.lineBreakMode = NSLineBreakMode.ByWordWrapping
            lblTaggedFriend.sizeToFit()
            cell.contentView.addSubview(lblTaggedFriend)
            
            let btnTagList   = UIButton(type: UIButtonType.Custom) as UIButton
            btnTagList.frame = CGRectMake(15, lblStatus.frame.origin.y + lblStatus.frame.size.height + 5, cell.frame.size.width - 30, 30)
            btnTagList.tag = 2589
            btnTagList.backgroundColor = UIColor.clearColor()
            btnTagList.setTitle("", forState: UIControlState.Normal)
            btnTagList.addTarget(self, action: "buttonActionTagList:", forControlEvents: UIControlEvents.TouchUpInside)
            cell.contentView.addSubview(btnTagList)
        }
        
        //--------------------------Bottom Comment Section--------------------------------
        //Label Views
        if let btnViews:UIButton = cell.viewWithTag(1009) as? UIButton {
            let xString : String = (objFeedCell.viewsCount)!
            if self.arrIsViewed.objectAtIndex(indexPath.row) as! String == "1"{
                btnViews.setTitle("\(Int(xString)! + 1)" + " Views", forState: .Normal)
            }else{
                btnViews.setTitle(xString + " Views", forState: .Normal)
            }
            
        }
        //Label Comments
        if let btnComments:UIButton = cell.viewWithTag(1010) as? UIButton {
            btnComments .setTitle((objFeedCell.commentsCount)! + " Comments", forState: .Normal)
        }
        //-----------------------------------------------------------------------
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
    }
    
//    func scrollViewWillBeginDecelerating(scrollView: UIScrollView){
//        print("BeginDecelerating")
//    }
//    func scrollViewDidEndDecelerating(scrollView: UIScrollView){
//        print("EndDecelerating")
//    }
    func scrollViewDidEndDragging(scrollView: UIScrollView, willDecelerate decelerate: Bool){
        print("EndDragging")
        let arrVisibleCell: NSArray = tblVwFeed.indexPathsForVisibleRows!
//        print("\(arrVisibleCell.objectAtIndex(0))")
        var indexPathRow: NSIndexPath!
        if arrVisibleCell.count > 1 {
            indexPathRow = arrVisibleCell.objectAtIndex(1) as! NSIndexPath
        }else{
            indexPathRow = arrVisibleCell.objectAtIndex(0) as! NSIndexPath
        }
        let objFeedCell:Feed = arrFeedData.objectAtIndex(indexPathRow.row) as! Feed
        let cell: UITableViewCell = tblVwFeed.cellForRowAtIndexPath(indexPathRow)!
        if self.arrIsViewed.objectAtIndex(indexPathRow.row) as! String == "0" {
            let backgroundQueue = NSOperationQueue()
            backgroundQueue.addOperationWithBlock(){
                self.arrIsViewed.replaceObjectAtIndex(indexPathRow.row, withObject: "1")
                print("hello from background")
                let dict:NSDictionary = [
                    "userId": NSIConstants.userDefaults.valueForKey("userId") as! String,
                    "feedId": "\(objFeedCell.postId)"
                ]
                print("\(dict)")
                self.fnViewPostWebServiceWithPostDic(dict, showLoader: false)
                NSOperationQueue.mainQueue().addOperationWithBlock(){
                    print("hello Done")
                    //Label Views
                    if let btnViews:UIButton = cell.viewWithTag(1009) as? UIButton {
                        let xString : String = (objFeedCell.viewsCount)!
                        btnViews.setTitle("\(Int(xString)! + 1)" + " Views", forState: .Normal)
                    }

                }
            }
        }
    }
    //Calculate UILabel height
    func heightForView(text:String, width:CGFloat) -> CGFloat{
        let label:UILabel = UILabel(frame: CGRectMake(0, 0, width, CGFloat.max))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.ByWordWrapping
        label.font = UIFont(name: "Lato-Regular", size: 14)
        label.text = text
        label.sizeToFit()
        return label.frame.height
    }
    
    //Tag Button Clicked
    func buttonActionTagList(sender:UIButton!)
    {
        let pointInTable: CGPoint = sender.convertPoint(sender.bounds.origin, toView: tblVwFeed)
        let cellIndexPath: NSIndexPath = tblVwFeed.indexPathForRowAtPoint(pointInTable)!
        let objFeedCell:Feed = arrFeedData.objectAtIndex(cellIndexPath.row) as! Feed
        let arrTagedFriends = objFeedCell.taggedFriendList
        
        let taggedFriendsView = TaggedFriendListView.init(frame: CGRectMake(0, 0, self.view.frame.width, self.view.frame.height))
        taggedFriendsView.delegate = self
        taggedFriendsView.setUpTaggedFriendView(["tagList":arrTagedFriends])
        self.view.addSubview(taggedFriendsView)
    }
    
    func taggedFriendTapped(userId: String) {
        let objProfileVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("ProfileViewController") as! ProfileViewController
        objProfileVC.userID = userId
        self.navigationController!.pushViewController(objProfileVC, animated: true)
    }
    
    //MARK - Get Feed Cell Height
    func getRowHeightFeedCell(indexPath: NSIndexPath) -> CGFloat{
        let objFeedCell:Feed = arrFeedData.objectAtIndex(indexPath.row) as! Feed
        if objFeedCell.feedType == "Status" {
            if objFeedCell.audioUrl == "" {
                let arrTagedFriends = objFeedCell.taggedFriendList
                if(arrTagedFriends.count > 0){
                    return 420
                }
                return 380
            }else{
                let arrTagedFriends = objFeedCell.taggedFriendList
                if(arrTagedFriends.count > 0){
                    return 444
                }
                return 414
            }
        }else{
            
            if(objFeedCell.audioUrl == "" && objFeedCell.photo == "" && objFeedCell.statusText != ""){
                let lblHeight = self.heightForView(objFeedCell.statusText, width: tblVwFeed.frame.size.width - 30)
                let arrTagedFriends = objFeedCell.taggedFriendList
                if(arrTagedFriends.count > 0){
                    return 167 + 20 + lblHeight
                }
                return 167 + lblHeight
            }
            else if(objFeedCell.audioUrl != "" && objFeedCell.photo == "" && objFeedCell.statusText == ""){
                let arrTagedFriends = objFeedCell.taggedFriendList
                if(arrTagedFriends.count > 0){
                    return 184 + 20
                }
                return 184
            }
            else if(objFeedCell.audioUrl != "" && objFeedCell.photo == "" && objFeedCell.statusText != ""){
                let lblHeight = self.heightForView(objFeedCell.statusText, width: tblVwFeed.frame.size.width - 30)
                let arrTagedFriends = objFeedCell.taggedFriendList
                if(arrTagedFriends.count > 0){
                    return 207 + 20 + lblHeight
                }
                return 207 + lblHeight
            }
            else if(objFeedCell.audioUrl == "" && objFeedCell.photo != "" && objFeedCell.statusText != ""){
                let lblHeight = self.heightForView(objFeedCell.statusText, width: tblVwFeed.frame.size.width - 30)
                let arrTagedFriends = objFeedCell.taggedFriendList
                if(arrTagedFriends.count > 0){
                    return 397 + 20 + lblHeight
                }
                return 397 + lblHeight
                
            }
            else if(objFeedCell.audioUrl != "" && objFeedCell.photo != "" && objFeedCell.statusText == ""){
                return 141
            }else
            {
                let lblHeight = self.heightForView(objFeedCell.statusText, width: tblVwFeed.frame.size.width - 30)
                let arrTagedFriends = objFeedCell.taggedFriendList
                if(arrTagedFriends.count > 0){
                    return 437 + 20 + lblHeight
                }
                return 437 + lblHeight
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
}
