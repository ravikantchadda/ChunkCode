//
//  NexmoDL.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/4/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

// --- - -- - -- - - - -Nexmo Model ---- -- - - -- -//

class NexmoBO:NSObject
{
    var requestID:String!
    var code:String!
    var status:Bool!
}

// --- - -- - -- - - - -Nexmo Data Layers ---- -- - - -- -//

class NexmoDL: PSRestAPIHelper {
    

    
    let nexmoServiceURL = "https://api.nexmo.com/verify/json"
    let nexmoServiceVerifyURL = "https://api.nexmo.com/verify/check/json"
    let apiKey = "cf8d0d30"
    let apiSecret = "370db7ce"

    
// Nexmo Number Service Calling
    func requestTheNexmoMobile(mobile_number:String, withCompletionHandler handler:CompletionHandler)
    {
        let dicParam:NSDictionary = ["api_key":apiKey,"api_secret":apiSecret,"number":mobile_number,"brand":"Localift"]
        self.webservice.isShowLoader = true
        
        self.requestforGETWithoutServiceURL(dicParam as! [NSObject : AnyObject!], withURL: nexmoServiceURL) { (obj, success) -> Void in
            
            if success == true
            {
                if let response:NSDictionary = obj as? NSDictionary {
                    let status = response.objectForKey("status") as! String
                        if status == "0"{
                            let nexmoBO:NexmoBO = NexmoBO()
                            nexmoBO.requestID = (obj!.valueForKey("request_id") as? String)!
                            handler(obj: nexmoBO, success: true)
                        }
                        else if status == "3"{
                            NSIUtility.show(Constants.kValidMobileNo)
                            handler(obj: response, success: false)
                        }
                        else if status == "10"{
                            NSIUtility.show("Concurrent verifications to the same number are not allowed. Please wait for 5 minutes")
                            handler(obj: response, success: false)
                        }
                        else{
                            NSIUtility.show("Something is not correct")
                            handler(obj: response, success: false)
                        }
                    
                }
            }else{
                handler(obj: obj, success: false)
            }
        }
    }
    
    
// Nexmo OTP Service Calling
    func requestTheNexmoOTP(nexmoBO:NexmoBO, withCompletionHandler handler:CompletionHandler)
    {
        
        let dicParam:NSDictionary = ["api_key":apiKey,"api_secret":apiSecret,"request_id":nexmoBO.requestID,"code":nexmoBO.code]
        
        self.requestforGETWithoutServiceURL(dicParam as! [NSObject : AnyObject!], withURL: nexmoServiceVerifyURL) { (obj, success) -> Void in
            if success == true
            {
                if let response:NSDictionary = obj as? NSDictionary {
                    let status = response.objectForKey("status") as! String
                    if status == "0"{
                        handler(obj: nexmoBO, success: true)
                    }
                    else {
                        NSIUtility.show("Please fill valid OTP")
                        handler(obj: nexmoBO, success: false)
                    }
                }
                
            }else{
                let error_text:String = (obj!.valueForKey("error_text") as? String)!
                NSIUtility.show(error_text)
                handler(obj: obj, success: false)
                print("Data is nil")
            }
            
        }
    }
    

}
