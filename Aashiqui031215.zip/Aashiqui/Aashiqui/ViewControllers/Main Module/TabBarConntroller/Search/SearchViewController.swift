//
//  SearchViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 18/09/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit

class SearchViewController: UIViewController {
    @IBOutlet weak var btnAll: UIButton!
    @IBOutlet weak var btnFriends: UIButton!
    @IBOutlet weak var tblUserList: UITableView!
    @IBOutlet weak var searchBarUser: UISearchBar!
    var arrUserData: NSMutableArray! = []
    var pageUser = 1
    var searchType = false
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationItem.titleView = Utility.navBarTitleLabel("Search")
        tblUserList.tableFooterView = UIView(frame: CGRectZero)
        btnAll.selected = true
//        btnAll.userInteractionEnabled = false
//        btnFriends.userInteractionEnabled = true
        self.fnAllUserList()
        
        //Paging
        tblUserList.addInfiniteScrollingWithHandler {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), { () ->  Void in
            
                    self.pageUser += 1
                    if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                        let dict:NSDictionary = [
                            "userId": userId,
                            "searchText": self.searchBarUser.text!,
                            "friend": self.searchType,
                            "page": self.pageUser
                        ]
                        print("\(dict)")
                        if self.searchBarUser.text != nil {
                            self.fnSearchUserWebServiceWithPostDic(dict, showLoader: true, arrClear: false)
                        } else{
                            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                                self.tblUserList.infiniteScrollingView?.stopAnimating()
                            })
                            
                        }
                }
            })
        }
    }
//    override func viewWillAppear(animated: Bool) {
//        super.viewWillAppear(true)
//        searchType = false
//        searchBarUser.text = ""
//        
//        btnAll.selected = true
//        btnFriends.selected = false
//        
//        self.fnAllUserList()
//    }
    
    
    func fnAllUserList(){
        if let userId = NSIConstants.userDefaults.valueForKey("userId") {
            self.pageUser = 1
            let dict:NSDictionary = [
                "userId": userId,
                "searchText": searchBarUser.text!,
                "friend": searchType,
                "page": self.pageUser
            ]
            print("\(dict)")
            self.fnSearchUserWebServiceWithPostDic(dict, showLoader: true, arrClear: true)
        }
    }
    
    // MARK: - Webservice Call Methods
    //Search User API
    func fnSearchUserWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool, arrClear: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        ObjWebserviceCall.cachePolicy = WebserviceCallCachePolicyRequestFromCacheFirstAndThenFromUrlAndUpdateInCache
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceGetSearchUser)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("getUsers--- \(response.webserviceResponse)")
                if (response.webserviceResponse != nil) {
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    if arrClear == true {
                        self.arrUserData.removeAllObjects()
                    }
                    //Search Model
                    let arrData = response.webserviceResponse.valueForKey("users") as! NSArray
                    let arrModelData = UserDetails().fillDataInModel(arrData)
                    arrModelData.enumerateObjectsUsingBlock({ object, index, stop in
                        self.arrUserData.addObject(arrModelData.objectAtIndex(index))
                    })
                    
                    if self.searchType == true {
                        if self.arrUserData.count == 0 {
                            let lblMsg = UILabel(frame: CGRectMake(0, 0, self.tblUserList.frame.size.width, 50))
                            lblMsg.center = self.tblUserList.center
                            lblMsg.text = "You don't have any friend."
                            lblMsg.numberOfLines = 0
                            lblMsg.textAlignment = NSTextAlignment.Center
                            lblMsg.font = UIFont(name: "Lato-Regular", size: 16)
                            lblMsg.textColor = UIColor.blackColor()
                            self.tblUserList.backgroundView = lblMsg
                            self.tblUserList.scrollEnabled = false
                            
                        }else{
                            self.tblUserList.backgroundView = nil
                            self.tblUserList.scrollEnabled = true
                        }
                    }else{
                        self.tblUserList.backgroundView = nil
                        self.tblUserList.scrollEnabled = true
                    }
                    print("arrUserData-- \(self.arrUserData)")
                    self.tblUserList.reloadData()
                    self.tblUserList.infiniteScrollingView?.stopAnimating()
                    
                }else{
                    
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                }
                self.tblUserList.infiniteScrollingView?.stopAnimating()
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnTapped_All(sender: AnyObject) {
        if (Utility.checkNetwork() == true){
            searchType = false
            searchBarUser.text = ""
            if btnAll.selected == false {
                btnAll.selected = true
                btnFriends.selected = false
                self.fnAllUserList()
            }
        }
    }
    
    @IBAction func btnTapped_Friends(sender: AnyObject) {
        if (Utility.checkNetwork() == true){
            searchType = true
            searchBarUser.text = ""
            if btnFriends.selected == false {
                btnAll.selected = false
                btnFriends.selected = true
                self.fnAllUserList()
            }
        }
    }
    
    //MARK: - TableView DataSource/Delegate
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrUserData.count;
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("cellUsers")! as UITableViewCell;
        
        let objUserCell:UserDetails = arrUserData.objectAtIndex(indexPath.row) as! UserDetails
        
        //UIImage Profile Image
        if let imgVwProfile:AsyncImageView = cell.viewWithTag(1001) as? AsyncImageView {
            imgVwProfile.image = UIImage(named: "placeholder")
            if let variableName: String = objUserCell.profilePic{
                imgVwProfile.crossfadeDuration = 0.0
                imgVwProfile.imageURL = NSURL(string: variableName)
            }
        }
        if let lblName = cell.viewWithTag(1002) as? UILabel {
            lblName.text = objUserCell.firstName + " " + objUserCell.lastName
        }
        if let lblTitle = cell.viewWithTag(1003) as? UILabel {
                lblTitle.text = objUserCell.statusText
        }
        

        return cell;
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if(tableView.respondsToSelector(Selector("setSeparatorInset:"))){
            tableView.separatorInset = UIEdgeInsetsZero
        }
        if(tableView.respondsToSelector(Selector("setLayoutMargins:"))){
//            if #available(iOS 8.0, *) {
                tableView.layoutMargins = UIEdgeInsetsZero
//            } else {
//                // Fallback on earlier versions
//                tableView.separatorInset = UIEdgeInsetsZero
//            }
        }
        if(cell.respondsToSelector(Selector("setLayoutMargins:"))){
//            if #available(iOS 8.0, *) {
                cell.layoutMargins = UIEdgeInsetsZero
//            } else {
//                // Fallback on earlier versions
//                cell.separatorInset = UIEdgeInsetsZero
//            }
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let objUserCell:UserDetails = arrUserData.objectAtIndex(indexPath.row) as! UserDetails
        let objProfileVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("ProfileViewController") as! ProfileViewController
        objProfileVC.userID = objUserCell.userId
        self.navigationController!.pushViewController(objProfileVC, animated: true)
    }
    
    //MARK: - UISearchBar Delegate

    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        
    }
    
    func searchBarTextDidEndEditing(searchBar: UISearchBar) {
        
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        if (Utility.checkNetwork() == true){
        if let userId = NSIConstants.userDefaults.valueForKey("userId") {
//            arrUserData.removeAllObjects()
            self.pageUser = 1
            let dict:NSDictionary = [
                "userId": userId,
                "searchText": searchBar.text!,
                "friend": searchType,
                "page": self.pageUser
            ]
            print("\(dict)")
            self.fnSearchUserWebServiceWithPostDic(dict, showLoader: true, arrClear: true)
        }
        }
        searchBar.resignFirstResponder()
    }
    /*
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        
        filtered = data.filter({ (text) -> Bool in
            let tmp: NSString = text
            let range = tmp.rangeOfString(searchText, options: NSStringCompareOptions.CaseInsensitiveSearch)
            return range.location != NSNotFound
        })

        tblUserList.reloadData()
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
