     //
//  App_UserAPI.swift
//  ReferenceApp
//
//  Created by Mohit Jain on 10/16/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import Foundation
import CoreData
class App_UserAPI: NSObject {
    class func checkUserIsNotExists(userId: Int) -> Bool {
        let userPredicate:NSPredicate? = NSPredicate(format: "id == %d", userId)
        return CoreDataManager.sharedManager.entityIsEmpty("App_User", predicate: userPredicate!)
    }
    
    class func fetchUser(userId: Int) -> AnyObject{
        let userPredicate:NSPredicate? = NSPredicate(format: "id == %d", userId)
        return CoreDataManager.sharedManager.fetchEntity("App_User", predicate: userPredicate!,fromBackgroundContext: false)!
    }
    
    class func saveUser(profiles:NSSet) {
        let infoModel:UserBO! = UserInfoManager.getUserInfoModel()
        if infoModel != nil {
            if App_UserAPI.checkUserIsNotExists(infoModel.userId!) {
                let arrList:NSMutableArray = NSMutableArray()
                let dict:NSDictionary = NSDictionary(objects: [infoModel.userFirstName!,infoModel.userId!,infoModel.userGoogle_Id!,infoModel.userFB_Id!,infoModel.userLinkedIn_Id!,profiles], forKeys: ["username","id","google_id","fb_id","linked_id","profile"])
                arrList.addObject(dict)
                CoreDataManager.sharedManager.saveEntity("App_User", arrOfRecords: arrList)
            }
        }
    }

}
