//
//  CreateProfileVC.swift
//  LocalLift
//
//  Created by neeru thakur on 12/21/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit
import ActionSheetPicker_3_0
import MFSideMenu
class CreateProfileVC:BaseViewController,TwoRadioButtonViewProtocol,UIImagePickerControllerDelegate, UINavigationControllerDelegate,ColectionCellSelectProtocol,MonthYearPickerViewProtocol{

    @IBOutlet weak var bottomConstraint_PickerView: NSLayoutConstraint!
    @IBOutlet weak var btnContinue: UIButton!
    @IBOutlet weak var pickerView: MonthYearPickerVW!
    @IBOutlet weak var baseScrollView: UIScrollView!
    @IBOutlet weak var viewRadioDOB: TwoRadioButtonView!
    @IBOutlet weak var viewRadioGender: TwoRadioButtonView!
    @IBOutlet weak var viewProfilePic: ProfilePicView!
    
    @IBOutlet weak var viewBlank: UIView!
    // MARK: UIImagePickerController object
    let imagePickerForUserPic = UIImagePickerController()
    // Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialization()
        self.setMyProfileBO()
        self.setRightBarButton()
       
        pickerView.delegate = self
    }
    
    func initialization(){
        self.bottomConstraint_PickerView.constant = -286
         self.btnContinue.backgroundColor = UIColor.colorWithRGB(31, green: 81, blue: 108, alpha:0.7)
        viewProfilePic.lblHeader.text = "Personalise Localfit and create your profile"
        viewProfilePic.delegate = self
        viewRadioGender.populate(headerText: "What is your gender? *", leftRadioLabelText: "Male", rightRadioLabelText: "Female", radioViewType:.genderView)
        viewRadioGender.delegate = self
        viewRadioDOB.populate(headerText: "What is your date of birth? *", leftRadioLabelText: "Minor", rightRadioLabelText: "Adult", radioViewType:.dobView)
        viewRadioDOB.delegate = self
        imagePickerForUserPic.delegate = self
    }
    
    func setMyProfileBO(){
        
        MyProfileBO.sharedInstanceOfUser.userPhoto = ""
        MyProfileBO.sharedInstanceOfUser.userDay = 1
        MyProfileBO.sharedInstanceOfUser.userSpecialDesc = ""
        MyProfileBO.sharedInstanceOfUser.userGender = Gender.male.rawValue
        MyProfileBO.sharedInstanceOfUser.isAdult = false
        MyProfileBO.sharedInstanceOfUser.userYear = 0
        MyProfileBO.sharedInstanceOfUser.userMonth = 0
        
    }
    
 // MARK : TO DO
    func setRightBarButton() {
        //        let barBtnMenu = UIBarButtonItem(image: UIImage(named:"backIcon"), style: .Plain, target: self, action: "backButtonClick:")
        let barBtnMenu = UIBarButtonItem(title:"Skip", style: .Plain, target: self, action: "skipButtonClick:")
        barBtnMenu.tintColor = UIColor.grayColor()
        navigationItem.leftItemsSupplementBackButton = true
        navigationItem.setRightBarButtonItems([barBtnMenu], animated: true)
    }
    
    func skipButtonClick(sender : AnyObject){
        self.configureMFSideMenu()
    }
   
    override func viewWillAppear(animated: Bool) {
        self.setNavigationBar(NavigationType.BlueNavigationType)
        self.navigationItem.setHidesBackButton(true, animated: true)
    
    }
    
    override func viewDidAppear(animated: Bool) {
        pickerView.updatePickerBounds()
    }

//Mark : two Radio
    
    func leftRadioButtonTapped(radiobuttonView :TwoRadioButtonView,  withState : RadioState ){
        
        if radiobuttonView == viewRadioGender{
            
        }
        else if radiobuttonView == viewRadioDOB{
        
        }
    
    }
    
    func rightRadioButtonTapped(radiobuttonView :TwoRadioButtonView, withState : RadioState){
        
        if radiobuttonView == viewRadioGender{
            
        }
        else if radiobuttonView == viewRadioDOB{
            
        }
    
    }
    
    func showDatePickerForOption(personType: PersonType, sender:UIButton) {
        switch personType{
                case .minor:
            
            

                    let datePicker = ActionSheetDatePicker(title: "Select Date", datePickerMode: UIDatePickerMode.Date, selectedDate: NSDate(), doneBlock: {
                        picker, value, index in
                        
                        if let selectedDate = value as? NSDate{
                            
                            let dateFormatter = NSDateFormatter()
                            dateFormatter.dateFormat = "dd MMMM yyyy"
                            let datestr = dateFormatter.stringFromDate(selectedDate)
                            sender.setTitleColor(UIColor.darkGrayColor(), forState: .Normal)
                            sender.setTitle(datestr , forState:UIControlState.Normal)
                            MyProfileBO.sharedInstanceOfUser.userMonth = selectedDate.month()
                            MyProfileBO.sharedInstanceOfUser.userYear = selectedDate.year()
                            MyProfileBO.sharedInstanceOfUser.userDay = selectedDate.day()
                            
                            self.toSelectBtnValidation()
                        }
                        
                        
                        return
                        }, cancelBlock: { ActionStringCancelBlock in sender.setTitle( "dd mm yyyy" , forState:UIControlState.Normal)
                            sender.setTitleColor(UIColor.grayColor(), forState: .Normal)
                            MyProfileBO.sharedInstanceOfUser.userMonth = 0
                            MyProfileBO.sharedInstanceOfUser.userYear = 0
                            MyProfileBO.sharedInstanceOfUser.userDay = 1
                             self.toSelectBtnValidation()
                            
return }, origin: self.view)
                    //        let secondsOfThirtyMin: NSTimeInterval = 30 * 60;
                    datePicker.minuteInterval = 1
                    datePicker.maximumDate = NSDate()
                    datePicker.showActionSheetPicker()
            
                case .adult:
            
                    self.showMonthYearPicker(sender)
        }

    }
    
    
    @IBAction func toSelectContinue(sender: AnyObject) {
        
        if (MyProfileBO.sharedInstanceOfUser.userMonth != 0 && MyProfileBO.sharedInstanceOfUser.userYear != 0){
            
            let adressVC = NSIUtility.fetchViewControllerWithName("MyProfileAddressVC", storyBoardName: "Main")
            self.navigationController?.pushViewController(adressVC, animated: true)
        }
        else {
            
            NSIUtility.showAlert("", message: "Please select date of birth.")
        }
        

      
    }
// MARK : TO DO
    func configureMFSideMenu(){
        
        let leftMenuVC:UIViewController = NSIUtility.fetchViewControllerWithName("LeftMenuVC", storyBoardName: "Home")
        let homeNavigationController:UINavigationController = NSIUtility.fetchViewControllerWithName("homeNavigationController", storyBoardName: "Home") as! UINavigationController
        let sideMenu:MFSideMenuContainerViewController = MFSideMenuContainerViewController.containerWithCenterViewController(homeNavigationController, leftMenuViewController: leftMenuVC, rightMenuViewController: nil)
        Constants.appDelegate.window?.rootViewController = sideMenu;
    }
    
    func toSelectBtnValidation()
    {
        if (MyProfileBO.sharedInstanceOfUser.userMonth != 0 && MyProfileBO.sharedInstanceOfUser.userYear != 0){
            self.btnContinue.backgroundColor = Constants.APP_THEME_COLOR
        }
        else{
            self.btnContinue.backgroundColor = UIColor.colorWithRGB(31, green: 81, blue: 108, alpha:0.7)
        }
    }
    
    // MARK: ActionSheet for image picker
    func select() {
        let optionMenu = UIAlertController(title: nil, message: "Choose", preferredStyle: .ActionSheet)
        //________get Photo From Gallery
        let chooseImageFromGalleryAction = UIAlertAction(title: "Take a Photo", style: .Default, handler: {
            (alert: UIAlertAction!) -> Void in
            self.shootPhotoFromCamera()
        })
        //________get Photo From Camera
        let chooseImageFromCamera = UIAlertAction(title: "From Camera Roll", style: .Default, handler: {
            (alert: UIAlertAction!) -> Void in
            
            self.shootPhotoFromGallery()
        })
        //________Cancel
        let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: {
            (alert: UIAlertAction!) -> Void in
        })
        //________Add button of actionsheet in controller
        optionMenu.addAction(chooseImageFromGalleryAction)
        optionMenu.addAction(chooseImageFromCamera)
        optionMenu.addAction(cancelAction)
        self.presentViewController(optionMenu, animated: true, completion: nil)
    }
    
    // MARK: Get photo from camera
    func shootPhotoFromCamera() {
        if UIImagePickerController.availableCaptureModesForCameraDevice(.Rear) != nil {
            self.imagePickerForUserPic.allowsEditing = false
            self.imagePickerForUserPic.sourceType = UIImagePickerControllerSourceType.Camera
            self.imagePickerForUserPic.cameraCaptureMode = .Photo
            self.imagePickerForUserPic.modalPresentationStyle = .FullScreen
            presentViewController(self.imagePickerForUserPic,
                animated: true,
                completion: nil)
        } else {
            NSIUtility.show("Sorry, this device has no camera")
        }
    }
    
    // MARK: Get photo from Gallery
    func shootPhotoFromGallery() {
        self.imagePickerForUserPic.allowsEditing = false
        self.imagePickerForUserPic.sourceType = .PhotoLibrary
        self.presentViewController(self.imagePickerForUserPic, animated: true, completion: nil)
    }
    
    // MARK: imagePickerController delegate
    
    // _____cancel  controller
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    // _____open image  controller
    func imagePickerController(
        picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [String : AnyObject]) {
            let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage
            viewProfilePic.imgVwProfile.contentMode = .ScaleToFill
            viewProfilePic.imgVwProfile.image = chosenImage
            viewProfilePic.btnUploadImage.setTitle("Change Photo", forState: UIControlState.Normal)
            MyProfileBO.sharedInstanceOfUser.userPhoto = NSIUtility.encodeImageToBase64String(chosenImage)
            dismissViewControllerAnimated(true, completion: nil)
    }
    
    // Month Year Picker
     func showMonthYearPicker(sender: AnyObject) {
         self.viewBlank.hidden = false
        self.pickerView.hidden = false
        
        UIView.animateWithDuration(2.0, animations: {
            self.bottomConstraint_PickerView.constant = 0
        })
        
    }

//MARK :MonthYearPickerViewProtocol
    func doneButtonPressed(){
        self.viewBlank.hidden = true
        UIView.animateWithDuration(2.0, animations:  {() in
            
            self.bottomConstraint_PickerView.constant = -286
            let dateStr = ((self.pickerView.expiryDatePicker.montheStr)+" "+String(self.pickerView.expiryDatePicker.year))
            self.viewRadioDOB.btnDOB.setTitle(dateStr, forState: UIControlState.Normal)
            self.viewRadioDOB.btnDOB.setTitleColor(UIColor.darkGrayColor(), forState: .Normal)
            MyProfileBO.sharedInstanceOfUser.userMonth =  self.pickerView.expiryDatePicker.month
            MyProfileBO.sharedInstanceOfUser.userYear =  self.pickerView.expiryDatePicker.year
            self.toSelectBtnValidation()

            }, completion:{(Bool)  in                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
                
        })

    }
    
    func cancelMonthYearPickerView(){
        self.viewBlank.hidden = true
        UIView.animateWithDuration(2.0, animations:  {() in
            self.bottomConstraint_PickerView.constant = -286
            }, completion:{(Bool)  in
//                self.pickerView.hidden = true
                MyProfileBO.sharedInstanceOfUser.userMonth =  0
                MyProfileBO.sharedInstanceOfUser.userYear =   0
                MyProfileBO.sharedInstanceOfUser.userDay =  1
                self.viewRadioDOB.btnDOB.setTitle("mm yyyy", forState: .Normal)
                self.viewRadioDOB.btnDOB.setTitleColor(UIColor.grayColor(), forState: .Normal)
                self.toSelectBtnValidation()


        })
    
    }

    func updateBtnValidation(){
         self.toSelectBtnValidation()
    }
}