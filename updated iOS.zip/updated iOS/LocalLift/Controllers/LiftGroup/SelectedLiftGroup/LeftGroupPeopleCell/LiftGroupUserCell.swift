//
//  LiftGroupUserCell.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/23/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class LiftGroupUserCell: UICollectionViewCell {

    @IBOutlet weak var imageViewUser: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        imageViewUser.layer.cornerRadius = imageViewUser.frame.size.width / 2;
        imageViewUser.clipsToBounds = true;

        
    }

}
