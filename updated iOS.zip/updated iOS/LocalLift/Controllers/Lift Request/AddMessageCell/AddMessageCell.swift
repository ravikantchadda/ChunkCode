//
//  AddMessageCell.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/25/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class AddMessageCell: UITableViewCell {

    @IBOutlet var txtMessage: UITextView!
    @IBOutlet var constraintVerticalTop: NSLayoutConstraint!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
// MARK:- TextView Delegate
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool{
        
        return UITextView.textView(textView, shouldChangeCharactersInRange: range, replacementString: text,
            withMaxLength:200, spaceAllowed: true)
    }
    
    
    
    func textViewShouldBeginEditing(textView: UITextView) -> Bool{
        if textView.text == "Write any additional messages here"{
            textView.text = ""
        }
        return true
    }
    func textViewShouldEndEditing(textView: UITextView) -> Bool{
        let strngText =  textView.text.removeWhiteCharacterSetFromString()
        if strngText.length == 0{
            textView.text = "Write any additional messages here"
        }
        return true
    }
    
    
    
}
