//
//  WebserviceConstants.m
//  Mobitime
//
//  Created by Mohit Jain on 9/11/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

#import "WebserviceConstants.h"

@implementation WebserviceConstants

/**
 *  Dev Server
 */
//NSString *const BASE_URL = @"http://192.168.0.211:81/";

/**
 *  Local Server
 */
//NSString *const BASE_URL = @"http://gsu-miscwork02-dev.netsol.in/";
NSString *const BASE_URL = @"http://gsu-miscwork02-qa.netsol.in/";
//NSString *const BASE_URL = @"http://gsu-miscwork02.netsolutions.in/";
/**
 *  Sub Url
 */
NSString *const APP_URL = @"app/api/";
NSString *const AUTH_URL = @"o/";


/*****************************************Webservice Constants******************************/
// Webservice Key or Value constants

NSInteger const DeviceType = 1;
NSInteger const WebserviceSuccessValue = 200;

NSString *const WebserviceAccessTokenKey = @"access_token";
NSString *const WebserviceStatusCodeKey = @"status_code";
NSString *const WebserviceResponseKey = @"response";
NSString *const WebserviceKeyForPublicToken = @"KeyForFetchPublicToken";
NSString *const WebserviceValueForPublicToken = @"ValueForFetchPublicToken";

/**
 *  Web services
 */
NSString *const WebserviceSignUp  = @"users/signup";
NSString *const WebserviceSignIn  = @"users/login";
NSString *const WebserviceFBlogin  = @"users/fblogin";
NSString *const WebserviceGetFeeds  = @"feeds/getFeeds";
NSString *const WebserviceGetFriends  = @"friends/getUserFriends";
NSString *const WebserviceSaveFeed  = @"feeds/saveFeed";
NSString *const WebserviceGetNotiSettings = @"notifications/getNotificationSettings";
NSString *const WebserviceSaveNotiSettings = @"notifications/updateNotificationSettings";
NSString *const WebserviceGetSearchUser = @"friends/search";
NSString *const WebserviceGetSendFriendReq = @"friends/sendFriendRequest";
NSString *const WebserviceGetProfile = @"users/getProfile";
NSString *const WebservicePagingProfile = @"users/profileDataSection";
NSString *const WebserviceSendFriendReq = @"sendFriendRequest";
NSString *const WebserviceFriendRequests = @"friends/getFriendRequestList";
NSString *const WebserviceupdateFriendRequest = @"friends/updateFriendRequest";
NSString *const WebserviceLogout = @"users/logout";
NSString *const WebserviceLikeProfile = @"users/likeProfile";
NSString *const WebserviceUpdateCoverPic = @"users/updateCoverPhoto";
NSString *const WebserviceUpdateProfilePic = @"users/updateProfilePic";
NSString *const WebserviceUnfriend = @"friends/removeFriend";
NSString *const WebserviceNotifyTagFriends = @"notifications/notifyTaggedFriends";
NSString *const WebservicePostComment = @"feeds/postComment";
NSString *const WebserviceGetComment = @"feeds/getComments";
NSString *const WebserviceGetChatList = @"messages/getChatList";
NSString *const WebserviceGetChat = @"messages/getChat";
NSString *const WebserviceSendMessage = @"messages/sendMessage";
NSString *const WebserviceChangeUsername = @"users/changeUsername";
NSString *const WebserviceChangePassword = @"users/changePassword";
NSString *const WebserviceChatHistory = @"messages/updateChatHistorySetting";
NSString *const WebserviceClearHistory = @"messages/clearHistory";
NSString *const WebserviceUpdateProfile = @"users/updateProfile";
NSString *const WebserviceGetNotificationList = @"notifications/getNotificationList";
NSString *const WebserviceForgetPassword = @"users/forgetPassword";
NSString *const WebserviceForgetUsername = @"users/forgetUsername";
NSString *const WebserviceSaveBookmark = @"feeds/saveBookmark";
NSString *const WebserviceGetBookmarkList = @"feeds/getBookmarkList";
NSString *const WebserviceDeleteMessage = @"messages/deleteMessage";
NSString *const WebserviceDeletePost = @"feeds/deleteFeed";
NSString *const WebserviceReportFeed = @"feeds/reportFeed";
NSString *const WebserviceNotificationCount = @"notifications/getNotificationCount";
NSString *const WebserviceGetAutoSuggestion = @"getAutoSuggestion";
NSString *const WebserviceViewPost = @"feeds/viewFeed";
@end
