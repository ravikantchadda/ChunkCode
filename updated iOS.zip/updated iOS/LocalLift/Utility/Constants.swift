//
//  Constants.swift
//  Rabbit
//
//  Created by Aditya Aggarwal on 10/5/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit
import Foundation



class Constants: NSObject {
    
    static let CkCalendarViewTag = 142341
     static let  appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    
    static let DateTimeFormatwithAMPM = "d MMM yyyy HH:mm:ss a"
    static let DateFormatwithAMPM = "d MMM yyyy"
    static let TimeFormat = "HH:mm a"
    
    static let DateTimeHiphenFormat = "yyyy-MM-dd HH:mm:ss a"
    static let DateTimeSlashFormat = "MM/dd/yyyy HH:mm:ss a"
    static let DateSlashFormat = "MM/dd/yyyy"
    
    //MARK:- Color Constants
    static let APP_THEME_COLOR:UIColor = UIColor.colorWithRGB(227, green: 36, blue: 98, alpha: 1)
    
    //MARK:- UI Alerts Constants
    
    static let kAlertTitle: String = "Error!"
    static let kEnterAllTheFields: String = "Please enter all the text fields"
    static let kValidMobileNo: String = "Please enter valid mobile number"
    static let kEnterEmailAddress: String = "Please enter email address."
    static let kEnterPassword: String = "Please enter password."
    static let kEnterRepeatPassword: String = "Please enter repeat password."
    static let kEnterValidEmailAddress: String = "Please enter a valid email address."
    static let kEnterUserName: String = "Please enter username."
    static let kEnterFirstName: String = "Please enter first name."
    static let kEnterLastName: String = "Please enter last name."
    static let kEnterPassowrdRepeatPassowrdMatch: String = "Your password & repeat password do not match."
    static let kSomethingWrong:String = "Oops! Something went wrong."
    
    
    // MARK:- API keys
    
//    static let APIKeyOfGoogle = "AIzaSyDwl6JCN5s6Jpu8N-wWQAnQZgjD1oF_z4o"
    static let APIKeyOfGoogle = "AIzaSyCudBoM1rqNWqVT8KGJ5VsPQkPUGvTeUf0"
    static let APIKeyOfGoogleFromAndroid =  "AIzaSyAORhHzkaIUZEseT3MNJSlcTJg1K_-vqfE"
    static let ServerKeyGoogle =  "AIzaSyCWXUyehck374mEoW5L7ZvefLVkEUcq1Yk"
    
    //MARK:- Device Type Constants
    enum UIUserInterfaceIdiom : Int
    {
        case Unspecified
        case Phone
        case Pad
    }
    
    struct ScreenSize
    {
        static let SCREEN_WIDTH         = UIScreen.mainScreen().bounds.size.width
        static let SCREEN_HEIGHT        = UIScreen.mainScreen().bounds.size.height
        static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
        static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    }
    
    struct DeviceType
    {
        static let IS_IPHONE_4_OR_LESS  = UIDevice.currentDevice().userInterfaceIdiom == .Phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
        static let IS_IPHONE_5          = UIDevice.currentDevice().userInterfaceIdiom == .Phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
        static let IS_IPHONE_6          = UIDevice.currentDevice().userInterfaceIdiom == .Phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
        static let IS_IPHONE_6P         = UIDevice.currentDevice().userInterfaceIdiom == .Phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
        static let IS_IPAD              = UIDevice.currentDevice().userInterfaceIdiom == .Pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
    }
    
    //MARK:- iOS Versions Constants
    struct Version{
        static let SYS_VERSION_FLOAT = (UIDevice.currentDevice().systemVersion as NSString).floatValue
        static let iOS7 = (Version.SYS_VERSION_FLOAT < 8.0 && Version.SYS_VERSION_FLOAT >= 7.0)
        static let iOS8 = (Version.SYS_VERSION_FLOAT >= 8.0 && Version.SYS_VERSION_FLOAT < 9.0)
        static let iOS9 = (Version.SYS_VERSION_FLOAT >= 9.0 && Version.SYS_VERSION_FLOAT < 10.0)
    }
    
    
}
