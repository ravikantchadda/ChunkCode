//
//  NotificationList.swift
//  Aashiqui
//
//  Created by ketan saini on 16/11/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class NotificationList: NSObject {
    /*
    {
    minutesAgo = 8594;
    notiContentId = 17834;
    notificationText = "rat rani has sent you a message";
    notificationType = MM;
    personName = "";
    postOwnerId = 0;
    postPhotoUrl = "";
    postType = "";
    userId = 2860;
    userProfilePicUrl = "http://gsu-miscwork02-qa.netsol.in/images/2860/profilepic/c1405cabb3a28978744bfd9ae2b5140a.jpg";
    }
    */
    
    var minutesAgo:String!
    var notiContentId:String!
    var notificationText:String!
    var notificationType:String!
    var personName:String!
    var postOwnerId:String!
    var postPhotoUrl:String!
    var postType:String!
    var userId:String!
    var userProfilePicUrl:String!
    
    
    // MARK: NSCoding
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.minutesAgo = (decoder.decodeObjectForKey("minutesAgo") as! String?)!
        self.notiContentId = (decoder.decodeObjectForKey("notiContentId") as! String?)!
        self.notificationText = (decoder.decodeObjectForKey("notificationText") as! String?)!
        self.notificationType = (decoder.decodeObjectForKey("notificationType") as! String?)!
        self.personName = (decoder.decodeObjectForKey("personName") as! String?)!
        self.postOwnerId = (decoder.decodeObjectForKey("postOwnerId") as! String?)!
        self.postPhotoUrl = (decoder.decodeObjectForKey("postPhotoUrl") as! String?)!
        self.postType = (decoder.decodeObjectForKey("postType") as! String?)!
        self.userId = (decoder.decodeObjectForKey("userId") as! String?)!
        self.userProfilePicUrl = (decoder.decodeObjectForKey("userProfilePicUrl") as! String?)!
        
    }
    
    func encodeWithCoder(coder: NSCoder) {
        coder.encodeObject(self.minutesAgo, forKey: "minutesAgo")
        coder.encodeObject(self.notiContentId, forKey: "notiContentId")
        coder.encodeObject(self.notificationText, forKey: "notificationText")
        coder.encodeObject(self.notificationType, forKey: "notificationType")
        coder.encodeObject(self.personName, forKey: "personName")
        coder.encodeObject(self.postOwnerId, forKey: "postOwnerId")
        coder.encodeObject(self.postPhotoUrl, forKey: "postPhotoUrl")
        coder.encodeObject(self.postType, forKey: "postType")
        coder.encodeObject(self.userId, forKey: "userId")
        coder.encodeObject(self.userProfilePicUrl, forKey: "userProfilePicUrl")
    }
    
    func fillDataInModel(arrData: NSArray) -> NSMutableArray {
        let arrListData: NSMutableArray! = []
        for dict in arrData{
            let objChatList = NotificationList()
            objChatList.minutesAgo = dict.valueForKey("minutesAgo") as! String
            objChatList.notiContentId = dict.valueForKey("notiContentId") as! String
            objChatList.notificationText = dict.valueForKey("notificationText") as! String
            objChatList.notificationType = dict.valueForKey("notificationType") as! String
            objChatList.personName = dict.valueForKey("personName") as! String
            objChatList.userId = dict.valueForKey("userId") as! String
            if (dict.valueForKey("userProfilePicUrl")?.isKindOfClass(NSNull) != true){
                objChatList.userProfilePicUrl = dict.valueForKey("userProfilePicUrl") as! String
            }else{
                objChatList.userProfilePicUrl = ""
            }
            if (dict.valueForKey("postPhotoUrl")?.isKindOfClass(NSNull) != true){
                objChatList.postPhotoUrl = dict.valueForKey("postPhotoUrl") as! String
            }else{
                objChatList.postPhotoUrl = ""
            }
            if (dict.valueForKey("postOwnerId")?.isKindOfClass(NSNull) != true){
                objChatList.postOwnerId = dict.valueForKey("postOwnerId") as! String
            }else{
                objChatList.postOwnerId = ""
            }
            if (dict.valueForKey("postType")?.isKindOfClass(NSNull) != true){
                objChatList.postType = dict.valueForKey("postType") as! String
            }else{
                objChatList.postType = ""
            }
            arrListData.addObject(objChatList)
        }
        return arrListData
    }

}
