//
//  GroupTypeCell.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/22/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class GroupTypeCell: UITableViewCell {

    @IBOutlet weak var btnSelectGroupType: UIButton!
    @IBOutlet weak var lblGroupTypeName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code blue_unchecked
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
