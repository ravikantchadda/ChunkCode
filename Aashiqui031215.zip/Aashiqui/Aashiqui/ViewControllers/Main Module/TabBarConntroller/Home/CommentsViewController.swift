//
//  CommentsViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 06/11/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class CommentsViewController: UIViewController, MessageComposerViewDelegate {
    var messageView: MessageComposerView!
    @IBOutlet weak var tblComments: UITableView!
    var postId: String!
    var pageComments = 1
    var arrCommentData: NSMutableArray! = []
    @IBOutlet weak var tblViewHeightConstrait: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        messageView = MessageComposerView()
        messageView.delegate = self
        messageView.messagePlaceholder = "Write Comment here"
        self.view.addSubview(messageView)
        tblComments.tableFooterView = UIView(frame: CGRectZero)
        print("postId--\(postId)")
        
        fnGetComments(true)
        
        //MARK: - Pull to refresh and Infinite scrolling
        tblComments.addPullToRefreshHandler {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), { () -> Void in
                self.pageComments += 1
                if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                    let dict:NSDictionary = [
                        "userId": userId,
                        "postId": self.postId,
                        "page": self.pageComments
                    ]
                    print("\(dict)")
                    self.fnGetCommentsWebServiceWithPostDic(dict, showLoader: false)
                }
            })
        }
    }
    
    func fnGetComments(showLoader: Bool) {
        if (Utility.checkNetwork() == true){
            if self.arrCommentData != nil {
                self.arrCommentData.removeAllObjects()
            }
            if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                self.pageComments = 1
                let dict:NSDictionary = [
                    "userId": userId,
                    "postId": self.postId,
                    "page": self.pageComments
                ]
                print("\(dict)")
                self.fnGetCommentsWebServiceWithPostDic(dict, showLoader: showLoader)
            }
        }
    }
    
    @IBAction func btnPressed_Back(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }

    
    // MARK: - Webservice Call Methods
    //Get Comments API
    func fnGetCommentsWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        //        ObjWebserviceCall.cachePolicy = WebserviceCallCachePolicyRequestFromCacheFirstAndThenFromUrlAndUpdateInCache
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceGetComment)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("GetComments--- \(response.webserviceResponse)")
                if (response.webserviceResponse != nil) {
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    let arrData = response.webserviceResponse.valueForKey("comments") as! NSArray
                    let arrModelData = Comment().fillDataInModel(arrData)
                    
                    if(showLoader){
                        arrModelData.enumerateObjectsWithOptions( NSEnumerationOptions.Reverse, usingBlock: { (obj, idx, stop) -> Void in
                            self.arrCommentData.addObject(arrModelData.objectAtIndex(idx))
                        })
                    }else{
                        arrModelData.enumerateObjectsUsingBlock({ object, index, stop in
                            self.arrCommentData.insertObject(arrModelData.objectAtIndex(index), atIndex: 0)
                        })
                    }
                }else{
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                self.tblComments.reloadData()
                if (self.arrCommentData.count > 0 && self.tblComments.contentSize.height > self.tblComments.frame.height){
                    self.tblComments.contentOffset = CGPointMake(0, self.tblComments.contentSize.height - self.tblComments.frame.height)
                }
                self.tblComments.pullToRefreshView?.stopAnimating()
                }
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
    //Post Comments API
    func fnPostCommentsWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebservicePostComment)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("PostComments--- \(response.webserviceResponse)")
                if (response.webserviceResponse != nil) {
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    self.fnGetComments(false)
                    
                }else{
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                }
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }

    
    
    //MARK: - TableView DataSource/Delegate
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView!, heightForRowAtIndexPath indexPath: NSIndexPath!) -> CGFloat {
        return self.getRowHeightFeedCell(indexPath)
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (arrCommentData != nil){
            return arrCommentData.count
        }
        return 0
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if(tableView.respondsToSelector(Selector("setSeparatorInset:"))){
            tableView.separatorInset = UIEdgeInsetsZero
        }
        if(tableView.respondsToSelector(Selector("setLayoutMargins:"))){
            
            tableView.layoutMargins = UIEdgeInsetsZero
            
        }
        if(cell.respondsToSelector(Selector("setLayoutMargins:"))){
            
            cell.layoutMargins = UIEdgeInsetsZero
            
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(
            "cellComments", forIndexPath: indexPath)
        let objComments:Comment = self.arrCommentData.objectAtIndex(indexPath.row) as! Comment
        
        //UIImage Profile Image
        if let imgVwProfile:AsyncImageView = cell.viewWithTag(1001) as? AsyncImageView {
            imgVwProfile.image = UIImage(named: "placeholder")
            if let variableName: String = objComments.userProfilePicUrl{
                imgVwProfile.crossfadeDuration = 0.0
                imgVwProfile.imageURL = NSURL(string: variableName)
            }
        }
        if let lblName = cell.viewWithTag(1002) as? UILabel {
            lblName.text = objComments.userFirstName + " " + objComments.userLastName
        }
        if let lblTime = cell.viewWithTag(1003) as? UILabel {
            let strSec: NSInteger = Int(objComments.minutesAgo)! * 60
            let date = NSDate(timeInterval: NSTimeInterval(-strSec), sinceDate: NSDate())
            lblTime.text = Utility.relativeDateStringForDate(date)
        }
        
        for view in cell.contentView.subviews{
            if(view.tag == 9852){
                view.removeFromSuperview()
            }
        }
        let lblStatus = UILabel()
        lblStatus.textAlignment = NSTextAlignment.Left
        lblStatus.text = objComments.commentText
        let lblHeight = self.heightForView(lblStatus.text!, width: cell.frame.size.width - 80)
        lblStatus.tag = 9852
        lblStatus.numberOfLines = 0
        lblStatus.textColor = NSIConstants.greyColor
        lblStatus.font = UIFont(name: "Lato-Regular", size: 13)
        lblStatus.lineBreakMode = NSLineBreakMode.ByWordWrapping
        lblStatus.sizeToFit()
        lblStatus.frame = CGRectMake(60, 30, cell.frame.size.width - 80, lblHeight + 2)
        cell.contentView.addSubview(lblStatus)
        

        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
    }
    
    //Calculate UILabel height
    func heightForView(text:String, width:CGFloat) -> CGFloat{
        let label:UILabel = UILabel(frame: CGRectMake(0, 0, width, CGFloat.max))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.ByWordWrapping
        label.font = UIFont(name: "Lato-Regular", size: 13)
        label.text = text
        label.sizeToFit()
        return label.frame.height
    }
    
    //MARK - Get Feed Cell Height
    func getRowHeightFeedCell(indexPath: NSIndexPath) -> CGFloat{
        let objComments:Comment = self.arrCommentData.objectAtIndex(indexPath.row) as! Comment
        let lblHeight = self.heightForView(objComments.commentText, width: tblComments.frame.size.width - 80)
    
        return 40 + lblHeight
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func messageComposerSendMessageClickedWithMessage(message: String) {
        if (Utility.checkNetwork() == true){
            if (message.characters.count < 200) {
                if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                    let dict:NSDictionary = [
                        "userId": userId,
                        "postId": self.postId,
                        "commentText": message
                    ]
                    print("\(dict)")
                    self.fnPostCommentsWebServiceWithPostDic(dict, showLoader: true)
                }
            }else{
                Utility.showAlert("", message: "You can enter maximum 200 characters.", delegate: nil)
            }
        }
    }
    func messageComposerFrameDidChange(frame: CGRect, withAnimationDuration duration: CGFloat, andCurve curve: Int) {
        
    }
    
    func messageComposerUserTyping(isTyping: Bool) {
        if isTyping {
            tblViewHeightConstrait.constant = 300
            tblComments.contentOffset = CGPointMake(0, tblComments.contentSize.height)
        }else{
            tblViewHeightConstrait.constant = 60
            tblComments.contentOffset = CGPointMake(0, tblComments.contentSize.height)
        }
        tblComments.reloadData()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
