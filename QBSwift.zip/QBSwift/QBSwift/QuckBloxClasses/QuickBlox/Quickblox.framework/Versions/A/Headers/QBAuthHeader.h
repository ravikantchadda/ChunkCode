//
//  QBAuthHeader.h
//  Quickblox
//
//  Created by Andrey Moskvin on 6/13/14.
//  Copyright (c) 2014 QuickBlox. All rights reserved.
//

#ifndef Quickblox_QBAuthHeader_h
#define Quickblox_QBAuthHeader_h

#import <Quickblox/QBRequest+QBAuth.h>
#import <Quickblox/QBSessionParameters.h>

#endif
