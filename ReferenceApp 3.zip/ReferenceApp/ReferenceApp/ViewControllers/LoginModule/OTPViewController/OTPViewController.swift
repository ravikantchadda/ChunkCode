//
//  OTPViewController.swift
//  ReferenceApp
//
//  Created by Mohit Jain on 9/1/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit

class OTPViewController: UIViewController {

    var strEmailUser:String!
    @IBOutlet weak var lblOTP: UILabel!
    @IBOutlet weak var btnOk: UIButton!
    @IBOutlet weak var txtFieldOTP: UITextField!
    @IBOutlet weak var txtFieldFirstDigit: UITextField!
    @IBOutlet weak var txtFieldSecondDigit: UITextField!
    @IBOutlet weak var txtFieldThirdDigit: UITextField!
    @IBOutlet weak var txtFieldFourthDigit: UITextField!
    private let passcodeCharacter:String = "\u{2014}" // A longer "-";

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //setup UI
        self.setupUIElements()
        makeDigitField()
//        let user = userDL()
        
      
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - SetupUIElements
    func setupUIElements() {
        //set text for iboutlets
//        lblOTP.text = NSLocalizedString("lblOTP",comment:"")
       // btnOk.setTitle(NSLocalizedString("btnOkOTP",comment:""), forState: UIControlState.Normal)

        self.navigationItem.title = NSLocalizedString("naviagtionBarTitleOTP",comment:"")
    }
    
    //MARK: - Intialize Digit Text Field
    func makeDigitField() {
        txtFieldFirstDigit.text = passcodeCharacter;
        txtFieldSecondDigit.text = passcodeCharacter;
        txtFieldThirdDigit.text = passcodeCharacter;
        txtFieldFourthDigit.text = passcodeCharacter;
        resetTextFields()
    }
    
    //MARK: - Reset Text Fields
    func resetTextFields() {
        txtFieldOTP.text = "";
        if !txtFieldOTP.isFirstResponder() {
            txtFieldOTP.becomeFirstResponder()
        }
        txtFieldFirstDigit.secureTextEntry = false;
        txtFieldSecondDigit.secureTextEntry = false;
        txtFieldThirdDigit.secureTextEntry = false;
        txtFieldFourthDigit.secureTextEntry = false;
    }

    
    //MARK: - Prepare For Segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!) {
        if (segue.identifier == "ResetPassword") {
            let viewController:ResetPasswordViewController = segue.destinationViewController as! ResetPasswordViewController
            viewController.strEmailUser = strEmailUser
            viewController.strOtpUser = txtFieldOTP.text
        }
    }
    
    // MARK: - @IBAction Methods
    
    @IBAction func btnResendTapped(sender: AnyObject) {
    
    self.navigationController?.popViewControllerAnimated(true)
    }

    @IBAction func btnOkTapped(sender: AnyObject) {
        if(checkEmptyOTP(txtFieldOTP.text)) {
            let dict:Dictionary = [
                "email": strEmailUser,
                "otp": txtFieldOTP.text,
                "device_id": NSIUtility.getUniqueIdentifier()
            ]
            
            
            self.requestforUserValidateOTP(dict)
            
        }
    }
    
    
    //MARK: - Method Validate OTP
    func requestforUserValidateOTP(params:NSDictionary){
        let user = UserDL()
        user.requestforUserValidateOTP(params, withCompletionHandler: { (obj, success) -> Void in
            
            if success == true{
                
                
                NSIUtility.DBlog(obj?.valueForKey(Constants.keyStatusCode) as! NSNumber)
                NSIUtility.DBlog(success as Bool!)
                
                print(obj?.valueForKey(Constants.keyStatusCode) as! NSNumber)
                
                let statusCode = obj?.valueForKey(Constants.keyStatusCode) as! NSNumber
                if statusCode == 200{//****Status code 200 defined the success response
                    self.performSegueWithIdentifier("ResetPassword", sender: self)
                    NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""),message:"OTP validate successfully.Please reset your password.", view: self, delegate: nil)
                    
                    
                }
                if statusCode == 111{//****Status code 200 defined the success response
                    self.performSegueWithIdentifier("ResetPassword", sender: self)
                    NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""),message:"Please enter a valid OTP.", view: self, delegate: nil)
                    
                    
                }
                
            }else{
                
                NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""), message: Constants.kAlertServerError, view: self, delegate: nil)
                
            }
            
        })
        
        
    }

    //MARK: - text Field Delegate
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        if string == "\n" {
            return false
        }
        let text:NSString? = textField.text
        let typedString:NSString = text!.stringByReplacingCharactersInRange(range, withString: string)
        if typedString.length >= 1 {
            txtFieldFirstDigit.secureTextEntry = true
        } else {
            txtFieldFirstDigit.secureTextEntry = false
        }
        if typedString.length >= 2 {
            txtFieldSecondDigit.secureTextEntry = true
        } else {
            txtFieldSecondDigit.secureTextEntry = false
        }
        if typedString.length >= 3 {
            txtFieldThirdDigit.secureTextEntry = true
        } else {
            txtFieldThirdDigit.secureTextEntry = false
        }
        if typedString.length >= 4 {
            txtFieldFourthDigit.secureTextEntry = true
        } else {
            txtFieldFourthDigit.secureTextEntry = false
        }
        if typedString.length > 4 {
            return false
        }
        return true
    }
    
    //MARK: Actions
    func denyAccess() {
        let dispatchTime: dispatch_time_t = dispatch_time(DISPATCH_TIME_NOW, Int64(0.2 * Double(NSEC_PER_SEC)))
        dispatch_after(dispatchTime, dispatch_get_main_queue(), {
            self.resetTextFields()
        })
        let animation:CAKeyframeAnimation = CAKeyframeAnimation(keyPath: "transform.translation.x")
        animation.duration = 0.6
        animation.timingFunction = CAMediaTimingFunction(name: kCAAnimationLinear)
        animation.values =  [-12,12,-12,-6,6,-3,3,0]
        txtFieldFirstDigit.layer.addAnimation(animation, forKey: "shake")
        txtFieldSecondDigit.layer.addAnimation(animation, forKey: "shake")
        txtFieldThirdDigit.layer.addAnimation(animation, forKey: "shake")
        txtFieldFourthDigit.layer.addAnimation(animation, forKey: "shake")
    }

    
    // MARK: - Check Validation
    /**
    Check validation
    1. Empty check for OTP Field.
    - returns: bool value yes if all validations are fullfilled otherwise false.
    */

    func checkEmptyOTP(password: String!) -> (Bool) {
        if (!NSIUtility.checkIfStringContainsText(password))
        {
            
            NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""),message:  NSLocalizedString("EmptyString",comment: "comment"), view: self, delegate: nil)
            return false
        }
        return true
    }
}
