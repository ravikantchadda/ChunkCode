//
//  SelectDatePopoverVC.swift
//  LocalLift
//
//  Created by prabhjot singh on 12/24/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class SelectDatePopoverVC: UIViewController,UITableViewDelegate,UITableViewDataSource {

    typealias CompletionHandlerOfTablePopup = (arrayOfRequestID: NSArray! , buttonClickedString:String!) -> Void
    
    @IBOutlet var tableViewDates: UITableView!
    @IBOutlet var btnCancel: UIButton!
    @IBOutlet var btnConfirm: UIButton!
    var arrayOfDates = NSMutableArray()
    var requestID:NSNumber!
    
    
    var handler = CompletionHandlerOfTablePopup!()
    

    
    func didSelectButton(handlerPop:CompletionHandlerOfTablePopup){
        self.handler = handlerPop
        self.fetchReccuringLift()
    }
    
    @IBAction func toActionBtn(sender: UIButton) {
//        self.handler(text: self.txtViewOptional.text,buttonClickedString: sender.currentTitle)
        if arrayOfDates.count > 0{
            
            let predicateFrom:NSPredicate = NSPredicate(format: "isLiftSelectedNumber == 1")
            let arrayFiltered:NSArray = (arrayOfDates.filteredArrayUsingPredicate(predicateFrom))
            if let arrayOfIds:NSArray = arrayFiltered.valueForKey("requestReccuringID") as? NSArray{
                self.handler(arrayOfRequestID: arrayOfIds,buttonClickedString: "")
            }

        }
        self.toDismissView([])
    }
    
    @IBAction func toDismissView(sender: AnyObject){
        self.dismissViewControllerAnimated(true) { () -> Void in
        }
    }

    //MARK: - Fetch data from web service
    func fetchReccuringLift() {
        let reuestDL = RequestDL()
        reuestDL.requestForGetRequestLift(self.requestID, lastIndex:1 ,hasMaxCount:true) { (obj, success) -> Void in
            if success == true{
                
                if let requestBO = obj as? RequestBO{
                    if requestBO.arrayRecurringLiftRequests?.count != 0{
                        self.arrayOfDates = requestBO.arrayRecurringLiftRequests!
                        self.tableViewDates.reloadData()
                    }
                }
                
            }
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.initialInitilization()
        // Do any additional setup after loading the view.
    }
    
    func initialInitilization(){
        tableViewDates.registerNib(UINib.init(nibName: "ShowTimeViewLiftCell", bundle: nil), forCellReuseIdentifier: "showTimeViewLiftCell")
        self.tableViewDates.delegate = self
        self.tableViewDates.dataSource = self
    }

    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) ->Int
    {return self.arrayOfDates.count}
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 75
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) ->UITableViewCell {
        let showTimeViewLiftCell  = self.tableViewDates.dequeueReusableCellWithIdentifier("showTimeViewLiftCell") as! ShowTimeViewLiftCell
        showTimeViewLiftCell.selectionStyle = .None
        showTimeViewLiftCell.constDownShowDate.constant = 19
        showTimeViewLiftCell.constShowTimeUp.constant = 16
        
        let dicOfLiftTime = self.arrayOfDates[indexPath.row] as? RecurringLiftRequestsBO
        showTimeViewLiftCell.lblShowTime.text = dicOfLiftTime?.liftTime
        showTimeViewLiftCell.lblShowDate.text = dicOfLiftTime?.dateString
        
        if (!(dicOfLiftTime!.isLiftSelected))  {
            showTimeViewLiftCell.btnSelectedLift.setImage(UIImage(named: "blue_unchecked"), forState: UIControlState.Normal)
            showTimeViewLiftCell.btnSelectedLift.setImage(UIImage(named: "blue_unchecked"), forState: UIControlState.Selected)
        }
        else {
            showTimeViewLiftCell.btnSelectedLift.setImage(UIImage(named: "blue_checked"), forState: UIControlState.Normal)
        }
        return showTimeViewLiftCell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        let dicOfLiftTime = self.arrayOfDates[indexPath.row] as? RecurringLiftRequestsBO
        dicOfLiftTime?.isLiftSelected = !(dicOfLiftTime!.isLiftSelected)
        self.arrayOfDates[indexPath.row]  = dicOfLiftTime!
        tableView.reloadRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.None)
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
