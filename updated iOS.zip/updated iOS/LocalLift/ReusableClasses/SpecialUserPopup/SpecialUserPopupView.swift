//
//  SpecialUserPopupView.swift
//  LocalLift
//
//  Created by neeru thakur on 12/11/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit


protocol SpecialUserPopupViewProtocol
{
    func didSpecialUserPopUpViewDismiss(objectInfo:AnyObject?)
}

class SpecialUserPopupView: UIView {
    
    @IBOutlet weak var viewBase: UIView!
    @IBOutlet weak var imageViewProfilePic: UIImageView!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelSpecialText: UILabel!
    @IBOutlet weak var textViewMessage: UITextView!
    
    var delegate: AnyObject?
    
    @IBAction func buttonSpecial(sender: AnyObject) {
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.initializer()
    }
    
    func initializer(){
        self.viewBase?.layer.cornerRadius = 5.0
        self.viewBase?.layer.borderWidth = 0.5
        self.viewBase.layer.borderColor = UIColor.blackColor().CGColor
        self.viewBase?.clipsToBounds = true
    }
    
    func setProfilePic( profilePic: UIImage, withName _withname: NSString, withSpecialText _withSpecialText:NSString, withTextMessage _withTextMessage:NSString){
    
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        super.touchesBegan(touches, withEvent: event)
      
        if let touch =  touches.first{
            let location = touch.locationInView(self.viewBase)
            
            if CGRectContainsPoint(self.viewBase.frame, location){
                return
            }
            self.removeFromSuperview()
        }
        
    }
}