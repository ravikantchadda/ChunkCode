//
//  NotificationVC.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/9/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//
//
//import UIKit
//
//class NotificationVC: BaseViewController,UITableViewDataSource,UITableViewDelegate {
//
//    @IBOutlet weak var tableOfNotifications: UITableView!
//    var arrayOfNotifications = NSArray()
//    weak var noNotificationVW:NoNotificationView!
//
//    //MARK: - View Life Cycle Methods
//
//    override func viewWillAppear(animated: Bool) {
//        super.viewWillAppear(animated)
//        self.setNavigationBar(NavigationType.BlueNavigationType)
//    }
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        self.initialInitialization()
//        self.fetchNotifications()
//    }
//
//    //MARK: - table initialInitialization method
//    func initialInitialization() {
//       tableOfNotifications.registerNib(UINib(nibName: "NotificationCell", bundle: nil) , forCellReuseIdentifier: "NotifyCell")
//   //dynamic heigt for rows of table
//        tableOfNotifications.estimatedRowHeight = 75
//        tableOfNotifications.rowHeight = UITableViewAutomaticDimension
//   //hide row seperator
//        tableOfNotifications.tableFooterView = UIView()
//   //add uiview to show no notification
//        noNotificationVW = UIView.viewFromNibName("NoNotificationView") as? NoNotificationView
//        noNotificationVW.frame = CGRectMake(0, 0, self.view.size.width, self.view.size.height-66)
//        noNotificationVW.hidden=true
//        tableOfNotifications.insertSubview(noNotificationVW, aboveSubview: tableOfNotifications)
//     }
//    
//   //MARK: - Fetch data from web service
//    func fetchNotifications() {
//        let notificationDL = NotificationDL()
//        notificationDL.requestForGetNotificatio { (obj, success) -> Void in
//            if success == true {
//                self.arrayOfNotifications = obj as! NSArray
//                self.tableOfNotifications.reloadData()
//            }
//        }
//    }
//    
//    //MARK: - Table VIew Delegates
//    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//       let dicNotificationLiftByDate = self.arrayOfNotifications[section] as? NotificationBO
//       return (dicNotificationLiftByDate?.arrayOfOfLift.count)!
//     }
//    
//    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
//       if(self.arrayOfNotifications.count <= 0) {
//            noNotificationVW?.hidden=false
//            return 0
//        }
//        else  {
//            noNotificationVW?.hidden=true
//            return self.arrayOfNotifications.count
//        }
//    }
//    
//     func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
//        return basicCellAtIndexPath(indexPath)
//    }
//    
//    func basicCellAtIndexPath(indexPath:NSIndexPath) -> NotificationCell {
//        let cell:NotificationCell = (tableOfNotifications.dequeueReusableCellWithIdentifier("NotifyCell", forIndexPath: indexPath) as? NotificationCell)!
//        
//        let dicNotificationLiftByDate = self.arrayOfNotifications[indexPath.section] as? NotificationBO
//        let dicOfLift = (dicNotificationLiftByDate?.arrayOfOfLift)! as NSArray as! [LiftBO]
//        let addressOfDestinationForBuddy = dicOfLift[indexPath.row].addressBO as AddressBO
//        
//        cell.setBuddyNameForCell(dicOfLift[indexPath.row].liftRequesterName, withbuddyMessage: dicOfLift[indexPath.row].message)
//        cell.setBuddyDestinationForCell((addressOfDestinationForBuddy.addressName)!)
//        return cell
//    }
//    
//    //  Header View
//    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?{
//        if let viewHeader:ViewOfLinkedPassenger = UIView.viewFromNibName("ViewOfLinkedPassenger") as? ViewOfLinkedPassenger {
//             let dicNotificationLiftByDate = self.arrayOfNotifications[section] as? NotificationBO
//             viewHeader.lblSectionName.text = dicNotificationLiftByDate?.dateString
//             return viewHeader
//        }
//        return UIView()
//    }
//    
//    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
//        if let viewHeader:ViewOfLinkedPassenger = UIView.viewFromNibName("ViewOfLinkedPassenger") as? ViewOfLinkedPassenger {
//            return viewHeader.height}
//        else {
//            return 0
//        }
//    }
//    
//    //MARK: - deinit methof to free allocate resources
//    deinit {
//        self.tableOfNotifications = nil;
//        self.noNotificationVW = nil;
//    }
//}