//
//  ViewController.swift
//  LocalLift
//
//  Created by prabhjot singh on 10/26/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit
import MFSideMenu

class ViewController: BaseViewController {
    
    
    @IBOutlet var scroller: UIScrollView!
    
    
    //MARK: - View Life Cycle Methods
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBarHidden = true
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        if LocaliftSharedObj.sharedInstance.isDevoloping == true{
            let gesture:UILongPressGestureRecognizer = UILongPressGestureRecognizer(target:self, action: "showActionSheet:")
            self.view.addGestureRecognizer(gesture)
        }
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - Button Methods
    
    @IBAction func toExplore(sender: AnyObject) {
        
//        NSIUtility.showUnderDevelopmentAlert()
//        return
        
        if LocaliftSharedObj.sharedInstance.isDevoloping == true{
            let userDL:UserDL = UserDL()
            let userCredentials = (strUserName:"pravi@gmail.com", strPassword:"123456")
            userDL.requestforUserLogin(userCredentials, withCompletionHandler: { (obj, success) -> Void in
                if success == true{
                    
                    let mainFunction = NSIUtility.fetchViewControllerWithName("CreateProfileVC",storyBoardName:"Main")
                    self.navigationController?.pushViewController(mainFunction, animated: true)
                    
                    //                    let mainFunction = NSIUtility.fetchViewControllerWithName("HomeVC",storyBoardName:"Home")
                    //                    self.navigationController?.pushViewController(mainFunction, animated: true)
                    //                    self.configureMFSideMenu()
                }
                
            })
        }else{
            NSIUtility.showUnderDevelopmentAlert()
        }
        
    }
    
    func showActionSheet(gesture:UILongPressGestureRecognizer){
        if gesture.state == UIGestureRecognizerState.Ended{
            LocaliftSharedObj.sharedInstance.openActionPicker(self)
        }
    }
    
    func configureMFSideMenu(){
        
        let leftMenuVC:UIViewController = NSIUtility.fetchViewControllerWithName("LeftMenuVC", storyBoardName: "Home")
        let homeNavigationController:UINavigationController = NSIUtility.fetchViewControllerWithName("homeNavigationController", storyBoardName: "Home") as! UINavigationController
        let sideMenu:MFSideMenuContainerViewController = MFSideMenuContainerViewController.containerWithCenterViewController(homeNavigationController, leftMenuViewController: leftMenuVC, rightMenuViewController: nil)
        Constants.appDelegate.window?.rootViewController = sideMenu;
    }
    
}

