//
//  HomeVC.swift
//  LocalLift
//
//  Created by prabhjot singh on 12/7/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class HomeVC: BaseViewController,MapViewHomeProtocol {
    
    @IBOutlet var btnAddress: UIButton!
    var mapViewHome:MapViewHome!
    var arrayOfRequests:NSMutableArray!
    @IBOutlet var viewLiftInfo:LiftInfoView!
    
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
         self.menuContainerViewController.disablePanGeture = false

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialInitilization()
        self.setNavigationBar(.MenuNavigationType, withLeftMenu: true)

//        self.showSpecialUserPopupView()
//        self.setNavigationLeftBarButton()
    }

    func initialInitilization(){
        mapViewHome = UIView.viewFromNibName("MapViewHome") as? MapViewHome
        mapViewHome.delegate = self
        let viewForMap = self.view.viewWithTag(1001)
        mapViewHome.frame = viewForMap!.bounds
        viewForMap!.addSubview(mapViewHome)
        self.fetchLiftsForUser()
        
        if LocaliftSharedObj.sharedInstance.isDevoloping == true{
            let gesture:UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "gestureTap:")
            gesture.numberOfTapsRequired = 4
            self.navigationController?.navigationBar.addGestureRecognizer(gesture)
        }
    }
    
//MARK :- Navigation item Action
    func calenderButPressed(sender : AnyObject){
        
        if let viewLiftRequest:MyLiftVC = NSIUtility.fetchViewControllerWithName("MyLiftVC", storyBoardName: "Home") as? MyLiftVC{
            
            self.menuContainerViewController.disablePanGeture = true
             self.menuContainerViewController.disablePanGeture = true
            self.navigationController?.pushViewController(viewLiftRequest, animated: true)

        }
//        NSIUtility.fetchViewControllerWithName("MyLiftVC", storyBoardName: "Home") as! UINavigationController
//        
//            let myLiftNavigationController:UINavigationController = NSIUtility.fetchViewControllerWithName("myLiftNavigationController", storyBoardName: "Home") as! UINavigationController
//            self.navigationController?.presentViewController(myLiftNavigationController, animated: true, completion: {
//        
//        })
        
    }

    
//MARK:- Fetch Data Form Server
    
    func fetchLiftsForUser(){
        let liftDL = LiftDL()
        liftDL.requestForGetMapMarkers { (obj, success) -> Void in
            if success == true{
                self.mapViewHome.mapView.clear()
                self.arrayOfRequests = obj as! NSMutableArray
                self.toSetMarker()
            }
        }
    }
    
    
    func toSetMarker(){
        if self.arrayOfRequests.count != 0{
            for mapMarker in self.arrayOfRequests{
                if let markerMapBO = mapMarker as? MapMarkerBO{
                    if markerMapBO.location != nil
                    {
                        let imageBlinker = UIImage.animatedImageNamed("requestIcon", duration: 3)
                        let imageFethced = (markerMapBO.isOfferRequest == true ? UIImage(named: "offerIcon"):(markerMapBO.isImmediate == true ? imageBlinker:UIImage(named: "requestIcon2")))
                        self.mapViewHome.createMarker(markerMapBO.location!, name: "", icon: imageFethced!, otherInfo: markerMapBO)
                    
                    }
                }
            }
        }
        
//        self.searchCurrentLocationAddress()
    
    }
    
    
    func searchCurrentLocationAddress(){
        
        if (self.mapViewHome.locationManager.location != nil){
        
        self.mapViewHome.reverseGeocodeCoordinate(self.mapViewHome.locationManager.location!.coordinate) { (obj, success) -> Void in
            if success == true{
                if let str = obj as? String{
                    self.btnAddress.setTitle(str, forState: .Normal)
                }else{
                    self.btnAddress.setTitle("Search Address", forState: .Normal)
                }
            }
        }
    }
    }
    
//MARK:- Buttons Method
    @IBAction func toOfferRequest(sender: AnyObject) {
        
        let liftRequestNavigationController:UINavigationController = NSIUtility.fetchViewControllerWithName("liftRequestNavigationController", storyBoardName: "Home") as! UINavigationController
        
        if let viewController: LiftRequestVC = liftRequestNavigationController.viewControllers.first as? LiftRequestVC{
            viewController.whichLiftType = .LiftTypeOffer
            self.navigationController?.presentViewController(liftRequestNavigationController, animated: true, completion: {
                
            })
        }
    }
    
    @IBAction func toLiftRequestVC(sender: AnyObject) {
        
         let liftRequestNavigationController:UINavigationController = NSIUtility.fetchViewControllerWithName("liftRequestNavigationController", storyBoardName: "Home") as! UINavigationController
        if let viewController: LiftRequestVC = liftRequestNavigationController.viewControllers.first as? LiftRequestVC{
            viewController.whichLiftType = .LiftTypeRequest
            self.navigationController?.presentViewController(liftRequestNavigationController, animated: true, completion: {
                
            })
        }
    }
    
    
    @IBAction func toAddressButton(sender: AnyObject) {
        
        let controller = GooglePlacesSearchController(
            apiKey: Constants.ServerKeyGoogle,
            placeType: PlaceType.All
        )
        
        controller.didSelectGooglePlace { (place) -> Void in
            if let placeObj:PlaceDetails = place{
                self.mapViewHome.setCameraOfMap(placeObj.coordinate)
                self.btnAddress.setTitle(placeObj.name, forState: .Normal)
            }
            controller.active = false
        }
        presentViewController(controller, animated: true, completion: nil)
    }
    
    @IBAction func toRequestDetailView(sender: AnyObject) {
        if let viewLiftRequest:ViewLiftRequestVC = NSIUtility.fetchViewControllerWithName("ViewLiftRequestVC", storyBoardName: "Home") as? ViewLiftRequestVC{
            self.hideTheDetailView()
            
            if self.viewLiftInfo.liftBO != nil{
                if mapViewHome.lastMarkerImage != nil && mapViewHome.lastClickedMarker != nil{
                    mapViewHome.lastClickedMarker!.icon = mapViewHome.lastMarkerImage
                }
                viewLiftRequest.liftBO = self.viewLiftInfo.liftBO
                self.navigationController?.pushViewController(viewLiftRequest, animated: true)
            }
        }
    }
    
// MARK:- Geture Touch Action
    
    func gestureTap(gesture:UITapGestureRecognizer){
        
        if gesture.numberOfTapsRequired == 4{
            
            if let array:NSArray = (self.navigationController?.viewControllers)! as NSArray{
                for controller in array{
                    if let control = controller as? UIViewController{
                        self.navigationController?.popToViewController(control, animated: false)
                    }
                }
            }
            Constants.appDelegate.window?.rootViewController = NSIUtility.fetchViewControllerWithName("MainNavigation", storyBoardName: "Main")
        }
    }


//MARK:- Methods from Map
    
    func didSelectMarker(objectInfo: AnyObject?) {
        viewLiftInfo.fadeOut(0.5)
        if objectInfo != nil{
            if let mapMarkerBo = objectInfo as? MapMarkerBO{
                if mapMarkerBo.isOfferRequest == true{
                    NSIUtility.showUnderDevelopmentAlert()
                    return
                }
                 viewLiftInfo.toSetLiftViewData(mapMarkerBo)
                self.showTheDetailView()
            }
        }
    }
    
    func didFindCurrentLocation(){
        self.searchCurrentLocationAddress()
    }
    
    func didTapOnMap() {
        self.hideTheDetailView()
    }
    
    func showTheDetailView(){
        viewLiftInfo.fadeIn(0.5)
        self.view.bringSubviewToFront(viewLiftInfo!)
    }
    
    func hideTheDetailView(){
        viewLiftInfo.fadeOut(0.5)
    }
    
}
