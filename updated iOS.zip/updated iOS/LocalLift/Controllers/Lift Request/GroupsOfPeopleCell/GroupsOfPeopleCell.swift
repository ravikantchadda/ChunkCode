//
//  GroupsOfPeopleCell.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/25/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

protocol GroupsOfPeopleProtocol{
    
    func didSelectTheCell()
    
}

class GroupsOfPeopleCell: UITableViewCell,UICollectionViewDataSource,UICollectionViewDelegate {
    
    enum CollectionType:Int {case CollectionPassenger = 0, CollectionNotifyPeople = 1}
    
    @IBOutlet var collOfPsgr: UICollectionView!
    
    var arrayOfPassenger = NSMutableArray()
    var arrayOfNotifyPeople: NSMutableArray = []
    var collectionType:CollectionType!
    @IBOutlet var lblAlertMessage: UILabel!
    var delegate:GroupsOfPeopleProtocol?
    @IBOutlet var lblTileOfTheGroup: UILabel!
    @IBOutlet var constraintTopView: NSLayoutConstraint!
    
    
    
    var callBack:AnyObject?

    override func awakeFromNib() {
        super.awakeFromNib()
        collOfPsgr.registerClass(UICollectionViewCell.self, forCellWithReuseIdentifier: "UserCollCell")
        collOfPsgr.registerNib(UINib.init(nibName: "UserCollCell", bundle: nil), forCellWithReuseIdentifier: "UserCollCell")
        collOfPsgr.delegate = self
        collOfPsgr.dataSource = self
        
        // Initialization code
    }

    @IBAction func toAddPeople(sender: AnyObject) {
        if callBack != nil{
            if let liftRequst = callBack as? LiftRequestVC{
                if collectionType == .CollectionPassenger{
                    let selctPassenger = NSIUtility.fetchViewControllerWithName("SelectPassengerVC", storyBoardName: "Home") as!SelectPassengerVC
                    let arrayOfPass = liftRequst.cellOfPeople.arrayOfPassenger as NSArray
                    selctPassenger.arrayOfAddedPassenger = arrayOfPass as! NSMutableArray
                    liftRequst.navigationController?.pushViewController(selctPassenger, animated: true)
                    
                }else{
                    let notifyPeople = NSIUtility.fetchViewControllerWithName("NotifyPeopleVC", storyBoardName: "Home") as!NotifyPeopleVC
//                    notifyPeople.selectedArray.removeAllObjects()
//                    notifyPeople.selectedArray.arrayByAddingObjectsFromArray(liftRequst.cellOfPeople.arrayOfNotifyPeople as [AnyObject])
//                    notifyPeople.selectedArray = liftRequst.cellOfPeople.arrayOfNotifyPeople
                        notifyPeople.selectedArray = arrayOfNotifyPeople
                    
                    liftRequst.navigationController?.pushViewController(notifyPeople, animated: true)
                }
            }
        }
    }
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if callBack != nil{
            if let liftRequest = callBack as? LiftRequestVC{
                if collectionType == .CollectionPassenger{
                    liftRequest.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
                    return arrayOfPassenger.count + 1
                }else{
                    liftRequest.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
                    return arrayOfNotifyPeople.count + 1
                }
            }
        }else{
            if delegate != nil{
                if arrayOfPassenger.count == 0{
                    lblAlertMessage.hidden = false
                }else{
                    lblAlertMessage.hidden = true
                }
                return arrayOfPassenger.count
            }
        }
        return 0
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell:UserCollCell = collectionView.dequeueReusableCellWithReuseIdentifier("UserCollCell", forIndexPath: indexPath) as! UserCollCell
        
        if callBack != nil{
            if collectionType == .CollectionPassenger{
                
                if indexPath.row == arrayOfPassenger.count{
                    cell.imgViewPsgr.image = UIImage(named: "addPeopleBtn")
                    cell.lblPsgrName.text = ""
                }else{
                    
                    let psgrObj:PassengerBO = arrayOfPassenger[indexPath.row] as! PassengerBO
                    
                    cell.imgViewPsgr.image =  UIImage(named: "user_defaultImage")
                    cell.lblPsgrName.text = psgrObj.firstName
                }
                
            }else{
                
                if indexPath.row == arrayOfNotifyPeople.count{
                    cell.imgViewPsgr.image = UIImage(named: "addPeopleBtn")
                    cell.lblPsgrName.text = ""
                }else{
                    
                    let contactBO:ContactsBO = arrayOfNotifyPeople[indexPath.row] as! ContactsBO
                    
                    cell.imgViewPsgr.image =  UIImage(named: "user_defaultImage")
                    cell.lblPsgrName.text = contactBO.firstName
                }
            }
            
        }else{
            if delegate != nil {
                let psgrObj:PassengerBO = arrayOfPassenger[indexPath.row] as! PassengerBO
                cell.imgViewPsgr.image =  UIImage(named: "user_defaultImage")
                cell.lblPsgrName.text = psgrObj.firstName
            }
        }
        
        return cell
        
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath){
        
        if callBack != nil{
            if collectionType == .CollectionPassenger{
                if indexPath.row == arrayOfPassenger.count{
                    self.toAddPeople(UIButton())
                }else{
    //                let psgrObj:PassengerBO = arrayOfPassenger[indexPath.row] as! PassengerBO
                    
                }
            }else{
                if indexPath.row == arrayOfNotifyPeople.count{
                    self.toAddPeople(UIButton())
                }else{
    //                let psgrObj:ContactsBO = arrayOfNotifyPeople[indexPath.row] as! ContactsBO
                    
                }
            }
        }else{
            if delegate != nil {
                delegate?.didSelectTheCell()
            }
        }
    }
    
    
}
