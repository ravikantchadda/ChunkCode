//
//  CustomFontLabel.swift
//  Rabbit
//
//  Created by prabhjot singh on 10/15/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import Foundation
import UIKit

public class PSCustomFontLabel: UILabel {

    
    public func setCustomFont()
    {
//        print("will set in sub class")
    }
    
    override public func awakeFromNib() {
        super.awakeFromNib()
        self.setCustomFont()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder:aDecoder)
        self.setCustomFont()
    }
    
    required  public override init(frame: CGRect) {
        super.init(frame: frame)
        self.setCustomFont()
    }
}




public class PSBariolLightLabel: PSCustomFontLabel {
    
    
    override public func setCustomFont()
    {
        self.font = UIFont (name: "Bariol-Light", size:self.font.pointSize)
    }
    
}

public class PSBariolHeavyLabel: PSCustomFontLabel {
    
    override public func setCustomFont()
    {
        self.font = UIFont (name: "Bariol-Light", size:self.font.pointSize)
    }
    
}


public class PSHAlveticaLightLabel: PSCustomFontLabel {
    
    override public func setCustomFont()
    {
        self.font = UIFont (name: "Bariol-Light", size:self.font.pointSize)
    }
    
}