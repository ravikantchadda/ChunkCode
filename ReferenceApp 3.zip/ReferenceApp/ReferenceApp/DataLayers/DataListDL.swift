//
//  DataListDL.swift
//  ReferenceApp
//
//  Created by ravi kant on 12/8/15.
//  Copyright © 2015 Netsol. All rights reserved.
//

import Foundation
class DataListDL: NSIRestAPIHelper{
    
    // MARK: -  Method to Request for DataList
    /**
    *************************************
    Params:ServiceURL(its defined the method name)
    *************************************
    **/
    func requestforDataList(obj:AnyObject, withCompletionHandler handler:CompletionHandler)
    {
        
        self.serviceURL = "App/api/list/"
        self.isCallforOuth = false
        let outhToken:String!
        outhToken = NSIUtility.getValueFromUserDefaultsForKey("outhtoken") as! String
        
        self.headerdict = ["Authorization":outhToken]
        
        self.requestforGET(["":""]) { (obj, success) -> Void in
            if success == true
            {
                handler(obj: obj, success: true)
            }
            else{
                handler(obj: nil, success: false)
            }
        }
        
       
        
        
        
}
}