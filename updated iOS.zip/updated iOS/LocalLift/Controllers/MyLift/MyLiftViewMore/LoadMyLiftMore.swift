//
//  LoadMyLiftMore.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/16/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

protocol ViewMoreLiftrotocol
{
    func showMoreLift()
}

class LoadMyLiftMore: UIView {

    @IBOutlet weak var btnViewMore: UIButton!
    @IBOutlet weak var imageViewDownArrow: UIImageView!
    var delegate:ViewMoreLiftrotocol?
    
    @IBAction func viewMoreLift(sender: AnyObject) {
        if(delegate != nil) {
            delegate?.showMoreLift()
        }

    }
    
    func viewMoreBtnLeftAlignment() {
            self.btnViewMore.titleLabel!.textAlignment = .Left;
            self.btnViewMore.titleLabel!.numberOfLines = 0;
            self.btnViewMore.contentEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
    }

}
