//
//  AddressCell.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/27/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class AddressCell: UITableViewCell {

    @IBOutlet var lblTitleType: UILabel!
    @IBOutlet var lblAddress: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
