//
//  MyLiftGroupVC.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/21/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class MyLiftGroupVC: BaseViewController,ColectionCellSelectProtocol {

   @IBOutlet weak var viewHeader: LiftGroupHeaderText!
   @IBOutlet weak var viewGroupItems: LiftGroupCollection!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.intialization()
    }
   
    //Intial function
    func intialization() {
        self.setNavigationTitle()
        self.setNavigationRightBarButton()
        self.setNavigationLeftBarButton()
       
        viewHeader.lblHeaderText.text = "Create lift group for your different lift needs, \nto make it easy to notify the right people"
         viewGroupItems.delegate = self
        viewGroupItems.Intilization()
        
    }
    
    //MARK: - Set Bar button in navigation
    func setNavigationRightBarButton() {
        let btnLater = UIBarButtonItem(title: "Later", style: .Plain, target: self, action: "LaterPressed:")
        navigationItem.setRightBarButtonItem(btnLater, animated: true)
    }
    
    //MARK: - Set Navigation Title
    func setNavigationTitle() {
        
        // set navigation titleLabel for current month
        let label = UILabel(frame: CGRectMake(0.0, 0.0, self.view.size.width, 60.0))
        label.backgroundColor = UIColor.clearColor()
        label.font = UIFont.boldSystemFontOfSize(14.0)
        label.numberOfLines = 2
        let str = "Step 3 of 3"
        
        let attString = "My Lifts Groups \n\(str)" as NSString
        let attrbtdStrngBuddyMessage = NSMutableAttributedString(string: attString as String)
        
        attrbtdStrngBuddyMessage.addAttribute(NSFontAttributeName, value: UIFont.systemFontOfSize(16.0), range: attString.rangeOfString("My Lifts Groups"))
        attrbtdStrngBuddyMessage.addAttribute(NSFontAttributeName, value: UIFont.systemFontOfSize(13.0), range: attString.rangeOfString(str))
        
        let firstAttributes = [NSForegroundColorAttributeName: UIColor.whiteColor(), NSBackgroundColorAttributeName: UIColor.clearColor()]
        
        attrbtdStrngBuddyMessage.addAttributes(firstAttributes, range: attString.rangeOfString("My Lifts Groups"))
        attrbtdStrngBuddyMessage.addAttributes(firstAttributes, range: attString.rangeOfString(str))
        
        label.attributedText = attrbtdStrngBuddyMessage
        label.sizeToFit()
        label.textAlignment = NSTextAlignment.Center
        self.navigationItem.titleView = label
    }

    // Continue button pressed
    @IBAction func continueAction(sender: AnyObject) {
    }
    
    //MARK:- LeftNav Bar Items
    func setNavigationLeftBarButton() {
        let barBtnMenu = UIBarButtonItem(image: UIImage(named: "MenuIcon"), style: .Plain, target: self, action: "menuButtonClick:")
        navigationItem.leftItemsSupplementBackButton = true
        navigationItem.setLeftBarButtonItems([barBtnMenu], animated: true)
    }
    
    func menuButtonClick(sender:UIButton!){
        self.menuContainerViewController.toggleLeftSideMenuCompletion({
        })
    }
    
    // Later button in left of navigation pressed
    func LaterPressed(sender: UIButton) {
    }
    
   override func viewDidAppear(animated: Bool) {
        self.initialInitilization()
     }
    
   func initialInitilization() {
        viewGroupItems.reloadCollectionView()
     }
    
    //MARK:- Load new view controller for Create group
    func select() {
        let createLiftGroup = NSIUtility.fetchViewControllerWithName("CreateLiftGroupVC", storyBoardName: "Main") as!CreateLiftGroupVC
        self.navigationController?.pushViewController(createLiftGroup, animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
