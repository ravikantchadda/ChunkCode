//
//  WhenLiftNeedCell.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/25/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit
import ActionSheetPicker_3_0
import AFDateHelper

class WhenLiftNeedCell: UITableViewCell {

    @IBOutlet var btnWhentTime: UIButton!
    @IBOutlet var btnRecurring: UIButton!
    @IBOutlet var btnRecurringUntil: UIButton!
    
    
    var selectedWhenDate:NSDate!
    var selectedFrequency:FrequencyBO!
    var selectedUntilDate:NSDate!
    
    var arrayOfFrequency = NSMutableArray()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.initialInitialization()
    }
    
    func initialInitialization(){
        
        self.fetchFrequency()
        
        let currentDate = NSDate()
    // For Recurring
        let frquency = FrequencyBO()
        frquency.frequencyID = 4711
        frquency.frequencyName = "None"
        
        self.selectedFrequency = frquency
        self.btnRecurring.setTitle("None", forState: .Normal)
        self.btnRecurringUntil.setTitle("-", forState: .Normal)
        self.btnRecurringUntil.userInteractionEnabled = false
    // For When Date
        selectedWhenDate = currentDate
        self.btnWhentTime.setTitle(ConstantTodayString, forState: .Normal)
    }
    
    func fetchFrequency(){
     
        let frequencyDL = FrequencyDL()
        frequencyDL.requestforFrequency { (obj, success) -> Void in
            if success == true{
                self.arrayOfFrequency = obj as! NSMutableArray
            }else{
                NSIUtility.show(Constants.kSomethingWrong)
            }
        }
    }
    
    
// MARK:- Button Methods
    
    @IBAction func toWhenDateBtn(sender: UIButton) {
        
        let datePicker = ActionSheetDatePicker(title: "Select Date And Time:", datePickerMode: UIDatePickerMode.DateAndTime, selectedDate: NSDate(), doneBlock: {
            picker, value, index in
            if let dateByPicker = value as? NSDate{
                
                    self.selectedWhenDate = dateByPicker
                    var strselctedDate = self.selectedWhenDate!.toString(format:DateFormat.Custom(Constants.DateTimeFormatwithAMPM))
                    let dateAddThirtyMin = NSDate().dateByAddingMinutes(30)
                    if self.selectedWhenDate.isEarlierThanDate(dateAddThirtyMin)
                        {strselctedDate = ConstantTodayString}
                    self.btnWhentTime.setTitle(strselctedDate, forState: .Normal)
                
//                 For Recurring
                    self.btnRecurringUntil.setTitle("-", forState: .Normal)
                
            }
            
            return
            }, cancelBlock: { ActionStringCancelBlock in return }, origin: sender.superview!.superview)
//        let secondsOfThirtyMin: NSTimeInterval = 30 * 60;
//        datePicker.minimumDate = NSDate(timeInterval: -secondsOfThirtyMin, sinceDate: NSDate())
//        datePicker.minuteInterval = 1
        datePicker.minimumDate = NSDate()
        datePicker.showActionSheetPicker()
        
    }
    
    @IBAction func toRecurringBtn(sender: AnyObject) {
        
        ActionSheetStringPicker.showPickerWithTitle("Select Frequency", rows:self.arrayOfFrequency.valueForKey("frequencyName") as! [AnyObject], initialSelection: 0, doneBlock: {
            picker, index ,value in
            if let frequency:String = value as? String {
                self.selectedFrequency = self.arrayOfFrequency[index] as! FrequencyBO
                self.btnRecurring.setTitle(frequency, forState: .Normal)
                
                if frequency == "None"{
                    self.btnRecurringUntil.userInteractionEnabled = false
                    self.btnRecurringUntil.setTitle("-", forState: .Normal)
                }else{
                    self.btnRecurringUntil.userInteractionEnabled = true
                }
            }
            return
            }, cancelBlock: { ActionStringCancelBlock in return }, origin: sender)
    }
    
    
    @IBAction func toRecurringUntilBtn(sender: AnyObject) {
        
        let datePicker = ActionSheetDatePicker(title: "Select Date", datePickerMode: UIDatePickerMode.Date, selectedDate: self.selectedWhenDate, doneBlock: {
            picker, value, index in
            
            if let dateUntil = value as? NSDate{
                self.selectedUntilDate = dateUntil
                self.btnRecurringUntil.setTitle(self.selectedUntilDate!.toString(format:DateFormat.Custom(Constants.DateFormatwithAMPM)), forState: .Normal)
            }
            
            return
            }, cancelBlock: { ActionStringCancelBlock in return }, origin: sender.superview!!.superview)
//        let secondsOfThirtyMin: NSTimeInterval = 30 * 60;
        datePicker.minimumDate = self.selectedWhenDate
        datePicker.minuteInterval = 1
        datePicker.showActionSheetPicker()
        
    }
    
 
}
