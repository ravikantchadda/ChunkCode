//
//  CoreDataManager.swift
//  ReferenceApp
//
//  Created by Vivek Khurana on 22/09/15.
//  Copyright © 2015 Vivek Khurana. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class CoreDataManager: NSObject{
    
    var store: CoreDataStore!
    
    // Shared instance for class
    class var sharedManager: CoreDataManager {
        struct Static {
            static var onceToken: dispatch_once_t = 0
            static var instance: CoreDataManager? = nil
        }
        dispatch_once(&Static.onceToken) {
            Static.instance = CoreDataManager()
        }
        return Static.instance!
    }
    
    // main thread context
    
    lazy var managedObjectContext: NSManagedObjectContext = {
        // Returns the managed object context for the application (which is already bound to the persistent store coordinator for the application.) This property is optional since there are legitimate error conditions that could cause the creation of the context to fail.
        let coordinator = self.store.persistentStoreCoordinator
        var managedObjectContext = NSManagedObjectContext(concurrencyType: .MainQueueConcurrencyType)
        managedObjectContext.persistentStoreCoordinator = coordinator
        return managedObjectContext
        }()
    
    // Returns the background object context for the application.
    // You can use it to process bulk data update in background.
    // If the context doesn't already exist, it is created and bound to the persistent store coordinator for the application.
    
    lazy var backgroundContext: NSManagedObjectContext? = {
        // Returns the managed object context for the application (which is already bound to the persistent store coordinator for the application.) This property is optional since there are legitimate error conditions that could cause the creation of the context to fail.
        let coordinator = self.store.persistentStoreCoordinator
        var backgroundContext = NSManagedObjectContext(concurrencyType: .PrivateQueueConcurrencyType)
        backgroundContext.persistentStoreCoordinator = coordinator
        return backgroundContext
        }()
    
    // Initialize Core Data Store and add observer for "contextDidSaveContext:"
    func setupDataManager() {
        
        self.store = CoreDataStore()
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "contextDidSaveContext:", name: NSManagedObjectContextDidSaveNotification, object: nil)
    }
    
    // save NSManagedObjectContext
    func saveContext (context: NSManagedObjectContext) {
        var error: NSError? = nil
        if context.hasChanges {
            do {
                try context.save()
            } catch let error1 as NSError {
                error = error1
                // Replace this implementation with code to handle the error appropriately.
                // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                NSLog("Unresolved error \(error), \(error!.userInfo)")
                //                abort()
            }
        }
    }
    
    func saveContext () {
        self.saveContext( self.backgroundContext! )
    }
    
    // call back function by saveContext, support multi-thread
    func contextDidSaveContext(notification: NSNotification) {
        let sender = notification.object as! NSManagedObjectContext
        if sender === self.managedObjectContext {
            self.backgroundContext!.performBlock {
                self.backgroundContext!.mergeChangesFromContextDidSaveNotification(notification)
            }
        } else if sender === self.backgroundContext {
            self.managedObjectContext.performBlock {
                self.managedObjectContext.mergeChangesFromContextDidSaveNotification(notification)
            }
        } else {
            self.backgroundContext!.performBlock {
                self.backgroundContext!.mergeChangesFromContextDidSaveNotification(notification)
            }
            self.managedObjectContext.performBlock {
                self.managedObjectContext.mergeChangesFromContextDidSaveNotification(notification)
            }
        }
    }
    
    // MARK: Core Data CRUD operations
    
    func deleteEntity(entity: String, index: Int) -> Bool {
        var data = fetchEntity(entity, predicate:nil,fromBackgroundContext: false)
        if data != nil {
            var success:Bool
            do {
                backgroundContext!.deleteObject(data![index])
                try backgroundContext!.save()
                success = true
            } catch let saveError as NSError {
                
                NSIUtility.DBlog("saveNewItem error: \(saveError.localizedDescription)")
               
                success = false
            }
            
            return success
        }
        
        return false
    }
    
    func entityIsEmpty(entity: String, predicate: NSPredicate?) -> Bool
    {
        let request = NSFetchRequest(entityName: entity)
        let error = NSErrorPointer()
        //setPredicate
        let count = managedObjectContext.countForFetchRequest(request, error: error)
        if error != nil
        {
            
              NSIUtility.DBlog("Error: \(error.debugDescription)")
            
            return true
        }
        else
        {
            if count == 0
            {
                return true
            }
            else
            {
                return false
            }
        }
    }
    func fetchEntity(entity: String, predicate: NSPredicate?,fromBackgroundContext:Bool) -> [NSManagedObject]? {
        let fetchRequest = NSFetchRequest(entityName: entity)

        //setPredicate
        fetchRequest.predicate = predicate
        
        //Execute Fetch request
        var fetchedResults:Array<NSManagedObject> = Array<NSManagedObject>()
        do {
            if fromBackgroundContext {
            fetchedResults = try backgroundContext!.executeFetchRequest(fetchRequest) as! [NSManagedObject]
            } else {
                fetchedResults = try managedObjectContext.executeFetchRequest(fetchRequest) as! [NSManagedObject]
            }
            
        } catch let fetchError as NSError {
            
            NSIUtility.DBlog("retrieveAllItems error: \(fetchError.localizedDescription)")
            
        }
        
        return fetchedResults
    }
    
    func saveEntity(entity: String, arrOfRecords: NSArray) -> Bool {
        let entityDescription = NSEntityDescription.entityForName(entity, inManagedObjectContext: backgroundContext!)
        for attributes in arrOfRecords {
            let managedObject = NSManagedObject(entity: entityDescription!, insertIntoManagedObjectContext: backgroundContext!)
            for (key, attr) in attributes as! [String:AnyObject] {
                managedObject.setValue(attr, forKey: key)
            }
        }
        var success:Bool
        do {
            try backgroundContext!.save()
            success = true
        } catch let saveError as NSError {
        
             NSIUtility.DBlog("saveNewItem error: \(saveError.localizedDescription)")
            
            success = false
        }
        return success
    }
    
    
    func updateEntity(entity: NSManagedObject, _ attributes: [String: AnyObject]) -> Bool {
        
        for (key, attr) in attributes {
            entity.setValue(attr, forKey: key)
        }
        
        var success:Bool
        do {
            try backgroundContext!.save()
            success = true
        } catch let saveError as NSError {
         
             NSIUtility.DBlog("saveNewItem error: \(saveError.localizedDescription)")
            
            success = false
        }
        
        return success
    }
    
    deinit{
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
}
