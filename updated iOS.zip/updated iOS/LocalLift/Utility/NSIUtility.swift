//
//  NSIUtility.swift
//  Rabbit
//
//  Created by Aditya Aggarwal on 10/5/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import Foundation
import UIKit
//import UIAlertController_Blocks
import MFSideMenu


class NSIUtility: NSObject {

    enum ObjectType:Int {case  NumberType = 0, StringType = 1}

//MARK: - Get Methods
//Get value from dictionary
    class func getObjectForKey(key:String!,dictResponse:NSDictionary!) -> AnyObject! {
        if key != nil{
            if let dict = dictResponse {
                if let value: AnyObject = dict.valueForKey(key) {
                    if let _:NSNull = value as? NSNull{
                        return ""
                    }else{
                        if let valueString = value as? String{
                            if valueString == "<null>"{
                                return ""
                            }
                        }
                        return value
                    }
                } else {return ""}
            } else {return ""}
        } else {return ""}
    }
    
//Get value from user defaults
    class func getUniqueIdentifier()-> String {
        return UIDevice.currentDevice().identifierForVendor!.UUIDString
    }
    
//MARK: user defaults Methods
    class func getValueFromUserDefaultsForKey(keyName:String!) -> AnyObject? {
        if !NSIUtility.checkIfStringContainsText(keyName) {
            return nil
        }
        let value: AnyObject? = NSUserDefaults.standardUserDefaults().objectForKey(keyName)
        if value != nil {
            return value
        } else {
            return nil
        }
    }
    
//Set value to user defaults
    class func setValueToUserDefaultsForKey(keyName:String!, value:AnyObject!) {
        
        if !NSIUtility.checkIfStringContainsText(keyName) {
            return
        }
        if  value == nil {
            return
        }
        NSUserDefaults.standardUserDefaults().setObject(value, forKey: keyName)
        NSUserDefaults.standardUserDefaults().synchronize()
    }
    
//MARK: - NSNotificationCenter methods
    class func addObserverToNSNotificationCenterForNameKey(observer: AnyObject, selector: Selector, name: String?, object: AnyObject?) {
        
        if !NSIUtility.checkIfStringContainsText(name) {
            return
        }
        
        NSNotificationCenter.defaultCenter().addObserver(observer, selector: selector, name: name,object: object)
        
    }
    
    
//Remove Observer frpm NSNotificationCenter defaultCenter
    class func removeObserverFromNSNotificationCenterForNameKey(observer: AnyObject, name: String?,object: AnyObject?) {
        
        NSNotificationCenter.defaultCenter().removeObserver(observer, name: name, object: object)
        
    }

    
//MARK: - Validation
    class func validateURL(url:String) -> Bool
    {
        let urlRegex:String = "^(?:(?:https?|ftp)://)(?:\\S+(?::\\S*)?@)?(?:(?!(?:10|127)(?:\\.\\d{1,3}){3})(?!(?:169\\.254|192\\.168)(?:\\.\\d{1,3}){2})(?!172\\.(?:1[6-9]|2\\d|3[0-1])(?:\\.\\d{1,3}){2})(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}(?:\\.(?:[1-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))|(?:(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)(?:\\.(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)*(?:\\.(?:[a-z\\u00a1-\\uffff]{2,}))\\.?)(?::\\d{2,5})?(?:[/?#]\\S*)?$";
        
        let predicateForURL:NSPredicate = NSPredicate(format: "SELF MATCHES %@",urlRegex)
        
        if predicateForURL.evaluateWithObject(url) {
            return true
        } else if predicateForURL.evaluateWithObject("http://\(url)") {
            return true
        } else {
            return false
        }
    }
    
//Check Number validation
    class func validateNumber(emailStr:String) -> Bool
    {
        let emailRegex:String = "[\\p{N}\\p{Lo}}]+"
        let predicateForEmail:NSPredicate = NSPredicate(format: "SELF MATCHES %@",emailRegex)
        return predicateForEmail.evaluateWithObject(emailStr);
    }
    
    
//Check Email validation
    class func validateEmail(emailStr:String) -> Bool
    {
        let emailRegex:String = "^[_\\p{L}\\p{Mark}0-9-]+(\\.[_\\p{L}\\p{Mark}0-9-]+)*@[\\p{L}\\p{Mark}0-9-]+(\\.[\\p{L}\\p{Mark}0-9]+)*(\\.[\\p{L}\\p{Mark}]{2,})$"
        let predicateForEmail:NSPredicate = NSPredicate(format: "SELF MATCHES %@",emailRegex)
        let isValidated:Bool = predicateForEmail.evaluateWithObject(emailStr)
        if isValidated == false
        {
            NSIUtility.show(Constants.kEnterValidEmailAddress)
        }
        
        return isValidated
    }
    
    //Check Email validation
    class func validateEmailWithoutAlert(emailStr:String) -> Bool
    {
        let emailRegex:String = "^[_\\p{L}\\p{Mark}0-9-]+(\\.[_\\p{L}\\p{Mark}0-9-]+)*@[\\p{L}\\p{Mark}0-9-]+(\\.[\\p{L}\\p{Mark}0-9]+)*(\\.[\\p{L}\\p{Mark}]{2,})$"
        let predicateForEmail:NSPredicate = NSPredicate(format: "SELF MATCHES %@",emailRegex)
        let isValidated:Bool = predicateForEmail.evaluateWithObject(emailStr)
        return isValidated
    }
    
//Check For Match between Password and Confirm Password
    class  func checkPasswordStringContainsInConfirmPassword(password:String?,confirmpassowrd:String?) ->Bool {
        if password == confirmpassowrd{
            return true
        }
        else{
            return false
            
        }
    }
    
//Check For Empty String
    class func checkIfStringContainsText(string:String?) -> Bool
    {
        if let stringEmpty = string {
            let newString = stringEmpty.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
            if(newString.isEmpty){
                return false
            }
            return true
        } else {
            return false
        }
    }
    
    // MARK: - Show AlertView Methods
    class func showAlert(title:String, message:String) {
        
        let alert:UIAlertView = UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: "Ok")
        alert.show()
        
//        UIAlertController.showAlertInViewController(self.currentVisibleController(),
//            withTitle: title,
//            message: message,
//            cancelButtonTitle: "Ok",
//            destructiveButtonTitle: nil,
//            otherButtonTitles: nil,
//            tapBlock: {(controller, action, buttonIndex) in
//        })
    }
    
    class func show(message:String) {
        self.showAlert("Localift", message:message)
    }
    
    class func showUnderDevelopmentAlert() {
        self.showAlert("Under Development!", message: "This feature is under development and will be available in future releases.")
    }
    
// Used to fetch current controller
    class func currentVisibleController() -> UIViewController
    {
        let navigationController:UINavigationController = Constants.appDelegate.window?.rootViewController as! UINavigationController
        return navigationController.visibleViewController!
    }
    
// Used to fetch the controller via StoryBoard
    class func fetchViewControllerWithName(vcName:String, storyBoardName:String) -> UIViewController
    {
        let storyboard = UIStoryboard(name: storyBoardName, bundle: nil)
        let controller:UIViewController = storyboard.instantiateViewControllerWithIdentifier(vcName)
        return controller
    }
    
// Validate the Array of TextFields
    class func validateTextFieldArray(arrayOFKeys:NSArray,arrayOFFields:NSArray) -> Bool
    {
        if arrayOFFields.count == arrayOFKeys.count
        {
            var i:Int = 0
            for element in arrayOFFields{
                if let textField:UITextField = element as? UITextField{
                    if textField.text?.length == 0{
                        NSIUtility.show("Please enter \(arrayOFKeys.objectAtIndex(i) as! String)")
                        return false
                    }
                }
                i++
            }
            return true
        }
        print("validation arrayOfFields is not equal to arrayOfKeys")
        return false
    }
    
    class func safeInsert(object:AnyObject?,objectType:ObjectType) -> AnyObject!
    {

            if let numberObject = object as? NSNumber{
                if let _:NSNull = object as? NSNull{
                    return 0
                }
                return numberObject
            }else if let stringObject = object as? String{
                if let _:NSNull = object as? NSNull{
                    return ""
                }else if stringObject.length >= 1{return stringObject}
                else {return ""}
                
            }
            else {
                if objectType == ObjectType.NumberType{
                    return 0
                }else if objectType == ObjectType.StringType{
                    return ""
                }
                else{
                    return object
                }
            }
        
    }
   class func removeSpecialCharsFromString(text: String) -> String {
        let okayChars : Set<Character> =
        Set("+1234567890".characters)
        return String(text.characters.filter {okayChars.contains($0) })
    }
    
    class func randomFloat(min: Double, max:Double) -> Double {
        return min + Double(arc4random_uniform(UInt32(max - min + 1)))
    }
    
    class func showJsonData(dicParam:NSDictionary){
        let data = try! NSJSONSerialization.dataWithJSONObject(dicParam, options:NSJSONWritingOptions.PrettyPrinted)
        let datad = NSString.init(data: data, encoding: NSUTF8StringEncoding)
        print(datad)
    }
    
    class func encodeImageToBase64String (image : UIImage)-> String{
        let imageData = UIImagePNGRepresentation(image)
        let base64String = imageData!.base64EncodedStringWithOptions(.Encoding64CharacterLineLength)
        return base64String
    }
    
//    class func decodeImageToBase64String (base64String : String)-> UIImage{
//        let decodedData = NSData(base64EncodedString: base64String, options: NSDataBase64DecodingOptions.fromRaw(0)!)
//        var decodedimage = UIImage(data: decodedData)
//        println(decodedimage)
//        yourImageView.image = decodedimage as UIImage
//    }
    
    
    
//     Marker: Used to set the viewcontroller when menu button is tapped
//    class func moveToViewController(controllerName:NSString, storyboardName _storyboardName:NSString){
//        
//        let viewController = NSIUtility.fetchViewControllerWithName(controllerName as String,storyBoardName:_storyboardName as String)
//        
//        let currentController = NSIUtility.currentVisibleController()
//        
//        let navigationController:UINavigationController = currentController.menuContainerViewController.centerViewController as! UINavigationController
//        navigationController.viewControllers = [viewController]
//        currentController.menuContainerViewController.setMenuState(MFSideMenuStateClosed, completion: {
//            
//        })
//        
//    }
    
}
