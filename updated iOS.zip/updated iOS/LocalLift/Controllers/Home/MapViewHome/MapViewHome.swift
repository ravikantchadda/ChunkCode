//
//  MapViewHome.swift
//  LocalLift
//
//  Created by prabhjot singh on 12/7/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit
import GoogleMaps
import CoreLocation

//enum TravelModes: Int {
//    case driving
//    case walking
//    case bicycling
//}


protocol MapViewHomeProtocol
{
    func didSelectMarker(objectInfo:AnyObject?)
    func didTapOnMap()
    func didFindCurrentLocation()
}

class MapViewHome: UIView {

    @IBOutlet var mapView: GMSMapView!
    
    
    var strAdress:String!
    var callBack:AnyObject!
    var addressData:GMSAddress!
//    var markerOfFromLoc = GMSMarker()
//    var markerOfToLocation=GMSMarker()
    var delegate:MapViewHomeProtocol?
    
    var mapTasks = MapTasks()
    
    let locationManager = CLLocationManager()
    var polyline = GMSPolyline()
    var travelMode = TravelModes.driving
    
    var lastClickedMarker:GMSMarker?
    var lastMarkerImage:UIImage?
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        locationManager.requestWhenInUseAuthorization()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        mapView.myLocationEnabled = true
        mapView.settings.myLocationButton = true
        locationManager.startUpdatingLocation()
        
        mapView.delegate = self
        mapView.updateConstraintsIfNeeded()
    }
    
    
    
    func reverseGeocodeCoordinate(coordinate: CLLocationCoordinate2D, handler:CompletionHandler) {
        
            let geocoder = GMSGeocoder()
            geocoder.reverseGeocodeCoordinate(coordinate) { response , error in
                if let address:GMSAddress = response?.firstResult() {
                    let lines = address.lines as! [String]
                    self.strAdress = lines.joinWithSeparator("\n")
                    self.addressData = address
                    handler(obj: self.strAdress, success: true)
                }else{
                    self.strAdress = ""
                    self.addressData = nil
                    handler(obj: self.strAdress, success: false)
                }
        }
    }
    
    
    func createMarker(location:CLLocationCoordinate2D,name:String, icon:UIImage, otherInfo:AnyObject!)
    {
        let marker = GMSMarker()
        marker.position = location
        marker.snippet = name
        marker.icon = icon
        marker.userData = otherInfo
        marker.appearAnimation = kGMSMarkerAnimationPop
        marker.map = mapView
    }
    
    func setCameraOfMap(location:CLLocationCoordinate2D)
    {
        self.mapView.camera = GMSCameraPosition.cameraWithLatitude(location.latitude, longitude: location.longitude, zoom: 12)
    }
    
//MARK:- Route Map
    
    func addRouteToMap(fromLocation:CLLocationCoordinate2D,withDestinationLoc destinationLoc:CLLocationCoordinate2D){
        
        let origin = "\(fromLocation.latitude)" + "," + "\(fromLocation.longitude)"
        let destination = "\(destinationLoc.latitude)" + "," + "\(destinationLoc.longitude)"
        
        self.mapTasks.getDirections(origin, destination: destination, waypoints: nil, travelMode: self.travelMode, completionHandler: { (status, success) -> Void in
            if success {
                self.drawRoute()
                self.mapView.camera = GMSCameraPosition.cameraWithTarget(self.mapTasks.originCoordinate, zoom: 11.0)
            }
            else {
                print(status)
            }
        })
    }
    
    func drawRoute(){
        
        let route = mapTasks.overviewPolyline["points"] as! String
        let path: GMSPath = GMSPath(fromEncodedPath: route)
        polyline.path = path
        polyline.strokeWidth = 4.0
        //        polyline.geodesic = true
        polyline.map = self.mapView
    }
    

    
}

// / // /// / / //  -- - - - -- - - -- -  Delgates Of Map and Location -- --- ---- - - -- - -  //////// // // / // /


// MARK: - CLLocationManagerDelegate
extension MapViewHome: CLLocationManagerDelegate {
    func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus) {
        if status == CLAuthorizationStatus.AuthorizedWhenInUse {
            
        }
    }
    
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if  self.locationManager.location != nil{
            mapView.camera = GMSCameraPosition(target: self.locationManager.location!.coordinate, zoom: 15, bearing: 0, viewingAngle: 0)
            self.delegate?.didFindCurrentLocation()
            self.locationManager.stopUpdatingLocation()
        }
    }
}

// MARK: - GMSMapViewDelegate
extension MapViewHome: GMSMapViewDelegate {
    func mapView(mapView: GMSMapView!, idleAtCameraPosition position: GMSCameraPosition!) {
//        reverseGeocodeCoordinate(position.target)
    }
    
    func mapView(mapView: GMSMapView!, willMove gesture: Bool) {
        if (gesture) {
           
        }
    }
    

    func mapView(mapView: GMSMapView!, didTapMarker marker: GMSMarker!) -> Bool {
        if delegate != nil{
            self.mapView.camera = GMSCameraPosition.cameraWithTarget(marker.position, zoom: 5.0)
            if lastMarkerImage != nil && lastClickedMarker != nil{
                lastClickedMarker!.icon = lastMarkerImage
            }
            lastClickedMarker = marker
            lastMarkerImage = lastClickedMarker!.icon
            
            if let mapMarkerBo = marker.userData as? MapMarkerBO{
                if mapMarkerBo.isOfferRequest == true{
                    lastClickedMarker!.icon = UIImage(named: "big_offer_icon")
                }else{
                    lastClickedMarker!.icon = UIImage(named: "big_request_icon")
                }
            }
            
            
            delegate?.didSelectMarker(marker.userData)
        }
        return true
    }
    
    func mapView(mapView: GMSMapView!, didTapAtCoordinate coordinate: CLLocationCoordinate2D) {
        if delegate != nil{
            if lastMarkerImage != nil && lastClickedMarker != nil{
                lastClickedMarker!.icon = lastMarkerImage
            }
            delegate?.didTapOnMap()
        }

    }

    
//    - (void)mapView:(GMSMapView *)mapView didTapOverlay:(GMSOverlay *)overlay;
    
//    - (void)mapView:(GMSMapView *)mapView
//    didTapAtCoordinate:(CLLocationCoordinate2D)coordinate
}