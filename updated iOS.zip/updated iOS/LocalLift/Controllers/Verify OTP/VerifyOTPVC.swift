//
//  VerifyOTPVC.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/4/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit


class VerifyOTPVC: BaseViewController,UITextFieldDelegate {

    @IBOutlet var btnVerifyCode: UIButton!
    
    var nexmoObject:NexmoBO = NexmoBO()
    private let passcodeCharacter:String = "*"
    private let tagOfVerifyView = 1001
    @IBOutlet var txtVerifyCode: UITextField!
    @IBOutlet weak var txtFieldFirstDigit: UITextField!
    @IBOutlet weak var txtFieldSecondDigit: UITextField!
    @IBOutlet weak var txtFieldThirdDigit: UITextField!
    @IBOutlet weak var txtFieldFourthDigit: UITextField!
    
//MARK: - View Life Cycle Methods
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBar(NavigationType.ClearNavigationType)
        self.navigationItem.setHidesBackButton(true, animated: true)
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.Plain, target: self, action: "toCancel")
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let gestureTap:UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "toTappedAction")
        (self.view.viewWithTag(tagOfVerifyView))?.addGestureRecognizer(gestureTap)
        self.makeDigitField()
        
    }

//MARK: - Intialize Digit Text Field
    func makeDigitField() {
        txtFieldFirstDigit.text = passcodeCharacter;
        txtFieldSecondDigit.text = passcodeCharacter;
        txtFieldThirdDigit.text = passcodeCharacter;
        txtFieldFourthDigit.text = passcodeCharacter;
        txtVerifyCode.text = "";
        if !txtVerifyCode.isFirstResponder() {
            txtVerifyCode.becomeFirstResponder()
        }
    }
    
//MARK: - Button Call Functions
    
    @IBAction func toVerifyCode(sender: UIButton) {
        
        self.nexmoObject.code = txtVerifyCode.text!
        if self.nexmoObject.requestID != nil
        {
            let nexmoDL = NexmoDL()
            nexmoDL.requestTheNexmoOTP(self.nexmoObject) { (obj, success) -> Void in
                if success == true{
                    let userDL = UserDL()
                    userDL.requestForUserActivation({ (obj, success) -> Void in
                        
                        if success == true{
                            NSIUtility.show("Your OTP Code is verified successfully, now you can login")
                        }else{
                            NSIUtility.show("Your OTP Code is verified successfully but coudn't Activate your Account")
                        }
                        self.view.endEditing(true)
//                        self.navigationController?.popToRootViewControllerAnimated(true)
                        if let signIN:SignInVC = NSIUtility.fetchViewControllerWithName("SignInVC", storyBoardName: "Main") as? SignInVC{
//                            self.navigationController?.popViewControllerAnimated(false)
                            self.navigationController?.pushViewController(signIN, animated: true)
                        }
                    })
                }else{
                }
            }
        }else{
            NSIUtility.show("Couldn't able to create the OTP. So please click on Resend Code.")
        }
    }
    
    func toCancel()
    {
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
//MARK: - Text Field Delegates
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
            if string == "\n" {
                return false
            }
            self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.2)
        
            var i = 0;if string == ""{ i = 1 }
        
            let text:NSString? = textField.text
            let typedString:NSString = text!.stringByReplacingCharactersInRange(range, withString: string)
            if typedString.length == 1-i {
                txtFieldFirstDigit.text = string as String
            }else if typedString.length == 2-i {
                txtFieldSecondDigit.text = string as String
            }else if typedString.length == 3-i {
                txtFieldThirdDigit.text = string as String
            }else if typedString.length == 4-i {
                txtFieldFourthDigit.text = string as String
            }
            if typedString.length > 4-i {
                return false
            }
            return true
        
    }
    
    
    func toSelectBtnValidation()
    {
        if  self.txtVerifyCode.text?.length < 4{
            btnVerifyCode.backgroundColor = UIColor.colorWithRGB(31, green: 81, blue: 108, alpha: 0.7)
            btnVerifyCode.userInteractionEnabled = false
        }
        else{
            btnVerifyCode.backgroundColor = Constants.APP_THEME_COLOR
            btnVerifyCode.userInteractionEnabled = true
            txtVerifyCode.resignFirstResponder()
        }
        self.setAllTextToAstricIfEmpty()
    }
    
    func setAllTextToAstricIfEmpty()
    {
        for case let textField as UITextField in (self.view.viewWithTag(tagOfVerifyView)?.subviews)! {
            if textField.text == ""{
                textField.text = "*"
            }
        }
    }
    
    func toTappedAction()
    {
        if !txtVerifyCode.isFirstResponder() {
            txtVerifyCode.becomeFirstResponder()
        }
    }
    

}
