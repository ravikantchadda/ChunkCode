//
//  RoundedView.swift
//  LocalLift
//
//  Created by prabhjot singh on 12/24/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class RoundedView: UIView {

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */
    @IBInspectable var roundCornerRadius: NSNumber? {
        didSet {
            self.layer.cornerRadius = roundCornerRadius as! CGFloat
        }
    }
    
    
    override  func awakeFromNib() {
        super.awakeFromNib()
    }
    
    required  init?(coder aDecoder: NSCoder) {
        super.init(coder:aDecoder)
    }
    
    required  override init(frame: CGRect) {
        super.init(frame: frame)
    }


}
