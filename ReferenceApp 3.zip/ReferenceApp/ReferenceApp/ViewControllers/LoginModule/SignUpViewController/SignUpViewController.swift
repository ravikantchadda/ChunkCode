////
//  SignUpViewController.swift
//  ReferenceApp
//
//  Created by Mohit Jain on 8/27/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController {
    
    @IBOutlet weak var txtFieldEmail: UITextField!
    @IBOutlet weak var txtFieldPassword: UITextField!
    
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblPassword: UILabel!
    
    @IBOutlet weak var btnSignUp: UIButton!
    @IBOutlet weak var btnCancel: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        
        
        //setup UI
        self.setupUIElements()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - SetupUIElements
    func setupUIElements() {
        //set text for iboutlets
        lblEmail.text = NSLocalizedString("lblEmailSignUp",comment:"")
        lblPassword.text = NSLocalizedString("lblPasswordSignUp",comment:"")
        btnSignUp.setTitle(NSLocalizedString("btnSignUp",comment:""), forState: UIControlState.Normal)
        btnCancel.setTitle(NSLocalizedString("btnCancelSignUp",comment:""), forState: UIControlState.Normal)
    }
    
    // MARK: - @IBAction Methods
    @IBAction func btnCancelTapped(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: { () -> Void in
        })
    }
    
    @IBAction func btnSignUpTapped(sender: AnyObject) {
        if(checkFieldsValidation(txtFieldEmail.text,password: txtFieldPassword.text)) {
            
            ///*********Check Password Strength************
            let strength:PasswordStrength = NSIUtility.calculatePasswordStrength(txtFieldPassword.text!)
            
            switch(strength){
                
            case .WEAK:
                
                print("week password")
                
                break
               
            case .MEDIUM:
                print("MEDIUM password")
                
                break
            case .STRONG:
                print("STRONG password")
                
                break
            case .VERY_STRONG:
                print("VERY_STRONG password")
                
                break
            case .CRAZY_STRONG:
                print("CRAZY_STRONG password")
                
                break
                
            }
            
            txtFieldEmail.resignFirstResponder()
            txtFieldPassword.resignFirstResponder()
            let headerbody:String = Constants.kOuthHeader
            self.callToGetOuthTokenWebServiceWithHeaderBody(headerbody)
            
        }
    }
    
    
    //MARK: - Method to Get OuthToken
    func callToGetOuthTokenWebServiceWithHeaderBody(headerBody:String){
        let outh = OuthDL()
        outh.requestforOuth(headerBody) { (obj, success) -> Void in
            
            if success == true{
                
                
                NSIUtility.DBlog(obj!)
                NSIUtility.DBlog(success as Bool!)
                
                
                let accessToken: String!
                let tokenType: String!
                accessToken = obj?.valueForKey(Constants.keyAccessToken) as! String
                tokenType = obj?.valueForKey(Constants.keyTokenType) as! String
                let outhToken: String!
                outhToken = tokenType + " " + accessToken
                
                NSIUtility.setValueToUserDefaultsForKey(Constants.keyOuthToken, value: outhToken)
                
                let email: NSString = "email"
                let password: NSString = "password"
                let fbId: NSString = "fb_id"
                let googleId: NSString = "google_id"
                let linkedinId: NSString = "linkedin_id"
                let deviceToken: NSString = "device_token"
                let deviceType: NSString = "device_type"
                let deviceTypeValue:NSString = "1"
                
                let dictParams:NSDictionary = NSDictionary(objects: [self.txtFieldEmail.text!,self.txtFieldPassword.text!,"","","",NSIUtility.getUniqueIdentifier(),deviceTypeValue], forKeys: [email,password,fbId,googleId,linkedinId,deviceToken,deviceType])
                
                
                
                self.callToSignUpWebServiceWithDict(dictParams)
                
            }else{
                
                NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""), message: Constants.kAlertServerError, view: self, delegate: nil)
            }
            
            
        }

    }
        //MARK: - Method to User SignUp
        func callToSignUpWebServiceWithDict(params:NSDictionary){
            
            let user = UserDL()
            user.requestforUploadMultiPartUserSignUp(params, withCompletionHandler: { (obj, success) -> Void in
                
                NSIUtility.DBlog(obj as! NSDictionary)
                
                if success == true{
                   
                    NSIUtility.DBlog(success as Bool!)

                    
                    let statusCode = obj?.valueForKey(Constants.keyStatusCode) as! NSNumber
                    if statusCode == 200{//****200 status defined success response
                         NSIUtility.setValueToUserDefaultsForKey("sociallogin", value: false)
                         NSIUtility.DBlog(obj?.valueForKey(Constants.keyResponse)?.valueForKey(Constants.keyAccessToken) as! String)
                        self.fillUserInfoModel(obj?.valueForKey(Constants.keyResponse) as! NSDictionary)
                        print("Successfully SignUp")
                        
                    }else if statusCode == 401{//****401 status defined Wrong Access Token or data in body
                        
                        NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""),message:  obj?.valueForKey("error") as! String, view: self, delegate: nil)
                        
                    }else if statusCode == 400{//***400 status defined Email and Password as blank
                        
                        
                        NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""),message: Constants.kAlertEmailExist, view: self, delegate: nil)
                    }
                    else{
                    
                    NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""),message: "Somthing went wrong!", view: self, delegate: nil)
                    }
                    
                }else{
                    
                    NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""), message: Constants.kAlertServerError, view: self, delegate: nil)
                }
                
                
            })

    }
   
    // MARK: - Fill UserInfoModel
    func fillUserInfoModel(dict: NSDictionary!) {
        let userDict:NSDictionary! = NSIUtility.getObjectForKey("user", dictResponse: dict) as! NSDictionary
        if userDict != nil {
            let userInfoModel = UserBO()
            userInfoModel.fillUserModel(userDict)
            //set AccessToken
            let accessToken:String! = NSIUtility.getObjectForKey(Constants.keyAccessToken, dictResponse: dict) as! String
            if accessToken != nil {
                userInfoModel.userAccesstoken = accessToken
            }
            UserInfoManager.setUserInfo(userInfoModel)
            NSIUtility.deleteTokenFromKeychain()
            
            do{
                
                try NSIUtility.saveTokenToKeychain(accessToken as String)
                try NSIUtility.getTokenFromKeychain()
                
              
                
            
            }catch{
            
                print("Error")
            }
            
            
            self.dismissViewControllerAnimated(true, completion: { () -> Void in
                
                let delegate =  UIApplication.sharedApplication().delegate as! AppDelegate
                delegate.showMainStoryboard()

            })
            
            
            //Successfully Login Remove Login Screen
        } else {
            
        }
    }

    
    // MARK: - Check Validation
    /**
    Check all validations
    1. Empty check for both fields
    2. Validate Email
    - returns: bool value yes if all validations are fullfilled otherwise false.
    */
    func checkFieldsValidation(email:String!, password:String!) -> (Bool) {
        return self.checkEmailValidation(email) && self.checkEmptyPassword(password)
    }
    
    func checkEmailValidation(email: String!) -> (Bool) {
        if (!NSIUtility.checkIfStringContainsText(email))
        {
            
             NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""),message:  NSLocalizedString("EmptyString",comment: "comment"), view: self, delegate: nil)
            return false
        }
        if(!NSIUtility.validateEmail(email))
        {
            
             NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""),message:  NSLocalizedString("InvalidEmail",comment: "comment"), view: self, delegate: nil)
            return false
        }
        return true
    }
    
    func checkEmptyPassword(password: String!) -> (Bool) {
        if (!NSIUtility.checkIfStringContainsText(password))
        {
            NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""),message:  NSLocalizedString("EmptyString",comment: "comment"), view: self, delegate: nil)
            return false
        }
        return true
    }
}
