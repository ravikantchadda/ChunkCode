//
//  GroupTypeDL.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/22/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import Foundation

class GroupTypeBO: NSObject {
    
    var groupTypeName: String!
    var isGroupTypeSelected: Bool!
    var hasSubCatories: Bool!
}

class GroupTypeDL: PSRestAPIHelper {
    
    func requestForGroupType(withSelectedGroupType:String, withCompletionHandler handler:CompletionHandler) {
        
        let arrayOfGroupTypeName = NSMutableArray()
        for (var j=0; j <= 10 ; j++) {
             let groupBO = GroupTypeBO()
            
                groupBO.groupTypeName = "Family \(j)"
           
            if (withSelectedGroupType == groupBO.groupTypeName) {
                groupBO.isGroupTypeSelected = true
            } else {
                groupBO.isGroupTypeSelected = false
            }
            
            if (j<7) {
                groupBO.hasSubCatories = false
            }
            else  {
                groupBO.hasSubCatories = true
                groupBO.groupTypeName = "Sports \(j)"
            }
            
            arrayOfGroupTypeName.addObject(groupBO)
        }
        handler(obj: arrayOfGroupTypeName, success: true)
    }
    
    func requestForSubCategoriesGroupType(withSelectedGroupType:String, withCompletionHandler handler:CompletionHandler) {
        
        let arrayOfGroupTypeName = NSMutableArray()
        for (var j=0; j <= 10 ; j++) {
            let groupBO = GroupTypeBO()
            groupBO.groupTypeName = "Cricket \(j)"
            
            if (withSelectedGroupType == groupBO.groupTypeName) {
                groupBO.isGroupTypeSelected = true
            } else {
                groupBO.isGroupTypeSelected = false
            }
                groupBO.hasSubCatories = false
            
            arrayOfGroupTypeName.addObject(groupBO)
        }
        handler(obj: arrayOfGroupTypeName, success: true)
    }
}
