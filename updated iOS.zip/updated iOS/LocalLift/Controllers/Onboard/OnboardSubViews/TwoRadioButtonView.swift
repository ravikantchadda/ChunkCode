//
//  TwoRadioButtonView.swift
//  LocalLift
//
//  Created by neeru thakur on 12/22/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit


enum RadioState {
    case checked, unchecked
}

enum RadioViewType {
    case genderView, dobView
}

enum PersonType: NSNumber{
    case minor, adult
}

enum Gender : NSNumber{
    case female, male
}


protocol TwoRadioButtonViewProtocol{
    
    func leftRadioButtonTapped(radiobuttonView :TwoRadioButtonView,  withState : RadioState )
    func rightRadioButtonTapped(radiobuttonView :TwoRadioButtonView, withState : RadioState)
    func showDatePickerForOption(personType:PersonType, sender:UIButton)
    func updateBtnValidation()

}
class TwoRadioButtonView: UIView{

    @IBOutlet weak var btnRightRadio: UIButton!
    @IBOutlet weak var lblRightRadio: UILabel!
    @IBOutlet weak var btnLeftRadio: UIButton!
    @IBOutlet weak var lblLeftRadio: UILabel!
    @IBOutlet weak var lblHeader: UILabel!
    
    var radioViewType : RadioViewType = RadioViewType.dobView
    var personType : PersonType = PersonType.minor
    
    @IBOutlet weak var btnDOB: UIButton!
    @IBOutlet weak var constraintLeading_btnDOB: NSLayoutConstraint!
    var delegate : TwoRadioButtonViewProtocol!
    // Our custom view from the XIB file
    var view: UIView!
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadViewFromNib ()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        loadViewFromNib ()
    }
    
    func loadViewFromNib() {
        let bundle = NSBundle(forClass: self.dynamicType)
        let nib = UINib(nibName: "TwoRadioButtonView", bundle: bundle)
        let view = nib.instantiateWithOwner(self, options: nil)[0] as! UIView
        view.frame = bounds
        view.autoresizingMask = [.FlexibleWidth, .FlexibleHeight]
        self.addSubview(view);
        self.initialization()
    }
    
    func initialization(){
        
        btnLeftRadio.setImage(UIImage(named: "blue_checked"), forState: UIControlState.Normal)
        btnRightRadio.setImage(UIImage(named: "blue_unchecked"), forState: UIControlState.Normal)
        self.setVisibilityofDOB()
        
    }
    
    func setVisibilityofDOB(){
        
        switch(self.radioViewType){
            case .genderView:
                btnDOB.hidden = true
            
            case .dobView:
                btnDOB.hidden = false
        }

    }
    
    // Populate the label text
    func populate(headerText _headerText:String ,leftRadioLabelText _leftRadioLabelText:String,rightRadioLabelText _rightRadioLabelText:String,  radioViewType : RadioViewType){
        self.lblHeader.text = _headerText
        self.lblLeftRadio.text = _leftRadioLabelText
        self.lblRightRadio.text = _rightRadioLabelText
        self.radioViewType = radioViewType
        
        MyProfileBO.sharedInstanceOfUser.isAdult = false
        MyProfileBO.sharedInstanceOfUser.userGender = Gender.female.rawValue
        self.setVisibilityofDOB()
    }
    
    // Set the color of radio button
    func fillRadio(sender : UIButton, state:RadioState){
        
        switch(state){
            
        case .checked:
            sender.setImage(UIImage(named: "blue_checked"), forState: UIControlState.Normal)
           
        case .unchecked:
             sender.setImage(UIImage(named: "blue_unchecked"), forState: UIControlState.Normal)

        }
        
        
    }
    
    // Action method
    @IBAction func toSelectLeftRadioButton(sender: AnyObject) {
        
        self.fillRadio(sender as! UIButton, state: .checked)
        self.fillRadio(self.btnRightRadio, state: .unchecked)
        
        switch(self.radioViewType){
        case .genderView:
//            var convertedMode = UpdateMode(rawValue: num.integerValue)
            MyProfileBO.sharedInstanceOfUser.userGender = Gender.male.rawValue
           
        case .dobView:
            if personType != PersonType.minor{
                MyProfileBO.sharedInstanceOfUser.userYear = 0
                MyProfileBO.sharedInstanceOfUser.userMonth = 0
                MyProfileBO.sharedInstanceOfUser.userDay = 1
                self.btnDOB.setTitle("dd mm yyyy", forState: .Normal)
                self.btnDOB.setTitleColor(UIColor.grayColor(), forState: .Normal)
                 delegate.updateBtnValidation()
            }
            personType = PersonType.minor
             MyProfileBO.sharedInstanceOfUser.isAdult = false
        }
       
    }
 
    @IBAction func toSelectRightRadioBtn(sender: AnyObject) {
        self.fillRadio(sender as! UIButton, state: .checked)
        self.fillRadio(self.btnLeftRadio, state: .unchecked)
        
        switch(self.radioViewType){
        case .genderView:
           
            MyProfileBO.sharedInstanceOfUser.userGender = Gender.female.rawValue

        case .dobView:
            
            if personType != PersonType.adult{
                MyProfileBO.sharedInstanceOfUser.userYear = 0
                MyProfileBO.sharedInstanceOfUser.userMonth = 0
                MyProfileBO.sharedInstanceOfUser.userDay = 1
                self.btnDOB.setTitle("mm yyyy", forState: .Normal)
                self.btnDOB.setTitleColor(UIColor.grayColor(), forState: .Normal)
                delegate.updateBtnValidation()
                
            }
            personType = PersonType.adult
            MyProfileBO.sharedInstanceOfUser.isAdult = true
        }
        
    }
    
    @IBAction func toSelectDOB(sender: AnyObject) {
        
                delegate.showDatePickerForOption(self.personType, sender: sender as! UIButton)
        
    }
}


