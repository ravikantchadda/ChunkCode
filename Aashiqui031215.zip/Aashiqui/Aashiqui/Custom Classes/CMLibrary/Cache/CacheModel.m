//
//  CacheModel.m
//  VideoTag
//
//  Created by Aditya Aggarwal on 09/04/14.
//
//

#import "CacheModel.h"

@implementation CacheModel

@end
