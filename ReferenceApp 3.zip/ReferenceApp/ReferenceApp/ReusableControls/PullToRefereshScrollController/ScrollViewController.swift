//
//  PullToRefereshScrollController.swift
//  ReferenceApp
//
//  Created by ravi kant on 12/4/15.
//  Copyright © 2015 Netsol. All rights reserved.
//

import UIKit

class ScrollViewController: UIViewController {
    @IBOutlet weak var scrollView: UIScrollView!
    var topRefreshControl: UIRefreshControl!
    var numberOfItems: NSInteger!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.numberOfItems = 20
        self.topRefreshControl = UIRefreshControl()
        self.topRefreshControl.attributedTitle = NSAttributedString(string: "Pull down to reload!")
        self.topRefreshControl.addTarget(self, action: "refreshTop", forControlEvents: .ValueChanged)
       // self.scrollView.addSubview(self.topRefreshControl)
        
        
        let refreshControl: UIRefreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull up to reload!")
        refreshControl.triggerVerticalOffset = 80.0
        refreshControl.addTarget(self, action: "refreshBottom", forControlEvents: .ValueChanged)
        self.scrollView.bottomRefreshControl = refreshControl
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func reloadData(){
    
    }
    func refreshTop(){
        
        let delayInSeconds: Double = 1.0
        
        let delayTime = dispatch_time(DISPATCH_TIME_NOW, Int64(delayInSeconds * Double(NSEC_PER_SEC)))
        let popTime: dispatch_time_t = delayTime
        dispatch_after(popTime, dispatch_get_main_queue(), {() -> Void in
            self.numberOfItems = max(0, self.numberOfItems - 5)
            self.reloadData()
            self.topRefreshControl.endRefreshing()
        })

    
    }
    func refreshBottom(){
        
        let delayInSeconds: Double = 1.0
        let delayTime = dispatch_time(DISPATCH_TIME_NOW, Int64(delayInSeconds * Double(NSEC_PER_SEC)))
        let popTime: dispatch_time_t = delayTime
        dispatch_after(popTime, dispatch_get_main_queue(), {() -> Void in
            self.numberOfItems  = self.numberOfItems+5
            self.reloadData()
            self.scrollView.bottomRefreshControl.endRefreshing()
        })
        
    }

}
