//
//  PhotoDisplayView.swift
//  Aashiqui
//
//  Created by ketan saini on 20/11/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class PhotoDisplayView: UIView {

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */
    @IBOutlet weak var mainContainerView: UIView!
    @IBOutlet weak var collVwImages: UICollectionView!
    var arrImages:NSArray = []
    
    override init(frame: CGRect) { // for using CustomView in code
        super.init(frame: frame)
        self.commonInit()
    }
    required init(coder aDecoder: NSCoder) { // for using CustomView in IB
        super.init(coder: aDecoder)!
        self.commonInit()
    }
    private func commonInit() {
        NSBundle.mainBundle().loadNibNamed("PhotoDisplayView", owner: self, options: nil)
        self.addSubview(mainContainerView)
        mainContainerView.frame = CGRectMake(0, 0, NSIConstants.ScreenSize.SCREEN_WIDTH, NSIConstants.ScreenSize.SCREEN_HEIGHT)
        collVwImages.frame = CGRectMake(0, 0, NSIConstants.ScreenSize.SCREEN_WIDTH, NSIConstants.ScreenSize.SCREEN_HEIGHT)
        collVwImages.registerClass(UICollectionViewCell.self, forCellWithReuseIdentifier: "Cell")
    }
    
    func setUpDisplayImagesView(arrayImages: NSArray, indexSelected: NSInteger) {
        print("arrayImages\(arrayImages)")
        arrImages = arrayImages
        let width = NSIConstants.ScreenSize.SCREEN_WIDTH
        let offsetY = width  * CGFloat(indexSelected)
        collVwImages.contentOffset = CGPointMake(offsetY, 0)
    }
    
    // MARK: UICollectionView Delegate
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return arrImages.count
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("Cell", forIndexPath: indexPath)
        let objPhoto:PhotosTab = arrImages.objectAtIndex(indexPath.row) as! PhotosTab
        var imageView : AsyncImageView
        imageView  = AsyncImageView(frame:CGRectMake(0, 0, cell.frame.size.width, cell.frame.size.height));
        imageView.imageURL = NSURL(string: objPhoto.photoUrl)
        imageView.contentMode = .ScaleAspectFit
        cell.addSubview(imageView)
        
        return cell
        
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath){
        
    }
    
    // MARK: UICollectionViewFlowLayout Delegate
    
    func collectionView(collectionView: UICollectionView,
        layout collectionViewLayout: UICollectionViewLayout,
        sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
        return CGSizeMake(collectionView.frame.size.width, collectionView.frame.size.height)
    }
    
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAtIndex section: Int) -> UIEdgeInsets {
  
        return UIEdgeInsetsMake(0, 0, 0, 0)
        
    }
    
    
    @IBAction func btnPressed_Close(sender: AnyObject) {
        self.removeFromSuperview()
    }

}
