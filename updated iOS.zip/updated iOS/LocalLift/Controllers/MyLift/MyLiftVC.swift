//
//  MyLiftVC.h
//  LocalLift
//
//  Created by Rajesh Kapur on 12/16/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit
import ActionSheetPicker_3_0



class MyLiftVC: BaseViewController,UITableViewDataSource,UITableViewDelegate,ViewMoreLiftrotocol,CKCalendarDelegate,SearchForLiftProtocol{
    
    @IBOutlet weak var constraintViewCalendar_Height: NSLayoutConstraint!
    @IBOutlet var viewCalendar: CKCalendarView!
    @IBOutlet weak var tableOfMyLifts: UITableView!
    var arrayOfMyLifts = NSMutableArray()
    var viewMoreLift:LoadMyLiftMore!
    var startIndex:Int!
    weak var noMyLiftsVW:NoMyLiftsView!
    var processingDate : NSDate!
    var lastProcessingDate : NSDate!
    var isFetchListWithCalData : Bool!
    
    
    //MARK: - View Life Cycle Methods
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        //         self.setNavigationBar(NavigationType.BlueNavigationType, withLeftMenu:true)
//        self.setNavigationBar(NavigationType.BlueNavigationType)
         self.setNavigationBar(.BlueNavigationType)
         self.menuContainerViewController.disablePanGeture = true
        
    }
    
    //MARK: - View did Load
    override func viewDidLoad() {
        super.viewDidLoad()
        startIndex = 0
        self.initialInitialization()
        self.setNavigationRightBarButton()
//        self.setNavigationLeftBarButton()
//        self.setNavigationBar(.BlueNavigationType, withLeftMenu: true)
    }
    
    override func viewDidAppear(animated: Bool) {
        self.fetchMyCalendarDataForDate(NSDate())
    }
    
    //MARK: - initialInitialization mthod to load view properly
    func initialInitialization()  {
        
//        viewCalendar.tag = CkCalendarViewTag
        viewCalendar.delegate = self
        self.processingDate = NSDate()
        self.lastProcessingDate = NSDate()
        isFetchListWithCalData = true
        viewCalendar.selectDate(NSDate(), makeVisible: true)
        
        tableOfMyLifts.registerNib(UINib(nibName: "MyLiftCell", bundle: nil) , forCellReuseIdentifier: "MyLifts")
        viewMoreLift = UIView.viewFromNibName("LoadMyLiftMore") as? LoadMyLiftMore
        viewMoreLift.imageViewDownArrow.hidden = true
        viewMoreLift.delegate=self
        tableOfMyLifts.tableFooterView = viewMoreLift
        
        self.arrayOfMyLifts = NSMutableArray()
        
        //add uiview to show no notification
        noMyLiftsVW = UIView.viewFromNibName("NoMyLiftsView") as? NoMyLiftsView
        noMyLiftsVW.delegate = self
        noMyLiftsVW.frame = CGRectMake(0, 0, self.view.size.width, self.view.size.height-(constraintViewCalendar_Height.constant+35))
        noMyLiftsVW.hidden=true
        tableOfMyLifts.insertSubview(noMyLiftsVW, aboveSubview: tableOfMyLifts)
        
    }
    
    //MARK: - Set Navigation Title
    func setNavigationTitle(date : NSDate) {
        
        // set navigation titleLabel for current month
        let label = UILabel(frame: CGRectMake(0.0, 0.0, self.view.size.width, 60.0))
        label.backgroundColor = UIColor.clearColor()
        label.font = UIFont.boldSystemFontOfSize(14.0)
        label.numberOfLines = 2
        let str = "\(date.shortMonthToString()) \(date.year())"
        
        let attString = "My Lifts \n\(str)" as NSString
        let attrbtdStrngBuddyMessage = NSMutableAttributedString(string: attString as String)
        
        attrbtdStrngBuddyMessage.addAttribute(NSFontAttributeName, value: UIFont.systemFontOfSize(16.0), range: attString.rangeOfString("My Lifts"))
        attrbtdStrngBuddyMessage.addAttribute(NSFontAttributeName, value: UIFont.systemFontOfSize(13.0), range: attString.rangeOfString(str))
        
        let firstAttributes = [NSForegroundColorAttributeName: UIColor.whiteColor(), NSBackgroundColorAttributeName: UIColor.clearColor()]
        
        attrbtdStrngBuddyMessage.addAttributes(firstAttributes, range: attString.rangeOfString("My Lifts"))
        attrbtdStrngBuddyMessage.addAttributes(firstAttributes, range: attString.rangeOfString(str))
        
        label.attributedText = attrbtdStrngBuddyMessage
        label.sizeToFit()
        label.textAlignment = NSTextAlignment.Center
        self.navigationItem.titleView = label
    }
    
    //MARK: - Set Bar button in navigation
    func setNavigationRightBarButton() {
        let barBtnCalender = UIBarButtonItem(image: UIImage(named: "calculatorIcon"), style: .Plain, target: self, action: "calenderPressed:")
        navigationItem.setRightBarButtonItem(barBtnCalender, animated: true)
    }
    
    
    //MARK:- LeftNav Bar Items
    func setNavigationLeftBarButton() {
        let barBtnMenu = UIBarButtonItem(image: UIImage(named:"backIcon"), style: .Plain, target: self, action: "backButtonClick:")
        navigationItem.leftItemsSupplementBackButton = true
        navigationItem.setLeftBarButtonItems([barBtnMenu], animated: true)
    }
    
    func backButtonClick(sender:UIButton!){
        
        self.navigationController?.dismissViewControllerAnimated(true, completion: {
        
        })
//        self.menuContainerViewController.toggleLeftSideMenuCompletion({
//            })
    }

    // Increase Notification Badge
    func calenderPressed(sender: UIButton) {
        self.calendarNavButtonClicked(UIButton())
    }
    
    //MARK: - Fetch calendar data
    
    func fetchMyCalendarDataForDate(date : NSDate){
        
        setNavigationTitle (date)
        
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "MM"
        
        let monthStr = dateFormatter.stringFromDate(date)
//        let monthStr = date.month()
        let yearStr = date.year()
        
        let calendarDL = CalendarDL()
        calendarDL.requestGetMyLiftCalendarData(String(monthStr), year:String(yearStr)) { (obj, success) -> Void in
            if success == true{
                if let arrayOfCalendarDate = obj as? NSMutableArray{
                    
                    self.viewCalendar.addDotsToTheDates(arrayOfCalendarDate  as [AnyObject])
                    // During first load of current month
                    // Fetch data for current date in case of Current month otherwise first date of month
                    if self.isFetchListWithCalData == true {
                        self.isFetchListWithCalData = false
                        self.fetchLiftsFromServices(self.processingDate)
                    }
                }
            }
            else{
                self.viewCalendar.addDotsToTheDates([])
                if !self.lastProcessingDate.isEqualToDate(self.processingDate){
                    self.arrayOfMyLifts.removeAllObjects()
                }
                
                self.tableOfMyLifts.delegate = self
                self.tableOfMyLifts.dataSource = self
                
                self.tableOfMyLifts.reloadData()
            }
        }
    }
    
    //MARK: - Fetch lifts from service
    func fetchLiftsFromServices(date : NSDate ) {
        self.processingDate = date
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "MM-dd-YYYY"
        
        let dateStr = dateFormatter.stringFromDate(date)
        
        let liftsDL = MyLiftsDL()
        let startIndexForList = startIndex == 0 ? 1 : startIndex
        liftsDL.requestforMyLifts(startIndexForList, withDate:dateStr ,withNumberOfItems : 5, withCompletionHandler: { (obj, success) -> Void in
            if success == true
            {
                if !self.lastProcessingDate.isEqualToDate(self.processingDate){
                    self.arrayOfMyLifts.removeAllObjects()
                }
                
                if(self.startIndex == 0) {
                    self.tableOfMyLifts.delegate = self
                    self.tableOfMyLifts.dataSource = self
                }
                
                if((obj! as! [LiftBO]).count == 0 && self.startIndex != 0){
                    NSIUtility.showAlert("", message: "No more lifts available")
                }

                
                self.lastProcessingDate  =  self.processingDate
                self.arrayOfMyLifts.addObjectsFromArray(obj! as! [LiftBO])
                self.startIndex = self.arrayOfMyLifts.count == 0 ? 1 : self.arrayOfMyLifts.count+1
                self.tableOfMyLifts.reloadData()
                
                
            }
            else{
                 if !self.lastProcessingDate.isEqualToDate(self.processingDate){
                    self.arrayOfMyLifts.removeAllObjects()
                }
                self.tableOfMyLifts.reloadData()
            }
        })
    }
    
    
    
    //MARK: - Table VIew Delegates
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat
    {
        return 85;
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if(self.arrayOfMyLifts.count <= 0) {
            noMyLiftsVW?.hidden=false
            return 0
        }
        else  {
            noMyLiftsVW?.hidden=true
            return self.arrayOfMyLifts.count
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell:MyLiftCell = (tableView.dequeueReusableCellWithIdentifier("MyLifts", forIndexPath: indexPath) as? MyLiftCell)!
        
        let myLiftObj:MyLiftBO
        myLiftObj = self.arrayOfMyLifts[indexPath.row] as! MyLiftBO
        let imageFethced = (myLiftObj.isOfferRequest == true ? UIImage(named: "offerIcon"):UIImage(named: "requestIcon2"))
        
        cell.setRequesterNameForCell(myLiftObj.liftRequesterName, withOfferRequest: myLiftObj.isOfferRequest)
        cell.liftDate.text =  myLiftObj.requestedDatetime.toString(format:.Custom(Constants.DateTimeFormatwithAMPM))
        cell.offerOrRequestImage.image = imageFethced
        cell.liftAddress.text = "\(myLiftObj.addressBO.streetAddress)\(myLiftObj.addressBO.city)\(myLiftObj.addressBO.state)\(myLiftObj.addressBO.country)" 
        cell.passengerCount.text =  (myLiftObj.isOfferRequest == true ? "" : String(myLiftObj.passengerCount))
        (myLiftObj.isOfferRequest == true ? (cell.groupIconForPassengerCount.hidden = true) : (cell.groupIconForPassengerCount.hidden = false))
        (myLiftObj.isImmediate == true ? (cell.progressVW.hidden = false) : (cell.progressVW.hidden = true))
//        (myLiftObj.addressBO.addressName.characters.count == 0 ? (cell.lblGoingTo.hidden = true) : (cell.lblGoingTo.hidden = false))
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        
        if let myLiftObj:MyLiftBO = self.arrayOfMyLifts[indexPath.row] as? MyLiftBO{
            
            if myLiftObj.isOfferRequest == false
            {
                let liftBO = LiftBO()
                liftBO.imagePath = NSIUtility.safeInsert(myLiftObj.liftRequesterPhotoPath, objectType: .StringType) as! String
                liftBO.liftRequesterName = NSIUtility.safeInsert(myLiftObj.liftRequesterName, objectType: .StringType) as! String
                liftBO.requestedDatetime = myLiftObj.requestedDatetime
                liftBO.seats = myLiftObj.passengerCount
                liftBO.toAddress = myLiftObj.addressBO.streetAddress
                liftBO.requestId = myLiftObj.requestId
                
                    if let cancelLiftRequest:CancelLiftVC = NSIUtility.fetchViewControllerWithName("CancelLiftVC", storyBoardName: "Home") as? CancelLiftVC{
                        cancelLiftRequest.liftBO = liftBO
                        cancelLiftRequest.cancelType = .CancelTypeRequest
                        self.navigationController?.pushViewController(cancelLiftRequest, animated: true)
                    }
            }else{
                NSIUtility.showUnderDevelopmentAlert()
            }
            
        }
    }
    
    //MARK: - Load more lift
    func showMoreLift() {
        if let date = processingDate {
            self.fetchLiftsFromServices(date)
        }
        
    }
    
    //MARK: - Search for lift protocols
    func searchForLifts() {
        // Naigate to Home screen
        self.navigationController?.popViewControllerAnimated(true)
//        if self.navigationController?.viewControllers.count == 1{
//            NSNotificationCenter.defaultCenter().postNotificationName("ChangeMenuCenterControllerNotification", object: "Home")
//        }
//        else{
//            self.navigationController?.popViewControllerAnimated(true)
//        }

    }
    
    // CKCalendarView delegate
    
    func calendar(calendar: CKCalendarView!, configureDateItem dateItem: CKDateItem!, forDate date: NSDate!) {
        
        let current = NSDate() as NSDate
        
        if  date.isEqualToDateIgnoringTime(current){
            dateItem.backgroundColor =  UIColor .whiteColor()
            dateItem.selectedBackgroundColor =  UIColor .redColor()
            dateItem.textColor =  UIColor .redColor()
            dateItem.selectedTextColor = UIColor.whiteColor()
        }
        else{
            dateItem.backgroundColor =  UIColor .whiteColor()
            dateItem.selectedBackgroundColor =  UIColor .redColor()
            dateItem.textColor =  UIColor .blackColor()
            dateItem.selectedTextColor = UIColor.whiteColor()
        }
    }
    
    func calendar(calendar: CKCalendarView!, willChangeToMonth date: NSDate!) -> Bool {
        
        return true
    }
    
    func calendar(calendar: CKCalendarView!, didChangeToMonth date: NSDate!) {
        
        
        // Fetch the data for selected month
        let firstDate = calendar._firstDayOfMonthContainingDate(date)//[calendar _firstDayOfMonthContainingDate:date];
        self.startIndex = 0
        
        self.isFetchListWithCalData = true
        
        if((date.month() == NSDate().month())  &&  (date.year() == NSDate().year())) {
            self.processingDate = NSDate()
            self.fetchMyCalendarDataForDate( NSDate())
        }
        else {
            self.processingDate = firstDate
            self.fetchMyCalendarDataForDate(firstDate)
        }
    }
    
    func calendar(calendar: CKCalendarView!, willSelectDate date: NSDate!) -> Bool {
        
        return calendar.dateIsInCurrentMonth(date)
    }
    
    func calendar(calendar: CKCalendarView!, didSelectDate date: NSDate!) {
        
        // Fetch the data for selected month
        startIndex = 0
        if let localDtae = date {
            self.fetchLiftsFromServices(localDtae)
        }
        
    }
    
    func calendar(calendar: CKCalendarView!, willDeselectDate date: NSDate!) -> Bool {
        
        return false
    }
    
    func calendar(calendar: CKCalendarView!, didDeselectDate date: NSDate!) {
        
    }
    
    func calendar(calendar: CKCalendarView!, didLayoutInRect frame: CGRect) {
        // Change height of the calendar view
        let frameHeight = frame.height
        constraintViewCalendar_Height.constant = frameHeight
        noMyLiftsVW.frame = CGRectMake(0, 0, self.view.size.width, self.view.size.height-(constraintViewCalendar_Height.constant+35))
    }
    
    
    //Mark : Picker selection
    func calendarNavButtonClicked( sender : AnyObject){
        
        let datePicker = ActionSheetDatePicker(title: "Select Date", datePickerMode: UIDatePickerMode.Date, selectedDate: self.processingDate, doneBlock: {
            picker, value, index in
            
            if let dateUntil = value as? NSDate{
                
                if((dateUntil.month() == self.processingDate.month())  &&  (dateUntil.year() == self.processingDate.year())  && (dateUntil.day() == self.processingDate.day())) {
                    return;
                }
                self.viewCalendar.selectDate(dateUntil, makeVisible: true)
                self.startIndex = 0
                self.processingDate = dateUntil
                self.isFetchListWithCalData = true
                self.fetchMyCalendarDataForDate(dateUntil)
            }
            
            return
            }, cancelBlock: { ActionStringCancelBlock in return }, origin: self.view)
        //        let secondsOfThirtyMin: NSTimeInterval = 30 * 60;
        datePicker.minuteInterval = 1
        datePicker.showActionSheetPicker()
        
    }
}
