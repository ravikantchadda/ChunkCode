//
//  ForgetPasswordVC.swift
//  LocalLift
//
//  Created by prabhjot singh on 11/16/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class ForgetPasswordVC: BaseViewController {

    @IBOutlet var txtEmail: UITextField!
    @IBOutlet var btnResetPassword: PSCustomFontButton!
    
    
    
    
//MARK: - View Life Cycle Methods
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBar(NavigationType.ClearNavigationType)
        
    }
    
    override  func viewDidLoad() {
        self.navigationItem.setHidesBackButton(true, animated: true)
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.Plain, target: self, action: "toCancel")
        super.viewDidLoad()
        
    }

//MARK: - Buttons Methods
    @IBAction func toBackToSignUp(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    @IBAction func toResetBtn(sender: UIButton) {
        if NSIUtility.validateEmail(txtEmail.text!){
            
            let userDL:UserDL = UserDL()
            userDL.requestForForgetPassword(txtEmail.text!, handler: { (obj, success) -> Void in
                if success == true{
                    if let dicResponse:NSDictionary = obj as? NSDictionary{
                        
                        let resendPassToEmail = NSIUtility.fetchViewControllerWithName("ResendPasswordVC",storyBoardName:"Main") as! ResendPasswordVC
                        resendPassToEmail.emailAddString = self.txtEmail.text
                        self.navigationController?.pushViewController(resendPassToEmail, animated: true)
                        let alertMessgae:String = NSIUtility.getObjectForKey("Message", dictResponse: dicResponse) as! String
                        NSIUtility.show(alertMessgae)
                    }
                    
                }else{
                    NSIUtility.show(Constants.kSomethingWrong)
                }
            })
        }
    }
    
    
//MARK: - Text Field Delegates
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        self.performSelector("toSelectBtnValidation", withObject: nil, afterDelay: 0.3)
        
        return UITextField.textField(textField, shouldChangeCharactersInRange: range, replacementString: string,
            withMaxLength: UITextField.MaxLength.DefaultMax, spaceAllowed: false)
    }
    
    func toSelectBtnValidation()
    {
        if (self.isAllTextFieldFilled(self.view) == false ){
            btnResetPassword.backgroundColor = UIColor.colorWithRGB(31, green: 81, blue: 108, alpha:0.7)
        }
        else{
            btnResetPassword.backgroundColor = Constants.APP_THEME_COLOR
        }
    }
    
    func toCancel(){
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    
}
