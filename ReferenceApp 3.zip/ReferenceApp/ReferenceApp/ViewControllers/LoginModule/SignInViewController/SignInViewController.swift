//
//  SignInViewController.swift
//  ReferenceApp
//
//  Created by Mohit Jain on 8/27/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit
typealias CompleteSocialLoginBlock = (Bool,LoginType,String!) -> Void

public class SignInViewController: UIViewController,TextFieldWithImageDelegate {
    
    @IBOutlet weak var txtFieldUserName: TextFieldWithImage!
    @IBOutlet weak var txtFieldPassword: TextFieldWithImage!
    @IBOutlet weak var btnSignIn: UIButton!
    @IBOutlet weak var btnCreateFreeAccount: UIButton!
    
   // let socialLogin = SocialMedia()
    let facebook = Facebook()
    let twitter = TWitter()
     let linkedIn = LinkedIn()
    let googlePlus = GooglePlus()
    
    var isVerifyAllValidation:Bool = false
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //setup Intial
        setupUIElements()
        setupDelegate()
        
        if view.gestureRecognizers != nil {
            for gesture in view.gestureRecognizers! {
                if let recognizer = gesture as? UISwipeGestureRecognizer {
                    view.removeGestureRecognizer(recognizer)
                }
            }
        }
        
    }
    
    override public func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Setup Intialize
    func setupUIElements() {
        
        //set Navigation Bar title
        self.navigationItem.title = NSLocalizedString("naviagtionBarTitleSignIn",comment:"")
        
        //set text for @IBOutlet
        btnSignIn.setTitle(NSLocalizedString("btnSignIn",comment:""), forState: UIControlState.Normal)
        btnCreateFreeAccount.setTitle(NSLocalizedString("btnCreateFreeAccountSignIn",comment:""), forState: UIControlState.Normal)
        btnSignIn.layer.borderColor = Constants.APP_THEME_COLOR.CGColor
        btnCreateFreeAccount.layer.borderColor = UIColor.grayColor().CGColor
    }
    
    func setupDelegate() {
        txtFieldUserName.delegate = self
        txtFieldPassword.delegate = self
    }
    
    override public func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?)
    {
        self.view.endEditing(true)
    }
    
    // MARK: - IBAction Methods
    @IBAction func btnSocialLogin(sender: AnyObject) {
        //Response for after user verify Passcode.
        let completionSocialLogin: CompleteSocialLoginBlock = { (isTokenFetched:Bool,loginType:LoginType,token:String!) -> Void in
            if isTokenFetched {
                var fb_token:String? =  ""
                var google_token:String? =  ""
                var linkedin_token:String? =  ""
                var twitter_token:String? =  ""
                
                
                switch (loginType) {
                case LoginType.LoginSourcetypeFacebook:
                    fb_token = token
                  //  self.facebook.postToTimeLineFaceBook(self)
                   // self.facebook.postToPagesFaceBook(self)
                     self.facebook.invitePeoples(self)
                    
                    self.facebook.requestProfile({ (data, success) -> Void in
                        
                    })

                case LoginType.LoginSourcetypeGooglePlus:
                    google_token = token
                case LoginType.LoginSourcetypeTwitter:
                    twitter_token = token
                case LoginType.LoginSourcetypeLinkedIn:
                    linkedin_token = token
                default: break
                }
                NSIUtility.setValueToUserDefaultsForKey("sociallogin", value: true)
                
                let delegate =  UIApplication.sharedApplication().delegate as! AppDelegate
                delegate.showMainStoryboard()
                
                let email: NSString = "email"
                let fbId: NSString = "fb_id"
                let googleId: NSString = "google_id"
                let linkedinId: NSString = "linkedin_id"
                let deviceToken: NSString = "device_token"
                let deviceType: NSString = "device_type"
                let deviceTypeValue:NSString = "1"
                let deviceId: NSString = "device_id"
                
                
                let dict:NSDictionary = NSDictionary(objects: [NSIUtility.getUniqueIdentifier(),fb_token!,google_token!,linkedin_token!,"",deviceTypeValue], forKeys: [deviceId,fbId,googleId,linkedinId,deviceToken,deviceType])
                print(dict)
                //                self.callToSocialLoginWebServiceWithPostDic(dict)
            } else {
                /**
                *  Error handling
                */
            }
        }
        switch (sender.tag) {
        case 1:
            facebook.viewCont = self
            facebook.signInWithFacebook(self,responseBlock:completionSocialLogin)
        case 2:
            googlePlus.signInWithGoogle(completionSocialLogin)
        case 3:
            linkedIn.signInWithLinkedIn(completionSocialLogin)
        case 4:
            twitter.signInWithTwitter(self, Block: completionSocialLogin)
            
        default: break
        }
        
    }
    @IBAction func btnCreateNewAccountTapped(sender: AnyObject) {
        //Present Create New Account Controller.
        self.performSegueWithIdentifier("CreateNewAccount", sender: self)
    }
    
    @IBAction func btnLoginTapped(sender: AnyObject) {
        self.view.endEditing(true)
        
        do {
            
          let boolValidation = try checkFieldsValidation(txtFieldUserName.txtField.text,password: txtFieldPassword.txtField.text) as Bool
            
            if boolValidation == true{
                let headerBody:String = Constants.kOuthHeader
                self.callToGetOuthTokenWebServiceWithHeaderBody(headerBody)
            }
            
        }
        catch  {
            print("Error**********Exception Handling")
        }
        
        
    }
    
    
    
    func getFBUsersProfile(){
    facebook.requestProfile { (data, success) -> Void in
        
        NSIUtility.DBlog(data as! NSDictionary)
        
        }
    
    }
    
    //MARK: - Method to Get OuthToken
    func callToGetOuthTokenWebServiceWithHeaderBody(headerBody:String){
        
        let outh = OuthDL()
        
        outh.requestforOuth(headerBody) { (obj, success) -> Void in
            if success == true{
                print(obj?.valueForKey(Constants.keyAccessToken) as! String)
                print(success as Bool!)
                let accessToken: String!
                let tokenType: String!
                accessToken = obj?.valueForKey(Constants.keyAccessToken) as! String
                tokenType = obj?.valueForKey(Constants.keyTokenType) as! String
                
                let outhToken: String!
                outhToken = tokenType + " " + accessToken
                NSIUtility.setValueToUserDefaultsForKey(Constants.keyOuthToken, value: outhToken)
                
                let email: NSString = "email"
                let password: NSString = "password"
                
                let dictParams:NSDictionary = NSDictionary(objects: [self.txtFieldUserName.txtField.text!,self.txtFieldPassword.txtField.text!], forKeys: [email,password])
                self.callToLoginWebServiceWithDict(dictParams)
                
            }else{
            
            NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""), message: Constants.kAlertServerError, view: self, delegate: nil)
            }
            
        }
        
        
        
    }
    
    
       //MARK: - Method to Login
    func callToLoginWebServiceWithDict(params:NSDictionary){
        
        let user = UserDL()
        user.requestforUserSignIn(params, withCompletionHandler: { (obj, success) -> Void in
            
            if success == true{
                
                print(obj?.valueForKey(Constants.keyStatusCode) as! NSNumber)
                print(success as Bool!)
                
                let statusCode = obj?.valueForKey(Constants.keyStatusCode) as! NSNumber
                
                if statusCode == 200{//****Status code 200 defined the success response
                    self.fillUserInfoModel(obj?.valueForKey(Constants.keyResponse) as! NSDictionary)
                    
                    NSIUtility.DBlog("Successfully Logedin")
                    NSIUtility.setValueToUserDefaultsForKey("sociallogin", value: false)
                    
                }else if statusCode == 111{//****Status code 111 defined the failure response
                    NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""), message: obj?.valueForKey("error") as! String, view: self, delegate: nil)
                }
                
            }else{
            
             NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""), message: Constants.kAlertServerError, view: self, delegate: nil)
            
            }
            
        })
        
    }
    
    
    
    //MARK: - Delegate Methods
    func btnActionForRightButton(sender:AnyObject) {
        self.performSegueWithIdentifier("ForgotPasswordNavigation", sender: self)
    }
    
    func textFieldWithImageDidEndEditing(textFieldWithImage: TextFieldWithImage) {
        
        //*********Exception Handling***************
        do {
            
            let boolValidation = try checkFieldsValidation(txtFieldUserName.txtField.text,password: txtFieldPassword.txtField.text) as Bool
            
            if boolValidation == true{
                isVerifyAllValidation = true
                btnSignIn.backgroundColor = Constants.APP_THEME_COLOR
                btnSignIn.setTitleColor( UIColor.whiteColor(),forState: UIControlState.Normal)
            }else {
                isVerifyAllValidation = false
                btnSignIn.backgroundColor = UIColor.clearColor()
                btnSignIn.setTitleColor(Constants.APP_THEME_COLOR,forState: UIControlState.Normal)
            }
            
        }
        catch  {
            print("Error**********Exception Handling")
        }
        
        
        
        
        
//        if(checkFieldsValidation(txtFieldUserName.txtField.text,password: txtFieldPassword.txtField.text)) {
//            isVerifyAllValidation = true
//            btnSignIn.backgroundColor = Constants.APP_THEME_COLOR
//            btnSignIn.setTitleColor( UIColor.whiteColor(),forState: UIControlState.Normal)
//        } else {
//            isVerifyAllValidation = false
//            btnSignIn.backgroundColor = UIColor.clearColor()
//            btnSignIn.setTitleColor(Constants.APP_THEME_COLOR,forState: UIControlState.Normal)
//        }
    }
    
    func textFieldWithImageShouldReturn(textFieldWithImage: TextFieldWithImage) -> Bool {
        if textFieldWithImage == txtFieldUserName {
            txtFieldPassword.txtField.becomeFirstResponder()
        } else {
            textFieldWithImage.txtField.resignFirstResponder()
        }
        return true
    }
    
    // MARK: - Fill UserInfoModel
    func fillUserInfoModel(dict: NSDictionary!) {
        let userDict:NSDictionary! = NSIUtility.getObjectForKey("user", dictResponse: dict) as! NSDictionary
        if userDict != nil {
            let userInfoModel = UserBO()
            userInfoModel.fillUserModel(userDict)
            //set AccessToken
            let accessToken:String! = NSIUtility.getObjectForKey(Constants.keyAccessToken, dictResponse: dict) as! String
            if accessToken != nil {
               userInfoModel.userAccesstoken = accessToken
            }
            UserInfoManager.setUserInfo(userInfoModel)
            NSIUtility.deleteTokenFromKeychain()
            
           
            
            
            
            do{
                
                try NSIUtility.saveTokenToKeychain(accessToken as String)
                try NSIUtility.getTokenFromKeychain()
                
                let delegate =  UIApplication.sharedApplication().delegate as! AppDelegate
                delegate.showMainStoryboard()
                
                
            }catch{
                
                print("Error")
            }
            
            let delegate =  UIApplication.sharedApplication().delegate as! AppDelegate
            delegate.showMainStoryboard()
            
            
            
            //Successfully Login Remove Login Screen
        } else {
            
        }
    }
    
    
    
    
    
    // MARK: - Check Validation
    /**
    Check all validations
    1. Empty check for both fields
    2. Validate Email
    - returns: bool value yes if all validations are fullfilled otherwise false.
    */
    
    func checkFieldsValidation(email:String!, password:String!) throws -> (Bool) {
        return self.checkEmailValidation(email) && self.checkEmptyPassword(password)
    }
    
    func checkEmailValidation(email: String!) -> (Bool) {
        if (!NSIUtility.checkIfStringContainsText(email))
        {
            
            NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""),message:  NSLocalizedString("EmptyString",comment: "comment"), view: self, delegate: nil)
            
            return false
        }
        if(!NSIUtility.validateEmail(email)) {
            NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""),message:  NSLocalizedString("InvalidEmail",comment: "comment"), view: self, delegate: nil)
            return false
        }
        return true
    }
    
    func checkEmptyPassword(password: String!) -> (Bool) {
        if (!NSIUtility.checkIfStringContainsText(password))
        {
            //            NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""), message: NSLocalizedString("EmptyString",comment: ""), delegate: nil)
            return false
        }
        return true
    }
    
}
