//
//  CreateGroupTextVW.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/21/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

protocol ShowGroupTypeProtocol
{
    func showGroupType()
    func changeGroupTypeNameText()
}

class CreateGroupTextVW: UIView {//90,99,124
    
    
    var delegate:ShowGroupTypeProtocol?
    @IBOutlet weak var txtViewDescription: UITextView!
    @IBOutlet weak var lbltxtUsedDescription: UILabel!
     @IBOutlet weak var txtFiledGroupName: UITextField!
    @IBOutlet weak var lblGroupType: UILabel!
    @IBOutlet weak var lblGroupTypePredefined: UILabel!
   
    // MARK:-  open grouptype tableview
    @IBAction func groupTypeAction(sender: AnyObject) {
        if(delegate != nil) {
            delegate?.showGroupType()
        }
    }
    
    // MARK:-  Our custom view from the XIB file
    var view: UIView!
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadViewFromNib ()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        loadViewFromNib ()
    }
    func loadViewFromNib() {
        let bundle = NSBundle(forClass: self.dynamicType)
        let nib = UINib(nibName: "CreateGroupTextVW", bundle: bundle)
        let view = nib.instantiateWithOwner(self, options: nil)[0] as! UIView
        view.frame = bounds
        view.autoresizingMask = [.FlexibleWidth, .FlexibleHeight]
        self.addSubview(view);
    }
    
    // MARK:- TextView Delegate
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool{
        let oldString = textView.text ?? ""
        let startIndex = oldString.startIndex.advancedBy(range.location)
        let endIndex = startIndex.advancedBy(range.length)
        let newString = oldString.stringByReplacingCharactersInRange(startIndex ..< endIndex, withString: text)
        lbltxtUsedDescription.text = "\(newString.characters.count)/500"
        return UITextView.textView(textView, shouldChangeCharactersInRange: range, replacementString: text,
            withMaxLength:499, spaceAllowed: true)
    }
    
    func textViewShouldBeginEditing(textView: UITextView) -> Bool{
        if textView.text == "Description"{
            textView.text = ""
        }
        return true
    }
    func textViewShouldEndEditing(textView: UITextView) -> Bool{
        let strngText =  textView.text.removeWhiteCharacterSetFromString()
        if strngText.length == 0{
            textView.text = "Description"
        }
        return true
    }
   
    // MARK:- TextVField value change call this function
    @IBAction  func textFieldDidChange(textField: UITextField) {
        if(delegate != nil) {
            delegate?.changeGroupTypeNameText()
        }
    }


}
