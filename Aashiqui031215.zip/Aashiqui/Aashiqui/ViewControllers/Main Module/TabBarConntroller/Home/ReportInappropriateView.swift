//
//  ReportInappropriateView.swift
//  Aashiqui
//
//  Created by ketan saini on 16/11/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

protocol ReportFeedDelegate
{
    func reportFeedTapped()
    
}
class ReportInappropriateView: UIView {
    @IBOutlet weak var tempView: UIView!
    @IBOutlet weak var tblReport: UITableView!
    @IBOutlet weak var imgVwBackground: UIImageView!
    @IBOutlet weak var viewContainer: UIView!
    @IBOutlet weak var txtReportOther: UITextField!
    var delegate: ReportFeedDelegate!
    var viewCenter: CGPoint!
    
    let arrList: NSArray = ["Inappropriate","Offensive","Nudity","Spam","Other"]
    var dictData: NSDictionary!
    
    override init(frame: CGRect) { // for using CustomView in code
        super.init(frame: frame)
        self.commonInit()
    }
    required init(coder aDecoder: NSCoder) { // for using CustomView in IB
        super.init(coder: aDecoder)!
        self.commonInit()
    }
    private func commonInit() {
        NSBundle.mainBundle().loadNibNamed("ReportInappropriateView", owner: self, options: nil)
        self.addSubview(tempView)
        tempView.frame = CGRectMake(0, 0, NSIConstants.ScreenSize.SCREEN_WIDTH, NSIConstants.ScreenSize.SCREEN_HEIGHT)
        imgVwBackground.frame = CGRectMake(0, 0, NSIConstants.ScreenSize.SCREEN_WIDTH, NSIConstants.ScreenSize.SCREEN_HEIGHT)
        viewContainer.frame = CGRectMake(NSIConstants.ScreenSize.SCREEN_WIDTH - 200, 64, 185,233)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "removeView")
        tapGesture.numberOfTapsRequired = 1
        imgVwBackground.addGestureRecognizer(tapGesture)
        tblReport.tableFooterView = UIView(frame: CGRectZero)
        tblReport.reloadData()
    }
    
    func setUpReportView(dict: NSDictionary) {
        print("setUpReportView\(dict)")
       viewContainer.center = CGPointMake(dict.valueForKey("center")?.objectAtIndex(0) as! CGFloat, dict.valueForKey("center")?.objectAtIndex(1) as! CGFloat)
        print(dict.valueForKey("data"))
        viewCenter = viewContainer.center
        dictData = dict.valueForKey("data") as! NSDictionary
    }

    func removeView(){
        self.removeFromSuperview()
    }
    //MARK: - Webservice call
    //Report Inappropriate API
    func fnReportFeedWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceReportFeed)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("GetChat--- \(response.webserviceResponse)")
                
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    self.removeView()
                    self.delegate.reportFeedTapped()
                }else{
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
    
    
    //MARK: - TableView DataSource/Delegate
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrList.count
    }
    
    func tableView(tableView: UITableView!, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 44
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCellWithIdentifier("\(indexPath.row)") as UITableViewCell!
        if (cell == nil) {
            cell = UITableViewCell(style: UITableViewCellStyle.Value1, reuseIdentifier: "\(indexPath.row)")
            cell.selectionStyle = UITableViewCellSelectionStyle.None
            
            let lblStatus: UILabel = UILabel(frame: CGRectMake(10, 4, cell.frame.size.width - 10, 36))
            lblStatus.textAlignment = NSTextAlignment.Left
            lblStatus.textColor = NSIConstants.greyColor
            lblStatus.text = arrList.objectAtIndex(indexPath.row) as? String
            lblStatus.numberOfLines = 1
            lblStatus.font = UIFont(name: "Lato-Regular", size: 14)
            lblStatus.lineBreakMode = NSLineBreakMode.ByWordWrapping
            lblStatus.sizeToFit()
            cell.addSubview(lblStatus)
        }
        
        return cell
    }
    
    func fnReportFeedAPICall(strReason: String){
        if let userId = NSIConstants.userDefaults.valueForKey("userId") {
            let dict:NSDictionary = [
                "userId": userId,
                "feedId": dictData.valueForKey("feedId") as! String,
                "reason": strReason
            ]
            print("\(dict)")
            self.fnReportFeedWebServiceWithPostDic(dict, showLoader: true)
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if indexPath.row != 4 {
            self.fnReportFeedAPICall(arrList.objectAtIndex(indexPath.row) as! String)
        }else{
            viewContainer.frame = CGRectMake(NSIConstants.ScreenSize.SCREEN_WIDTH - 200, 64, 185,283)
            viewContainer.center = viewCenter
        }
    }
    func textFieldShouldReturn(textField: UITextField!) -> Bool {
        textField.resignFirstResponder()
        if textField.text?.characters.count > 0 {
            self.fnReportFeedAPICall(textField.text!)
        }
        return true
    }
    
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
