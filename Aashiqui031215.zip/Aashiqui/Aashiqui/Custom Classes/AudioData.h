//
//  AudioData.h
//  Aashiqui
//
//  Created by ketan saini on 27/10/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>
#import <AddressBook/AddressBook.h>

@interface AudioData : NSObject
+(void)removeImage:(NSString *)fileName;
+(NSData*)audioData:(MPMediaItem *)item;
@end
