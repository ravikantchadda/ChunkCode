//
//  LeftMenuVC.swift
//  LocalLift
//
//  Created by neeru thakur on 12/8/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//


import UIKit
import MFSideMenu

class LeftMenuVC: UIViewController, UITableViewDelegate,UITableViewDataSource{

    @IBOutlet weak var viewTopLogo: UIView! // View for logo
    @IBOutlet weak var tableViewMenu: UITableView!
    var headerTextArray : NSArray! // Used to keep the name of menu
    
    var tableViewHeaders : [UIView]!
    var lastControllerStr : String!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.initialInitialization()
        self.createViewHeader()
        self.addNotificationObserver()
    }
    
    func addNotificationObserver(){
       
        NSIUtility.addObserverToNSNotificationCenterForNameKey(self, selector: "changenMenuCenterController:", name: "ChangeMenuCenterControllerNotification", object: nil)
    }
    
    func changenMenuCenterController(notification:NSNotification){
        
        self.moveToViewController("HomeVC", storyboardName: "Home", object: "")
        
    }
    
    
    func createViewHeader(){
        let views = NSBundle.mainBundle().loadNibNamed("MenuMyLiftView", owner: self, options: nil)
        let viewHeader : UIView? =  views.first as? UIView
        viewHeader?.backgroundColor = UIColor.colorWithRGB(8, green: 29, blue: 61, alpha: 1)
        viewHeader?.subviews.first!.layer.cornerRadius = 5.0
        viewHeader?.subviews.first!.layer.borderWidth = 0.5
        viewHeader?.subviews.first!.clipsToBounds = true
        viewHeader?.subviews.first!.backgroundColor = UIColor.colorWithRGB(58.0, green: 64.0, blue: 83.0, alpha: 1.0)
        
        tableViewHeaders = Array()
        tableViewHeaders.append(viewHeader!)
    }
    
    func initialInitialization(){
        
        // Set the color
        lastControllerStr = ""
        self.view.backgroundColor = UIColor.colorWithRGB(8, green: 29, blue: 61, alpha: 1)
        self.tableViewMenu.backgroundColor = UIColor.colorWithRGB(8, green: 29, blue: 61, alpha: 1)
         self.viewTopLogo.backgroundColor = UIColor.colorWithRGB(8, green: 29, blue: 61, alpha: 1)
        
        headerTextArray = ["MyLiftSection","Invite a Friend","Upgrade to Localift Premium","Promotions","My Profile","Settings"]
    }
    
    //MARK: - Table VIew Delegates
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return 0
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int{
        
        return headerTextArray.count
    }
    
    func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
       
        return nil
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat{
            return 60
    }
    
     func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat{
        
        let height: CGFloat
        switch section
        {
            case 0:
                height = 212
            
            default:
                height = 40
            
        }
        return height
    }
    
     func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: "Cell")
        cell.textLabel?.text =  headerTextArray.objectAtIndex(indexPath.row) as? String
        return cell
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
    
        switch section
        {
            case 0:
                return tableViewHeaders[section]
            default:
                
                if(tableViewHeaders.count > section){
                    if let header = tableViewHeaders[section] as UIView?{
                        return header
                    }
                }
                else{

                    let view:MenuNormalHeaderView = MenuNormalHeaderView(frame: CGRectMake(0, 0, tableViewMenu.width, 40))
                    view.leftMenuVCCallBack = self
                    view.setButtonTile((headerTextArray.objectAtIndex(section) as? String)!, section: section)
                    tableViewHeaders.insert(view, atIndex: section)
                    return view
                }
        }
        
    }
    
    //MARK : Action methods
    @IBAction func toMyLift(sender: AnyObject) {

//        self.presentController("myLiftNavigationController", storyboardName: "Home", object: "")
        self.pushToViewController("MyLiftVC", storyboardName: "Home", object: "")
        
    }
    
    @IBAction func toRequestALift(sender: AnyObject) {
        self.presentController("liftRequestNavigationController", storyboardName: "Home", object: "")
    }
    
    @IBAction func toOfferALift(sender: AnyObject) {
        self.presentController("liftRequestNavigationController", storyboardName: "Home", object: "offer")
    }
    
    @IBAction func toMyLiftGroups(sender: AnyObject) {
        NSIUtility.showUnderDevelopmentAlert()
//       self.moveToViewController("myLiftGroup", storyboardName: "Main", object: "")
        
    }
    
    @IBAction func toSponsoredGroups(sender: AnyObject) {
                 NSIUtility.showUnderDevelopmentAlert()
        
    }

    
    // Present View controllers
    
    func presentController(navControllerName:String, storyboardName _storyboardName:String,  object:String){
        
        let navigationController:UINavigationController = NSIUtility.fetchViewControllerWithName(navControllerName, storyBoardName:_storyboardName) as! UINavigationController
        let viewController = navigationController.viewControllers.first
            
        if let viewController:LiftRequestVC = viewController as? LiftRequestVC{
            if object == "offer"{
                viewController.whichLiftType = .LiftTypeOffer
            }else{
                viewController.whichLiftType = .LiftTypeRequest
            }
        }
        
        let currentController:UINavigationController = self.menuContainerViewController.centerViewController as! UINavigationController
        currentController.presentViewController(navigationController, animated: true, completion: {
            self.menuContainerViewController.toggleLeftSideMenuCompletion({
                
            })
        })
    
        
    }
    
    func pushToViewController(controllerName:String, storyboardName _storyboardName:String,  object:String){
        
        let viewController = NSIUtility.fetchViewControllerWithName(controllerName,storyBoardName:_storyboardName)
        let currentController:UINavigationController = self.menuContainerViewController.centerViewController as! UINavigationController
        
        self.menuContainerViewController.disablePanGeture = false
        if(controllerName == "MyLiftVC"){
            self.menuContainerViewController.disablePanGeture = true
            self.menuContainerViewController.disablePanGeture = true
        }
        self.menuContainerViewController.toggleLeftSideMenuCompletion({
            
        })
        currentController.pushViewController(viewController, animated: true)

    }
   
    
    // Marker: Used to set the viewcontroller when menu button is tapped
    func moveToViewController(controllerName:String, storyboardName _storyboardName:String,  object:String){
        
        let viewController = NSIUtility.fetchViewControllerWithName(controllerName,storyBoardName:_storyboardName)
        
        if let controller:LiftRequestVC = viewController as? LiftRequestVC{
            if object == "offer"{
                controller.whichLiftType = .LiftTypeOffer
            }else{
                controller.whichLiftType = .LiftTypeRequest
            }
        }
        
        self.menuContainerViewController.disablePanGeture = false
        if(controllerName == "MyLiftVC"){
             self.menuContainerViewController.disablePanGeture = true
        }

        
        let navigationController:UINavigationController = self.menuContainerViewController.centerViewController as! UINavigationController

        if  navigationController.viewControllers.last?.isKindOfClass(viewController.classForCoder) == true{
            
            if let controller:LiftRequestVC = viewController as? LiftRequestVC{
                if object == "offer"{
                    controller.whichLiftType = .LiftTypeOffer
                }else{
                    controller.whichLiftType = .LiftTypeRequest
                }
            }
            
            if object != lastControllerStr{
                lastControllerStr = object
                navigationController.viewControllers = [viewController]
                self.menuContainerViewController.setMenuState(MFSideMenuStateClosed, completion: {
                    
                })
            }else{
                self.menuContainerViewController.toggleLeftSideMenuCompletion({
                    
                })
            }
            
        }
        else{
             lastControllerStr = object
            navigationController.viewControllers = [viewController]
            self.menuContainerViewController.setMenuState(MFSideMenuStateClosed, completion: {
                
            })
        }

    }

    // MARK : MenuNormalHeaderView callback function
    func didSelectMenuOption(index:Int){
        
        switch index
        {
            case 1:
                NSIUtility.showUnderDevelopmentAlert()
            case 2:
                NSIUtility.showUnderDevelopmentAlert()
            case 3:
                NSIUtility.showUnderDevelopmentAlert()
            case 4:
                NSIUtility.showUnderDevelopmentAlert()
//                self.logout()
            case 5:
                NSIUtility.showUnderDevelopmentAlert()
            case 6:
                NSIUtility.showUnderDevelopmentAlert()
            case 7:
                NSIUtility.showUnderDevelopmentAlert()
            
            default:
                print(" Default Values")
        }
        
    }
    
    @IBAction func toHomeButton(sender: AnyObject) {
        self.moveToViewController("HomeVC", storyboardName: "Home", object: "")

    }
    

    
    

}