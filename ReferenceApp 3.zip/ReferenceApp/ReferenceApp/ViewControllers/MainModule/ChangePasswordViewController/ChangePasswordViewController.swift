//
//  ChangePasswordViewController.swift
//  ReferenceApp
//
//  Created by Mohit Jain on 9/15/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit

class ChangePasswordViewController: UIViewController {
    
    @IBOutlet weak var txtFieldOldPassword: UITextField!
    @IBOutlet weak var txtFieldNewPassword: UITextField!
    @IBOutlet weak var txtFieldConfirmPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - IBAction Methods
    @IBAction func btnChangePasswordTapped(sender: AnyObject) {
        let newPassword: NSString = "new_password"
        let oldPassword: NSString = "old_password"
        
        let dictParams:NSDictionary = NSDictionary(objects: [txtFieldNewPassword.text!,txtFieldOldPassword.text!], forKeys: [newPassword,oldPassword])
        
        
        let accessToken: String!
        let tokenType: String!
        
        
        
        do{
            
            let dict = try NSIUtility.getTokenFromKeychain() as! NSDictionary as NSDictionary!
            accessToken = dict.valueForKey("desc") as! String
            tokenType = Constants.keyDefinedTokenType
            let loginUserToken: String!
            loginUserToken = tokenType + " " + accessToken
            
            NSIUtility.DBlog("Successfully Change Password")
            NSIUtility.setValueToUserDefaultsForKey(Constants.keyOuthToken, value: loginUserToken)
            
            
            self.callToChangePasswordWebServiceWithDict(dictParams)
            
        }catch{
            
            print("Error")
        
        }
        
        
       
        
        
    }
    
    
    //MARK: - Method call to change password
    func callToChangePasswordWebServiceWithDict(params:NSDictionary){
        let user = UserDL()
        user.requestforUserChangePassword(params, withCompletionHandler: { (obj, success) -> Void in
            
            if success == true{
                
              
                NSIUtility.DBlog(obj?.valueForKey(Constants.keyStatusCode) as! NSNumber)
                NSIUtility.DBlog(success as Bool!)
                
                
                let statusCode = obj?.valueForKey(Constants.keyStatusCode) as! NSNumber
                if statusCode == 200{//****Status code 200 defined the success response
                    
                    NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""),message:  NSLocalizedString("PasswordChange",comment: "comment"), view: self, delegate: nil)
                    let delegate =  UIApplication.sharedApplication().delegate as! AppDelegate
                    delegate.showLoginStoryboard()
                    
                }else if statusCode == 401{//****401 status defined Wrong Access Token or data in body
                    
                    
                    NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""),message:  obj?.valueForKey("error") as! String, view: self, delegate: nil)
                }
                
            }else{
                
                NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""), message: Constants.kAlertServerError, view: self, delegate: nil)
                
            }
            
        })
        
        
    }
    
    
}
