//
//  ProfilePicView.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/22/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class ProfilePicView: UIView {
    @IBOutlet weak var btnUploadImage: UIButton!
    @IBOutlet weak var imgVwProfile: UIImageView!
    @IBOutlet weak var lblHeader: UILabel!
     var delegate:ColectionCellSelectProtocol?
    
    // Mark: Upload photo action
    @IBAction func uploadPhotoAction(sender: AnyObject) {
        if(delegate != nil) {
            delegate?.select()
        }
    }
    
    
    // Our custom view from the XIB file
    var view: UIView!
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadViewFromNib ()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        loadViewFromNib ()
    }
    // MARK:- loadViewFromNib
    func loadViewFromNib() {
        let bundle = NSBundle(forClass: self.dynamicType)
        let nib = UINib(nibName: "ProfilePicView", bundle: bundle)
        let view = nib.instantiateWithOwner(self, options: nil)[0] as! UIView
        view.frame = bounds
        view.autoresizingMask = [.FlexibleWidth, .FlexibleHeight]
        self.addSubview(view);
        
        lblHeader.text = "Personalise your Lift group with a photo,\na memorable name and a brief description."
    }

}
