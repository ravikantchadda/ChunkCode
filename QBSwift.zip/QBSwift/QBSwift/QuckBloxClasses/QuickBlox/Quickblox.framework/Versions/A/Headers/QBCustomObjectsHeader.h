//
//  QBCustomObjectsHeader.h
//  Quickblox
//
//  Created by Andrey Moskvin on 7/28/14.
//  Copyright (c) 2014 QuickBlox. All rights reserved.
//

#ifndef Quickblox_QBCustomObjectsHeader_h
#define Quickblox_QBCustomObjectsHeader_h

#import <Quickblox/QBCOPermissions.h>
#import <Quickblox/QBCOCustomObject.h>
#import <Quickblox/QBRequest+QBCustomObjects.h>
#import <Quickblox/QBCOFile.h>

#endif
