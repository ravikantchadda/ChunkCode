//  ReferenceApp
//
//  Created by ravi kant on 11/6/15.
//  Copyright © 2015 Netsol. All rights reserved.
//


import UIKit



// MARK: -  User Model
/**
*************************************
i.e. the User Model here we difine the objects
used in the service and these objects are used
to manage the data of user
*************************************
**/
class UserBO: NSObject {
    
    //MARK: Key Parameters variables
    let userEmailKey:String = "email"
    let userFirstNameKey:String = "first_name"
    let userCompanyKey:String = "company"
    let userDOBKey:String = "date_of_birth"
    let userDesignationKey:String = "designation"
    let userDeviceTokenKey:String = "device_token"
    let userDeviceTypeKey:String = "device_type"
    let userFbIdKey:String = "fb_id"
    let userGoogleIdKey:String = "google_id"
    let userLinkedInKey:String = "linkedin_id"
    let userTitleKey:String = "title"
    let userAccessTokenKey:String = "access_token"
    let userIdKey:String = "id"
    
    //MARK: class variables
    var userEmailAddress:String!
    var userFirstName:String!
    var userCompany:String!
    var userDOB:String!
    var userDesignation:String!
    var userDeviceToken:String!
    var userDeviceType:Int!
    var userFB_Id:String!
    var userGoogle_Id:String!
    var userLinkedIn_Id:String!
    var userTitle:String!
    var userAccesstoken:String!
    var userId:Int!
    
    
    
    //MARK: fillUserInfo Model
    func fillUserModel(dictUserInfo:NSDictionary!) {
        userEmailAddress = NSIUtility.getObjectForKey(userEmailKey, dictResponse: dictUserInfo) as! String
        userFirstName = NSIUtility.getObjectForKey(userFirstNameKey, dictResponse: dictUserInfo) as! String
        //userCompany = NSIUtility.getObjectForKey(userCompanyKey, dictResponse: dictUserInfo) as! String
        // userDOB = NSIUtility.getObjectForKey(userDOBKey, dictResponse: dictUserInfo) as! String
        // userDesignation = NSIUtility.getObjectForKey(userDesignationKey, dictResponse: dictUserInfo) as! String
        userDeviceToken = NSIUtility.getObjectForKey(userDeviceTokenKey, dictResponse: dictUserInfo) as! String
        userDeviceType = NSIUtility.getObjectForKey(userDeviceTypeKey, dictResponse: dictUserInfo) as! Int
        userFB_Id = NSIUtility.getObjectForKey(userFbIdKey, dictResponse: dictUserInfo) as! String
        userGoogle_Id = NSIUtility.getObjectForKey(userGoogleIdKey, dictResponse: dictUserInfo) as! String
        userLinkedIn_Id = NSIUtility.getObjectForKey(userLinkedInKey, dictResponse: dictUserInfo) as! String
        //userTitle = NSIUtility.getObjectForKey(userTitleKey, dictResponse: dictUserInfo) as! String
        // userAccesstoken = NSIUtility.getObjectForKey(userAccessTokenKey, dictResponse: dictUserInfo) as! String
        userId = NSIUtility.getObjectForKey(userIdKey, dictResponse: dictUserInfo) as! Int
    }
    
    
    // MARK: NSCoding
    /****
    
    1. Convenience initialisers allow you to initialise a class without all
    the required parameters the designated initialiser needs.
    2. Decoding: Decoding is the reverse process of encoding,
    which converts encoded information back in to its original format
    
    *****/
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.userEmailAddress = (decoder.decodeObjectForKey(userEmailKey) as! String?)!
        self.userFirstName = (decoder.decodeObjectForKey(userFirstNameKey) as! String?)!
        //self.userCompany = (decoder.decodeObjectForKey(userCompanyKey) as! String?)!
        //self.userDOB = (decoder.decodeObjectForKey(userDOBKey) as! String?)!
        //self.userDesignation = (decoder.decodeObjectForKey(userDesignationKey) as! String?)!
        self.userDeviceToken = (decoder.decodeObjectForKey(userDeviceTokenKey) as! String?)!
        self.userDeviceType = (decoder.decodeObjectForKey(userDeviceTypeKey) as! Int?)!
        self.userFB_Id = (decoder.decodeObjectForKey(userFbIdKey) as! String?)!
        self.userGoogle_Id = (decoder.decodeObjectForKey(userGoogleIdKey) as! String?)!
        self.userLinkedIn_Id = (decoder.decodeObjectForKey(userLinkedInKey) as! String?)!
        //self.userTitle = (decoder.decodeObjectForKey(userTitleKey) as! String?)!
        //  self.userAccesstoken = (decoder.decodeObjectForKey(userAccessTokenKey) as! String?)!
        self.userId = (decoder.decodeObjectForKey(userIdKey) as! Int?)!
        
    }
    /****
     1. Encoding: Transforming data in to more usable formats for different systems,
     using a method publicly available is called encoding. Encoded data can be easily reversed.
     
     *****/
    func encodeWithCoder(coder: NSCoder) {
        coder.encodeObject(self.userEmailAddress, forKey: userEmailKey)
        coder.encodeObject(self.userFirstName, forKey: userFirstNameKey)
        //coder.encodeObject(self.userCompany, forKey: userCompanyKey)
        //coder.encodeObject(self.userDOB, forKey: userDOBKey)
        // coder.encodeObject(self.userDesignation, forKey: userDesignationKey)
        coder.encodeObject(self.userDeviceToken, forKey: userDeviceTokenKey)
        coder.encodeObject(self.userDeviceType, forKey: userDeviceTypeKey)
        coder.encodeObject(self.userFB_Id, forKey: userFbIdKey)
        coder.encodeObject(self.userGoogle_Id, forKey: userGoogleIdKey)
        coder.encodeObject(self.userLinkedIn_Id, forKey: userLinkedInKey)
        //coder.encodeObject(self.userTitle, forKey: userTitleKey)
        //  coder.encodeObject(self.userAccesstoken, forKey: userAccessTokenKey)
        coder.encodeObject(self.userId, forKey: userIdKey)
        
    }
    
}




// MARK: -  User Data Layer
/**
*************************************
USER DATA LAYERS (here we define all the services of User activity)
*************************************
**/
class UserDL: NSIRestAPIHelper {
    
    
    // MARK: -  Method to Request for User SignIn
    func requestforUserSignIn(obj:AnyObject, withCompletionHandler handler:CompletionHandler)
    {
        self.serviceURL = "app/api/signin/"
        self.isCallforOuth = false
        let outhToken:String!
        outhToken = NSIUtility.getValueFromUserDefaultsForKey("outhtoken") as! String
        
        self.headerdict = ["Authorization":outhToken]
        self.requestforPOST(obj as! [NSObject : AnyObject!], withCompletionHandler:{ (obj, success) -> Void in
            if success == true
            {
                handler(obj: obj, success: true)
            }else{
                
                handler(obj: nil, success: false)
            }
            
        })
    }
    
    
    // MARK: -  Method to Request for User LogOut
    func requestforUserLogOut(headerBody:String, withCompletionHandler handler:CompletionHandler)
    {
        
        self.serviceURL = "app/api/signout/"
        self.isCallforOuth = false
        let outhToken:String!
        outhToken = NSIUtility.getValueFromUserDefaultsForKey("outhtoken") as! String
        
        self.headerdict = ["Authorization":outhToken]
        
        self.requestforPUT(headerBody) { (obj, success) -> Void in
            if success == true
            {
                handler(obj: obj, success: true)
            }else{
                
                handler(obj: nil, success: false)
            }
        }
        
    }
    
    
    // MARK: -  Method to Request for User SignUp
    func requestforUserSignUp(obj:AnyObject, withCompletionHandler handler:CompletionHandler)
    {
        self.serviceURL = "app/api/signup/"
        self.isCallforOuth = false
        
        let outhToken:String!
        outhToken = NSIUtility.getValueFromUserDefaultsForKey("outhtoken") as! String
        
        self.headerdict = ["Authorization":outhToken]
        
        self.requestforPOST(obj as! [NSObject : AnyObject!], withCompletionHandler:{ (obj, success) -> Void in
            if success == true
            {
                handler(obj: obj, success: true)
            }else{
                
                handler(obj: nil, success: false)
            }
            
        })
    }
    
    // MARK: -  Method to Request for User SignUp/Upload mulipart
    func requestforUploadMultiPartUserSignUp(obj:AnyObject, withCompletionHandler handler:CompletionHandler)
    {
        self.serviceURL = "app/api/signup/"
        self.isCallforOuth = false
        
        let outhToken:String!
        outhToken = NSIUtility.getValueFromUserDefaultsForKey("outhtoken") as! String
        
        self.headerdict = ["Authorization":outhToken]
        
        self.requestforUploadMultiPart(obj as! [NSObject : AnyObject!], withCompletionHandler:{ (obj, success) -> Void in
            if success == true
            {
                handler(obj: obj, success: true)
            }else{
                
                handler(obj: nil, success: false)
            }
            
        })
    }
    
    // MARK: -  Method to Request for User Change Password
    func requestforUserChangePassword(obj:AnyObject, withCompletionHandler handler:CompletionHandler)
    {
        self.serviceURL = "app/api/changepassword/"
        self.isCallforOuth = false
        
        let outhToken:String!
        outhToken = NSIUtility.getValueFromUserDefaultsForKey("outhtoken") as! String
        
        self.headerdict = ["Authorization":outhToken]
        
        self.requestforPOST(obj as! [NSObject : AnyObject!], withCompletionHandler:{ (obj, success) -> Void in
            if success == true
            {
                handler(obj: obj, success: true)
            }else{
                
                handler(obj: nil, success: false)
            }
            
        })
    }
    
    
    // MARK: -  Method to Request for User Forgot Password
    func requestforUserForgotPassword(obj:AnyObject, withCompletionHandler handler:CompletionHandler)
    {
        self.serviceURL = "app/api/forgotpassword/"
        self.isCallforOuth = false
        
        let outhToken:String!
        outhToken = NSIUtility.getValueFromUserDefaultsForKey("outhtoken") as! String
        
        self.headerdict = ["Authorization":outhToken]
        
        self.requestforPOST(obj as! [NSObject : AnyObject!], withCompletionHandler:{ (obj, success) -> Void in
            if success == true
            {
                handler(obj: obj, success: true)
            }else{
                
                handler(obj: nil, success: false)
            }
            
        })
    }

    // MARK: -  Method to Request for Validate OTP
    func requestforUserValidateOTP(obj:AnyObject, withCompletionHandler handler:CompletionHandler)
    {
        self.serviceURL = "app/api/validateotp/"
        self.isCallforOuth = false
        
        let outhToken:String!
        outhToken = NSIUtility.getValueFromUserDefaultsForKey("outhtoken") as! String
        
        self.headerdict = ["Authorization":outhToken]
        
        self.requestforPOST(obj as! [NSObject : AnyObject!], withCompletionHandler:{ (obj, success) -> Void in
            if success == true
            {
                handler(obj: obj, success: true)
            }else{
                
                handler(obj: nil, success: false)
            }
            
        })
    }
    
    // MARK: -  Method to Request for Reset Password
    func requestforUserResetPassword(obj:AnyObject, withCompletionHandler handler:CompletionHandler)
    {
        self.serviceURL = "app/api/resetpassword/"
        self.isCallforOuth = false
        
        let outhToken:String!
        outhToken = NSIUtility.getValueFromUserDefaultsForKey("outhtoken") as! String
        
        self.headerdict = ["Authorization":outhToken]
        
        self.requestforPOST(obj as! [NSObject : AnyObject!], withCompletionHandler:{ (obj, success) -> Void in
            if success == true
            {
                handler(obj: obj, success: true)
            }else{
                
                handler(obj: nil, success: false)
            }
            
        })
    }

    
    
    
    
    
}
