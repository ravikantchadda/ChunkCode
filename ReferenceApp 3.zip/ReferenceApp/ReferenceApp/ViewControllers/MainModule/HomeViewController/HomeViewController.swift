//
//  ViewController.swift
//  ReferenceApp
//
//  Created by Aditya Aggarwal on 8/26/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit
import MFSideMenu
enum APIError: ErrorType {
    case ConnectionFailed(description: String)
}
class HomeViewController: UIViewController {
    
    
    //MARK: View Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //
        
        
        
    }
    override func viewDidAppear(animated: Bool) {
        
        super.viewDidAppear(animated)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - IBAction Methods
    
    @IBAction func btnPressedToViewUserProfile(sender: AnyObject) {
       // self.performSegueWithIdentifier("pulltorefereshvc", sender: self)
        
    }
    
    @IBAction func btnPressedToCallPullToRefereshView(sender: AnyObject) {
        self.performSegueWithIdentifier("pulltorefereshvc", sender: self)

    }
    @IBAction func btnPressedToCallPhotoBrowser(sender: AnyObject) {
        
        self.performSegueWithIdentifier("browserVC", sender: self)
        
    }
    
    
    @IBAction func toCallLeftMenuViewController(sender: AnyObject) {
        
        self.menuContainerViewController.toggleLeftSideMenuCompletion(nil)
        
    }
    @IBAction func btnChangePasscodeTapped(sender: AnyObject) {
        
        let boolKey = NSIUtility.getValueFromUserDefaultsForKey("sociallogin") as! Bool
        
        if boolKey == true{
            
            NSIUtility.showAlert("Alert!", message: "Work in progress!", view: self, delegate: nil)
            
            return
        }
        self.performSegueWithIdentifier("ChangePassword", sender: self)
        
    }
    
    @IBAction func btnSignOutTapped(sender: AnyObject) {
        
        let boolKey = NSIUtility.getValueFromUserDefaultsForKey("sociallogin") as! Bool
        
        if boolKey == true{
            let delegate =  UIApplication.sharedApplication().delegate as! AppDelegate
            delegate.showLoginStoryboard()
            UserInfoManager.removeUserInfo()
        NSIUtility.showAlert("Alert!", message: "Work in progress!", view: self, delegate: nil)
            
            return
        }
        
        
        let accessToken: String!
        let tokenType: String!
        
        do{
            let dict = try NSIUtility.getTokenFromKeychain() as! NSDictionary as NSDictionary!
            NSIUtility.DBlog(dict)
            accessToken = dict.valueForKey("desc") as! String
            tokenType = Constants.keyDefinedTokenType
            let loginUserToken: String!
            loginUserToken = tokenType + " " + accessToken
            
            NSIUtility.DBlog(loginUserToken)
            NSIUtility.setValueToUserDefaultsForKey(Constants.keyOuthToken, value: loginUserToken)
            
            self.serverCallToLogout()
            
        }catch{
            
            NSIUtility.DBlog("error")
        }
        
        
        
    }
    
    //MARK: - Method to Logout
    func serverCallToLogout(){
        let user = UserDL()
        
        user.requestforUserLogOut("")
            { (obj, success) -> Void in
                
                if success == true{
                    let delegate =  UIApplication.sharedApplication().delegate as! AppDelegate
                    delegate.showLoginStoryboard()
                    UserInfoManager.removeUserInfo()
                }
                else{
                    NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""), message: Constants.kAlertServerError, view: self, delegate: nil)
                    
                }
        }
        
        
        
    }
    
    
    
}

