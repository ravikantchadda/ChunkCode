//
//  ChatViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 10/11/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class ChatViewController: UIViewController, MessageComposerViewDelegate {
    @IBOutlet weak var tblChat: UITableView!
    var messageView: MessageComposerView!
    var arrChatData: NSMutableArray! = []
    var receiverId: String!
    var pageChat = 1
    @IBOutlet weak var tblViewHeightConstrait: NSLayoutConstraint!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.navigationController?.navigationBar.translucent = false
        self.navigationItem.titleView = Utility.navBarTitleLabel("Messages")
        self.navigationItem.title = ""
//        self.navigationItem.hidesBackButton = true
//        self.navigationItem.leftBarButtonItem = Utility.navBarLeftButton(UIImage(named: "btnBack")!, viewController: self)
        
        messageView = MessageComposerView()
        messageView.delegate = self
        messageView.messagePlaceholder = "Write Comment here"
        NSIConstants.appDelegate.window!.addSubview(messageView)
        tblChat.allowsMultipleSelectionDuringEditing = false
        fnGetChat(true)
        
        //MARK: - Pull to refresh and Infinite scrolling
        tblChat.addPullToRefreshHandler {
            if (Utility.checkNetwork() == true){
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), { () -> Void in
                if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                    self.pageChat += 1
                    let dict:NSDictionary = [
                        "userId": userId,
                        "receiverId": self.receiverId,
                        "page": self.pageChat
                    ]
                    print("\(dict)")
                    self.fnGetChatWebServiceWithPostDic(dict, showLoader: false)
                }
            })
        }
        }
    }
    
    func fnGetChat(showLoader: Bool){
        if (Utility.checkNetwork() == true){
        if let userId = NSIConstants.userDefaults.valueForKey("userId") {
            self.pageChat = 1
            let dict:NSDictionary = [
                "userId": userId,
                "receiverId": self.receiverId,
                "page": self.pageChat
            ]
            print("\(dict)")
            self.fnGetChatWebServiceWithPostDic(dict, showLoader: showLoader)
        }
        }
    }
    
    // MARK: - NavigationBar LeftBarButton Method
    func fnLeftBarButton(){
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
    }
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        messageView.removeFromSuperview()
    }
    
    func fnUpdateChat(){
        fnGetChat(false)
    }
    //MARK: - Webservices
    //Get Comments API
    func fnGetChatWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
//        ObjWebserviceCall.cachePolicy = WebserviceCallCachePolicyRequestFromCacheFirstAndThenFromUrlAndUpdateInCache
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceGetChat)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("GetChat--- \(response.webserviceResponse)")
                
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    
                    if self.arrChatData != nil {
                        self.arrChatData.removeAllObjects()
                    }
                    
                    let arrData = response.webserviceResponse.valueForKey("messages") as! NSArray
                    let arrModelData = Chat().fillDataInModel(arrData)
                    if(showLoader){
                        arrModelData.enumerateObjectsWithOptions( NSEnumerationOptions.Reverse, usingBlock: { (obj, idx, stop) -> Void in
                            self.arrChatData.addObject(arrModelData.objectAtIndex(idx))
                        })
                    }else{
                        arrModelData.enumerateObjectsUsingBlock({ object, index, stop in
                            self.arrChatData.insertObject(arrModelData.objectAtIndex(index), atIndex: 0)
                        })
                    }
                    print("self.arrChatData--\(self.arrChatData)")
                    
                }else{
                    if response.webserviceResponse.valueForKey("status") as! String != "No more data" && response.webserviceResponse.valueForKey("status") as! String != "Result not found" {
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                    }
                }
                self.tblChat.reloadData()
                if (self.arrChatData.count > 0 && self.tblChat.contentSize.height > self.tblChat.frame.height){
                    self.tblChat.contentOffset = CGPointMake(0, self.tblChat.contentSize.height - self.tblChat.frame.height)
                }
                self.tblChat.pullToRefreshView?.stopAnimating()
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
    
    //Delete Message API
    func fnDeleteMessageWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceDeleteMessage)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("GetChat--- \(response.webserviceResponse)")
                
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    self.fnGetChat(true)
                }else{
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }

    //Send Message API
    func fnSendMessageWebServiceWithPostDic(dict: NSDictionary!, showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            if(showLoader){
                ObjWebserviceCall.isShowLoader = true
            }else{
                ObjWebserviceCall.isShowLoader = false
            }
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceSendMessage)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("GetChat--- \(response.webserviceResponse)")
                
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    self.fnGetChat(false)
                }else{
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
        
    //MARK: - TableView DataSource/Delegate
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView!, heightForRowAtIndexPath indexPath: NSIndexPath!) -> CGFloat {
        return self.getRowHeightFeedCell(indexPath)
        //        return 130.0
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (self.arrChatData != nil){
            return self.arrChatData.count
        }
        return 0
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if(tableView.respondsToSelector(Selector("setSeparatorInset:"))){
            tableView.separatorInset = UIEdgeInsetsZero
        }
        if(tableView.respondsToSelector(Selector("setLayoutMargins:"))){
            
            tableView.layoutMargins = UIEdgeInsetsZero
            
        }
        if(cell.respondsToSelector(Selector("setLayoutMargins:"))){
            
            cell.layoutMargins = UIEdgeInsetsZero
            
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let objChat:Chat = self.arrChatData.objectAtIndex(indexPath.row) as! Chat
        
        var strCellIdentifier: String
        if objChat.messageSenderId == NSIConstants.userDefaults.valueForKey("userId") as! String{
            strCellIdentifier = "cellReceiver"
        }else{
            strCellIdentifier = "cellSender"
        }
        //        let cell = tableView.dequeueReusableCellWithIdentifier("cellReceiver", forIndexPath: indexPath)
        let cell = tableView.dequeueReusableCellWithIdentifier(strCellIdentifier, forIndexPath: indexPath)
        
        
        //UIImage Profile Image
        if let imgVwProfile:AsyncImageView = cell.viewWithTag(1001) as? AsyncImageView {
            imgVwProfile.image = UIImage(named: "placeholder")
            if let variableName: String = objChat.messageSenderProfilePicUrl{
                imgVwProfile.crossfadeDuration = 0.0
                imgVwProfile.imageURL = NSURL(string: variableName)
            }
        }
        if let lblName = cell.viewWithTag(1002) as? UILabel {
            lblName.text = objChat.messageSenderFirstName + " " + objChat.messageSenderLastName
        }
        if let lblTime = cell.viewWithTag(1003) as? UILabel {
            let strSec: NSInteger = Int(objChat.minutesAgo)! * 60
            let date = NSDate(timeInterval: NSTimeInterval(-strSec), sinceDate: NSDate())
            lblTime.text = Utility.relativeDateStringForDate(date)
        }
        
        if let lblMessage = cell.viewWithTag(1004) as? UILabel {
            lblMessage.text = objChat.messageText
            
            let arrCon = lblMessage.constraints as NSArray
            arrCon.enumerateObjectsUsingBlock({ object, index, stop in
                let conts: NSLayoutConstraint = arrCon.objectAtIndex(index) as! NSLayoutConstraint
                if conts.identifier == "senderLabelHeight" {
                    conts.constant = self.heightForView(lblMessage.text!, width: self.tblChat.frame.size.width - 140)
                }
            })
        }
        
        if let imgChatBackground = cell.viewWithTag(2001) as? UIImageView {
            let arrCon = imgChatBackground.constraints as NSArray
            arrCon.enumerateObjectsUsingBlock({ object, index, stop in
                let conts: NSLayoutConstraint = arrCon.objectAtIndex(index) as! NSLayoutConstraint
                if conts.identifier == "senderBackImgHeight" {
                    if let lblMessage = cell.viewWithTag(1004) as? UILabel {
                        conts.constant = self.heightForView(lblMessage.text!, width: self.tblChat.frame.size.width - 140) + 45
                    }
                    
                }
            })
        }
        
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
    }
    
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        let objChat:Chat = self.arrChatData.objectAtIndex(indexPath.row) as! Chat
        
        if (editingStyle == UITableViewCellEditingStyle.Delete) {
            if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                let dict:NSDictionary = [
                    "userId": userId,
                    "messageId": objChat.messageId
                ]
                print("\(dict)")
                self.fnDeleteMessageWebServiceWithPostDic(dict, showLoader: true)
            }
        }
    }
    
    //Calculate UILabel height
    func heightForView(text:String, width:CGFloat) -> CGFloat{
        let label:UILabel = UILabel(frame: CGRectMake(0, 0, width, CGFloat.max))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.ByWordWrapping
        label.font = UIFont(name: "Lato-Regular", size: 15)
        label.text = text
        label.sizeToFit()
        return label.frame.height
    }
    
    //MARK - Get Feed Cell Height
    func getRowHeightFeedCell(indexPath: NSIndexPath) -> CGFloat{
        let objChat:Chat = self.arrChatData.objectAtIndex(indexPath.row) as! Chat
        let lblHeight = self.heightForView(objChat.messageText, width: tblChat.frame.size.width - 140)
        return 60 + lblHeight
    }
    
    func messageComposerSendMessageClickedWithMessage(message: String) {
        if (Utility.checkNetwork() == true){
        if (message.characters.count < 200) {
            
            if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                self.pageChat = 1
                let dict:NSDictionary = [
                    "userId": userId,
                    "receiverId": self.receiverId,
                    "messageText": message
                ]
                print("\(dict)")
                self.fnSendMessageWebServiceWithPostDic(dict, showLoader: true)
            }
        }else{
            Utility.showAlert("", message: "You can enter maximum 200 characters.", delegate: nil)
        }
        }
    }
    func messageComposerFrameDidChange(frame: CGRect, withAnimationDuration duration: CGFloat, andCurve curve: Int) {

        
    }
    
    func messageComposerUserTyping(isTyping: Bool) {
        if isTyping {
            tblViewHeightConstrait.constant = 250
            tblChat.contentOffset = CGPointMake(0, tblChat.contentSize.height)
        }else{
            tblViewHeightConstrait.constant = 0
            tblChat.contentOffset = CGPointMake(0, tblChat.contentSize.height)
        }
        tblChat.reloadData()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
}
