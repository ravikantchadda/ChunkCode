//
//  ForgotPasswordViewController.swift
//  ReferenceApp
//
//  Created by Mohit Jain on 9/1/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit

class ForgotPasswordViewController: UIViewController,TextFieldWithImageDelegate {

    
    @IBOutlet weak var txtFieldEmail: TextFieldWithImage!
    @IBOutlet weak var btnOk: UIButton!
    
    var isVerifyAllValidation:Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //setup Intial
        setupUIElements()
        setupDelegate()
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - SetupUIElements
    func setupUIElements() {
        //set text for iboutlets
        btnOk.setTitle(NSLocalizedString("btnOkForgotPassword",comment:""), forState: UIControlState.Normal)
        btnOk.layer.borderColor = Constants.APP_THEME_COLOR.CGColor
        

        // SetUp Navigation Bar
        self.naviagtionSetup()
    }
    func naviagtionSetup() {
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.Cancel, target: self, action: "btnCancelTapped")
        self.navigationController?.navigationBar.tintColor = UIColor.whiteColor()
        self.navigationItem.title = NSLocalizedString("naviagtionBarTitleForgotPassword",comment:"")
    }
    
    func setupDelegate() {
        txtFieldEmail.delegate = self
    }
    override internal func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?)
    {
        self.view.endEditing(true)
    }
    
    // MARK: - @IBAction Methods
    @IBAction func btnOkTapped(sender: AnyObject) {
       
        if(checkEmailValidation(txtFieldEmail.txtField.text)) {
            
            let headerBody:String = Constants.kOuthHeader
            self.callToGetOuthTokenWebServiceWithHeaderBody(headerBody)
            
        }
    }
    
    func btnCancelTapped() {
        self.dismissViewControllerAnimated(true, completion: { () -> Void in
        })
    }
    
    //MARK: - Delegate Methods
    func textFieldWithImageDidEndEditing(textFieldWithImage: TextFieldWithImage) {
        if checkEmailValidation(txtFieldEmail.txtField.text) {
            isVerifyAllValidation = true
            btnOk.backgroundColor = Constants.APP_THEME_COLOR
            btnOk.setTitleColor( UIColor.whiteColor(),forState: UIControlState.Normal)
        } else {
            isVerifyAllValidation = false
            btnOk.backgroundColor = UIColor.clearColor()
            btnOk.setTitleColor(Constants.APP_THEME_COLOR,forState: UIControlState.Normal)
        }
    }
    
    func textFieldWithImageShouldReturn(textFieldWithImage: TextFieldWithImage) -> Bool {
        textFieldWithImage.txtField.resignFirstResponder()
        return true
    }

    //MARK: - Prepare For Segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!) {
        if (segue.identifier == "OTP") {
            let viewController:OTPViewController = segue.destinationViewController as! OTPViewController
            viewController.strEmailUser = txtFieldEmail.txtField.text
            
        }
    }
    

    // MARK: - Check Validation
    /**
    Check all validations
    1. Empty check for Email Field.
    2. Validate Email.
    - returns: bool value yes if all validations are fullfilled otherwise false.
    */
    
    func checkEmailValidation(email: String!) -> (Bool) {
        if (!NSIUtility.checkIfStringContainsText(email))
        {
            NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""), message: NSLocalizedString("EmptyString",comment: "comment"), view: self, delegate: nil)
            return false
        }
        if(!NSIUtility.validateEmail(email))
        {
            NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""), message: NSLocalizedString("InvalidEmail",comment: ""), view: self, delegate: nil)
            return false
        }
        return true
    }
    
    //MARK: - Method to Get OuthToken
    func callToGetOuthTokenWebServiceWithHeaderBody(headerBody:String){
        
        let outh = OuthDL()
        
        outh.requestforOuth(headerBody) { (obj, success) -> Void in
            if success == true{
                print(obj?.valueForKey(Constants.keyAccessToken) as! String)
                print(success as Bool!)
                let accessToken: String!
                let tokenType: String!
                accessToken = obj?.valueForKey(Constants.keyAccessToken) as! String
                tokenType = obj?.valueForKey(Constants.keyTokenType) as! String
                
                let outhToken: String!
                outhToken = tokenType + " " + accessToken
                NSIUtility.setValueToUserDefaultsForKey(Constants.keyOuthToken, value: outhToken)
                
                let email: NSString = "email"
                let dictParams:NSDictionary = NSDictionary(objects: [self.txtFieldEmail.txtField.text!], forKeys: [email])
                self.callToForgotPasswordWebServiceWithDict(dictParams)
                
            }else{
                
                NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""), message: Constants.kAlertServerError, view: self, delegate: nil)
            }
            
        }
        
        
        
    }

    
    
    
    //MARK: - Method call to change password
    func callToForgotPasswordWebServiceWithDict(params:NSDictionary){
        let user = UserDL()
        user.requestforUserForgotPassword(params, withCompletionHandler: { (obj, success) -> Void in
            
            if success == true{
                
                               
                    NSIUtility.DBlog(obj?.valueForKey(Constants.keyStatusCode) as! NSNumber)
                    NSIUtility.DBlog(success as Bool!)
                
                print(obj?.valueForKey(Constants.keyStatusCode) as! NSNumber)
                
                let statusCode = obj?.valueForKey(Constants.keyStatusCode) as! NSNumber
                if statusCode == 200{//****Status code 200 defined the success response
                    self.performSegueWithIdentifier("OTP", sender: self)
                    NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""),message:  obj?.valueForKey(Constants.keyResponse)!.valueForKey("message") as! String, view: self, delegate: nil)
                    
                    
                }
                
            }else{
                
                NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""), message: Constants.kAlertServerError, view: self, delegate: nil)
                
            }
            
        })
        
        
    }
    
   
    
    
}
