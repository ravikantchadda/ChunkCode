//
//  SelectPassengerCell.swift
//  LocalLift
//
//  Created by Sarishti on 11/26/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class SelectPassengerCell: UITableViewCell {

 
  
    @IBOutlet var lblNameOfPassenger: UILabel!
    @IBOutlet var lblEmailOfPassenger: UILabel!
    @IBOutlet var btnSelectedPassenger: UIButton!
    @IBOutlet var imgSelectPassengerCell: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.selectionStyle = .None
        
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
}
