//
//  UpdateProfileViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 13/11/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class UpdateProfileViewController: UIViewController {
    @IBOutlet weak var txtFirstname: UITextField!
    @IBOutlet weak var txtLastname: UITextField!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtAboutMe: UITextField!
    @IBOutlet weak var scrollVw_Container: UIScrollView!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationItem.titleView = Utility.navBarTitleLabel("Update Profile")
//        self.navigationItem.hidesBackButton = true
//        self.navigationItem.leftBarButtonItem = Utility.navBarLeftButton(UIImage(named: "btnBack")!, viewController: self)
        if (Utility.checkNetwork() == true){
            let dict:NSDictionary = [
                "profileId": NSIConstants.userDefaults.valueForKey("userId") as! String,
                "userId": NSIConstants.userDefaults.valueForKey("userId") as! String,
                "lessInfo": "YES"
            ]
            print("\(dict)")
            fnGetProfileWebServiceWithPostDic(dict, showLoader: true)
        }
    }
    
    // MARK: - Webservice Call Methods
    //Get Profile API
    func fnGetProfileWebServiceWithPostDic(dict: NSDictionary! , showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        //        ObjWebserviceCall.cachePolicy = WebserviceCallCachePolicyRequestFromCacheFirstAndThenFromUrlAndUpdateInCache
        if(showLoader){
            ObjWebserviceCall.isShowLoader = true
        }else{
            ObjWebserviceCall.isShowLoader = false
        }
        
        ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":NSIConstants.userDefaults.valueForKey("AUTHTOKEN") as! String]
        ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceGetProfile)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
            let response = response
            if(response.isResponseFromCache){
                
            }else{
                print("GetFeedResponse \(response.webserviceResponse)")
                if response.webserviceResponse != nil {
                    if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                        self.txtAboutMe.text = response.webserviceResponse.valueForKey("profileDetail")?.valueForKey("aboutMe") as? String
                        self.txtEmail.text = response.webserviceResponse.valueForKey("profileDetail")?.valueForKey("email") as? String
                        self.txtFirstname.text = response.webserviceResponse.valueForKey("profileDetail")?.valueForKey("firstName") as? String
                        self.txtLastname.text = response.webserviceResponse.valueForKey("profileDetail")?.valueForKey("lastName") as? String
                        self.txtPhone.text = response.webserviceResponse.valueForKey("profileDetail")?.valueForKey("phone") as? String
                    }
                }else{
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
            }
            }) { (error: NSError!) -> Void in
        }
    }
    
    // MARK: - NavigationBar LeftBarButton Method
    func fnLeftBarButton(){
        self.navigationController?.popViewControllerAnimated(true)
    }
    override func viewWillLayoutSubviews() {
        
        scrollVw_Container.contentSize = CGSizeMake(self.view.frame.size.width, 450)
    }
    
    @IBAction func btnPressed_Submit(sender: AnyObject) {
        if (Utility.checkNetwork() == true){
            let strError = fnCheckValidation()
            if strError == ""{
                if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                    let dict:NSDictionary = [
                        "userId": userId,
                        "firstName": txtFirstname.text!,
                        "lastName": txtLastname.text!,
                        "phone": txtPhone.text!,
                        "email": txtEmail.text!,
                        "aboutMe": txtAboutMe.text!
                    ]
                    print("\(dict)")
                    fnSaveSettingsWebServiceWithPostDic(dict)
                }
            }else{
                Utility.showAlert("", message: strError as String, delegate: nil)
            }
        }
    }
    
    
    // MARK: - Webservice Call Methods
    // UpdateProfile API
    func fnSaveSettingsWebServiceWithPostDic(dict: NSDictionary!) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            ObjWebserviceCall.isShowLoader = true
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceUpdateProfile)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("UpdateProfile--- \(response.webserviceResponse)")
                
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    
                    let alert = UIAlertController(title: "", message: response.webserviceResponse.valueForKey("status") as? String, preferredStyle: .Alert)
                    let action = UIAlertAction(title: "OK", style: .Default) { _ in
                        self.navigationController?.popViewControllerAnimated(true)
                    }
                    alert.addAction(action)
                    self.presentViewController(alert, animated: true, completion: nil)
                    
                    
                }else{
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
    func alertView(View: UIAlertView, clickedButtonAtIndex buttonIndex: Int){
        
        if (buttonIndex == 0){
            self.navigationController?.popViewControllerAnimated(true)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - UITextField Delegate Method
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        let nextTag:NSInteger = textField.tag + 1
        // Try to find next responder
        let nextResponder = textField.superview?.viewWithTag(nextTag)
        if (nextResponder != nil){
            nextResponder!.becomeFirstResponder()
        }else{
            textField.resignFirstResponder()
        }
        return true
    }
    
    @IBAction func textEnterBegin(sender: AnyObject) {
        if (sender.tag == 104){
            self.checkMaxLength(sender as! UITextField, maxLength: 60)
        }
    }
    
    func checkMaxLength(textField: UITextField!, maxLength: Int) {
        let str = textField.text
        let strCount = str!.characters.count
        if (strCount > maxLength) {
            textField.deleteBackward()
        }
    }
    
    // MARK: - Validations check
    func fnCheckValidation() -> NSString{
        var strError = String()
        
        if !Utility.checkIfStringContainsText(txtFirstname.text){
            strError = "Please enter First name."
        }else if !Utility.checkIfStringContainsText(txtLastname.text){
            strError = "Please enter Last name."
        }else if !Utility.checkIfStringContainsText(txtEmail.text){
            strError = "Please enter Email address."
        }
//        else if !Utility.checkIfStringContainsText(txtPhone.text){
//            strError = "Please enter Confirm Password."
//        }else if !Utility.checkIfStringContainsText(txtAboutMe.text){
//            strError = "Please enter Confirm Password."
//        }
        
        return strError
    }

    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
