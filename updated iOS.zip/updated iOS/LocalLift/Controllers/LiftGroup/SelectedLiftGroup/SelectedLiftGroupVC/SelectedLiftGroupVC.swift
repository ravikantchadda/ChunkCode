//
//  SelectedLiftGroupVC.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/22/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class SelectedLiftGroupVC: BaseViewController,SelectPassValueProtocol {

    @IBOutlet weak var heightConstraint_thumbnail: NSLayoutConstraint!
    @IBOutlet weak var viewThumbnail: ThumbnailView!
    @IBOutlet weak var viewLiftGroupUsersCollection: LiftGroupPeopleCollectionView!
    @IBOutlet weak var viewInviteMessage: NoGroupType!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setNavigationLeftBarButton()
        self.intialization()
        
    }

    override func viewWillAppear(animated: Bool) {
        reloadView()
    }
    
    //MARK: - Set Bar button in navigation
    func setNavigationLeftBarButton() {
        let btnBack = UIBarButtonItem(title: "Back", style: .Plain, target: nil, action: nil)
        self.navigationItem.backBarButtonItem = btnBack;
        self.navigationItem.title = "Roadtrip Buddies"
        let btnLater = UIBarButtonItem(title: "Edit", style: .Plain, target: self, action: "EditPressed:")
        navigationItem.setRightBarButtonItem(btnLater, animated: true)
    }
    
    // Edit button in Right of navigation pressed
    func EditPressed(sender: UIButton) {
        
    }
    
    //MARK:- intial function
    func intialization() {
        viewThumbnail.lblTitle.hidden = true
        viewLiftGroupUsersCollection.Intilization()
        viewLiftGroupUsersCollection.delegate = self
        viewInviteMessage.lblMessage.text = "Invite friends and family to be part of your Lift Group.\nClick the + sign to begin."
        viewInviteMessage.btnContinue.setTitle("You have invited members to join \"Roadtrip Buddies\"", forState: UIControlState.Normal)
        
    }
    
    func reloadView() {
     
        if(viewLiftGroupUsersCollection.arrayUserOfLiftgroup.count > 0) {
            viewLiftGroupUsersCollection.collectionViewSelectLiftGroup.reloadData()
            viewInviteMessage.btnContinue.hidden = false
            
        } else  {
            viewInviteMessage.btnContinue.hidden = false
        }
    }
    
    func selectCell(value:String) {
        let invitationType = NSIUtility.fetchViewControllerWithName("AddUserInGroup", storyBoardName: "Main") as! AddUserInGroup
            invitationType.invitationType = .FromContact
            self.navigationController?.pushViewController(invitationType, animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
