//
//  TextFieldWithImage.swift
//  ReferenceApp
//
//  Created by Mohit Jain on 9/15/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit

@objc protocol TextFieldWithImageDelegate {
    optional func btnActionForRightButton(sender:AnyObject)
    optional func textFieldWithImageDidBeginEditing(textFieldWithImage: TextFieldWithImage)
    optional func textFieldWithImageDidEndEditing(textFieldWithImage: TextFieldWithImage)
    optional func textFieldWithImageShouldReturn(textFieldWithImage: TextFieldWithImage) -> Bool
}
class TextFieldWithImage: UIView,UITextFieldDelegate {
    
    //MARK: TextField Properties
    @IBOutlet weak var txtField: UITextField!
    @IBInspectable var placeholderLocalizeText: String = ""
    var txtFieldKeyboardType:UIKeyboardType! = UIKeyboardType.Default
    @IBInspectable var isRightButtonEnable: Bool = false
    @IBInspectable var txtFieldTag: Int = 0

    //MARK: Button Properties
    @IBInspectable var isSecureTextEntry: Bool = false
    @IBOutlet weak var btnRight: UIButton!
    @IBOutlet weak var constraintWidthRightButton: NSLayoutConstraint!
    @IBInspectable var btnTitleLocalizeText: String = ""
    
    //MARK: ImgView Properties
    @IBOutlet weak var imgViewPlaceHolder: UIImageView!
    @IBInspectable var imageName: String = ""
    
    //MARK: - protocol Properties
    var delegate:TextFieldWithImageDelegate!
    
    
    //MARK: - View Init Methods
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        setupView()
    }
    
    func setupView() {
        let arrNib:NSArray! = NSBundle.mainBundle().loadNibNamed("TextFieldWithImage", owner: self, options: nil)
        let viewTextField:UIView = arrNib!.lastObject! as! UIView
        viewTextField.frame = self.bounds
        addSubview(viewTextField)
        updateField()
    }
    
    //MARK: Update Data from selected by storyboards.
    func updateField() {
        
        //MARK: Set TextField Properties
        txtField.placeholder = NSLocalizedString(placeholderLocalizeText,comment:"")
        txtField.secureTextEntry = isSecureTextEntry
        txtField.tag = txtFieldTag
        
        //MARK: Set Button Properties
        btnRight.setTitle(NSLocalizedString(btnTitleLocalizeText,comment:""), forState: .Normal)
        constraintWidthRightButton.constant = isRightButtonEnable ? 50 : 0
        
    }
    
    //MARK: - @IBAction Methods
    @IBAction func btnRightButtonTapped(sender: AnyObject) {
        delegate?.btnActionForRightButton?(sender)
    }
    
    //MARK: - UITextFieldDelegate Methods
    func textFieldDidBeginEditing(textField: UITextField) {    //delegate method
        delegate?.textFieldWithImageDidBeginEditing?(self)
    }
    
    func textFieldDidEndEditing(textField: UITextField) {  //delegate method
        delegate?.textFieldWithImageDidEndEditing?(self)
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        var isShouldReturn:Bool = true
        if let value = delegate?.textFieldWithImageShouldReturn?(self) {
            isShouldReturn = value
        }
        return isShouldReturn
    }
}
