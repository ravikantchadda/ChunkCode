//
//  MyLiftGroupDL.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/22/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import Foundation

class MyLiftGroupBO: NSObject {
    
    var groupTypeName: String!
}
