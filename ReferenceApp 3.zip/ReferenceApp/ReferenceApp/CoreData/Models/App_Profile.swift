//
//  App_Profile.swift
//  ReferenceApp
//
//  Created by Mohit Jain on 10/13/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import Foundation
import CoreData

@objc(App_Profile)
class App_Profile: NSManagedObject {
    @NSManaged var change_date: NSDate?
    @NSManaged var company: String?
    @NSManaged var create_date: NSDate?
    @NSManaged var date_of_birth: NSDate?
    @NSManaged var date_of_birth_type: NSNumber?
    @NSManaged var department: String?
    @NSManaged var designation: String?
    @NSManaged var first_name: String?
    @NSManaged var id: NSNumber?
    @NSManaged var is_active: NSNumber?
    @NSManaged var last_name: String?
    @NSManaged var user: App_User?
}
