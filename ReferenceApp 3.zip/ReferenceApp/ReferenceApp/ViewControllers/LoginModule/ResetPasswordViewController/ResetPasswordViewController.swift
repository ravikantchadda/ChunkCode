//
//  ResetPasswordViewController.swift
//  ReferenceApp
//
//  Created by Mohit Jain on 9/1/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit

class ResetPasswordViewController: UIViewController {
    
    var strEmailUser:String!
    var strOtpUser:String!

    @IBOutlet weak var txtFieldNewPassword: UITextField!
    @IBOutlet weak var lblNewPassword: UILabel!
    @IBOutlet weak var btnOk: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        //SetupUIElements
        setupUIElements()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - SetupUIElements
    
    func setupUIElements() {
        //set text for @IBOutlet
        lblNewPassword.text = NSLocalizedString("lblPasswordResetPassword",comment:"")
        btnOk.setTitle(NSLocalizedString("btnOkResetPassword",comment:""), forState: UIControlState.Normal)
        self.navigationItem.title = NSLocalizedString("naviagtionBarTitleResetPassword",comment:"")
    }
    
    // MARK: - @IBAction Methods
    @IBAction func btnOkTapped(sender: AnyObject) {
        if(checkEmptyPassword(txtFieldNewPassword.text)) {
            let dict:Dictionary = [
                "email": strEmailUser,
                "otp": strOtpUser,
                "password": txtFieldNewPassword.text,
                "device_id": NSIUtility.getUniqueIdentifier()
            ]
        self.requestforUserResetPassword(dict)
        }
    }
    
    
    //MARK: - Method To Reset Password
    func requestforUserResetPassword(params:NSDictionary){
        let user = UserDL()
        user.requestforUserResetPassword(params, withCompletionHandler: { (obj, success) -> Void in
            
            if success == true{
                
                
                NSIUtility.DBlog(obj?.valueForKey(Constants.keyStatusCode) as! NSNumber)
                NSIUtility.DBlog(success as Bool!)
                
                print(obj?.valueForKey(Constants.keyStatusCode) as! NSNumber)
                
                let statusCode = obj?.valueForKey(Constants.keyStatusCode) as! NSNumber
                if statusCode == 200{//****Status code 200 defined the success response
                    
//                   let delegate =  UIApplication.sharedApplication().delegate as! AppDelegate
//                    delegate.showLoginStoryboard()
                    
 //                   self.navigationController?.popToRootViewControllerAnimated(true)

                    NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""),message:"Your password reset successfully.", view: self, delegate: nil)
                    //  ResetPassword
                    
                }
                
            }else{
                
                NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""), message: Constants.kAlertServerError, view: self, delegate: nil)
                
            }
            
        })
        
        
    }
    
    
    // MARK: - Helper Methods
    // MARK: - Check Validation
    /**
    Check validation
    1. Empty check for Password Field.
    - returns: bool value yes if all validations are fullfilled otherwise false.
    */
    func checkEmptyPassword(password: String!) -> (Bool) {
        if (!NSIUtility.checkIfStringContainsText(password))
        {
           
            NSIUtility.showAlert(NSLocalizedString("AlertTitle",comment:""),message:  NSLocalizedString("EmptyString",comment: ""), view: self, delegate: nil)
            return false
        }
        return true
    }
    
}


