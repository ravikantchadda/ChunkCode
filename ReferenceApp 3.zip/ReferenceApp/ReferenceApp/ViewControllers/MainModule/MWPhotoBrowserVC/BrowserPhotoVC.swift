//
//  BrowserPhotoVC.swift
//  ReferenceApp
//
//  Created by ravi kant on 12/2/15.
//  Copyright © 2015 Netsol. All rights reserved.
//

import UIKit
import Photos
import AssetsLibrary
import MWPhotoBrowser


class BrowserPhotoVC: UIViewController,MWPhotoBrowserDelegate,UITableViewDataSource,UITableViewDelegate {
    
    
    
    var segmentedControl = UISegmentedControl()
    var selections = NSMutableArray()
    var photos = NSMutableArray()
    var thumbs = NSMutableArray()
    var assets = NSMutableArray()
    var library = ALAssetsLibrary()
    @IBOutlet var tblViewBrowser: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "PhotoBrowser"
        
        let array  = ["Push", "Modal"]
        
        self.segmentedControl = UISegmentedControl(items: array)
        self.segmentedControl.selectedSegmentIndex = 0
        segmentedControl.addTarget(self, action: "segmentChange", forControlEvents: .ValueChanged)
        
        let item: UIBarButtonItem = UIBarButtonItem(customView: segmentedControl)
        self.navigationItem.rightBarButtonItem = item
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "Back", style: .Bordered, target: nil, action: nil)
        self.loadAssets()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func segmentChange(){
        self.tblViewBrowser.reloadData()
    }
    
    // MARK: - Load Assets
    func loadAssets(){
        if (NSClassFromString("PHAsset") != nil) {
            // Check library permissions
            let status: PHAuthorizationStatus = PHPhotoLibrary.authorizationStatus()
            if status == .NotDetermined {
                PHPhotoLibrary.requestAuthorization({(status: PHAuthorizationStatus) -> Void in
                    if status == .Authorized {
                        self.performLoadAssets()
                    }
                })
            }
            else {
                if status == .Authorized {
                    self.performLoadAssets()
                }
            }
            
        }
        else {
            
        }
        
        
    }
  
    
    
    func performLoadAssets()   {
        
        if (NSClassFromString("PHAsset") != nil) {
            
            // Photos library iOS >= 8
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), {() -> Void in
                let options: PHFetchOptions = PHFetchOptions()
                let descriptor: NSSortDescriptor = NSSortDescriptor(key: "creationDate", ascending: true)
                options.sortDescriptors  = [descriptor]
                
                let fetchResults: PHFetchResult = PHAsset.fetchAssetsWithOptions(options)
                
              //  let isDir = ObjCBool(false)
                fetchResults.enumerateObjectsUsingBlock({ (obj:AnyObject, idx:Int, isDir) -> Void in
                    self.assets.addObject(obj)
                })
                
                if fetchResults.count > 0 {
                    self.tblViewBrowser.performSelectorOnMainThread("reloadData", withObject: nil, waitUntilDone: false)
                }
            })
            
        }
        else {
            
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), {() -> Void in
            
            
            let assetGroups  = NSMutableArray()
            let assetURLDictionaries = NSMutableArray()
            self.library.enumerateGroupsWithTypes(ALAssetsGroupSavedPhotos, usingBlock: { (group, stop) -> Void in
                group?.setAssetsFilter(ALAssetsFilter.allPhotos())
                group?.enumerateAssetsWithOptions(NSEnumerationOptions.Reverse, usingBlock: {
                    (asset : ALAsset!, index, stopEnumeration) -> Void in
                    
                    let assetType:NSString = (asset?.valueForProperty(ALAssetPropertyType))! as! NSString
                    
                    assetGroups.addObject(group)
                    
                    if assetType.isEqualToString(ALAssetTypePhoto) || assetType.isEqualToString(ALAssetTypeVideo){
                        assetURLDictionaries.addObject((asset?.valueForProperty(ALAssetPropertyURLs))!)
                        
                        let url: NSURL = (asset?.defaultRepresentation().url())!
                        
                        self.library.assetForURL(url, resultBlock: { (asset:ALAsset!) -> Void in
                            
                            if asset != nil{
                                
                                self.assets.addObject(asset)
                                if self.assets.count == 1 {
                                    // Added first asset so reload data
                                    self.tblViewBrowser.performSelectorOnMainThread("reloadData", withObject: nil, waitUntilDone: false)
                                }
                            }
                            
                            }, failureBlock: { (error:NSError!) -> Void in
                                
                                print("operation was not successfull!");
                                
                        })
                        
                        
                        
                        
                    }
                    
                    
                    
                    
                    //                        // For just the thumbnails use the following line.
                    //                        let cgImage = asset.thumbnail().takeUnretainedValue()
                    //                        let imgURL = asset.defaultRepresentation().url()
                    //                        if let image: UIImage = UIImage(CGImage: cgImage ) {
                    //                            assetGroups.addObject(image)
                    //                            assetURLDictionaries.addObject(imgURL)
                    //                        }
                    
                    
                })
                },failureBlock : { error in
                    print(error)
            })
            
            
        })
        
        }
       
    }


/*
// MARK: - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
// Get the new view controller using segue.destinationViewController.
// Pass the selected object to the new view controller.
}
*/

// MARK: - MWPhotoBrowserDelegate


    func numberOfPhotosInPhotoBrowser(photoBrowser: MWPhotoBrowser!) -> UInt {
        return UInt(self.photos.count)
    }
    
    func photoBrowser(photoBrowser: MWPhotoBrowser!, photoAtIndex index: UInt) -> MWPhotoProtocol! {
        if Int(index) < self.photos.count {
            return photos.objectAtIndex(Int(index)) as! MWPhoto
        }
        return nil
    }
    
    func photoBrowserDidFinishModalPresentation(photoBrowser:MWPhotoBrowser) {
        self.dismissViewControllerAnimated(true, completion:nil)
    }
    func photoBrowser(photoBrowser: MWPhotoBrowser!, thumbPhotoAtIndex index: UInt) -> MWPhotoProtocol! {
        
        if Int(index) < self.thumbs.count {
            return thumbs.objectAtIndex(Int(index)) as! MWPhoto
        }
        return nil
        
    }
    
    func photoBrowser(photoBrowser: MWPhotoBrowser!, didDisplayPhotoAtIndex index: UInt) {
        print("Did start viewing photo at index \(index)" );
    }
    func photoBrowser(photoBrowser: MWPhotoBrowser!, isPhotoSelectedAtIndex index: UInt) -> Bool {
        
        let newRandom: Int = Int(index)
        return self.selections.objectAtIndex(newRandom).boolValue
        
    }
    func photoBrowser(photoBrowser: MWPhotoBrowser!, photoAtIndex index: UInt, selectedChanged selected: Bool) {
        let newRandom: Int = Int(index)
        self.selections.replaceObjectAtIndex(newRandom, withObject: NSNumber(bool: selected))
        print("Did start viewing photo at index \(index) selected \(selected)" );
        
    }
    
    
//    func photoBrowser(photoBrowser: MWPhotoBrowser!, titleForPhotoAtIndex index: UInt) -> String! {
//        
//    }
//    func photoBrowser(photoBrowser: MWPhotoBrowser!, actionButtonPressedForPhotoAtIndex index: UInt) {
//        
//    }
//    func photoBrowser(photoBrowser: MWPhotoBrowser!, captionViewForPhotoAtIndex index: UInt) -> MWCaptionView! {
//        
//    }
    
    
    
    
    // MARK: - UITabelView DataSource/Delegate Methods
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var rows: Int = 9
        if assets.count>0 {
            rows++
        }
        
        return rows
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        // Create
        let CellIdentifier: String = "cell"
        var cell: UITableViewCell = tableView.dequeueReusableCellWithIdentifier(CellIdentifier)!
            cell = UITableViewCell(style: .Subtitle, reuseIdentifier: CellIdentifier)
        cell.accessoryType = segmentedControl.selectedSegmentIndex == 0 ? .DisclosureIndicator : .None
        
        
        
        
        switch(indexPath.row){
            
        case 0:
            cell.textLabel?.text = "Single photo"
            cell.detailTextLabel?.text = "with caption, no grid button"
        case 1:
            cell.textLabel?.text = "Multiple photos and video"
            cell.detailTextLabel?.text = "with captions"
        case 2:
            cell.textLabel?.text = "Multiple photo grid"
            cell.detailTextLabel?.text = "showing grid first, nav arrows enabled"
        case 3:
            cell.textLabel?.text = "Photo selections"
            cell.detailTextLabel?.text = "selection enabled"
        case 4:
            cell.textLabel?.text = "Photo selection grid"
            cell.detailTextLabel?.text = "selection enabled, start at grid"
        case 5:
            cell.textLabel?.text = "Web photos"
            cell.detailTextLabel?.text = "photos from web"
        case 6:
            cell.textLabel?.text = "Web photo grid"
            cell.detailTextLabel?.text = "showing grid first"
        case 7:
            cell.textLabel?.text = "Single video"
            cell.detailTextLabel?.text = "with auto-play"
        case 8:
            cell.textLabel?.text = "Web videos"
            cell.detailTextLabel?.text = "showing grid first"
        case 9:
            cell.textLabel?.text = "Library photos and videos"
            cell.detailTextLabel?.text = "media from device library"
        default:
            break
        
        
        }
        
        
        return cell
    }
    
    func tableView(tableView: UITableView, didDeselectRowAtIndexPath indexPath: NSIndexPath) {
        // Browser
        let photos = NSMutableArray()
        let thumbs = NSMutableArray()
        
        var photo = MWPhoto()
        var thumb = MWPhoto()
        
       
        
        var displayActionButton: Bool = true
        var displaySelectionButtons: Bool = false
        var displayNavArrows: Bool = false
        var enableGrid: Bool = true
        var startOnGrid: Bool = false
        var autoPlayOnAppear: Bool = false
        
        switch(indexPath.row){
            
        case 0:
           // Photos
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo2", ofType: "jpg")!))
            photo.caption = "The London Eye is a giant Ferris wheel situated on the banks of the River Thames, in London, England."
            photos.addObject(photo)
            
            // Options
            startOnGrid = false
            
            break
        case 1:
            // Photos
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo5", ofType: "jpg")!))
            photo.caption = "Fireworks"
            photos.addObject(photo)
            
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo2", ofType: "jpg")!))
            photo.caption = "The London Eye is a giant Ferris wheel situated on the banks of the River Thames, in London, England."
            photos.addObject(photo)
            
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo3", ofType: "jpg")!))
            photo.caption = "York Floods"
            photos.addObject(photo)
            
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("video_thumb", ofType: "jpg")!))
            photo.caption = "Big Buck Bunny"
            photo.videoURL = NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("video", ofType: "mp4")!)
            photos.addObject(photo)
            
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo4", ofType: "jpg")!))
            photo.caption = "Campervan"
            photos.addObject(photo)

            // Options
            startOnGrid = false
            break
            
        case 2:
            // Photos
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo5", ofType: "jpg")!))
            photo.caption = "White Tower"
            photos.addObject(photo)
            
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo2", ofType: "jpg")!))
            photo.caption = "The London Eye is a giant Ferris wheel situated on the banks of the River Thames, in London, England."
            photos.addObject(photo)
            
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo3", ofType: "jpg")!))
            photo.caption = "York Floods"
            photos.addObject(photo)
            
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo4", ofType: "jpg")!))
            photo.caption = "Campervan"
            photos.addObject(photo)
            
            // Thumbs
            
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo5t", ofType: "jpg")!))
            thumbs.addObject(photo)
            
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo2t", ofType: "jpg")!))
            thumbs.addObject(photo)
            
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo3t", ofType: "jpg")!))
            thumbs.addObject(photo)
            
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo4t", ofType: "jpg")!))
            thumbs.addObject(photo)
            // Options
            startOnGrid = true
            displayNavArrows = true
            
        case 3:
            break
        case 4:
            // Photos
            
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo4", ofType: "jpg")!))
            photos.addObject(photo)
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo1", ofType: "jpg")!))
            photos.addObject(photo)
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo2", ofType: "jpg")!))
            photos.addObject(photo)
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo3", ofType: "jpg")!))
            photos.addObject(photo)
            
            
            
            // Thumbs
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo4t", ofType: "jpg")!))
            thumbs.addObject(photo)
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo1t", ofType: "jpg")!))
            thumbs.addObject(photo)
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo2t", ofType: "jpg")!))
            thumbs.addObject(photo)
            
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("photo3t", ofType: "jpg")!))
            thumbs.addObject(photo)
            // Options
            displayActionButton = false
            displaySelectionButtons = true
            startOnGrid = indexPath.row == 4
            enableGrid = false
            break
        case 5:
             // Photos
            photos.addObject(MWPhoto(URL: NSURL(string: "http://farm4.static.flickr.com/3567/3523321514_371d9ac42f_b.jpg")))
            photos.addObject(MWPhoto(URL: NSURL(string: "http://farm4.static.flickr.com/3629/3339128908_7aecabc34b_b.jpg")))
            photos.addObject(MWPhoto(URL: NSURL(string: "http://farm4.static.flickr.com/3364/3338617424_7ff836d55f_b.jpg")))
            photos.addObject(MWPhoto(URL: NSURL(string: "http://farm4.static.flickr.com/3590/3329114220_5fbc5bc92b_b.jpg")))
            // Thumbs
            thumbs.addObject(MWPhoto(URL: NSURL(string: "http://farm4.static.flickr.com/3567/3523321514_371d9ac42f_q.jpg")))
            thumbs.addObject(MWPhoto(URL: NSURL(string: "http://farm4.static.flickr.com/3629/3339128908_7aecabc34b_q.jpg")))
            thumbs.addObject(MWPhoto(URL: NSURL(string: "http://farm4.static.flickr.com/3364/3338617424_7ff836d55f_q.jpg")))
            thumbs.addObject(MWPhoto(URL: NSURL(string: "http://farm4.static.flickr.com/3590/3329114220_5fbc5bc92b_q.jpg")))
            
            break
            
        case 6:
            // Photos & thumbs
            
            photo = MWPhoto(URL: NSURL(string: "http://farm4.static.flickr.com/3779/9522424255_28a5a9d99c_b.jpg"))
            photo.caption = "Tube"
            photos.addObject(photo)
            
            thumbs.addObject(MWPhoto(URL: NSURL(string: "http://farm4.static.flickr.com/3779/9522424255_28a5a9d99c_q.jpg")))
            
            photo = MWPhoto(URL: NSURL(string: "http://farm4.static.flickr.com/3777/9522276829_fdea08ffe2_b.jpg"))
            photo.caption = "Flat White at Elliot's"
            photos.addObject(photo)
            
            thumbs.addObject(MWPhoto(URL: NSURL(string: "http://farm4.static.flickr.com/3777/9522276829_fdea08ffe2_q.jpg")))
            
            
            photo = MWPhoto(URL: NSURL(string: "http://farm8.static.flickr.com/7109/7604416018_f23733881b_b.jpg"))
            photo.caption = "Jury's Inn"
            photos.addObject(photo)
            
            thumbs.addObject(MWPhoto(URL: NSURL(string: "http://farm8.static.flickr.com/7109/7604416018_f23733881b_q.jpg")))
            
            photo = MWPhoto(URL: NSURL(string: "http://farm7.static.flickr.com/6002/6020924733_b21874f14c_b.jpg"))
            photo.caption = "Heavy Rain"
            photos.addObject(photo)
            
            thumbs.addObject(MWPhoto(URL: NSURL(string: "http://farm7.static.flickr.com/6002/6020924733_b21874f14c_q.jpg")))
            break
        case 7:
           // Single video
            photo = MWPhoto(URL: NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("video_thumb", ofType: "jpg")!))
            photo.videoURL = NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("video", ofType: "mp4")!)
            photos.addObject(photo)
            enableGrid = false
            autoPlayOnAppear = true
            break
        case 8:
            
            photo = MWPhoto(URL: NSURL(string: "https://scontent.cdninstagram.com/hphotos-xpt1/t51.2885-15/e15/11192696_824079697688618_1761661_n.jpg"))
            photo.videoURL = NSURL(string: "https://scontent.cdninstagram.com/hphotos-xpa1/t50.2886-16/11200303_1440130956287424_1714699187_n.mp4")
            photos.addObject(photo)
            
            
             thumb = MWPhoto(URL: NSURL(string: "https://scontent.cdninstagram.com/hphotos-xpt1/t51.2885-15/s150x150/e15/11192696_824079697688618_1761661_n.jpg"))
            thumb.isVideo = true
            thumbs.addObject(photo)
            
            break
            
        case 9:
            let copyData = assets
            if (NSClassFromString("PHAsset") != nil) {
                // Photos library
                let screen: UIScreen = UIScreen.mainScreen()
                let scale: CGFloat = screen.scale
                // Sizing is very rough... more thought required in a real implementation
                let imageSize: CGFloat = max(screen.bounds.size.width, screen.bounds.size.height) * 1.5
                let imageTargetSize: CGSize = CGSizeMake(imageSize * scale, imageSize * scale)
                let thumbTargetSize: CGSize = CGSizeMake(imageSize / 3.0 * scale, imageSize / 3.0 * scale)
                
                //let asset: PHAsset
                for  asset in copyData {
                    
                    photos.addObject(MWPhoto(asset: asset as! PHAsset, targetSize: imageTargetSize))
                    thumbs.addObject(MWPhoto(asset: asset as! PHAsset, targetSize: thumbTargetSize))
                    
                    
                }
            }else{
                //let assset: ALAsset

                // Assets library
                for assset in copyData {
                    
                     let photo = MWPhoto(URL: assset.defaultRepresentation().url())
                    photos.addObject(photo)
                    let thumb = MWPhoto(image:UIImage(CGImage: assset.thumbnails as! CGImageRef))
                    thumbs.addObject(thumb)
                    if assset.valueForProperty(ALAssetPropertyType).isEqualToString(ALAssetTypeVideo)  {
                        photo.videoURL = assset.defaultRepresentation().url()
                        thumb.isVideo = true
                    }
                }

            
            }
            
            break
        default:
            break
            
        
        }
        
        self.photos = photos;
        self.thumbs = thumbs;
        // Create browser
        let browser = MWPhotoBrowser()
        browser.displayActionButton = displayActionButton;
        browser.displayNavArrows = displayNavArrows;
        browser.displaySelectionButtons = displaySelectionButtons;
        browser.alwaysShowControls = displaySelectionButtons;
        browser.zoomPhotosToFill = true;
        browser.enableGrid = enableGrid;
        browser.startOnGrid = startOnGrid;
        browser.enableSwipeToDismiss = false;
        browser.autoPlayOnAppear = autoPlayOnAppear;
        browser.delegate = self
        browser.setCurrentPhotoIndex(0)
        
        // Test custom selection images
        //    browser.customImageSelectedIconName = @"ImageSelected.png";
        //    browser.customImageSelectedSmallIconName = @"ImageSelectedSmall.png";
        
        // Reset selections
        if displaySelectionButtons {
            self.selections = NSMutableArray()
            for var i = 0; i < photos.count; i++ {
                selections.addObject(NSNumber(bool: false))
            }
        }
        
        // Show
        if segmentedControl.selectedSegmentIndex == 0 {
            // Push
            self.navigationController!.pushViewController(browser, animated: true)
        }
        else {
            // Modal
            var nc: UINavigationController = UINavigationController(rootViewController: browser)
            nc.modalTransitionStyle = .CrossDissolve
            self.presentViewController(nc, animated: true, completion: nil)
        }
        
        // Release
        // Deselect
        self.tblViewBrowser.deselectRowAtIndexPath(indexPath, animated: true)



        
    }
    
    
    
}