//
//  groupTypeSubCatVC.swift
//  LocalLift
//
//  Created by Rajesh Kapur on 12/22/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

protocol UpdateCategoryListProtocol
{
    func updateListOnSelect()
}

class groupTypeSubCatVC: BaseViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var tableOfGroupSubCategories: UITableView!
    var arrayOfGroupType = NSMutableArray()
    @IBOutlet weak var noGroupTypeView:NoGroupType!
    var lastSelectedGroup:NSIndexPath?
    var delegate:UpdateCategoryListProtocol?
    var liftGroupVC:CreateLiftGroupVC?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setNavigationBar(NavigationType.BlueNavigationType)
        self.setNavigationLeftBarButton()
        self.initialInitialization()
    }
    
    //MARK: -Initialization mthod to load view properly
    func initialInitialization()  {
        liftGroupVC = self.fetchPreviousControllerFromNavigationStack(2) as? CreateLiftGroupVC
        
        tableOfGroupSubCategories.registerNib(UINib(nibName: "GroupTypeCell", bundle: nil) , forCellReuseIdentifier: "GroupType")
        
        //add uiview to show no Group
        noGroupTypeView.frame =  CGRectMake(0, 0, self.view.size.width, self.view.size.height-64)
        noGroupTypeView.hidden=true
        noGroupTypeView.btnContinue.hidden = true
        tableOfGroupSubCategories.insertSubview(noGroupTypeView, aboveSubview: tableOfGroupSubCategories)
        
        tableOfGroupSubCategories.tableFooterView = UIView()
        
        self.arrayOfGroupType = NSMutableArray()
        self.tableOfGroupSubCategories.delegate = self
        self.tableOfGroupSubCategories.dataSource = self
        self.fetchGroupTypeFromServices()
    }
    
    
    //MARK: - Set navigation bar button
    func setNavigationLeftBarButton() {
        self.navigationItem.title = "Select Lift Group Type"
    }
    
    
    
    //MARK: - Fetch lifts from service
    func fetchGroupTypeFromServices()  {
        let groupDL = GroupTypeDL()
        groupDL.requestForSubCategoriesGroupType(liftGroupVC?.liftGroupBO.groupType ?? "", withCompletionHandler: { (obj, success) -> Void in
            if success == true {
                self.arrayOfGroupType.addObjectsFromArray(obj as! NSArray as [AnyObject])
                self.tableOfGroupSubCategories.reloadData()
            }
        })
        
    }
    
    //MARK: - Table VIew Delegates
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 75;
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if(self.arrayOfGroupType.count <= 0) {
            noGroupTypeView?.hidden=false
            return 0
        }
        else  {
            noGroupTypeView?.hidden=true
            return self.arrayOfGroupType.count
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell:GroupTypeCell = (tableView.dequeueReusableCellWithIdentifier("GroupType", forIndexPath: indexPath) as? GroupTypeCell)!
        cell.selectionStyle = .None
        
        let groupBO:GroupTypeBO
        groupBO = self.arrayOfGroupType[indexPath.row] as! GroupTypeBO
        cell.lblGroupTypeName.text = groupBO.groupTypeName
        
        if (!(groupBO.isGroupTypeSelected)){
            cell.btnSelectGroupType.setImage(UIImage(named: "blue_unchecked"), forState: UIControlState.Normal)
        }
        else {
            cell.btnSelectGroupType.setImage(UIImage(named: "blue_checked"), forState: UIControlState.Normal)
             liftGroupVC?.liftGroupBO.groupType = groupBO.groupTypeName
             lastSelectedGroup = indexPath
            
            
        }
        
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let groupBO:GroupTypeBO
        groupBO = self.arrayOfGroupType[indexPath.row] as! GroupTypeBO
        
        if let lastSelectedIndexPath = lastSelectedGroup {
                let lastSeletedGroupBO:GroupTypeBO
                lastSeletedGroupBO = self.arrayOfGroupType[(lastSelectedGroup?.row)!] as! GroupTypeBO
                lastSeletedGroupBO.isGroupTypeSelected = !(lastSeletedGroupBO.isGroupTypeSelected)
                self.arrayOfGroupType[(lastSelectedGroup?.row)!]  = lastSeletedGroupBO
                
                if indexPath.row != lastSelectedGroup?.row {
                    tableView.reloadRowsAtIndexPaths([lastSelectedIndexPath], withRowAnimation: UITableViewRowAnimation.None)
                }
            }
        
            groupBO.isGroupTypeSelected = !(groupBO.isGroupTypeSelected)
            self.arrayOfGroupType[indexPath.row]  = groupBO
            tableView.reloadRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.None)
        
        if(delegate != nil) {
            delegate?.updateListOnSelect()
        }
        
    }
    
    
    //MARK: - deinit methof to free allocate resources
    deinit {
        self.tableOfGroupSubCategories = nil;
        self.noGroupTypeView = nil;
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
