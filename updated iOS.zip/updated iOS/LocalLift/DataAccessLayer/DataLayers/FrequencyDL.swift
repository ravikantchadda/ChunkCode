//
//  FrequencyDL.swift
//  LocalLift
//
//  Created by prabhjot singh on 12/1/15.
//  Copyright © 2015 prabhjot singh. All rights reserved.
//

import UIKit

class FrequencyBO: NSObject {
    
    var frequencyName:String!
    var frequencyID:NSNumber!
}

class FrequencyDL: PSRestAPIHelper {

    func requestforFrequency(handler:CompletionHandler)
    {
        self.serviceURL = "LiftFrequency"
        self.webservice.isShowLoader = true
        self.setContentTypeHeaders()
        
        let dicParam:NSDictionary = ["":""]
        
        self.requestforGET(dicParam as! [NSObject : AnyObject!]) { (obj, success) -> Void in
            
            if success == true
            {
                let arrayOfFrequency:NSMutableArray = NSMutableArray()
                
                if let arrayOfParams:NSArray = obj!.valueForKey("Data") as? NSArray
                {
                    for item in arrayOfParams {
                        let dicBlock = item as! NSDictionary
                        let frequency = FrequencyBO()
                        frequency.frequencyID = NSIUtility.getObjectForKey("ID", dictResponse: dicBlock) as! NSNumber
                        frequency.frequencyName = NSIUtility.getObjectForKey("Name", dictResponse: dicBlock) as! String
                        arrayOfFrequency.addObject(frequency)
                    }
                    
                    handler(obj: arrayOfFrequency, success: true)
                    return
                }
                
                handler(obj: nil, success: false)
                print("Data is nil")
            }
        }
    }
    
}


