#import "HFImageEditorViewController.h"

@interface DemoImageEditor : HFImageEditorViewController

@property(nonatomic,strong) IBOutlet UIBarButtonItem *saveButton;
- (void)setLandscapeAction;
@end
